# ScamShield AI

ScamShield AI is a production-oriented full-stack cybersecurity web application for detecting suspicious URLs, scam messages, phishing emails, UPI/QR scams, fake job offers, fake shopping sites, screenshots, phone numbers, and social engineering attempts.

It is built as a progressive solo-developer MVP with a realistic path to enterprise hardening. It does not claim to be unhackable; it uses layered controls aligned with OWASP best practices.

## Stack

- Frontend: Next.js, React, TypeScript, Tailwind CSS, ShadCN-style components, Framer Motion, Recharts
- Backend: Node.js, Express.js, TypeScript
- Database: MongoDB Atlas or local MongoDB
- Auth: JWT access tokens, refresh token rotation, HttpOnly cookies, MFA-ready user model
- AI: Gemini API first, OpenAI fallback, deterministic local fallback
- Security APIs: Google Safe Browsing, VirusTotal, IPQualityScore, HIBP-ready
- OCR: Tesseract.js
- Deployment: Vercel for web, Railway/Render for API

## Monorepo Structure

```text
apps/
  api/    Express API, Mongo models, scan services, auth, moderation
  web/    Next.js app, scanner UI, dashboards, public pages
packages/
  shared/ Shared scan types, risk levels, extraction, and heuristic scoring
services/
  python-scanner/ Python defensive scanner used by the local Next API route
docs/
  API.md
  DEPLOYMENT.md
  SECURITY.md
```

## Quick Start

```bash
npm install
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env.local
npm run dev
```

API: `http://localhost:4000/health`  
Web: `http://localhost:3000`

The local web route `POST /api/scan/:type` runs the Python scanner first and
falls back to TypeScript heuristics if Python is unavailable. Set
`SCAMSHIELD_ENABLE_URL_NETWORK=0` in `apps/web/.env.local` to disable DNS, TLS,
and HTTP HEAD metadata checks during URL scans.

Seed demo data after MongoDB is running:

```bash
npm run seed
```

Default seeded admin:

- Email: `admin@scamshield.local`
- Password: `ChangeThisAdminPassword!2026`

Change it immediately before using outside local development.

## MVP Included

- URL scanner
- Message checker
- Email checker
- UPI checker
- QR payload checker
- Screenshot OCR analyzer
- Phone, job, shopping, and social scam checks
- Security Lab for file triage, link threat checks, DNS, TLS, security headers, passive OSINT, authorized port checks, and limited exposure path checks
- Integration Hub catalog for VirusTotal, urlscan.io, Google Safe Browsing, AbuseIPDB, Shodan, AlienVault OTX, Mozilla HTTP Observatory, SSL Labs, HIBP, MalwareBazaar, WhoisXML, Cloudflare DNS, Google DNS, OWASP ZAP, Nmap, Nuclei, ClamAV, YARA, Trivy, Gitleaks, Semgrep, MobSF, Wazuh, ExifTool, pefile, pdfid, pdf-parser, Wappalyzer, PhishTank, Cisco Talos, IBM X-Force, MXToolbox, Hybrid Analysis, Cuckoo Sandbox, Joe Sandbox, Any.Run, and SecurityHeaders.com
- AI explanation engine with local fallback
- Scam report submission
- Scan history API
- Auth flow with refresh rotation
- Admin moderation and overview APIs
- Scam database and alerts
- Education hub
- Privacy, terms, PWA manifest, and generated hero asset

## Security Notes

- All inputs are validated and sanitized.
- Scan values are hashed for matching; raw scan content is encrypted only when retention is enabled.
- Cookies are HttpOnly, SameSite, and Secure in production.
- CSRF tokens protect state-changing routes.
- Helmet, HSTS, strict CORS, rate limiting, NoSQL sanitization, and centralized errors are enabled.
- File uploads are size and MIME limited before OCR.
- External AI/reputation calls are optional; leave keys blank for local-only demo mode.
- Security Lab blocks private/internal targets by default. Port and exposure path checks require an explicit authorization confirmation in the UI.
- Active/local tools such as OWASP ZAP, Nmap, Nuclei, MobSF, Cuckoo, and CLI file/code scanners are disabled until `SCAMSHIELD_ENABLE_ACTIVE_TOOLS=1` and the matching path/service variables are configured.
- Mutating API routes use same-origin CSRF and trusted Origin/Referer checks. Set `SCAMSHIELD_ALLOWED_ORIGINS` or `NEXT_PUBLIC_WEB_URL` for production custom domains.
- On Vercel, the public attack surface is HTTPS at the edge. Do not expose MongoDB, scanner workers, OWASP ZAP, MobSF, Cuckoo, or local tool daemons to the internet.
- If deploying to a VPS/container later, expose only 80/443 through a reverse proxy and keep database/admin/scanner ports private or IP-allowlisted.
- Runtime posture can be checked at `/api/v1/health` and `/api/v1/security/posture`.

## Scripts

```bash
npm run dev
npm run build
npm run typecheck
npm run lint
npm run seed
```

## Progressive Roadmap

1. MVP: URL/message/screenshot scans, login, reports, scan history
2. Integrations: production Safe Browsing, VirusTotal, IPQualityScore, HIBP, Cloudinary
3. Product: multilingual explanations, alert subscriptions, PDF reports, quizzes
4. Enterprise: browser extension APIs, admin analytics, anomaly detection, WAF dashboards
5. Mobile: React Native or Flutter companion app
