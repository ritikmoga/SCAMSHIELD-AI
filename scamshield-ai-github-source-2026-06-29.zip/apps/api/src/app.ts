import express from "express";
import { AppError } from "./utils/errors.js";
import { applySecurityMiddleware, csrfMiddleware, csrfReadMiddleware, csrfTokenRoute } from "./middleware/security.js";
import { globalRateLimit } from "./middleware/rateLimit.js";
import { ensureGuestCookie } from "./middleware/guest.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { authRouter } from "./routes/auth.routes.js";
import { scanRouter } from "./routes/scan.routes.js";
import { reportRouter } from "./routes/report.routes.js";
import { databaseRouter } from "./routes/database.routes.js";
import { alertsRouter } from "./routes/alerts.routes.js";
import { educationRouter } from "./routes/education.routes.js";
import { adminRouter } from "./routes/admin.routes.js";

export function createApp() {
  const app = express();

  applySecurityMiddleware(app);
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: false, limit: "1mb" }));
  app.use(globalRateLimit);
  app.use(ensureGuestCookie);

  app.get("/health", (_req, res) => {
    res.json({
      ok: true,
      service: "ScamShield AI API",
      timestamp: new Date().toISOString()
    });
  });

  app.get("/api/v1/security/csrf-token", csrfReadMiddleware, csrfTokenRoute);
  app.use("/api/v1/auth", csrfMiddleware, authRouter);
  app.use("/api/v1/scan", csrfMiddleware, scanRouter);
  app.use("/api/v1/reports", csrfMiddleware, reportRouter);
  app.use("/api/v1/database", databaseRouter);
  app.use("/api/v1/alerts", csrfMiddleware, alertsRouter);
  app.use("/api/v1/education", educationRouter);
  app.use("/api/v1/admin", csrfMiddleware, adminRouter);

  app.use((_req, _res, next) => next(new AppError("Route not found", 404, "NOT_FOUND")));
  app.use(errorHandler);

  return app;
}
