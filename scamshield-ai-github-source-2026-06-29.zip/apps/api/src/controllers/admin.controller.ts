import { AuditLog } from "../models/AuditLog.js";
import { Report } from "../models/Report.js";
import { Scan } from "../models/Scan.js";
import { User } from "../models/User.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { hashValue } from "../utils/crypto.js";

export const adminOverview = asyncHandler(async (_req, res) => {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const [users, scans24h, dangerousScans, pendingReports, verifiedReports] = await Promise.all([
    User.countDocuments({ status: "active" }),
    Scan.countDocuments({ createdAt: { $gte: since } }),
    Scan.countDocuments({ riskLevel: "Dangerous", createdAt: { $gte: since } }),
    Report.countDocuments({ status: "pending" }),
    Report.countDocuments({ status: "verified" })
  ]);

  res.json({
    metrics: {
      users,
      scans24h,
      dangerousScans,
      pendingReports,
      verifiedReports
    }
  });
});

export const writeAudit = asyncHandler(async (req, res) => {
  await AuditLog.create({
    actorId: req.user?.id,
    action: "manual_admin_event",
    entityType: "system",
    ipHash: req.ip ? hashValue(req.ip) : undefined,
    userAgent: req.headers["user-agent"],
    metadata: req.body
  });
  res.status(201).json({ ok: true });
});
