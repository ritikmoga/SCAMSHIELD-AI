import { z } from "zod";
import { Alert } from "../models/Alert.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const alertListSchema = z.object({
  query: z.object({
    category: z.string().optional(),
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(50).default(20)
  })
});

export const createAlertSchema = z.object({
  body: z.object({
    title: z.string().min(4).max(180),
    slug: z.string().min(4).max(180).regex(/^[a-z0-9-]+$/),
    category: z.enum(["kyc", "upi", "courier", "job", "investment", "shopping", "phishing", "malware", "romance", "other"]),
    severity: z.enum(["info", "low", "medium", "high", "critical"]).default("medium"),
    summary: z.string().min(10).max(300),
    body: z.string().min(20).max(5000),
    regions: z.array(z.string()).default(["IN"]),
    indicators: z.array(z.string()).default([]),
    recommendedActions: z.array(z.string()).default([]),
    status: z.enum(["draft", "published", "archived"]).default("draft")
  })
});

export const listAlerts = asyncHandler(async (req, res) => {
  const page = Number(req.query.page ?? 1);
  const limit = Number(req.query.limit ?? 20);
  const query: Record<string, unknown> = { status: "published" };
  if (req.query.category) query.category = req.query.category;

  const [items, total] = await Promise.all([
    Alert.find(query).sort({ publishedAt: -1, createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
    Alert.countDocuments(query)
  ]);
  res.json({ items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

export const createAlert = asyncHandler(async (req, res) => {
  const alert = await Alert.create({
    ...req.body,
    createdBy: req.user?.id,
    publishedAt: req.body.status === "published" ? new Date() : undefined
  });
  res.status(201).json({ alert });
});
