import { z } from "zod";
import { User } from "../models/User.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { AppError } from "../utils/errors.js";
import { issueSession, publicUser, registerUser, revokeRefreshToken, rotateRefreshToken, verifyLogin } from "../services/auth.service.js";

export const registerSchema = z.object({
  body: z.object({
    name: z.string().trim().min(1).max(120).optional(),
    email: z.string().email(),
    password: z.string().min(10).max(128)
  })
});

export const loginSchema = z.object({
  body: z.object({
    email: z.string().email(),
    password: z.string().min(1).max(128)
  })
});

export const register = asyncHandler(async (req, res) => {
  const user = await registerUser({
    ...req.body,
    ip: req.ip,
    userAgent: req.headers["user-agent"]
  });
  const { refreshTokenHash: _refreshTokenHash, ...session } = await issueSession(user, res, {
    ip: req.ip,
    userAgent: req.headers["user-agent"]
  });
  res.status(201).json(session);
});

export const login = asyncHandler(async (req, res) => {
  const user = await verifyLogin({
    ...req.body,
    ip: req.ip,
    userAgent: req.headers["user-agent"]
  });
  const { refreshTokenHash: _refreshTokenHash, ...session } = await issueSession(user, res, {
    ip: req.ip,
    userAgent: req.headers["user-agent"]
  });
  res.json(session);
});

export const refresh = asyncHandler(async (req, res) => {
  const refreshToken = req.cookies?.refreshToken;
  if (!refreshToken) throw new AppError("Refresh token required", 401, "REFRESH_REQUIRED");
  const session = await rotateRefreshToken(refreshToken, res, { ip: req.ip, userAgent: req.headers["user-agent"] });
  res.json(session);
});

export const logout = asyncHandler(async (req, res) => {
  await revokeRefreshToken(req.cookies?.refreshToken, res);
  res.status(204).send();
});

export const me = asyncHandler(async (req, res) => {
  if (!req.user) throw new AppError("Authentication required", 401, "AUTH_REQUIRED");
  const user = (await User.findById(req.user.id).lean()) as any;
  if (!user) throw new AppError("User not found", 404, "USER_NOT_FOUND");
  res.json({ user: publicUser(user) });
});

export const passwordReset = asyncHandler(async (_req, res) => {
  res.json({
    message:
      "If an account exists, password reset instructions will be sent. Configure transactional email before enabling production resets."
  });
});
