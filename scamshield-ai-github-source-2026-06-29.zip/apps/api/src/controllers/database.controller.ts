import { z } from "zod";
import { ScamDatabase } from "../models/ScamDatabase.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const databaseSearchSchema = z.object({
  query: z.object({
    q: z.string().max(120).optional(),
    type: z
      .enum(["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"])
      .optional(),
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(50).default(20)
  })
});

export const searchScamDatabase = asyncHandler(async (req, res) => {
  const page = Number(req.query.page ?? 1);
  const limit = Number(req.query.limit ?? 20);
  const query: Record<string, unknown> = { status: "active" };
  if (req.query.type) query.type = req.query.type;
  if (req.query.q) query.$text = { $search: req.query.q };

  const [items, total] = await Promise.all([
    ScamDatabase.find(query)
      .sort(req.query.q ? { score: { $meta: "textScore" } } : { createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .select("-encryptedValue")
      .lean(),
    ScamDatabase.countDocuments(query)
  ]);

  res.json({ items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});
