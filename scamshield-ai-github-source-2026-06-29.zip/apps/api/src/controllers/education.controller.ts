import type { EducationTopic } from "@scamshield/shared";
import { asyncHandler } from "../utils/asyncHandler.js";

const topics: EducationTopic[] = [
  {
    slug: "upi-safety",
    title: "UPI Safety Basics",
    category: "Payments",
    readingMinutes: 5,
    summary: "Understand collect requests, refund traps, QR scams, and why a UPI PIN is only for sending money.",
    checklist: ["Never share UPI PIN", "Verify receiver name", "Reject unknown collect requests", "Use official app support"]
  },
  {
    slug: "fake-kyc-alerts",
    title: "Fake KYC and Bank Alerts",
    category: "Banking",
    readingMinutes: 6,
    summary: "Spot urgency, spoofed sender names, suspicious links, and fake account-blocking messages.",
    checklist: ["Do not click SMS links", "Call official bank number", "Check domain spelling", "Avoid remote access apps"]
  },
  {
    slug: "job-scam-checklist",
    title: "Job Scam Checklist",
    category: "Careers",
    readingMinutes: 4,
    summary: "Identify fake job offers, registration fees, unrealistic salaries, and document harvesting attempts.",
    checklist: ["No payment for interviews", "Verify company domain", "Search recruiter profile", "Avoid Aadhaar/PAN sharing early"]
  },
  {
    slug: "phishing-links",
    title: "Phishing Link Detection",
    category: "Web",
    readingMinutes: 7,
    summary: "Learn how attackers use lookalike domains, shorteners, fake login pages, and urgency.",
    checklist: ["Check HTTPS and domain", "Avoid short links", "Use bookmarks for banking", "Use password manager warnings"]
  }
];

export const listEducationTopics = asyncHandler(async (_req, res) => {
  res.json({ items: topics });
});
