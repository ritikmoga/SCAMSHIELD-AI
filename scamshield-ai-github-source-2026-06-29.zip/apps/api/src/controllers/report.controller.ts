import { z } from "zod";
import { redactSensitive, type ScanType } from "@scamshield/shared";
import { Report } from "../models/Report.js";
import { ScamDatabase } from "../models/ScamDatabase.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { encryptField, hashValue } from "../utils/crypto.js";
import { AppError } from "../utils/errors.js";

const scanTypes = ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"] as const;

export const reportSchema = z.object({
  body: z.object({
    type: z.enum(scanTypes),
    value: z.string().min(2).max(10000),
    description: z.string().min(10).max(2000),
    evidenceUrls: z.array(z.string().url()).max(5).optional()
  })
});

export const listReportsSchema = z.object({
  query: z.object({
    status: z.enum(["pending", "verified", "rejected", "duplicate"]).optional(),
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(50).default(20)
  })
});

export const submitReport = asyncHandler(async (req, res) => {
  const report = await Report.create({
    submittedBy: req.user?.id,
    guestId: req.cookies?.guestId,
    type: req.body.type,
    valueHash: hashValue(req.body.value),
    valuePreview: redactSensitive(req.body.value),
    encryptedValue: req.user ? encryptField(req.body.value) : undefined,
    description: req.body.description,
    evidenceUrls: req.body.evidenceUrls ?? [],
    source: {
      ipHash: req.ip ? hashValue(req.ip) : undefined,
      userAgent: req.headers["user-agent"]
    }
  });

  res.status(201).json({ report });
});

export const listReports = asyncHandler(async (req, res) => {
  const page = Number(req.query.page ?? 1);
  const limit = Number(req.query.limit ?? 20);
  const query = req.query.status ? { status: req.query.status } : {};
  const [items, total] = await Promise.all([
    Report.find(query).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
    Report.countDocuments(query)
  ]);
  res.json({ items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

export const moderateReportSchema = z.object({
  params: z.object({ id: z.string().min(12) }),
  body: z.object({
    status: z.enum(["verified", "rejected", "duplicate"]),
    note: z.string().max(1000).optional()
  })
});

export const moderateReport = asyncHandler(async (req, res) => {
  const report = await Report.findById(req.params.id).select("+encryptedValue").exec();
  if (!report) throw new AppError("Report not found", 404, "REPORT_NOT_FOUND");

  report.status = req.body.status;
  report.moderatorId = req.user?.id;
  report.moderationNote = req.body.note;
  report.verifiedAt = req.body.status === "verified" ? new Date() : undefined;
  await report.save();

  if (req.body.status === "verified") {
    await ScamDatabase.findOneAndUpdate(
      { valueHash: report.valueHash },
      {
        $setOnInsert: {
          type: report.type as ScanType,
          valueHash: report.valueHash,
          valuePreview: report.valuePreview,
          encryptedValue: report.encryptedValue,
          title: `Verified ${report.type} scam`,
          description: report.description,
          tags: [report.type, "user-report"],
          riskLevel: "Dangerous",
          confidence: 88,
          source: { kind: "user_report" },
          status: "active",
          verifiedBy: req.user?.id,
          verifiedAt: new Date()
        },
        $inc: { reportCount: 1 }
      },
      { upsert: true, new: true }
    );
  }

  res.json({ report });
});
