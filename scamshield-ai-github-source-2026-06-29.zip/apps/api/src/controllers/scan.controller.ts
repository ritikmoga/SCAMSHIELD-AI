import { z } from "zod";
import type { ScanType } from "@scamshield/shared";
import { getScanHistory, scanContent, scanScreenshot } from "../services/scan.service.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { AppError } from "../utils/errors.js";

const scanTypes = ["url", "message", "email", "upi", "qr", "phone", "job", "shopping", "social"] as const;

export const scanSchema = z.object({
  body: z.object({
    input: z.string().min(1).max(15000),
    locale: z.enum(["en", "hi"]).optional(),
    retainContent: z.boolean().optional()
  }),
  params: z.object({
    type: z.enum(scanTypes)
  })
});

export const historySchema = z.object({
  query: z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(50).default(12)
  })
});

export const scanGeneric = asyncHandler(async (req, res) => {
  const result = await scanContent(req.params.type as ScanType, req.body.input, {
    userId: req.user?.id,
    guestId: req.cookies?.guestId,
    ip: req.ip,
    userAgent: req.headers["user-agent"],
    locale: req.body.locale,
    retainContent: req.body.retainContent
  });
  res.json({ result });
});

export const scanImage = asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError("Screenshot file is required", 400, "FILE_REQUIRED");
  const result = await scanScreenshot(req.file.buffer, {
    userId: req.user?.id,
    guestId: req.cookies?.guestId,
    ip: req.ip,
    userAgent: req.headers["user-agent"],
    locale: req.body.locale
  });
  res.json({ result });
});

export const history = asyncHandler(async (req, res) => {
  const result = await getScanHistory(
    { userId: req.user?.id },
    Number(req.query.page ?? 1),
    Number(req.query.limit ?? 12)
  );
  res.json(result);
});
