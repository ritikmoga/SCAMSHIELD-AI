import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/env.js";
import type { UserRole } from "../models/User.js";
import { User } from "../models/User.js";
import { AppError } from "../utils/errors.js";

interface AccessTokenPayload {
  sub: string;
  role: UserRole;
  email: string;
}

export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const bearer = req.headers.authorization?.replace(/^Bearer\s+/i, "");
    const token = req.cookies?.accessToken || bearer;

    if (!token) throw new AppError("Authentication required", 401, "AUTH_REQUIRED");

    const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessTokenPayload;
    const user = (await User.findById(payload.sub).select("_id email role status").lean()) as any;

    if (!user || user.status !== "active") {
      throw new AppError("Account is not active", 401, "ACCOUNT_INACTIVE");
    }

    req.user = {
      id: user._id.toString(),
      email: user.email,
      role: user.role
    };
    next();
  } catch (error) {
    next(error instanceof AppError ? error : new AppError("Invalid or expired token", 401, "INVALID_TOKEN"));
  }
}

export async function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const bearer = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  const token = req.cookies?.accessToken || bearer;
  if (!token) return next();

  try {
    const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessTokenPayload;
    const user = (await User.findById(payload.sub).select("_id email role status").lean()) as any;
    if (user && user.status === "active") {
      req.user = {
        id: user._id.toString(),
        email: user.email,
        role: user.role
      };
    }
  } catch {
    // Optional auth should never block guest scanning.
  }

  next();
}

export function requireRole(...roles: UserRole[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(new AppError("Authentication required", 401, "AUTH_REQUIRED"));
    if (!roles.includes(req.user.role)) return next(new AppError("Insufficient permissions", 403, "FORBIDDEN"));
    return next();
  };
}
