import type { ErrorRequestHandler } from "express";
import { env } from "../config/env.js";
import { logger } from "../config/logger.js";
import { AppError, isOperationalError } from "../utils/errors.js";

export const notFoundHandler = new AppError("Route not found", 404, "NOT_FOUND");

export const errorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  const statusCode = isOperationalError(error) ? error.statusCode : error.statusCode || 500;
  const code = isOperationalError(error) ? error.code : error.code || "INTERNAL_ERROR";
  const message =
    statusCode >= 500 && env.NODE_ENV === "production"
      ? "Something went wrong. Please try again later."
      : error.message || "Something went wrong";

  logger.error(
    {
      err: error,
      correlationId: req.correlationId,
      path: req.path,
      method: req.method,
      userId: req.user?.id
    },
    "Request failed"
  );

  res.status(statusCode).json({
    error: {
      code,
      message,
      correlationId: req.correlationId,
      details: env.NODE_ENV === "production" ? undefined : error.details
    }
  });
};
