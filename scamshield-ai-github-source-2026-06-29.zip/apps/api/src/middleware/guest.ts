import crypto from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import { isProduction } from "../config/env.js";

export function ensureGuestCookie(req: Request, res: Response, next: NextFunction) {
  if (!req.cookies?.guestId) {
    res.cookie("guestId", crypto.randomUUID(), {
      httpOnly: true,
      secure: isProduction,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1000
    });
  }
  next();
}
