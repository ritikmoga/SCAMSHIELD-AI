import crypto from "node:crypto";
import compression from "compression";
import cookieParser from "cookie-parser";
import cors from "cors";
import type { Express, NextFunction, Request, Response } from "express";
import mongoSanitize from "express-mongo-sanitize";
import helmet from "helmet";
import hpp from "hpp";
import pinoHttp from "pino-http";
import { env, isProduction } from "../config/env.js";
import { logger } from "../config/logger.js";

const csrfCookieName = "csrfSecret";

export function applySecurityMiddleware(app: Express) {
  app.disable("x-powered-by");
  app.set("trust proxy", 1);

  app.use((req: Request, res: Response, next: NextFunction) => {
    const correlationId = req.headers["x-correlation-id"]?.toString() || crypto.randomUUID();
    req.correlationId = correlationId;
    res.setHeader("X-Correlation-ID", correlationId);
    next();
  });

  app.use(
    pinoHttp({
      logger,
      genReqId: (req) => req.correlationId ?? crypto.randomUUID(),
      customLogLevel: (_req, res, err) => {
        if (err || res.statusCode >= 500) return "error";
        if (res.statusCode >= 400) return "warn";
        return "info";
      }
    })
  );

  app.use(
    helmet({
      crossOriginResourcePolicy: { policy: "same-site" },
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          "default-src": ["'self'"],
          "script-src": ["'self'"],
          "img-src": ["'self'", "data:", "https:"],
          "connect-src": ["'self'", env.WEB_ORIGIN],
          "frame-ancestors": ["'none'"],
          "upgrade-insecure-requests": isProduction ? [] : null
        }
      },
      hsts: isProduction
        ? {
            maxAge: 31536000,
            includeSubDomains: true,
            preload: true
          }
        : false
    })
  );

  app.use(
    cors({
      origin: env.WEB_ORIGIN.split(",").map((origin) => origin.trim()),
      credentials: true,
      allowedHeaders: ["Content-Type", "Authorization", "X-CSRF-Token", "X-Correlation-ID"],
      methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"]
    })
  );
  app.use(compression());
  app.use(cookieParser(env.COOKIE_SECRET));
  app.use(mongoSanitize({ replaceWith: "_" }));
  app.use(hpp());
}

export function csrfTokenRoute(req: Request, res: Response) {
  const secret = ensureCsrfSecret(req, res);
  res.json({ csrfToken: signCsrfToken(secret) });
}

export function csrfMiddleware(req: Request, res: Response, next: NextFunction) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  if (req.path.includes("/webhooks/")) return next();

  const secret = req.signedCookies?.[csrfCookieName];
  const token = req.headers["x-csrf-token"]?.toString();

  if (!secret || !token || !safeEqual(token, signCsrfToken(secret))) {
    res.status(403).json({
      error: {
        code: "CSRF_INVALID",
        message: "Invalid or missing CSRF token"
      }
    });
    return;
  }

  next();
}

export function csrfReadMiddleware(req: Request, res: Response, next: NextFunction) {
  ensureCsrfSecret(req, res);
  next();
}

function ensureCsrfSecret(req: Request, res: Response) {
  const existing = req.signedCookies?.[csrfCookieName];
  if (existing) return existing;

  const secret = crypto.randomBytes(32).toString("base64url");
  res.cookie(csrfCookieName, secret, {
    httpOnly: true,
    signed: true,
    sameSite: "lax",
    secure: isProduction,
    maxAge: 2 * 60 * 60 * 1000
  });
  return secret;
}

function signCsrfToken(secret: string) {
  return crypto.createHmac("sha256", env.COOKIE_SECRET).update(secret).digest("base64url");
}

function safeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer);
}
