import multer from "multer";
import { AppError } from "../utils/errors.js";

const allowedMimeTypes = new Set(["image/png", "image/jpeg", "image/webp"]);

export const screenshotUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024,
    files: 1
  },
  fileFilter: (_req, file, cb) => {
    if (!allowedMimeTypes.has(file.mimetype)) {
      cb(new AppError("Only PNG, JPG, and WebP images are allowed", 400, "INVALID_FILE_TYPE"));
      return;
    }
    cb(null, true);
  }
});
