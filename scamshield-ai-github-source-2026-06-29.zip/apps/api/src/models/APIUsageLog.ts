import mongoose, { Schema, type InferSchemaType } from "mongoose";

const apiUsageLogSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
    guestId: { type: String, index: true },
    endpoint: { type: String, required: true, index: true },
    method: { type: String, required: true },
    statusCode: Number,
    latencyMs: Number,
    ipHash: String,
    userAgent: String,
    riskEvent: {
      type: String,
      enum: ["none", "rate_limit", "failed_auth", "suspicious_scan", "admin_action"],
      default: "none",
      index: true
    },
    metadata: Schema.Types.Mixed
  },
  { timestamps: true }
);

apiUsageLogSchema.index({ createdAt: -1 });

export type APIUsageLogDocument = mongoose.HydratedDocument<InferSchemaType<typeof apiUsageLogSchema>>;
export const APIUsageLog = (mongoose.models.APIUsageLog || mongoose.model("APIUsageLog", apiUsageLogSchema)) as mongoose.Model<any>;
