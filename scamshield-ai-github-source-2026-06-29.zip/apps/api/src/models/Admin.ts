import mongoose, { Schema, type InferSchemaType } from "mongoose";

const adminSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true, unique: true, index: true },
    role: { type: String, enum: ["moderator", "super_admin"], required: true },
    permissions: [String],
    invitedBy: { type: Schema.Types.ObjectId, ref: "User" },
    lastActionAt: Date,
    status: { type: String, enum: ["active", "suspended"], default: "active", index: true }
  },
  { timestamps: true }
);

export type AdminDocument = mongoose.HydratedDocument<InferSchemaType<typeof adminSchema>>;
export const Admin = (mongoose.models.Admin || mongoose.model("Admin", adminSchema)) as mongoose.Model<any>;
