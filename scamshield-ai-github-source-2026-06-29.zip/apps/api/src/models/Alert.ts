import mongoose, { Schema, type InferSchemaType } from "mongoose";

const alertSchema = new Schema(
  {
    title: { type: String, required: true, maxlength: 180 },
    slug: { type: String, required: true, unique: true, index: true },
    category: {
      type: String,
      enum: ["kyc", "upi", "courier", "job", "investment", "shopping", "phishing", "malware", "romance", "other"],
      required: true,
      index: true
    },
    severity: {
      type: String,
      enum: ["info", "low", "medium", "high", "critical"],
      default: "medium",
      index: true
    },
    summary: { type: String, required: true, maxlength: 300 },
    body: { type: String, required: true, maxlength: 5000 },
    regions: [{ type: String, default: "IN" }],
    indicators: [String],
    recommendedActions: [String],
    status: {
      type: String,
      enum: ["draft", "published", "archived"],
      default: "draft",
      index: true
    },
    publishedAt: Date,
    createdBy: { type: Schema.Types.ObjectId, ref: "User" }
  },
  { timestamps: true }
);

alertSchema.index({ status: 1, severity: 1, publishedAt: -1 });

export type AlertDocument = mongoose.HydratedDocument<InferSchemaType<typeof alertSchema>>;
export const Alert = (mongoose.models.Alert || mongoose.model("Alert", alertSchema)) as mongoose.Model<any>;
