import mongoose, { Schema, type InferSchemaType } from "mongoose";

const auditLogSchema = new Schema(
  {
    actorId: { type: Schema.Types.ObjectId, ref: "User", index: true },
    action: { type: String, required: true, index: true },
    entityType: { type: String, required: true, index: true },
    entityId: { type: String, index: true },
    ipHash: String,
    userAgent: String,
    metadata: Schema.Types.Mixed
  },
  { timestamps: true }
);

auditLogSchema.index({ createdAt: -1 });

export type AuditLogDocument = mongoose.HydratedDocument<InferSchemaType<typeof auditLogSchema>>;
export const AuditLog = (mongoose.models.AuditLog || mongoose.model("AuditLog", auditLogSchema)) as mongoose.Model<any>;
