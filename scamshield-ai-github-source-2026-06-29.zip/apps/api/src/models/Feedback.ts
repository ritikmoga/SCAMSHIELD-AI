import mongoose, { Schema, type InferSchemaType } from "mongoose";

const feedbackSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
    scanId: { type: Schema.Types.ObjectId, ref: "Scan", index: true },
    rating: { type: Number, min: 1, max: 5, required: true },
    wasHelpful: { type: Boolean, required: true },
    comment: { type: String, maxlength: 1200 },
    labels: [String],
    reviewedBy: { type: Schema.Types.ObjectId, ref: "User" },
    reviewedAt: Date
  },
  { timestamps: true }
);

feedbackSchema.index({ createdAt: -1 });

export type FeedbackDocument = mongoose.HydratedDocument<InferSchemaType<typeof feedbackSchema>>;
export const Feedback = (mongoose.models.Feedback || mongoose.model("Feedback", feedbackSchema)) as mongoose.Model<any>;
