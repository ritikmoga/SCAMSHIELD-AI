import mongoose, { Schema, type InferSchemaType } from "mongoose";

const notificationSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
    type: {
      type: String,
      enum: ["scan_result", "alert", "report_status", "security", "system"],
      required: true,
      index: true
    },
    title: { type: String, required: true, maxlength: 160 },
    body: { type: String, required: true, maxlength: 1000 },
    readAt: Date,
    metadata: Schema.Types.Mixed
  },
  { timestamps: true }
);

notificationSchema.index({ userId: 1, readAt: 1, createdAt: -1 });

export type NotificationDocument = mongoose.HydratedDocument<InferSchemaType<typeof notificationSchema>>;
export const Notification = (mongoose.models.Notification || mongoose.model("Notification", notificationSchema)) as mongoose.Model<any>;
