import mongoose, { Schema, type InferSchemaType } from "mongoose";

const reportSchema = new Schema(
  {
    submittedBy: { type: Schema.Types.ObjectId, ref: "User", index: true },
    guestId: { type: String, index: true },
    type: {
      type: String,
      enum: ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"],
      required: true,
      index: true
    },
    valueHash: { type: String, required: true, index: true },
    valuePreview: { type: String, required: true },
    encryptedValue: { type: String, select: false },
    description: { type: String, required: true, maxlength: 2000 },
    evidenceUrls: [{ type: String, maxlength: 500 }],
    status: {
      type: String,
      enum: ["pending", "verified", "rejected", "duplicate"],
      default: "pending",
      index: true
    },
    moderatorId: { type: Schema.Types.ObjectId, ref: "User" },
    moderationNote: String,
    verifiedAt: Date,
    source: {
      ipHash: String,
      userAgent: String
    }
  },
  { timestamps: true }
);

reportSchema.index({ status: 1, createdAt: -1 });

export type ReportDocument = mongoose.HydratedDocument<InferSchemaType<typeof reportSchema>>;
export const Report = (mongoose.models.Report || mongoose.model("Report", reportSchema)) as mongoose.Model<any>;
