import mongoose, { Schema, type InferSchemaType } from "mongoose";

const scamDatabaseSchema = new Schema(
  {
    type: {
      type: String,
      enum: ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"],
      required: true,
      index: true
    },
    valueHash: { type: String, required: true, unique: true, index: true },
    valuePreview: { type: String, required: true },
    encryptedValue: { type: String, select: false },
    title: { type: String, required: true, maxlength: 180 },
    description: { type: String, required: true, maxlength: 3000 },
    tags: [{ type: String, index: true }],
    riskLevel: {
      type: String,
      enum: ["Safe", "Low Risk", "Suspicious", "High Risk", "Dangerous"],
      default: "Dangerous",
      index: true
    },
    confidence: { type: Number, min: 0, max: 100, default: 85 },
    source: {
      kind: { type: String, enum: ["manual", "user_report", "api", "research"], default: "manual" },
      referenceUrl: String
    },
    status: {
      type: String,
      enum: ["active", "under_review", "removed"],
      default: "active",
      index: true
    },
    verifiedBy: { type: Schema.Types.ObjectId, ref: "User" },
    verifiedAt: Date,
    reportCount: { type: Number, default: 0 }
  },
  { timestamps: true }
);

scamDatabaseSchema.index({ title: "text", description: "text", tags: "text", valuePreview: "text" });

export type ScamDatabaseDocument = mongoose.HydratedDocument<InferSchemaType<typeof scamDatabaseSchema>>;
export const ScamDatabase = (mongoose.models.ScamDatabase || mongoose.model("ScamDatabase", scamDatabaseSchema)) as mongoose.Model<any>;
