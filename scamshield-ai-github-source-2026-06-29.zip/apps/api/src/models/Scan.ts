import mongoose, { Schema, type InferSchemaType } from "mongoose";
import type { RiskLevel, ScanType } from "@scamshield/shared";

const signalSchema = new Schema(
  {
    id: String,
    label: String,
    category: String,
    severity: String,
    weight: Number,
    evidence: String
  },
  { _id: false }
);

const scanSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
    guestId: { type: String, index: true },
    type: {
      type: String,
      enum: ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"],
      required: true,
      index: true
    },
    inputHash: { type: String, required: true, index: true },
    inputPreview: { type: String, required: true },
    encryptedInput: { type: String, select: false },
    riskScore: { type: Number, required: true, min: 0, max: 100, index: true },
    riskLevel: {
      type: String,
      enum: ["Safe", "Low Risk", "Suspicious", "High Risk", "Dangerous"],
      required: true,
      index: true
    },
    confidence: { type: Number, required: true },
    explanation: String,
    recommendedAction: String,
    signals: [signalSchema],
    breakdown: {
      ai: Number,
      reputation: Number,
      heuristics: Number,
      userReports: Number,
      technical: Number
    },
    extracted: {
      urls: [String],
      phoneNumbers: [String],
      upiIds: [String],
      emails: [String],
      decodedQr: String,
      ocrText: { type: String, select: false }
    },
    dataRetentionDays: { type: Number, default: 30 },
    source: {
      ipHash: String,
      userAgent: String
    }
  },
  { timestamps: true }
);

scanSchema.index({ createdAt: -1 });
scanSchema.index({ type: 1, riskLevel: 1, createdAt: -1 });

export type ScanDocument = mongoose.HydratedDocument<InferSchemaType<typeof scanSchema> & {
  type: ScanType;
  riskLevel: RiskLevel;
}>;

export const Scan = (mongoose.models.Scan || mongoose.model("Scan", scanSchema)) as mongoose.Model<any>;
