import mongoose, { Schema, type InferSchemaType } from "mongoose";

export type UserRole = "guest" | "user" | "moderator" | "super_admin";

const loginEventSchema = new Schema(
  {
    at: { type: Date, default: Date.now },
    ip: String,
    userAgent: String,
    success: { type: Boolean, default: true },
    reason: String
  },
  { _id: false }
);

const userSchema = new Schema(
  {
    name: { type: String, trim: true, maxlength: 120 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
    passwordHash: { type: String, select: false },
    avatarUrl: String,
    role: {
      type: String,
      enum: ["guest", "user", "moderator", "super_admin"],
      default: "user",
      index: true
    },
    provider: {
      type: String,
      enum: ["local", "google", "firebase"],
      default: "local"
    },
    firebaseUid: { type: String, sparse: true, index: true },
    mfa: {
      enabled: { type: Boolean, default: false },
      secretEncrypted: { type: String, select: false },
      recoveryCodesHash: [{ type: String, select: false }]
    },
    refreshTokenFamily: [
      {
        tokenHash: { type: String, select: false },
        createdAt: { type: Date, default: Date.now },
        expiresAt: Date,
        revokedAt: Date,
        replacedByHash: { type: String, select: false },
        ip: String,
        userAgent: String
      }
    ],
    status: {
      type: String,
      enum: ["active", "locked", "suspended", "deleted"],
      default: "active",
      index: true
    },
    failedLoginCount: { type: Number, default: 0 },
    lockedUntil: Date,
    privacy: {
      retainScanContent: { type: Boolean, default: false },
      allowSecurityResearch: { type: Boolean, default: true },
      locale: { type: String, enum: ["en", "hi"], default: "en" }
    },
    usage: {
      scansToday: { type: Number, default: 0 },
      lastScanAt: Date,
      lastUsageResetAt: { type: Date, default: Date.now }
    },
    loginHistory: [loginEventSchema]
  },
  {
    timestamps: true
  }
);

userSchema.index({ "usage.lastScanAt": -1 });

export type UserDocument = mongoose.HydratedDocument<InferSchemaType<typeof userSchema>>;
export const User = (mongoose.models.User || mongoose.model("User", userSchema)) as mongoose.Model<any>;
