import { Router } from "express";
import { adminOverview, writeAudit } from "../controllers/admin.controller.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

export const adminRouter = Router();

adminRouter.use(requireAuth, requireRole("moderator", "super_admin"));
adminRouter.get("/overview", adminOverview);
adminRouter.post("/audit", writeAudit);
