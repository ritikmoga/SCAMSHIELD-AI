import { Router } from "express";
import { createAlert, createAlertSchema, alertListSchema, listAlerts } from "../controllers/alerts.controller.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";

export const alertsRouter = Router();

alertsRouter.get("/", validate(alertListSchema), listAlerts);
alertsRouter.post("/", requireAuth, requireRole("moderator", "super_admin"), validate(createAlertSchema), createAlert);
