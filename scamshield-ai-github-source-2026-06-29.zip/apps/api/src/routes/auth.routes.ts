import { Router } from "express";
import { login, loginSchema, logout, me, passwordReset, refresh, register, registerSchema } from "../controllers/auth.controller.js";
import { requireAuth } from "../middleware/auth.js";
import { authRateLimit } from "../middleware/rateLimit.js";
import { validate } from "../middleware/validate.js";

export const authRouter = Router();

authRouter.post("/register", authRateLimit, validate(registerSchema), register);
authRouter.post("/login", authRateLimit, validate(loginSchema), login);
authRouter.post("/refresh", refresh);
authRouter.post("/logout", logout);
authRouter.post("/password-reset", authRateLimit, passwordReset);
authRouter.get("/me", requireAuth, me);
