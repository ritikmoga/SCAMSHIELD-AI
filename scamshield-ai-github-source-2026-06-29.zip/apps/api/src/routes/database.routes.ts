import { Router } from "express";
import { databaseSearchSchema, searchScamDatabase } from "../controllers/database.controller.js";
import { validate } from "../middleware/validate.js";

export const databaseRouter = Router();

databaseRouter.get("/", validate(databaseSearchSchema), searchScamDatabase);
