import { Router } from "express";
import { listEducationTopics } from "../controllers/education.controller.js";

export const educationRouter = Router();

educationRouter.get("/", listEducationTopics);
