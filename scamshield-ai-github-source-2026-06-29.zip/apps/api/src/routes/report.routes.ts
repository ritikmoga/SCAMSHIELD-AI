import { Router } from "express";
import { listReports, listReportsSchema, moderateReport, moderateReportSchema, reportSchema, submitReport } from "../controllers/report.controller.js";
import { optionalAuth, requireAuth, requireRole } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";

export const reportRouter = Router();

reportRouter.post("/", optionalAuth, validate(reportSchema), submitReport);
reportRouter.get("/", requireAuth, requireRole("moderator", "super_admin"), validate(listReportsSchema), listReports);
reportRouter.patch("/:id/moderate", requireAuth, requireRole("moderator", "super_admin"), validate(moderateReportSchema), moderateReport);
