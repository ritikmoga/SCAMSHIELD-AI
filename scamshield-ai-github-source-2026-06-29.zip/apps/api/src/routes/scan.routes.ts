import { Router } from "express";
import { history, historySchema, scanGeneric, scanImage, scanSchema } from "../controllers/scan.controller.js";
import { optionalAuth, requireAuth } from "../middleware/auth.js";
import { scanRateLimit } from "../middleware/rateLimit.js";
import { screenshotUpload } from "../middleware/upload.js";
import { validate } from "../middleware/validate.js";

export const scanRouter = Router();

scanRouter.post("/:type", optionalAuth, scanRateLimit, validate(scanSchema), scanGeneric);
scanRouter.post("/screenshot/image", optionalAuth, scanRateLimit, screenshotUpload.single("screenshot"), scanImage);
scanRouter.get("/history/me", requireAuth, validate(historySchema), history);
