import argon2 from "argon2";
import { connectDatabase, disconnectDatabase } from "./config/database.js";
import { logger } from "./config/logger.js";
import { Alert } from "./models/Alert.js";
import { ScamDatabase } from "./models/ScamDatabase.js";
import { User } from "./models/User.js";
import { hashValue } from "./utils/crypto.js";

async function seed() {
  await connectDatabase();

  const adminPasswordHash = await argon2.hash("ChangeThisAdminPassword!2026", {
    type: argon2.argon2id,
    memoryCost: 19456,
    timeCost: 2,
    parallelism: 1
  });

  const admin = await User.findOneAndUpdate(
    { email: "admin@scamshield.local" },
    {
      $setOnInsert: {
        name: "ScamShield Admin",
        email: "admin@scamshield.local",
        passwordHash: adminPasswordHash,
        role: "super_admin",
        provider: "local",
        status: "active"
      }
    },
    { upsert: true, new: true }
  );

  await ScamDatabase.bulkWrite(
    [
      {
        type: "url",
        value: "https://sbi-kyc-secure-login.example.com",
        title: "Fake SBI KYC phishing domain",
        description: "Lookalike KYC portal using urgency language to harvest banking credentials.",
        tags: ["banking", "kyc", "phishing", "india"]
      },
      {
        type: "upi",
        value: "refund-helpdesk@oksbi",
        title: "Fake refund UPI collect handle",
        description: "UPI handle used in refund collect-request scams that pressure victims to enter PIN.",
        tags: ["upi", "refund", "collect-request"]
      },
      {
        type: "phone",
        value: "+919876543210",
        title: "Impersonated customer-care number",
        description: "Reported as a fake customer support line asking users to install remote access apps.",
        tags: ["phone", "customer-care", "remote-access"]
      },
      {
        type: "message",
        value: "Your KYC expires today. Click link and share OTP to avoid account block.",
        title: "Fake KYC SMS template",
        description: "Common template combining urgency, OTP request, and fake account blocking.",
        tags: ["sms", "kyc", "otp"]
      }
    ].map((item) => ({
      updateOne: {
        filter: { valueHash: hashValue(item.value) },
        update: {
          $setOnInsert: {
            type: item.type,
            valueHash: hashValue(item.value),
            valuePreview: item.value,
            title: item.title,
            description: item.description,
            tags: item.tags,
            riskLevel: "Dangerous",
            confidence: 92,
            source: { kind: "research" },
            status: "active",
            verifiedBy: admin._id,
            verifiedAt: new Date()
          }
        },
        upsert: true
      }
    }))
  );

  await Alert.bulkWrite(
    [
      {
        title: "Fake KYC Expiry Messages Surge",
        slug: "fake-kyc-expiry-messages",
        category: "kyc",
        severity: "high",
        summary: "Scammers are sending fake bank KYC expiry alerts that ask users to click links and share OTPs.",
        body:
          "Verify KYC only through the official banking app, website, or branch. Banks do not ask for OTPs, passwords, UPI PINs, or remote access apps to complete KYC.",
        indicators: ["account will be blocked", "share OTP", "urgent KYC update"],
        recommendedActions: ["Do not click SMS links", "Call the official bank number", "Report the sender"],
        status: "published"
      },
      {
        title: "Courier Address Confirmation Scam",
        slug: "courier-address-confirmation-scam",
        category: "courier",
        severity: "medium",
        summary: "Fake delivery messages ask users to pay a small fee or update address through suspicious links.",
        body:
          "Attackers use low-value delivery fees to steal card details. Open courier tracking only from official apps or typed URLs.",
        indicators: ["delivery failed", "pay 2 rupees", "address incomplete"],
        recommendedActions: ["Avoid short links", "Do not enter card details", "Verify tracking ID directly"],
        status: "published"
      }
    ].map((alert) => ({
      updateOne: {
        filter: { slug: alert.slug },
        update: {
          $setOnInsert: {
            ...alert,
            publishedAt: new Date(),
            createdBy: admin._id
          }
        },
        upsert: true
      }
    }))
  );

  logger.info("Seed data created");
  await disconnectDatabase();
}

seed().catch(async (error) => {
  logger.error({ err: error }, "Seed failed");
  await disconnectDatabase();
  process.exit(1);
});
