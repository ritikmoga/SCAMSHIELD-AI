import { GoogleGenerativeAI } from "@google/generative-ai";
import { defaultAction, defaultExplanation, type DetectionSignal, type RiskLevel, type ScanType } from "@scamshield/shared";
import { env } from "../config/env.js";
import { logger } from "../config/logger.js";

interface AIExplanationInput {
  type: ScanType;
  inputPreview: string;
  riskLevel: RiskLevel;
  riskScore: number;
  signals: DetectionSignal[];
  locale?: "en" | "hi";
}

interface AIExplanationOutput {
  aiScore?: number;
  explanation: string;
  recommendedAction: string;
}

export async function generateAIExplanation(params: AIExplanationInput): Promise<AIExplanationOutput> {
  const prompt = buildPrompt(params);

  if (env.GEMINI_API_KEY) {
    try {
      const genAI = new GoogleGenerativeAI(env.GEMINI_API_KEY);
      const model = genAI.getGenerativeModel({ model: env.GEMINI_MODEL });
      const result = await model.generateContent(prompt);
      return parseAIResponse(result.response.text(), params);
    } catch (error) {
      logger.warn({ err: error }, "Gemini explanation failed");
    }
  }

  if (env.OPENAI_API_KEY) {
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${env.OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: env.OPENAI_MODEL,
          temperature: 0.2,
          response_format: { type: "json_object" },
          messages: [
            {
              role: "system",
              content:
                "You are ScamShield AI, a defensive cybersecurity assistant. Explain scam risk in simple language. Never request secrets, never help bypass security, and never tell users a system is unhackable."
            },
            { role: "user", content: prompt }
          ]
        })
      });
      const body = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
      return parseAIResponse(body.choices?.[0]?.message?.content ?? "", params);
    } catch (error) {
      logger.warn({ err: error }, "OpenAI explanation failed");
    }
  }

  return {
    explanation: defaultExplanation(params.riskLevel, params.signals),
    recommendedAction: defaultAction(params.riskLevel)
  };
}

function buildPrompt(params: AIExplanationInput) {
  const language = params.locale === "hi" ? "Hindi with simple English security terms" : "plain English";
  return JSON.stringify({
    instruction:
      "Return compact JSON with keys aiScore, explanation, recommendedAction. Keep it defensive and beginner-friendly. Do not ask for OTP, UPI PIN, passwords, CVV, or private documents.",
    language,
    scanType: params.type,
    riskLevel: params.riskLevel,
    riskScore: params.riskScore,
    inputPreview: params.inputPreview,
    signals: params.signals.map((signal) => ({
      label: signal.label,
      severity: signal.severity,
      category: signal.category,
      evidence: signal.evidence
    }))
  });
}

function parseAIResponse(text: string, fallback: AIExplanationInput): AIExplanationOutput {
  try {
    const cleaned = text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
    const parsed = JSON.parse(cleaned) as Partial<AIExplanationOutput>;
    return {
      aiScore: typeof parsed.aiScore === "number" ? parsed.aiScore : undefined,
      explanation: parsed.explanation || defaultExplanation(fallback.riskLevel, fallback.signals),
      recommendedAction: parsed.recommendedAction || defaultAction(fallback.riskLevel)
    };
  } catch {
    return {
      explanation: defaultExplanation(fallback.riskLevel, fallback.signals),
      recommendedAction: defaultAction(fallback.riskLevel)
    };
  }
}
