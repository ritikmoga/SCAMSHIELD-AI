import argon2 from "argon2";
import jwt from "jsonwebtoken";
import type { Response } from "express";
import { env, isProduction } from "../config/env.js";
import { User, type UserDocument } from "../models/User.js";
import { hashValue } from "../utils/crypto.js";
import { AppError } from "../utils/errors.js";

const accessCookieOptions = {
  httpOnly: true,
  secure: isProduction,
  sameSite: "lax" as const,
  maxAge: 15 * 60 * 1000
};

const refreshCookieOptions = {
  httpOnly: true,
  secure: isProduction,
  sameSite: "lax" as const,
  maxAge: 7 * 24 * 60 * 60 * 1000
};

export async function registerUser(params: { name?: string; email: string; password: string; ip?: string; userAgent?: string }) {
  const existing = await User.findOne({ email: params.email.toLowerCase() }).lean();
  if (existing) throw new AppError("An account with this email already exists", 409, "EMAIL_EXISTS");

  const passwordHash = await argon2.hash(params.password, {
    type: argon2.argon2id,
    memoryCost: 19456,
    timeCost: 2,
    parallelism: 1
  });

  const user = await User.create({
    name: params.name,
    email: params.email,
    passwordHash,
    provider: "local",
    loginHistory: [{ ip: params.ip, userAgent: params.userAgent, success: true }]
  });

  return user;
}

export async function verifyLogin(params: { email: string; password: string; ip?: string; userAgent?: string }) {
  const user = await User.findOne({ email: params.email.toLowerCase() }).select("+passwordHash").exec();
  if (!user || !user.passwordHash) throw new AppError("Invalid email or password", 401, "INVALID_CREDENTIALS");

  if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
    throw new AppError("Account temporarily locked due to failed attempts", 423, "ACCOUNT_LOCKED");
  }

  const valid = await argon2.verify(user.passwordHash, params.password);
  if (!valid) {
    user.failedLoginCount += 1;
    user.loginHistory.push({ ip: params.ip, userAgent: params.userAgent, success: false, reason: "invalid_password" });
    if (user.failedLoginCount >= 6) {
      user.lockedUntil = new Date(Date.now() + 15 * 60 * 1000);
      user.status = "locked";
    }
    await user.save();
    throw new AppError("Invalid email or password", 401, "INVALID_CREDENTIALS");
  }

  user.failedLoginCount = 0;
  user.lockedUntil = undefined;
  user.status = "active";
  user.loginHistory.push({ ip: params.ip, userAgent: params.userAgent, success: true });
  await user.save();
  return user;
}

export async function issueSession(user: UserDocument, res: Response, context: { ip?: string; userAgent?: string } = {}) {
  const accessToken = jwt.sign({ sub: user._id.toString(), email: user.email, role: user.role }, env.JWT_ACCESS_SECRET, {
    expiresIn: "15m"
  });
  const refreshToken = jwt.sign({ sub: user._id.toString(), family: cryptoRandomId() }, env.JWT_REFRESH_SECRET, {
    expiresIn: "7d"
  });
  const refreshHash = hashValue(refreshToken);

  user.refreshTokenFamily.push({
    tokenHash: refreshHash,
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    ip: context.ip,
    userAgent: context.userAgent
  });
  await user.save();

  setAuthCookies(res, accessToken, refreshToken);
  return {
    accessToken,
    refreshTokenHash: refreshHash,
    user: publicUser(user)
  };
}

export async function rotateRefreshToken(refreshToken: string, res: Response, context: { ip?: string; userAgent?: string } = {}) {
  let payload: { sub: string };
  try {
    payload = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as { sub: string };
  } catch {
    throw new AppError("Invalid refresh token", 401, "INVALID_REFRESH_TOKEN");
  }

  const user = await User.findById(payload.sub).select("+refreshTokenFamily.tokenHash").exec();
  if (!user || user.status !== "active") throw new AppError("Invalid refresh token", 401, "INVALID_REFRESH_TOKEN");

  const oldHash = hashValue(refreshToken);
  const tokenRecord = user.refreshTokenFamily.find((item: any) => item.tokenHash === oldHash);
  if (!tokenRecord || tokenRecord.revokedAt || (tokenRecord.expiresAt && tokenRecord.expiresAt.getTime() < Date.now())) {
    user.refreshTokenFamily.forEach((item: any) => {
      item.revokedAt = item.revokedAt ?? new Date();
    });
    await user.save();
    clearAuthCookies(res);
    throw new AppError("Refresh token reuse detected. Sessions were revoked.", 401, "REFRESH_REUSE_DETECTED");
  }

  tokenRecord.revokedAt = new Date();
  const session = await issueSession(user, res, context);
  tokenRecord.replacedByHash = session.refreshTokenHash;
  await user.save();
  return {
    accessToken: session.accessToken,
    user: session.user
  };
}

export async function revokeRefreshToken(refreshToken: string | undefined, res: Response) {
  if (refreshToken) {
    try {
      const payload = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as { sub: string };
      const user = await User.findById(payload.sub).select("+refreshTokenFamily.tokenHash").exec();
      const tokenRecord = user?.refreshTokenFamily.find((item: any) => item.tokenHash === hashValue(refreshToken));
      if (tokenRecord) {
        tokenRecord.revokedAt = new Date();
        await user?.save();
      }
    } catch {
      // Ignore invalid logout token.
    }
  }
  clearAuthCookies(res);
}

export function publicUser(user: any) {
  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    role: user.role,
    avatarUrl: user.avatarUrl,
    mfaEnabled: user.mfa?.enabled ?? false,
    privacy: user.privacy
  };
}

function setAuthCookies(res: Response, accessToken: string, refreshToken: string) {
  res.cookie("accessToken", accessToken, accessCookieOptions);
  res.cookie("refreshToken", refreshToken, refreshCookieOptions);
}

function clearAuthCookies(res: Response) {
  res.clearCookie("accessToken", accessCookieOptions);
  res.clearCookie("refreshToken", refreshCookieOptions);
}

function cryptoRandomId() {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
}
