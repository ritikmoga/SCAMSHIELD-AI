import { createWorker } from "tesseract.js";
import { logger } from "../config/logger.js";

export async function extractTextFromImage(buffer: Buffer) {
  const worker = await createWorker("eng");
  try {
    const result = await worker.recognize(buffer);
    return result.data.text.trim();
  } catch (error) {
    logger.warn({ err: error }, "OCR extraction failed");
    return "";
  } finally {
    await worker.terminate();
  }
}
