import NodeCache from "node-cache";
import {
  analyzeUrlHeuristics,
  extractIndicators,
  normalizeUrl,
  signal,
  type DetectionSignal,
  type ScanType
} from "@scamshield/shared";
import { env } from "../config/env.js";
import { logger } from "../config/logger.js";
import { ScamDatabase } from "../models/ScamDatabase.js";
import { hashValue } from "../utils/crypto.js";

const cache = new NodeCache({ stdTTL: 60 * 10, checkperiod: 120 });

interface ReputationResult {
  score: number;
  signals: DetectionSignal[];
}

export async function checkReputation(type: ScanType, input: string): Promise<ReputationResult> {
  const cacheKey = `${type}:${hashValue(input)}`;
  const cached = cache.get<ReputationResult>(cacheKey);
  if (cached) return cached;

  const signals: DetectionSignal[] = [];
  let score = 0;

  const databaseHits = await findInternalDatabaseHits(type, input);
  if (databaseHits > 0) {
    score += Math.min(45, databaseHits * 22);
    signals.push(signal("internal-scam-db", "Matched ScamShield verified scam database", "reputation", "critical", 30));
  }

  if (type === "url" || extractIndicators(input).urls.length > 0) {
    const url = extractIndicators(input).urls[0] ?? input;
    const urlSignals = analyzeUrlHeuristics(url);
    signals.push(...urlSignals);
    const externalUrlScore = await checkUrlReputation(url);
    score += externalUrlScore.score;
    signals.push(...externalUrlScore.signals);
  }

  if (type === "phone") {
    const phoneScore = await checkPhoneReputation(input);
    score += phoneScore.score;
    signals.push(...phoneScore.signals);
  }

  const result = { score: Math.min(100, score), signals };
  cache.set(cacheKey, result);
  return result;
}

async function findInternalDatabaseHits(type: ScanType, input: string) {
  const indicators = extractIndicators(input);
  const hashes = [
    hashValue(input),
    ...indicators.urls.map(hashValue),
    ...indicators.phoneNumbers.map(hashValue),
    ...indicators.upiIds.map(hashValue),
    ...indicators.emails.map(hashValue)
  ];

  return ScamDatabase.countDocuments({
    status: "active",
    $or: [{ valueHash: { $in: hashes } }, { type, valueHash: hashValue(input) }]
  });
}

async function checkUrlReputation(rawUrl: string): Promise<ReputationResult> {
  const signals: DetectionSignal[] = [];
  let score = 0;
  const normalized = normalizeUrl(rawUrl);

  if (env.GOOGLE_SAFE_BROWSING_API_KEY) {
    try {
      const response = await fetch(
        `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${env.GOOGLE_SAFE_BROWSING_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            client: { clientId: "scamshield-ai", clientVersion: "1.0.0" },
            threatInfo: {
              threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
              platformTypes: ["ANY_PLATFORM"],
              threatEntryTypes: ["URL"],
              threatEntries: [{ url: normalized }]
            }
          })
        }
      );
      const body = (await response.json()) as { matches?: unknown[] };
      if (body.matches?.length) {
        score += 50;
        signals.push(signal("google-safe-browsing", "Google Safe Browsing reported a threat", "reputation", "critical", 32));
      }
    } catch (error) {
      logger.warn({ err: error }, "Google Safe Browsing lookup failed");
    }
  }

  if (env.VIRUSTOTAL_API_KEY) {
    try {
      const encoded = Buffer.from(normalized).toString("base64url");
      const response = await fetch(`https://www.virustotal.com/api/v3/urls/${encoded}`, {
        headers: { "x-apikey": env.VIRUSTOTAL_API_KEY }
      });
      if (response.ok) {
        const body = (await response.json()) as {
          data?: { attributes?: { last_analysis_stats?: { malicious?: number; suspicious?: number } } };
        };
        const malicious = body.data?.attributes?.last_analysis_stats?.malicious ?? 0;
        const suspicious = body.data?.attributes?.last_analysis_stats?.suspicious ?? 0;
        if (malicious + suspicious > 0) {
          score += Math.min(45, malicious * 12 + suspicious * 7);
          signals.push(signal("virustotal-detection", "VirusTotal engines flagged this URL", "reputation", "critical", 30));
        }
      }
    } catch (error) {
      logger.warn({ err: error }, "VirusTotal lookup failed");
    }
  }

  return { score, signals };
}

async function checkPhoneReputation(phone: string): Promise<ReputationResult> {
  if (!env.IPQUALITYSCORE_API_KEY) return { score: 0, signals: [] };

  try {
    const encoded = encodeURIComponent(phone.replace(/\D/g, ""));
    const response = await fetch(`https://ipqualityscore.com/api/json/phone/${env.IPQUALITYSCORE_API_KEY}/${encoded}?strictness=1`);
    if (!response.ok) return { score: 0, signals: [] };
    const body = (await response.json()) as { fraud_score?: number; recent_abuse?: boolean; risky?: boolean; active?: boolean };
    const score = Math.min(45, Math.round((body.fraud_score ?? 0) * 0.45));
    const signals: DetectionSignal[] = [];
    if (body.recent_abuse || body.risky || score > 25) {
      signals.push(signal("phone-risk-api", "Phone reputation API reported scam or abuse signals", "reputation", "high", 22));
    }
    if (body.active === false) {
      signals.push(signal("phone-inactive", "Phone number may be inactive or disposable", "reputation", "medium", 12));
    }
    return { score, signals };
  } catch (error) {
    logger.warn({ err: error }, "Phone reputation lookup failed");
    return { score: 0, signals: [] };
  }
}
