import sanitizeHtml from "sanitize-html";
import {
  analyzeTextHeuristics,
  analyzeUrlHeuristics,
  buildScanResult,
  clampScore,
  extractIndicators,
  getRiskLevel,
  redactSensitive,
  type ScanResult,
  type ScanType
} from "@scamshield/shared";
import { env } from "../config/env.js";
import { Scan } from "../models/Scan.js";
import { User } from "../models/User.js";
import { APIUsageLog } from "../models/APIUsageLog.js";
import { encryptField, hashValue } from "../utils/crypto.js";
import { AppError } from "../utils/errors.js";
import { generateAIExplanation } from "./ai.service.js";
import { extractTextFromImage } from "./ocr.service.js";
import { checkReputation } from "./reputation.service.js";

interface ScanContext {
  userId?: string;
  guestId?: string;
  ip?: string;
  userAgent?: string;
  locale?: "en" | "hi";
  retainContent?: boolean;
}

export async function scanContent(type: ScanType, input: string, context: ScanContext = {}): Promise<ScanResult> {
  const cleanInput = normalizeScanInput(input);
  if (!cleanInput) throw new AppError("Scan input is required", 400, "SCAN_INPUT_REQUIRED");
  if (cleanInput.length > 15000) throw new AppError("Scan input is too large", 413, "SCAN_INPUT_TOO_LARGE");

  await enforceGuestLimit(context);

  const heuristicSignals = type === "url" ? analyzeUrlHeuristics(cleanInput) : analyzeTextHeuristics(cleanInput, type);
  const reputation = await checkReputation(type, cleanInput);
  const provisionalScore = clampScore(
    heuristicSignals.reduce((sum, signal) => sum + signal.weight, 0) + reputation.score
  );
  const provisionalLevel = getRiskLevel(provisionalScore);
  const inputPreview = redactSensitive(cleanInput);
  const ai = await generateAIExplanation({
    type,
    inputPreview,
    riskLevel: provisionalLevel,
    riskScore: provisionalScore,
    signals: [...heuristicSignals, ...reputation.signals],
    locale: context.locale
  });

  const result = buildScanResult({
    type,
    input: cleanInput,
    signals: [...heuristicSignals, ...reputation.signals],
    externalScore: reputation.score,
    aiScore: ai.aiScore,
    reputationScore: reputation.score,
    explanation: ai.explanation,
    recommendedAction: ai.recommendedAction
  });

  const saved = await saveScan(type, cleanInput, result, context);
  return { ...result, id: saved._id.toString() };
}

export async function scanScreenshot(buffer: Buffer, context: ScanContext = {}) {
  if (buffer.length > 5 * 1024 * 1024) throw new AppError("Screenshot must be under 5MB", 413, "FILE_TOO_LARGE");
  const ocrText = await extractTextFromImage(buffer);
  const result = await scanContent("screenshot", ocrText || "No readable text found in screenshot", {
    ...context,
    retainContent: false
  });
  return {
    ...result,
    extracted: {
      ...result.extracted,
      ocrText
    }
  };
}

export async function getScanHistory(context: ScanContext, page = 1, limit = 12) {
  if (!context.userId) throw new AppError("Authentication required", 401, "AUTH_REQUIRED");
  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Scan.find({ userId: context.userId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .select("-encryptedInput -extracted.ocrText")
      .lean(),
    Scan.countDocuments({ userId: context.userId })
  ]);

  return {
    items,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    }
  };
}

async function enforceGuestLimit(context: ScanContext) {
  if (context.userId) {
    await User.findByIdAndUpdate(context.userId, {
      $inc: { "usage.scansToday": 1 },
      $set: { "usage.lastScanAt": new Date() }
    });
    return;
  }

  const guestId = context.guestId;
  if (!guestId) return;
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const count = await Scan.countDocuments({ guestId, createdAt: { $gte: since } });
  if (count >= env.GUEST_DAILY_SCAN_LIMIT) {
    throw new AppError("Guest scan limit reached. Please create an account for more scans.", 429, "GUEST_LIMIT_REACHED");
  }
}

async function saveScan(type: ScanType, input: string, result: ScanResult, context: ScanContext) {
  const shouldRetain = Boolean(context.retainContent && context.userId);
  const source = {
    ipHash: context.ip ? hashValue(context.ip) : undefined,
    userAgent: context.userAgent
  };

  const scan = await Scan.create({
    userId: context.userId,
    guestId: context.guestId,
    type,
    inputHash: hashValue(input),
    inputPreview: result.inputPreview,
    encryptedInput: shouldRetain ? encryptField(input) : undefined,
    riskScore: result.riskScore,
    riskLevel: result.riskLevel,
    confidence: result.confidence,
    explanation: result.explanation,
    recommendedAction: result.recommendedAction,
    signals: result.signals,
    breakdown: result.breakdown,
    extracted: {
      ...result.extracted,
      ocrText: shouldRetain ? encryptField(result.extracted?.ocrText) : undefined
    },
    dataRetentionDays: shouldRetain ? 90 : 30,
    source
  });

  await APIUsageLog.create({
    userId: context.userId,
    guestId: context.guestId,
    endpoint: `/scan/${type}`,
    method: "POST",
    statusCode: 200,
    ipHash: source.ipHash,
    userAgent: source.userAgent,
    riskEvent: result.riskScore >= 80 ? "suspicious_scan" : "none",
    metadata: {
      riskLevel: result.riskLevel,
      signalCount: result.signals.length,
      extracted: extractIndicators(input)
    }
  });

  return scan;
}

function normalizeScanInput(input: string) {
  return sanitizeHtml(input, {
    allowedTags: [],
    allowedAttributes: {}
  })
    .replace(/\u0000/g, "")
    .trim();
}
