import type { UserRole } from "../models/User.js";

declare global {
  namespace Express {
    interface UserContext {
      id: string;
      role: UserRole;
      email: string;
    }

    interface Request {
      user?: UserContext;
      correlationId?: string;
    }
  }
}

export {};
