# ScamShield AI Mobile

ScamShield AI Mobile is a Flutter cross-platform Android/iOS app version of the ScamShield AI web platform. It gives privacy-first scam risk guidance for suspicious URLs, SMS/WhatsApp messages, emails, UPI IDs, QR payloads, phone numbers, screenshots, fake job offers, shopping websites, social profiles, scam alerts, and verified scam indicators.

Safety disclaimer: ScamShield AI provides layered security guidance and safer next steps. It does not guarantee detection, does not promise absolute security, and must not be used for offensive cybersecurity activity. Never enter OTP, UPI PIN, CVV, passwords, or full identity documents.

## Features

- Splash, onboarding, home, bottom navigation, and advanced drawer.
- Unified scanner with local risk engine, redaction, indicator extraction, red flags, score, verdict, confidence, report copy, JSON export, and local redacted history.
- QR scanner with camera permission flow, manual QR payload fallback, and no automatic link/payment launch.
- Screenshot scanner with camera/gallery selection, OCR-ready demo service, manual correction, and risk result.
- Alerts, alert details, follow/unfollow state, search, severity/category filters.
- Learn modules, quizzes, Hindi/English toggle, score/progress, completion badge, and spot-the-scam game.
- Report scam form with validation, anonymous mode, consent, redacted preview, screenshot placeholder, and local demo submission.
- Dashboard with stats, search/filter history, JSON/CSV export, delete single scan, delete all history, guest/sign-in notices, loading/error/empty-ready UI.
- Scam database with search, type/risk filters, load more, detail screen, false-positive modal, and report similar scam.
- Security Lab and Integration Status provider cards for Google Safe Browsing, VirusTotal, urlscan.io, IPQualityScore, HIBP, AbuseIPDB, and Internal Scam Database.
- Auth-ready Login, Signup, Forgot Password, Continue as Guest, and Google sign-in placeholder screens.
- Settings with language, privacy toggles, local data export/clear controls, terms/privacy links, contact support, app version, and demo mode indicator.
- Admin Reports Demo with moderation tabs, cards, detail modal, and actions.
- Terms of Use and Privacy Policy screens.

## Folder Structure

```text
lib/
  main.dart
  app.dart
  core/
    theme/
    constants/
    utils/
    security/
    validation/
    storage/
    network/
  features/
    splash/
    onboarding/
    home/
    scanner/
    qr_scanner/
    screenshot_scanner/
    alerts/
    learn/
    report/
    dashboard/
    database/
    security_lab/
    integrations/
    auth/
    settings/
    admin_reports/
    legal/
  shared/
    widgets/
    models/
```

## API Configuration

Default API base URL:

```text
https://create-a-production-level-full-stac.vercel.app/api/v1
```

Override at build time:

```bash
flutter run --dart-define=SCAMSHIELD_API_BASE_URL=https://your-domain.com/api/v1
```

Prepared endpoints:

- `POST /scan`
- `GET /scan/history`
- `DELETE /scan/history`
- `POST /report`
- `GET /alerts`
- `GET /alerts/:id`
- `POST /alerts/follow`
- `GET /database`
- `GET /database/:id`
- `POST /database/:id/false-positive`
- `GET /integrations/status`

API keys must be configured only on the backend/server environment:

- `GOOGLE_SAFE_BROWSING_API_KEY`
- `VIRUSTOTAL_API_KEY`
- `URLSCAN_API_KEY`
- `IPQUALITYSCORE_API_KEY`
- `HIBP_API_KEY`
- `ABUSEIPDB_API_KEY`

Never place these key values in Flutter code or mobile app assets.

## Running

```bash
cd apps/mobile
flutter pub get
flutter run
```

## Android

Android permissions are configured in `android/app/src/main/AndroidManifest.xml`:

- Camera
- Internet
- Media/image access

Build APK:

```bash
cd apps/mobile
flutter build apk --release
```

## iOS

iOS permission descriptions are configured in `ios/Runner/Info.plist`:

- Camera usage
- Photo library usage

Build iOS:

```bash
cd apps/mobile
flutter build ios --release
```

If the local Flutter SDK needs to regenerate native metadata, run `flutter create .` inside `apps/mobile` and keep the existing `lib/` implementation.

## Demo Fallback Data

The app works with demo/mock data when the backend is unavailable. Demo sections are labeled `Demo data`. Demo data covers scam alerts, scan history, database indicators, provider status, admin reports, quizzes, spot-the-scam challenges, safety tips, and dashboard stats.

## Privacy-First Design

- Raw scan input is not saved by default.
- Local history stores only redacted scan results.
- Reports are redacted and reviewed before becoming verified indicators.
- User contact is optional and is never shown publicly.
- The app never opens suspicious links automatically.
- The app never calls suspicious phone numbers automatically.
- The app never starts UPI/card payments automatically.

## Risk Engine

The local risk engine in `features/scanner/services/risk_engine_service.dart` implements:

- `normalizeInput()`
- `redactSensitiveSecrets()`
- `extractIndicators()`
- `runHeuristicChecks()`
- `calculateRiskScore()`
- `getVerdict()`
- `getConfidence()`
- `generateHumanExplanation()`
- `createScanResult()`

It checks OTP requests, UPI PIN pressure, CVV/password requests, KYC/account-block urgency, shortened URLs, brand lookalike domains, fake job fees, refund/collect requests, customer-care remote access scripts, free-mail reply-to patterns, QR payment payloads, APK download lures, lottery/prize fees, guaranteed returns, and loan approval fees.

## Redaction

`core/security/redaction_service.dart` redacts OTP-like numbers, CVV/PIN values, UPI PIN/password patterns, Aadhaar-like numbers, card-like numbers, long identity-like numbers, and account-number-like values before local save or report preview.

## Local Storage

SharedPreferences stores:

- App settings
- Demo scan history
- Followed alerts
- Quiz progress
- Guest/demo auth state
- Local privacy preferences
- Local demo reports

## Implementation Checklist

- [x] Splash screen implemented
- [x] Onboarding implemented
- [x] Home screen implemented
- [x] Scanner implemented
- [x] Local risk engine implemented
- [x] Redaction engine implemented
- [x] Indicator extraction implemented
- [x] QR scanner implemented
- [x] Screenshot scanner implemented
- [x] Alerts implemented
- [x] Alert detail implemented
- [x] Learn modules implemented
- [x] Quizzes implemented
- [x] Spot the Scam game implemented
- [x] Report scam form implemented
- [x] Dashboard implemented
- [x] Scam database implemented
- [x] Database detail implemented
- [x] False positive reporting implemented
- [x] Security Lab implemented
- [x] Integration Status implemented
- [x] Auth screens implemented
- [x] Settings implemented
- [x] Admin Reports Demo implemented
- [x] Terms screen implemented
- [x] Privacy screen implemented
- [x] Mock data implemented
- [x] API service layer implemented
- [x] Local storage implemented
- [x] Export JSON implemented
- [x] Export CSV implemented
- [x] Delete local history implemented
- [x] Hindi/English toggle implemented
- [x] Demo data badges implemented
- [x] Loading states implemented
- [x] Error states implemented
- [x] Empty states implemented
- [x] Android configuration implemented
- [x] iOS configuration implemented
- [x] README completed
