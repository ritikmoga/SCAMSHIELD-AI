import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/storage/app_state.dart';
import 'core/theme/app_theme.dart';
import 'features/admin_reports/screens/admin_reports_screen.dart';
import 'features/alerts/screens/alert_detail_screen.dart';
import 'features/auth/screens/forgot_password_screen.dart';
import 'features/auth/screens/login_screen.dart';
import 'features/auth/screens/signup_screen.dart';
import 'features/database/screens/database_detail_screen.dart';
import 'features/database/screens/scam_database_screen.dart';
import 'features/home/screens/home_screen.dart';
import 'features/integrations/screens/integration_status_screen.dart';
import 'features/legal/screens/privacy_policy_screen.dart';
import 'features/legal/screens/terms_screen.dart';
import 'features/onboarding/screens/onboarding_screen.dart';
import 'features/qr_scanner/screens/qr_scanner_screen.dart';
import 'features/scanner/screens/scanner_screen.dart';
import 'features/screenshot_scanner/screens/screenshot_scanner_screen.dart';
import 'features/security_lab/screens/security_lab_screen.dart';
import 'features/settings/screens/settings_screen.dart';
import 'features/splash/screens/splash_screen.dart';
import 'shared/widgets/app_shell.dart';

class ScamShieldApp extends StatelessWidget {
  const ScamShieldApp({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ScamShieldAppState>();
    return MaterialApp(
      title: 'ScamShield AI',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      initialRoute: state.onboardingComplete ? '/home' : '/splash',
      routes: {
        '/splash': (_) => const SplashScreen(),
        '/onboarding': (_) => const OnboardingScreen(),
        '/home': (_) => const HomeScreen(),
        '/main': (_) => const AppShell(),
        '/scanner': (_) => const ScannerScreen(),
        '/qr': (_) => const QrScannerScreen(),
        '/screenshot': (_) => const ScreenshotScannerScreen(),
        '/securityLab': (_) => const SecurityLabScreen(),
        '/database': (_) => const ScamDatabaseScreen(),
        '/integrations': (_) => const IntegrationStatusScreen(),
        '/login': (_) => const LoginScreen(),
        '/signup': (_) => const SignupScreen(),
        '/forgot': (_) => const ForgotPasswordScreen(),
        '/settings': (_) => const SettingsScreen(),
        '/adminReports': (_) => const AdminReportsScreen(),
        '/terms': (_) => const TermsScreen(),
        '/privacy': (_) => const PrivacyPolicyScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/alertDetail') {
          return MaterialPageRoute(
            builder: (_) => AlertDetailScreen(alertId: settings.arguments as String?),
          );
        }
        if (settings.name == '/databaseDetail') {
          return MaterialPageRoute(
            builder: (_) => DatabaseDetailScreen(recordId: settings.arguments as String?),
          );
        }
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      },
    );
  }
}
