class ApiConstants {
  static const baseUrl = String.fromEnvironment(
    'SCAMSHIELD_API_BASE_URL',
    defaultValue: 'https://create-a-production-level-full-stac.vercel.app/api/v1',
  );
  static const scan = '/scan';
  static const scanHistory = '/scan/history';
  static const report = '/report';
  static const alerts = '/alerts';
  static String alertDetail(String id) => '/alerts/$id';
  static const followAlert = '/alerts/follow';
  static const database = '/database';
  static String databaseDetail(String id) => '/database/$id';
  static String falsePositive(String id) => '/database/$id/false-positive';
  static const integrationsStatus = '/integrations/status';
}
