class AppConstants {
  static const appName = 'ScamShield AI';
  static const tagline = 'Risk guidance before you click, pay, or trust.';
  static const privacyWarning = 'Never enter OTP, UPI PIN, CVV, passwords, or full identity documents.';
  static const demoData = 'Demo data';
  static const version = '1.0.0';
}
