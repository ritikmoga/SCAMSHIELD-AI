import 'dart:convert';

import 'package:http/http.dart' as http;

import '../constants/api_constants.dart';
import 'api_result.dart';

class ApiClient {
  ApiClient({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  Future<ApiResult<Map<String, dynamic>>> getJson(String path) async {
    try {
      final response = await _client.get(Uri.parse('${ApiConstants.baseUrl}$path')).timeout(const Duration(seconds: 10));
      if (response.statusCode < 200 || response.statusCode >= 300) return const ApiResult.failure('Backend unavailable. Showing demo data.');
      return ApiResult.success(jsonDecode(response.body) as Map<String, dynamic>);
    } catch (_) {
      return const ApiResult.failure('Backend unavailable. Showing demo data.');
    }
  }

  Future<ApiResult<Map<String, dynamic>>> postJson(String path, Map<String, dynamic> body) async {
    try {
      final response = await _client
          .post(
            Uri.parse('${ApiConstants.baseUrl}$path'),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode < 200 || response.statusCode >= 300) return const ApiResult.failure('Request failed safely. Demo fallback is active.');
      return ApiResult.success(jsonDecode(response.body) as Map<String, dynamic>);
    } catch (_) {
      return const ApiResult.failure('Request failed safely. Demo fallback is active.');
    }
  }
}
