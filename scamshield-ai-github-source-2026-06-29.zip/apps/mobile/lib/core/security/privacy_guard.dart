import 'redaction_service.dart';

class PrivacyGuard {
  static String safeForLocalSave(String rawInput) => RedactionService.preview(rawInput, maxLength: 220);
  static bool containsSensitivePrompt(String input) {
    return RegExp(r'\b(otp|upi pin|cvv|password|aadhaar|card pin)\b', caseSensitive: false).hasMatch(input);
  }
}
