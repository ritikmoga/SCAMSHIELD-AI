class RedactionService {
  static String redactSensitiveSecrets(String input) {
    var value = input;
    value = value.replaceAll(RegExp(r'\b\d{6}\b'), '[REDACTED_OTP]');
    value = value.replaceAll(RegExp(r'\b\d{3,4}\b(?=\s*(?:cvv|card pin|pin)\b)', caseSensitive: false), '[REDACTED_PIN]');
    value = value.replaceAll(RegExp(r'\b\d{12}\b'), '[REDACTED_ID]');
    value = value.replaceAll(RegExp(r'\b(?:\d[ -]?){13,19}\b'), '[REDACTED_CARD]');
    value = value.replaceAll(RegExp(r'(password|passcode|upi pin|cvv)\s*[:=]\s*\S+', caseSensitive: false), r'$1=[REDACTED]');
    value = value.replaceAll(RegExp(r'\b(account|customer)\s*(number|no)\s*[:=]?\s*\d{6,}\b', caseSensitive: false), r'$1 $2 [REDACTED]');
    return value.trim();
  }

  static String preview(String input, {int maxLength = 180}) {
    final redacted = redactSensitiveSecrets(input).replaceAll(RegExp(r'\s+'), ' ');
    if (redacted.length <= maxLength) return redacted;
    return '${redacted.substring(0, maxLength)}...';
  }
}
