import 'dart:convert';

import 'package:flutter/material.dart';

import '../../features/scanner/services/risk_engine_service.dart';
import '../../shared/models/scan_result.dart';
import '../constants/mock_data.dart';
import '../utils/export_utils.dart';
import 'local_storage_service.dart';
import 'scan_history_storage.dart';
import 'settings_storage.dart';

class ScamShieldAppState extends ChangeNotifier {
  final LocalStorageService _storage = LocalStorageService();
  late final ScanHistoryStorage _historyStorage = ScanHistoryStorage(_storage);
  late final SettingsStorage _settingsStorage = SettingsStorage(_storage);

  bool onboardingComplete = false;
  bool saveRedactedHistory = true;
  bool demoAuth = true;
  String language = 'en';
  List<ScanResult> history = [];
  List<String> followedAlertIds = [];
  Map<String, int> quizScores = {};
  List<Map<String, dynamic>> localReports = [];

  Future<void> load() async {
    await _storage.init();
    onboardingComplete = _settingsStorage.onboardingComplete;
    saveRedactedHistory = _settingsStorage.saveRedactedHistory;
    language = _settingsStorage.language;
    history = _historyStorage.read();
    followedAlertIds = _storage.getStringList('followed_alerts');
    quizScores = Map<String, int>.from(jsonDecode(_storage.getString('quiz_scores', fallback: '{}')) as Map);
    localReports = _storage.getStringList('local_reports').map((item) => Map<String, dynamic>.from(jsonDecode(item) as Map)).toList();
  }

  Future<void> completeOnboarding() async {
    onboardingComplete = true;
    await _settingsStorage.setOnboardingComplete(true);
    notifyListeners();
  }

  Future<ScanResult> runLocalScan(String type, String input) async {
    await Future<void>.delayed(const Duration(milliseconds: 450));
    final result = RiskEngineService.createScanResult(inputType: type, rawInput: input);
    return result;
  }

  Future<void> saveScan(ScanResult result) async {
    if (!saveRedactedHistory) return;
    history = [result, ...history].take(50).toList();
    await _historyStorage.write(history);
    notifyListeners();
  }

  Future<void> deleteScan(String id) async {
    history = history.where((item) => item.id != id).toList();
    await _historyStorage.write(history);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    history = [];
    await _historyStorage.write(history);
    notifyListeners();
  }

  String exportHistoryJson() => ExportUtils.historyJson(history);
  String exportHistoryCsv() => ExportUtils.historyCsv(history);

  Future<void> toggleFollowAlert(String id) async {
    followedAlertIds = followedAlertIds.contains(id) ? followedAlertIds.where((item) => item != id).toList() : [...followedAlertIds, id];
    await _storage.setStringList('followed_alerts', followedAlertIds);
    notifyListeners();
  }

  Future<void> saveQuizScore(String moduleId, int score) async {
    quizScores = {...quizScores, moduleId: score};
    await _storage.setString('quiz_scores', jsonEncode(quizScores));
    notifyListeners();
  }

  Future<void> resetQuizProgress() async {
    quizScores = {};
    await _storage.setString('quiz_scores', '{}');
    notifyListeners();
  }

  Future<void> saveReport(Map<String, dynamic> report) async {
    localReports = [report, ...localReports];
    await _storage.setStringList('local_reports', localReports.map(jsonEncode).toList());
    notifyListeners();
  }

  Future<void> clearReports() async {
    localReports = [];
    await _storage.setStringList('local_reports', []);
    notifyListeners();
  }

  Future<void> setLanguage(String next) async {
    language = next;
    await _settingsStorage.setLanguage(next);
    notifyListeners();
  }

  Future<void> setSaveRedactedHistory(bool value) async {
    saveRedactedHistory = value;
    await _settingsStorage.setSaveRedactedHistory(value);
    notifyListeners();
  }

  Future<void> clearFollowedAlerts() async {
    followedAlertIds = [];
    await _storage.setStringList('followed_alerts', []);
    notifyListeners();
  }

  Map<String, int> get dashboardStats => {
        'totalScans': history.isEmpty ? MockData.demoHistory.length : history.length,
        'dangerous': history.where((scan) => scan.verdict == 'Dangerous').length,
        'suspicious': history.where((scan) => scan.verdict == 'Suspicious').length,
        'reports': localReports.length,
        'followed': followedAlertIds.length,
      };
}
