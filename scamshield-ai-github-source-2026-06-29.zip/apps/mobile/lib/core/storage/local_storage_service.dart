import 'package:shared_preferences/shared_preferences.dart';

class LocalStorageService {
  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  bool getBool(String key, {bool fallback = false}) => _prefs?.getBool(key) ?? fallback;
  Future<void> setBool(String key, bool value) async => _prefs?.setBool(key, value);

  String getString(String key, {String fallback = ''}) => _prefs?.getString(key) ?? fallback;
  Future<void> setString(String key, String value) async => _prefs?.setString(key, value);

  List<String> getStringList(String key) => _prefs?.getStringList(key) ?? <String>[];
  Future<void> setStringList(String key, List<String> value) async => _prefs?.setStringList(key, value);

  Future<void> remove(String key) async => _prefs?.remove(key);
}
