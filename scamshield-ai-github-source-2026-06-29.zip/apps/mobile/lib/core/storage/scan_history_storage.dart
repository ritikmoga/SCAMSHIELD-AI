import 'dart:convert';

import '../../shared/models/scan_result.dart';
import 'local_storage_service.dart';

class ScanHistoryStorage {
  ScanHistoryStorage(this.storage);
  final LocalStorageService storage;
  static const _key = 'scan_history';

  List<ScanResult> read() {
    return storage.getStringList(_key).map((item) => ScanResult.fromJson(jsonDecode(item) as Map<String, dynamic>)).toList();
  }

  Future<void> write(List<ScanResult> history) => storage.setStringList(_key, history.map((item) => jsonEncode(item.toJson())).toList());
}
