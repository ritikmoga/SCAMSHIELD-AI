import 'local_storage_service.dart';

class SettingsStorage {
  SettingsStorage(this.storage);
  final LocalStorageService storage;

  bool get saveRedactedHistory => storage.getBool('save_redacted_history', fallback: true);
  Future<void> setSaveRedactedHistory(bool value) => storage.setBool('save_redacted_history', value);

  String get language => storage.getString('language', fallback: 'en');
  Future<void> setLanguage(String value) => storage.setString('language', value);

  bool get onboardingComplete => storage.getBool('onboarding_complete');
  Future<void> setOnboardingComplete(bool value) => storage.setBool('onboarding_complete', value);
}
