import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFF050A0E);
  static const surface = Color(0xFF0C151C);
  static const surfaceAlt = Color(0xFF12202A);
  static const border = Color(0xFF223845);
  static const text = Color(0xFFF1F7F6);
  static const muted = Color(0xFFA5B4B8);
  static const primary = Color(0xFF66F08A);
  static const cyan = Color(0xFF49D9FF);
  static const yellow = Color(0xFFFFD166);
  static const orange = Color(0xFFFF9F1C);
  static const red = Color(0xFFFF4B6E);
}
