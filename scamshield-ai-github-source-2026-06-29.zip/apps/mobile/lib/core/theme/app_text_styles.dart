import 'package:flutter/material.dart';

class AppTextStyles {
  static const headline = TextStyle(fontSize: 26, fontWeight: FontWeight.w800, height: 1.15);
  static const title = TextStyle(fontSize: 18, fontWeight: FontWeight.w700);
  static const body = TextStyle(fontSize: 14, height: 1.5);
  static const label = TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.4);
}
