import 'package:flutter/services.dart';

class ClipboardUtils {
  static Future<void> copy(String value) => Clipboard.setData(ClipboardData(text: value));
}
