import 'dart:convert';

import '../../shared/models/scan_result.dart';

class ExportUtils {
  static String historyJson(List<ScanResult> history) => const JsonEncoder.withIndent('  ').convert(history.map((item) => item.toJson()).toList());

  static String historyCsv(List<ScanResult> history) {
    final rows = ['id,type,redactedPreview,riskScore,verdict,confidence,timestamp'];
    for (final item in history) {
      rows.add([
        item.id,
        item.inputType,
        '"${item.redactedPreview.replaceAll('"', '""')}"',
        item.riskScore,
        item.verdict,
        item.confidence,
        item.timestamp.toIso8601String(),
      ].join(','));
    }
    return rows.join('\n');
  }
}
