class Validators {
  static String? requiredText(String? value, {String label = 'This field'}) {
    if (value == null || value.trim().isEmpty) return '$label is required.';
    return null;
  }

  static String? minLength(String? value, int min, {String label = 'This field'}) {
    final required = requiredText(value, label: label);
    if (required != null) return required;
    if (value!.trim().length < min) return '$label must be at least $min characters.';
    return null;
  }

  static String? emailOptional(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim())) return 'Enter a valid email or leave it blank.';
    return null;
  }
}
