class AdminReport {
  AdminReport(this.data);
  final Map<String, dynamic> data;
}
