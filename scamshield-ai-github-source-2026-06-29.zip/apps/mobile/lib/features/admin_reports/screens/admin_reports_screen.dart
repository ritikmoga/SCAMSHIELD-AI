import 'package:flutter/material.dart';

import '../../../core/constants/mock_data.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/section_header.dart';

class AdminReportsScreen extends StatefulWidget {
  const AdminReportsScreen({super.key});

  @override
  State<AdminReportsScreen> createState() => _AdminReportsScreenState();
}

class _AdminReportsScreenState extends State<AdminReportsScreen> {
  String tab = 'Pending';
  final notes = <String, String>{};
  final tabs = const ['Pending', 'Verified', 'Rejected', 'Duplicate', 'Escalated'];

  @override
  Widget build(BuildContext context) {
    final reports = MockData.adminReports.where((item) => item['status'] == tab).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Reports Demo')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Row(children: [SectionHeader(title: 'Demo moderation data'), Spacer(), DemoDataBadge()]),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: tabs.map((item) => Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(item), selected: tab == item, onSelected: (_) => setState(() => tab = item)))).toList()),
          ),
          const SizedBox(height: 12),
          ...reports.map((report) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: AppCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${report['type']} - ${report['valuePreview']}', style: Theme.of(context).textTheme.titleMedium),
                      Text('${report['sourcePlatform']} - ${report['createdDate']} - ${report['status']}'),
                      Text('Risk hints: ${(report['riskHints'] as List).join(', ')}'),
                      const SizedBox(height: 10),
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        AppButton(label: 'Verify', icon: Icons.verified, onPressed: () => _mark(report, 'Verified')),
                        AppButton(label: 'Reject', icon: Icons.close, secondary: true, onPressed: () => _mark(report, 'Rejected')),
                        AppButton(label: 'Mark duplicate', icon: Icons.copy, secondary: true, onPressed: () => _mark(report, 'Duplicate')),
                        AppButton(label: 'Escalate', icon: Icons.priority_high, secondary: true, onPressed: () => _mark(report, 'Escalated')),
                        AppButton(label: 'View details', icon: Icons.open_in_new, secondary: true, onPressed: () => _details(context, report)),
                      ]),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }

  void _mark(Map<String, dynamic> report, String status) {
    setState(() => notes[report['id']] = 'Demo action: ${report['id']} marked $status');
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(notes[report['id']]!)));
  }

  void _details(BuildContext context, Map<String, dynamic> report) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${report['type']} report'),
        content: SingleChildScrollView(
          child: Text(
            'Redacted value: ${report['valuePreview']}\nDescription: ${report['description']}\nSource: ${report['sourcePlatform']}\nRisk hints: ${(report['riskHints'] as List).join(', ')}\nCreated: ${report['createdDate']}\nStatus: ${report['status']}\nModeration notes: ${notes[report['id']] ?? 'No notes yet.'}',
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      ),
    );
  }
}
