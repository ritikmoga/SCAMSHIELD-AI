import '../../../core/constants/mock_data.dart';

class AdminReportsService {
  List<Map<String, dynamic>> reports() => MockData.adminReports;
}
