class ScamAlert {
  ScamAlert(this.data);
  final Map<String, dynamic> data;
  String get id => data['id'];
  String get title => data['title'];
}
