import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/storage/app_state.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/risk_badge.dart';
import '../../../shared/widgets/section_header.dart';

class AlertDetailScreen extends StatelessWidget {
  const AlertDetailScreen({super.key, this.alertId});
  final String? alertId;

  @override
  Widget build(BuildContext context) {
    final alert = MockData.alerts.firstWhere((item) => item['id'] == alertId, orElse: () => MockData.alerts.first);
    final followed = context.watch<ScamShieldAppState>().followedAlertIds.contains(alert['id']);
    return Scaffold(
      appBar: AppBar(title: const Text('Alert Detail')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [RiskBadge(label: alert['severity']), const Spacer(), const DemoDataBadge()]),
                const SizedBox(height: 12),
                Text(alert['title'], style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text('${alert['category']} - Last updated ${alert['lastUpdated']}'),
                const SizedBox(height: 10),
                Text(alert['summary']),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _ListSection(title: 'Common scam script', items: [alert['commonScript']]),
          _ListSection(title: 'Red flags', items: List<String>.from(alert['redFlags'])),
          _ListSection(title: 'What to do', items: List<String>.from(alert['whatToDo'])),
          _ListSection(title: 'What not to do', items: List<String>.from(alert['whatNotToDo'])),
          _ListSection(title: 'Related indicators', items: List<String>.from(alert['relatedIndicators'])),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              AppButton(label: followed ? 'Unfollow alert' : 'Follow alert', icon: Icons.notifications, onPressed: () => context.read<ScamShieldAppState>().toggleFollowAlert(alert['id'])),
              AppButton(label: 'Report similar scam', icon: Icons.report, secondary: true, onPressed: () => Navigator.pushNamed(context, '/main', arguments: 3)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ListSection extends StatelessWidget {
  const _ListSection({required this.title, required this.items});
  final String title;
  final List<String> items;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(title: title),
            ...items.map((item) => ListTile(contentPadding: EdgeInsets.zero, dense: true, leading: const Icon(Icons.check_circle_outline), title: Text(item))),
          ],
        ),
      ),
    );
  }
}
