import 'package:flutter/material.dart';

import '../../../core/constants/mock_data.dart';
import '../../../shared/widgets/alert_card.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/search_and_filter_bar.dart';
import '../../../shared/widgets/section_header.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key, this.embed = false});
  final bool embed;

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {
  final search = TextEditingController();
  String severity = 'All';
  String category = 'All';
  bool loading = false;
  String? error;

  List<Map<String, dynamic>> get filtered {
    final q = search.text.toLowerCase();
    return MockData.alerts.where((alert) {
      final text = '${alert['title']} ${alert['summary']} ${alert['category']}'.toLowerCase();
      return (q.isEmpty || text.contains(q)) && (severity == 'All' || alert['severity'] == severity) && (category == 'All' || alert['category'] == category);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Row(children: [SectionHeader(title: 'Trending scam alerts'), Spacer(), DemoDataBadge()]),
        const SizedBox(height: 12),
        SearchAndFilterBar(
          searchController: search,
          hint: 'Search alerts',
          onChanged: (_) => setState(() {}),
          filters: const ['All', 'Low', 'Medium', 'High', 'Critical'],
          selectedFilter: severity,
          onFilterChanged: (value) => setState(() => severity = value),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          children: ['All', 'UPI', 'KYC', 'Banking', 'Job', 'Shopping', 'QR', 'Delivery', 'Social Media', 'Investment', 'Other']
              .map((item) => ChoiceChip(selected: category == item, label: Text(item), onSelected: (_) => setState(() => category = item)))
              .toList(),
        ),
        if (loading) const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
        if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        const SizedBox(height: 12),
        if (filtered.isEmpty) const EmptyState(title: 'No alerts found', message: 'Try a different severity, category, or search term.'),
        ...filtered.map((alert) => Padding(padding: const EdgeInsets.only(bottom: 12), child: AlertCard(alert: alert))),
      ],
    );
    if (widget.embed) return content;
    return Scaffold(appBar: AppBar(title: const Text('Alerts')), body: content);
  }
}
