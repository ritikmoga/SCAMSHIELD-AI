import '../../../core/constants/mock_data.dart';

class AlertsService {
  Future<List<Map<String, dynamic>>> loadAlerts() async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    return MockData.alerts;
  }
}
