class DemoUser {
  const DemoUser({required this.name, required this.email, required this.guest});
  final String name;
  final String email;
  final bool guest;
}
