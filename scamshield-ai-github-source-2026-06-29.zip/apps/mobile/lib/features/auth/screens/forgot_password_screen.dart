import 'package:flutter/material.dart';

import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/app_text_field.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final email = TextEditingController();
  String? status;
  String? error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Forgot Password')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(child: Column(children: [
          AppTextField(controller: email, label: 'Email'),
          const SizedBox(height: 12),
          AppButton(label: 'Send reset link', icon: Icons.send, onPressed: () => setState(() => email.text.contains('@') ? status = 'Demo reset link sent.' : error = 'Enter a valid email.')),
          if (status != null) Text(status!),
          if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Back to login')),
        ])),
      ]),
    );
  }
}
