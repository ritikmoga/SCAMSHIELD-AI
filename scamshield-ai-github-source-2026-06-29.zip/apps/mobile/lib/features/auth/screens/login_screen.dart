import 'package:flutter/material.dart';

import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/app_text_field.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  String? status;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(child: Column(children: [
          const Text('Demo auth notice: backend auth is not connected. Guest mode still allows scanning.'),
          const SizedBox(height: 12),
          AppTextField(controller: email, label: 'Email'),
          const SizedBox(height: 12),
          AppTextField(controller: password, label: 'Password'),
          const SizedBox(height: 12),
          AppButton(label: 'Login', icon: Icons.login, onPressed: () => setState(() => status = 'Demo login state active. Sign in to save history across devices when backend auth is connected.')),
          AppButton(label: 'Continue as guest', icon: Icons.person, secondary: true, onPressed: () => Navigator.pushReplacementNamed(context, '/home')),
          AppButton(label: 'Google sign-in placeholder', icon: Icons.g_mobiledata, secondary: true, onPressed: () => setState(() => status = 'Google sign-in placeholder.')),
          TextButton(onPressed: () => Navigator.pushNamed(context, '/forgot'), child: const Text('Forgot password?')),
          TextButton(onPressed: () => Navigator.pushNamed(context, '/signup'), child: const Text('Create account')),
          if (status != null) Text(status!),
        ])),
      ]),
    );
  }
}
