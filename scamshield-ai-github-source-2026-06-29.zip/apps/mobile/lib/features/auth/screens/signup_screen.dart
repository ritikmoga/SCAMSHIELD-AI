import 'package:flutter/material.dart';

import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/app_text_field.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final confirm = TextEditingController();
  bool agree = false;
  String? status;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Signup')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(child: Column(children: [
          const Text('Demo auth notice: signup state is local until backend auth is connected.'),
          const SizedBox(height: 12),
          AppTextField(controller: name, label: 'Name'),
          const SizedBox(height: 12),
          AppTextField(controller: email, label: 'Email'),
          const SizedBox(height: 12),
          AppTextField(controller: password, label: 'Password'),
          const SizedBox(height: 12),
          AppTextField(controller: confirm, label: 'Confirm password'),
          CheckboxListTile(value: agree, onChanged: (value) => setState(() => agree = value ?? false), title: const Text('I agree to Terms and Privacy Policy.')),
          AppButton(label: 'Signup', icon: Icons.person_add, onPressed: agree ? () => setState(() => status = 'Demo signup created. Sign in to save history across devices when backend auth is connected.') : null),
          AppButton(label: 'Continue as guest', icon: Icons.person, secondary: true, onPressed: () => Navigator.pushReplacementNamed(context, '/home')),
          TextButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: const Text('Already have an account? Login')),
          if (status != null) Text(status!),
        ])),
      ]),
    );
  }
}
