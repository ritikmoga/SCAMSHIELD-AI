class AuthService {
  Future<bool> demoLogin(String email, String password) async {
    await Future<void>.delayed(const Duration(milliseconds: 450));
    return email.isNotEmpty && password.isNotEmpty;
  }
}
