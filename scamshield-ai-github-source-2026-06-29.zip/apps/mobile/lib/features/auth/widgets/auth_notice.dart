import 'package:flutter/material.dart';

class AuthNotice extends StatelessWidget {
  const AuthNotice({super.key});
  @override
  Widget build(BuildContext context) => const Text('Demo auth mode. Sign in to save history across devices when backend auth is connected.');
}
