class DashboardStat {
  const DashboardStat(this.label, this.value);
  final String label;
  final String value;
}
