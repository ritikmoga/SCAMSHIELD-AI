import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/storage/app_state.dart';
import '../../../core/utils/clipboard_utils.dart';
import '../../../shared/models/scan_result.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/confirm_dialog.dart';
import '../../../shared/widgets/dashboard_stat_card.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/risk_badge.dart';
import '../../../shared/widgets/search_and_filter_bar.dart';
import '../../../shared/widgets/section_header.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, this.embed = false});
  final bool embed;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final search = TextEditingController();
  String type = 'All';
  String verdict = 'All';
  String date = 'All';
  bool loading = false;
  String? error;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<ScamShieldAppState>();
    final source = app.history.isEmpty ? MockData.demoHistory : app.history;
    final filtered = source.where((scan) {
      final q = search.text.toLowerCase();
      final ageDays = DateTime.now().difference(scan.timestamp).inDays;
      return (q.isEmpty || '${scan.inputType} ${scan.redactedPreview} ${scan.verdict}'.toLowerCase().contains(q)) &&
          (type == 'All' || scan.inputType == type) &&
          (verdict == 'All' || scan.verdict == verdict) &&
          (date == 'All' || (date == '7d' && ageDays <= 7) || (date == '30d' && ageDays <= 30));
    }).toList();
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionHeader(title: 'Dashboard'),
        const Text('Sign in to save history across devices. Continue as guest keeps local redacted history only.'),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1.35,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          children: [
            DashboardStatCard(label: 'Total scans', value: '${source.length}', icon: Icons.radar),
            DashboardStatCard(label: 'Dangerous found', value: '${source.where((scan) => scan.verdict == 'Dangerous').length}', icon: Icons.warning),
            DashboardStatCard(label: 'Suspicious found', value: '${source.where((scan) => scan.verdict == 'Suspicious').length}', icon: Icons.info),
            DashboardStatCard(label: 'Reports submitted', value: '${app.localReports.length}', icon: Icons.report),
            DashboardStatCard(label: 'Followed alerts', value: '${app.followedAlertIds.length}', icon: Icons.notifications),
          ],
        ),
        const SizedBox(height: 14),
        SearchAndFilterBar(searchController: search, onChanged: (_) => setState(() {}), filters: const ['All', 'url', 'message', 'email', 'upi', 'qr', 'phone', 'job', 'shopping', 'social'], selectedFilter: type, onFilterChanged: (value) => setState(() => type = value), hint: 'Search history'),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: ['All', 'Safe', 'Suspicious', 'Dangerous'].map((item) => ChoiceChip(label: Text(item), selected: verdict == item, onSelected: (_) => setState(() => verdict = item))).toList()),
        Wrap(spacing: 8, children: ['All', '7d', '30d'].map((item) => ChoiceChip(label: Text(item), selected: date == item, onSelected: (_) => setState(() => date = item))).toList()),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        if (filtered.isEmpty) const EmptyState(title: 'No scans found', message: 'Run a scan or adjust filters.'),
        ...filtered.map((scan) => _HistoryTile(scan: scan, demo: app.history.isEmpty)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            AppButton(label: 'Export JSON', icon: Icons.data_object, onPressed: () => ClipboardUtils.copy(app.exportHistoryJson())),
            AppButton(label: 'Export CSV', icon: Icons.table_chart, secondary: true, onPressed: () => ClipboardUtils.copy(app.exportHistoryCsv())),
            AppButton(label: 'Delete all history', icon: Icons.delete, destructive: true, onPressed: () async { if (await showConfirmDialog(context, title: 'Delete all history?', message: 'Only local redacted history will be deleted.')) app.clearHistory(); }),
          ],
        ),
      ],
    );
    if (widget.embed) return content;
    return Scaffold(appBar: AppBar(title: const Text('Dashboard')), body: content);
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({required this.scan, required this.demo});
  final ScanResult scan;
  final bool demo;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(scan.redactedPreview, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${scan.inputType} - ${scan.riskScore}/100${demo ? ' - Demo data' : ''}'),
      leading: RiskBadge(label: scan.verdict),
      trailing: IconButton(icon: const Icon(Icons.delete), onPressed: demo ? null : () => context.read<ScamShieldAppState>().deleteScan(scan.id)),
    );
  }
}
