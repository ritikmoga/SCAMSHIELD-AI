class DashboardService {
  Future<void> load() async => Future<void>.delayed(const Duration(milliseconds: 250));
}
