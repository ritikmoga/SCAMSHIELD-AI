class DatabaseIndicator {
  DatabaseIndicator(this.data);
  final Map<String, dynamic> data;
  String get id => data['id'];
}
