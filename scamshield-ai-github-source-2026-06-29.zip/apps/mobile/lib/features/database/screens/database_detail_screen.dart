import 'package:flutter/material.dart';

import '../../../core/constants/mock_data.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/risk_badge.dart';
import '../../../shared/widgets/section_header.dart';
import '../widgets/false_positive_modal.dart';

class DatabaseDetailScreen extends StatelessWidget {
  const DatabaseDetailScreen({super.key, this.recordId});
  final String? recordId;

  @override
  Widget build(BuildContext context) {
    final record = MockData.database.firstWhere((item) => item['id'] == recordId, orElse: () => MockData.database.first);
    return Scaffold(
      appBar: AppBar(title: const Text('Indicator Detail')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [RiskBadge(label: record['risk']), const Spacer(), Text(record['type'])]),
                const SizedBox(height: 12),
                Text(record['value'], style: Theme.of(context).textTheme.headlineSmall),
                Text('Last verified ${record['lastVerified']} - ${record['sourceConfidence']} confidence'),
                const SizedBox(height: 10),
                Text(record['description']),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _Section(title: 'Known red flags', items: List<String>.from(record['redFlags'])),
          _Section(title: 'Safety steps', items: List<String>.from(record['safetySteps'])),
          _Section(title: 'Related alerts', items: List<String>.from(record['relatedAlerts'])),
          Wrap(spacing: 8, runSpacing: 8, children: [
            AppButton(label: 'Report false positive', icon: Icons.flag, onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => FalsePositiveModal(record: record))),
            AppButton(label: 'Report similar scam', icon: Icons.report, secondary: true, onPressed: () => Navigator.pushNamed(context, '/main', arguments: 3)),
          ]),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.items});
  final String title;
  final List<String> items;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SectionHeader(title: title),
          ...items.map((item) => ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.check), title: Text(item))),
        ]),
      ),
    );
  }
}
