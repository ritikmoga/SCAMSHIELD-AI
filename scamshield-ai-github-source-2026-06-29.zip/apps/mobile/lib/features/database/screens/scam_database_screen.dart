import 'package:flutter/material.dart';

import '../../../core/constants/mock_data.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/risk_badge.dart';
import '../../../shared/widgets/search_and_filter_bar.dart';
import '../../../shared/widgets/section_header.dart';
import '../widgets/false_positive_modal.dart';

class ScamDatabaseScreen extends StatefulWidget {
  const ScamDatabaseScreen({super.key, this.embed = false});
  final bool embed;

  @override
  State<ScamDatabaseScreen> createState() => _ScamDatabaseScreenState();
}

class _ScamDatabaseScreenState extends State<ScamDatabaseScreen> {
  final search = TextEditingController();
  String type = 'All';
  String risk = 'All';
  int visibleCount = 4;

  List<Map<String, dynamic>> get filtered {
    final q = search.text.toLowerCase();
    return MockData.database.where((record) {
      final text = '${record['type']} ${record['value']} ${record['description']}'.toLowerCase();
      return (q.isEmpty || text.contains(q)) && (type == 'All' || record['type'] == type) && (risk == 'All' || record['risk'] == risk);
    }).toList()
      ..sort((a, b) => '${b['lastVerified']}'.compareTo('${a['lastVerified']}'));
  }

  @override
  Widget build(BuildContext context) {
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Row(children: [SectionHeader(title: 'Scam Database'), Spacer(), DemoDataBadge()]),
        const SizedBox(height: 12),
        SearchAndFilterBar(
          searchController: search,
          onChanged: (_) => setState(() {}),
          filters: const ['All', 'URL', 'UPI', 'Phone', 'Email', 'Message Template', 'Job', 'Shopping', 'Social'],
          selectedFilter: type,
          onFilterChanged: (value) => setState(() => type = value),
          hint: 'Search indicators',
        ),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: ['All', 'Safe', 'Suspicious', 'High Risk', 'Dangerous'].map((item) => ChoiceChip(label: Text(item), selected: risk == item, onSelected: (_) => setState(() => risk = item))).toList()),
        if (filtered.isEmpty) const EmptyState(title: 'No indicators found', message: 'Try another filter or search.'),
        ...filtered.take(visibleCount).map((record) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [RiskBadge(label: record['risk']), const Spacer(), Text(record['type'])]),
                    const SizedBox(height: 8),
                    Text(record['value'], style: Theme.of(context).textTheme.titleMedium),
                    Text('Last verified ${record['lastVerified']} - ${record['sourceConfidence']} confidence'),
                    Text(record['description']),
                    const SizedBox(height: 10),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      AppButton(label: 'View details', icon: Icons.open_in_new, onPressed: () => Navigator.pushNamed(context, '/databaseDetail', arguments: record['id'])),
                      AppButton(label: 'Report false positive', icon: Icons.flag, secondary: true, onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => FalsePositiveModal(record: record))),
                      AppButton(label: 'Report similar scam', icon: Icons.report, secondary: true, onPressed: () => Navigator.pushNamed(context, '/main', arguments: 3)),
                    ]),
                  ],
                ),
              ),
            )),
        if (visibleCount < filtered.length) AppButton(label: 'Load more', icon: Icons.expand_more, secondary: true, onPressed: () => setState(() => visibleCount += 4)),
      ],
    );
    if (widget.embed) return content;
    return Scaffold(appBar: AppBar(title: const Text('Scam Database')), body: content);
  }
}
