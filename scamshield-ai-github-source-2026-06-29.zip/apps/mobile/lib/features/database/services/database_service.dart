import '../../../core/constants/mock_data.dart';

class DatabaseService {
  Future<List<Map<String, dynamic>>> load() async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    return MockData.database;
  }
}
