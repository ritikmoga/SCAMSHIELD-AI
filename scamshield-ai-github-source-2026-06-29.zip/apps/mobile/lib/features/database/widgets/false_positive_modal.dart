import 'package:flutter/material.dart';

import '../../../core/validation/validators.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_text_field.dart';

class FalsePositiveModal extends StatefulWidget {
  const FalsePositiveModal({super.key, required this.record});
  final Map<String, dynamic> record;

  @override
  State<FalsePositiveModal> createState() => _FalsePositiveModalState();
}

class _FalsePositiveModalState extends State<FalsePositiveModal> {
  final formKey = GlobalKey<FormState>();
  final reason = TextEditingController();
  final contact = TextEditingController();
  final evidence = TextEditingController();
  bool consent = false;
  bool loading = false;
  String? status;
  String? error;

  Future<void> submit() async {
    if (!(formKey.currentState?.validate() ?? false) || !consent) {
      setState(() => error = consent ? 'Fix validation errors.' : 'Consent is required.');
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    await Future<void>.delayed(const Duration(milliseconds: 450));
    setState(() {
      loading = false;
      status = 'False-positive review submitted in demo mode.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: Form(
        key: formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Report false positive: ${widget.record['value']}', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            AppTextField(controller: reason, label: 'Reason', validator: (value) => Validators.minLength(value, 8, label: 'Reason')),
            const SizedBox(height: 10),
            AppTextField(controller: contact, label: 'Optional contact', validator: Validators.emailOptional),
            const SizedBox(height: 10),
            AppTextField(controller: evidence, label: 'Optional evidence / description', maxLines: 3),
            CheckboxListTile(value: consent, onChanged: (value) => setState(() => consent = value ?? false), title: const Text('I consent to defensive review.')),
            if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            if (status != null) Text(status!),
            const SizedBox(height: 12),
            AppButton(label: loading ? 'Submitting...' : 'Submit false positive', icon: Icons.flag, onPressed: loading ? null : submit),
          ],
        ),
      ),
    );
  }
}
