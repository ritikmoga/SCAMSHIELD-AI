import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/storage/app_state.dart';
import '../../../shared/widgets/alert_card.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/section_header.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ScamShieldAppState>();
    final tip = MockData.safetyTips[DateTime.now().day % MockData.safetyTips.length];
    final latestAlert = MockData.alerts.first;
    return Scaffold(
      appBar: AppBar(title: const Text('ScamShield AI'), actions: [IconButton(onPressed: () => Navigator.pushNamed(context, '/settings'), icon: const Icon(Icons.settings))]),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Privacy-first risk guidance before you click, pay, reply, or trust.'),
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(children: [SectionHeader(title: 'Quick scan'), Spacer(), DemoDataBadge()]),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    AppButton(label: 'Scan URL', icon: Icons.link, onPressed: () => Navigator.pushNamed(context, '/scanner')),
                    AppButton(label: 'Scan Message', icon: Icons.message, secondary: true, onPressed: () => Navigator.pushNamed(context, '/scanner')),
                    AppButton(label: 'Scan QR', icon: Icons.qr_code_scanner, secondary: true, onPressed: () => Navigator.pushNamed(context, '/qr')),
                    AppButton(label: 'Scan Screenshot', icon: Icons.image_search, secondary: true, onPressed: () => Navigator.pushNamed(context, '/screenshot')),
                    AppButton(label: 'Report Scam', icon: Icons.report, secondary: true, onPressed: () => Navigator.pushNamed(context, '/main', arguments: 3)),
                    AppButton(label: 'Learn Safety', icon: Icons.school, secondary: true, onPressed: () => Navigator.pushNamed(context, '/main', arguments: 2)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'Recent scan summary'),
                Text('${state.history.length} local redacted scan(s). Demo data is shown if history is empty.'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionHeader(title: 'Safety tip of the day'), const SizedBox(height: 8), Text(tip)])),
          const SizedBox(height: 16),
          const SectionHeader(title: 'Latest scam alert'),
          const SizedBox(height: 8),
          AlertCard(alert: latestAlert),
          const SizedBox(height: 28),
          AppButton(label: 'Open main app', icon: Icons.dashboard, onPressed: () => Navigator.pushNamed(context, '/main')),
        ],
      ),
    );
  }
}
