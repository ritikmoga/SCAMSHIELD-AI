class IntegrationProvider {
  IntegrationProvider(this.data);
  final Map<String, dynamic> data;
}
