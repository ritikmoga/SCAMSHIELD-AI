import 'package:flutter/material.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/utils/clipboard_utils.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/provider_status_card.dart';
import '../../../shared/widgets/section_header.dart';

class IntegrationStatusScreen extends StatefulWidget {
  const IntegrationStatusScreen({super.key});

  @override
  State<IntegrationStatusScreen> createState() => _IntegrationStatusScreenState();
}

class _IntegrationStatusScreenState extends State<IntegrationStatusScreen> {
  String? message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Integration Status')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Row(children: [SectionHeader(title: 'Integration Hub'), Spacer(), DemoDataBadge()]),
          const SizedBox(height: 8),
          const Text('Copy env names for backend configuration. Actual API keys must never be placed inside the mobile app.'),
          if (message != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(message!)),
          const SizedBox(height: 12),
          ...MockData.providers.map((provider) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ProviderStatusCard(
                  provider: provider,
                  onCopyEnv: () => ClipboardUtils.copy(provider['envVar']),
                  onTest: () => setState(() => message = '${provider['name']} demo provider test queued.'),
                ),
              )),
        ],
      ),
    );
  }
}
