import '../../../core/constants/mock_data.dart';

class IntegrationService {
  List<Map<String, dynamic>> demoProviders() => MockData.providers;
}
