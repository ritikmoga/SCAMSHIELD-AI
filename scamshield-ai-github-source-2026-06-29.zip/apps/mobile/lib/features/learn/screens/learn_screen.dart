import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/storage/app_state.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/completion_badge.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/language_toggle.dart';
import '../../../shared/widgets/progress_tracker.dart';
import '../../../shared/widgets/section_header.dart';

class LearnScreen extends StatelessWidget {
  const LearnScreen({super.key, this.embed = false});
  final bool embed;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ScamShieldAppState>();
    final score = state.quizScores.values.fold<int>(0, (sum, value) => sum + value);
    final total = MockData.quizzes.length;
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Row(children: [SectionHeader(title: 'Interactive learning'), Spacer(), DemoDataBadge()]),
        const SizedBox(height: 10),
        const LanguageToggle(),
        const SizedBox(height: 12),
        ProgressTracker(score: state.quizScores.length, total: total),
        const SizedBox(height: 8),
        CompletionBadge(completed: state.quizScores.length >= total),
        const SizedBox(height: 12),
        AppButton(label: 'Reset progress', icon: Icons.refresh, secondary: true, onPressed: () => context.read<ScamShieldAppState>().resetQuizProgress()),
        const SizedBox(height: 16),
        ...MockData.quizzes.map((quiz) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(state.language == 'hi' ? quiz['titleHi'] : quiz['titleEn'], style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    Text('Best score: ${state.quizScores[quiz['id']] ?? 0}/1'),
                    const SizedBox(height: 10),
                    AppButton(label: 'Start quiz', icon: Icons.play_arrow, onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(quiz: quiz)))),
                  ],
                ),
              ),
            )),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionHeader(title: 'Spot the Scam Game'),
              const SizedBox(height: 8),
              Text('Score tracking: $score point(s)'),
              const SizedBox(height: 10),
              AppButton(label: 'Play mini-game', icon: Icons.extension, onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpotScamGameScreen()))),
            ],
          ),
        ),
      ],
    );
    if (embed) return content;
    return Scaffold(appBar: AppBar(title: const Text('Learn')), body: content);
  }
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.quiz});
  final Map<String, dynamic> quiz;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int? selected;
  bool revealed = false;

  @override
  Widget build(BuildContext context) {
    final language = context.watch<ScamShieldAppState>().language;
    final options = List<String>.from(language == 'hi' ? widget.quiz['optionsHi'] : widget.quiz['optionsEn']);
    final answer = widget.quiz['answer'] as int;
    final correct = selected == answer;
    return Scaffold(
      appBar: AppBar(title: Text(language == 'hi' ? widget.quiz['titleHi'] : widget.quiz['titleEn'])),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(language == 'hi' ? widget.quiz['questionHi'] : widget.quiz['questionEn'], style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 14),
                for (var i = 0; i < options.length; i++)
                  ListTile(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: selected == i ? Theme.of(context).colorScheme.primary : Colors.white12)),
                    title: Text(options[i]),
                    tileColor: revealed && i == answer ? Colors.green.withOpacity(0.2) : revealed && selected == i && selected != answer ? Colors.red.withOpacity(0.2) : null,
                    onTap: revealed ? null : () => setState(() => selected = i),
                  ),
                if (revealed) ...[
                  const SizedBox(height: 12),
                  Text(correct ? 'Correct' : 'Wrong'),
                  Text(language == 'hi' ? widget.quiz['explanationHi'] : widget.quiz['explanationEn']),
                ],
                const SizedBox(height: 12),
                AppButton(
                  label: revealed ? 'Finish quiz' : 'Submit answer',
                  icon: revealed ? Icons.check : Icons.quiz,
                  onPressed: selected == null
                      ? null
                      : () async {
                          if (!revealed) {
                            setState(() => revealed = true);
                            await context.read<ScamShieldAppState>().saveQuizScore(widget.quiz['id'], correct ? 1 : 0);
                          } else {
                            if (mounted) Navigator.pop(context);
                          }
                        },
                ),
                if (revealed) AppButton(label: 'Retry', icon: Icons.refresh, secondary: true, onPressed: () => setState(() { selected = null; revealed = false; })),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
