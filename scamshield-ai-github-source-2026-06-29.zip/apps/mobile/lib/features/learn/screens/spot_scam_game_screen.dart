import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/storage/app_state.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/completion_badge.dart';
import '../../../shared/widgets/progress_tracker.dart';
import '../../../shared/widgets/section_header.dart';

class SpotScamGameScreen extends StatefulWidget {
  const SpotScamGameScreen({super.key});

  @override
  State<SpotScamGameScreen> createState() => _SpotScamGameScreenState();
}

class _SpotScamGameScreenState extends State<SpotScamGameScreen> {
  int index = 0;
  final selected = <String>{};
  int score = 0;
  bool submitted = false;

  @override
  Widget build(BuildContext context) {
    final language = context.watch<ScamShieldAppState>().language;
    final challenge = MockData.spotChallenges[index];
    final flags = List<String>.from(challenge['flags']);
    final complete = index == MockData.spotChallenges.length - 1 && submitted;
    return Scaffold(
      appBar: AppBar(title: const Text('Spot the Scam Game')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ProgressTracker(score: score, total: MockData.spotChallenges.fold<int>(0, (sum, item) => sum + (item['flags'] as List).length)),
          const SizedBox(height: 12),
          CompletionBadge(completed: complete),
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'Scam message card'),
                const SizedBox(height: 8),
                Text(language == 'hi' ? challenge['messageHi'] : challenge['messageEn']),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: flags
                .map((flag) => FilterChip(
                      selected: selected.contains(flag),
                      label: Text(flag),
                      onSelected: submitted ? null : (_) => setState(() => selected.contains(flag) ? selected.remove(flag) : selected.add(flag)),
                    ))
                .toList(),
          ),
          const SizedBox(height: 12),
          if (submitted) AppCard(child: Text('${challenge['explanation']}\nRound score: ${selected.intersection(flags.toSet()).length}/${flags.length}')),
          const SizedBox(height: 12),
          AppButton(
            label: submitted ? (index == MockData.spotChallenges.length - 1 ? 'Reset game' : 'Next challenge') : 'Submit answer',
            icon: submitted ? Icons.arrow_forward : Icons.check,
            onPressed: () {
              if (!submitted) {
                setState(() {
                  submitted = true;
                  score += selected.intersection(flags.toSet()).length;
                });
              } else if (index == MockData.spotChallenges.length - 1) {
                setState(() {
                  index = 0;
                  score = 0;
                  selected.clear();
                  submitted = false;
                });
              } else {
                setState(() {
                  index++;
                  selected.clear();
                  submitted = false;
                });
              }
            },
          ),
        ],
      ),
    );
  }
}
