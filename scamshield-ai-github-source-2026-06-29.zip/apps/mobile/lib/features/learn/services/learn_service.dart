import '../../../core/constants/mock_data.dart';

class LearnService {
  List<Map<String, dynamic>> quizzes() => MockData.quizzes;
  List<Map<String, dynamic>> challenges() => MockData.spotChallenges;
}
