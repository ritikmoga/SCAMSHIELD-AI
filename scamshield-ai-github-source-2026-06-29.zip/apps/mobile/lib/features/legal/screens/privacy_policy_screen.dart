import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Policy')),
      body: const ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text('ScamShield AI Privacy Policy', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          Text('The app gives risk guidance, not guarantees. Raw scan input is not stored by default. Sensitive values are redacted before local saving. Demo data may be shown when backend is unavailable. Users should never enter OTP, UPI PIN, CVV, passwords, or full identity documents. API keys must remain server-side only.'),
        ],
      ),
    );
  }
}
