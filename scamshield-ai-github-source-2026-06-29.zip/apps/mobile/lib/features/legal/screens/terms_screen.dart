import 'package:flutter/material.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Terms of Use')),
      body: const ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text('ScamShield AI Terms of Use', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          Text('ScamShield AI provides defensive risk guidance and safer next steps. It does not guarantee detection and is not a substitute for official verification. Do not use this app for offensive security activity, unauthorized scanning, or harmful behavior.'),
        ],
      ),
    );
  }
}
