import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/storage/app_state.dart';
import '../../../shared/widgets/app_button.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final controller = PageController();
  int page = 0;
  final pages = const [
    (
      'Scan suspicious links, messages, QR codes, and UPI IDs',
      'Check risky content before you click, pay, reply, or trust it.',
      Icons.radar
    ),
    (
      'Learn scam red flags before sending money',
      'Understand phishing, fake KYC, UPI fraud, QR scams, job scams, and fake shopping traps.',
      Icons.school
    ),
    (
      'Report scams anonymously and help others stay safe',
      'Submit suspicious indicators with privacy-first redaction and demo moderation flow.',
      Icons.report
    ),
  ];

  Future<void> finish() async {
    await context.read<ScamShieldAppState>().completeOnboarding();
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, '/home');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Align(alignment: Alignment.centerRight, child: TextButton(onPressed: finish, child: const Text('Skip'))),
              Expanded(
                child: PageView.builder(
                  controller: controller,
                  onPageChanged: (value) => setState(() => page = value),
                  itemCount: pages.length,
                  itemBuilder: (context, index) {
                    final item = pages[index];
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item.$3, size: 92),
                        const SizedBox(height: 24),
                        Text(item.$1, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
                        const SizedBox(height: 14),
                        Text(item.$2, textAlign: TextAlign.center),
                      ],
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(pages.length, (index) => Container(width: page == index ? 24 : 8, height: 8, margin: const EdgeInsets.all(4), decoration: BoxDecoration(color: page == index ? Theme.of(context).colorScheme.primary : Colors.white24, borderRadius: BorderRadius.circular(999)))),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  if (page > 0) Expanded(child: AppButton(label: 'Back', icon: Icons.arrow_back, secondary: true, onPressed: () => controller.previousPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut))) else const Expanded(child: SizedBox()),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AppButton(
                      label: page == pages.length - 1 ? 'Get Started' : 'Next',
                      icon: page == pages.length - 1 ? Icons.check : Icons.arrow_forward,
                      onPressed: page == pages.length - 1 ? finish : () => controller.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
