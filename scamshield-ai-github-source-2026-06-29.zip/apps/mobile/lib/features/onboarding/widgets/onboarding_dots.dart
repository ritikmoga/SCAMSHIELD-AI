import 'package:flutter/material.dart';

class OnboardingDots extends StatelessWidget {
  const OnboardingDots({super.key, required this.index, required this.count});
  final int index;
  final int count;
  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(count, (i) => Icon(Icons.circle, size: i == index ? 10 : 7)));
}
