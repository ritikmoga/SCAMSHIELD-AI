import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../shared/models/scan_result.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/section_header.dart';
import '../../scanner/services/risk_engine_service.dart';
import '../services/qr_scan_service.dart';

class QrScannerScreen extends StatefulWidget {
  const QrScannerScreen({super.key});

  @override
  State<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen> {
  final controller = TextEditingController(text: QrScanService.demoPayload);
  bool cameraAllowed = false;
  bool scanning = false;
  String? error;
  ScanResult? result;

  Future<void> requestPermission() async {
    final status = await Permission.camera.request();
    setState(() {
      cameraAllowed = status.isGranted;
      error = status.isGranted ? null : 'Camera permission denied. You can paste QR payload manually.';
    });
  }

  void scanPayload(String payload) {
    setState(() {
      controller.text = payload;
      result = RiskEngineService.createScanResult(inputType: 'qr', rawInput: payload);
      scanning = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('QR Scanner')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const AppCard(
            child: Text('Camera permission is used only to read QR payloads. ScamShield never opens links or starts payment intents automatically.'),
          ),
          const SizedBox(height: 12),
          if (!cameraAllowed)
            AppButton(label: 'Request camera permission', icon: Icons.camera_alt, onPressed: requestPermission)
          else
            SizedBox(
              height: 260,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: MobileScanner(
                  onDetect: (capture) {
                    final value = capture.barcodes.isEmpty ? null : capture.barcodes.first.rawValue;
                    if (value != null && value.isNotEmpty) scanPayload(value);
                  },
                ),
              ),
            ),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'Manual QR payload'),
                const SizedBox(height: 10),
                TextField(controller: controller, minLines: 4, maxLines: 8),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    AppButton(label: 'Analyze payload', icon: Icons.radar, onPressed: () => scanPayload(controller.text)),
                    AppButton(label: 'Load demo QR', icon: Icons.refresh, secondary: true, onPressed: () => scanPayload(QrScanService.demoPayload)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (scanning) const Center(child: CircularProgressIndicator()),
          if (result != null) ScanResultCard(result: result!, onScanAgain: () => setState(() => result = null)),
        ],
      ),
    );
  }
}
