class QrScanService {
  static const demoPayload = 'upi://pay?pa=refund-helpdesk@oksbi&pn=Refund%20Desk&am=4999&cu=INR';
}
