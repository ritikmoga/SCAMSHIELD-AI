import 'package:flutter/material.dart';

class QrPermissionCard extends StatelessWidget {
  const QrPermissionCard({super.key});
  @override
  Widget build(BuildContext context) => const Text('Camera permission is used only to decode QR payloads.');
}
