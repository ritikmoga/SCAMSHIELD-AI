class ScamReport {
  ScamReport(this.data);
  final Map<String, dynamic> data;
}
