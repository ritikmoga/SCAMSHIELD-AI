import 'package:flutter/material.dart';

import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/section_header.dart';
import '../widgets/report_form.dart';

class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key, this.embed = false});
  final bool embed;

  @override
  Widget build(BuildContext context) {
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        Row(children: [SectionHeader(title: 'Report Scam'), Spacer(), DemoDataBadge()]),
        SizedBox(height: 12),
        AppCard(child: ReportForm()),
      ],
    );
    if (embed) return content;
    return Scaffold(appBar: AppBar(title: const Text('Report Scam')), body: content);
  }
}
