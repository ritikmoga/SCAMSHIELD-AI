import '../../../core/network/api_client.dart';

class ReportService {
  ReportService({ApiClient? client}) : client = client ?? ApiClient();
  final ApiClient client;

  Future<bool> submit(Map<String, dynamic> payload) async {
    final result = await client.postJson('/report', payload);
    return result.isSuccess;
  }
}
