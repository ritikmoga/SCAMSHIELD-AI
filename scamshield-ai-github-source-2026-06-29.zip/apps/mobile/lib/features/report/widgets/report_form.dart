import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/security/redaction_service.dart';
import '../../../core/storage/app_state.dart';
import '../../../core/validation/validators.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_text_field.dart';

class ReportForm extends StatefulWidget {
  const ReportForm({super.key});

  @override
  State<ReportForm> createState() => _ReportFormState();
}

class _ReportFormState extends State<ReportForm> {
  final formKey = GlobalKey<FormState>();
  final value = TextEditingController();
  final description = TextEditingController();
  final contact = TextEditingController();
  String type = 'URL';
  String platform = 'SMS';
  bool anonymous = true;
  bool consent = false;
  bool loading = false;
  String? status;
  String? error;
  String screenshotName = '';

  final reportTypes = const ['URL', 'UPI ID', 'Phone Number', 'Email', 'Message', 'QR Code', 'Job Offer', 'Shopping Website', 'Social Profile', 'Other'];
  final platforms = const ['SMS', 'WhatsApp', 'Telegram', 'Instagram', 'Facebook', 'Email', 'Website', 'Phone Call', 'Other'];

  Future<void> submit() async {
    setState(() {
      status = null;
      error = null;
    });
    if (!(formKey.currentState?.validate() ?? false) || !consent) {
      setState(() => error = consent ? 'Fix validation errors before submitting.' : 'Consent is required for moderator review.');
      return;
    }
    setState(() => loading = true);
    final report = {
      'type': type,
      'valuePreview': RedactionService.preview(value.text),
      'description': RedactionService.preview(description.text, maxLength: 260),
      'sourcePlatform': platform,
      'userContactPublic': false,
      'anonymous': anonymous,
      'screenshot': screenshotName,
      'createdAt': DateTime.now().toIso8601String(),
    };
    await Future<void>.delayed(const Duration(milliseconds: 500));
    await context.read<ScamShieldAppState>().saveReport(report);
    setState(() {
      loading = false;
      status = 'Report saved in demo moderation queue. Reports are redacted and reviewed before becoming verified indicators.';
      value.clear();
      description.clear();
      contact.clear();
      screenshotName = '';
      consent = false;
      anonymous = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DropdownButtonFormField(value: type, decoration: const InputDecoration(labelText: 'Report type'), items: reportTypes.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(), onChanged: (value) => setState(() => type = value ?? type)),
          const SizedBox(height: 12),
          AppTextField(controller: value, label: 'Suspicious value', hint: 'URL, UPI ID, phone, email, QR payload, or message', validator: (text) => Validators.minLength(text, 3, label: 'Suspicious value')),
          const SizedBox(height: 8),
          Text('Redacted preview: ${RedactionService.preview(value.text)}'),
          const SizedBox(height: 12),
          AppTextField(controller: description, label: 'Description', maxLines: 5, validator: (text) => Validators.minLength(text, 12, label: 'Description')),
          const SizedBox(height: 12),
          DropdownButtonFormField(value: platform, decoration: const InputDecoration(labelText: 'Source platform'), items: platforms.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(), onChanged: (value) => setState(() => platform = value ?? platform)),
          const SizedBox(height: 12),
          AppButton(label: screenshotName.isEmpty ? 'Attach optional screenshot' : screenshotName, icon: Icons.upload_file, secondary: true, onPressed: () => setState(() => screenshotName = 'demo-evidence.png')),
          const SizedBox(height: 12),
          AppTextField(controller: contact, label: 'Optional user contact', enabled: !anonymous, validator: Validators.emailOptional),
          CheckboxListTile(value: anonymous, onChanged: (value) => setState(() => anonymous = value ?? true), title: const Text('Submit anonymously')),
          CheckboxListTile(value: consent, onChanged: (value) => setState(() => consent = value ?? false), title: const Text('I consent to defensive moderator review.')),
          const Text('Privacy note: Reports are redacted and reviewed before becoming verified indicators. User contact is not shown publicly.'),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          if (status != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(status!)),
          const SizedBox(height: 12),
          AppButton(label: loading ? 'Submitting...' : 'Submit report', icon: Icons.report, onPressed: loading ? null : submit),
        ],
      ),
    );
  }
}
