class ScannerInputType {
  const ScannerInputType(this.id, this.label);
  final String id;
  final String label;
}
