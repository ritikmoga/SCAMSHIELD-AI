import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/mock_data.dart';
import '../../../shared/models/scan_result.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/section_header.dart';
import '../services/risk_engine_service.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key, this.embed = false, this.initialType = 'message', this.initialInput});
  final bool embed;
  final String initialType;
  final String? initialInput;

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  late String inputType = widget.initialType;
  late final controller = TextEditingController(text: widget.initialInput ?? MockData.samples[widget.initialType] ?? '');
  String state = 'Idle';
  String? error;
  ScanResult? result;
  final types = const ['url', 'message', 'email', 'upi', 'qr', 'phone', 'screenshot', 'job', 'shopping', 'social'];

  Future<void> runScan() async {
    setState(() {
      state = 'Validating';
      error = null;
      result = null;
    });
    if (controller.text.trim().isEmpty) {
      setState(() {
        state = 'Error';
        error = 'Add suspicious content before running a scan.';
      });
      return;
    }
    setState(() => state = 'Scanning');
    await Future<void>.delayed(const Duration(milliseconds: 450));
    try {
      final scan = RiskEngineService.createScanResult(inputType: inputType, rawInput: controller.text);
      setState(() {
        result = scan;
        state = 'Completed';
      });
    } catch (_) {
      setState(() {
        state = 'Error';
        error = 'The local risk engine could not analyze this input. Try a shorter sample.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionHeader(title: 'Unified scanner'),
              const SizedBox(height: 8),
              const Text(AppConstants.privacyWarning),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: inputType,
                items: types.map((type) => DropdownMenuItem(value: type, child: Text(_label(type)))).toList(),
                onChanged: (value) => setState(() {
                  inputType = value ?? inputType;
                  controller.text = MockData.samples[inputType] ?? '';
                  result = null;
                  state = 'Idle';
                }),
                decoration: const InputDecoration(labelText: 'Input type'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                minLines: 6,
                maxLines: 12,
                decoration: const InputDecoration(labelText: 'Suspicious content', hintText: 'Paste URL, SMS, email, UPI ID, QR payload, phone script, or social profile text.'),
              ),
              const SizedBox(height: 12),
              Text('State: $state'),
              if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  AppButton(label: 'Paste', icon: Icons.paste, secondary: true, onPressed: () async {
                    final data = await Clipboard.getData('text/plain');
                    if (data?.text != null) setState(() => controller.text = data!.text!);
                  }),
                  AppButton(label: 'Clear', icon: Icons.clear, secondary: true, onPressed: () => setState(() => controller.clear())),
                  AppButton(label: 'Load sample', icon: Icons.refresh, secondary: true, onPressed: () => setState(() => controller.text = MockData.samples[inputType] ?? '')),
                  AppButton(label: state == 'Scanning' ? 'Scanning...' : 'Scan', icon: Icons.radar, onPressed: state == 'Scanning' ? null : runScan),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const SectionHeader(title: 'Recent samples'),
        const SizedBox(height: 8),
        ...MockData.samples.entries.take(4).map((sample) => ListTile(
              title: Text(_label(sample.key)),
              subtitle: Text(sample.value, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () => setState(() {
                inputType = sample.key;
                controller.text = sample.value;
              }),
            )),
        const SizedBox(height: 16),
        if (state == 'Idle') const EmptyState(title: 'Ready for risk guidance', message: 'Run a scan to see score, verdict, indicators, explanation, and safer next steps.'),
        if (state == 'Scanning') const Center(child: CircularProgressIndicator()),
        if (result != null) ScanResultCard(result: result!, onScanAgain: () => setState(() => result = null)),
      ],
    );
    if (widget.embed) return content;
    return Scaffold(appBar: AppBar(title: const Text('Scanner')), body: content);
  }

  String _label(String type) {
    const labels = {
      'url': 'URL / Link',
      'message': 'SMS / WhatsApp Message',
      'email': 'Email',
      'upi': 'UPI ID',
      'qr': 'QR Payload',
      'phone': 'Phone Number',
      'screenshot': 'Screenshot Text',
      'job': 'Job Offer',
      'shopping': 'Shopping Website',
      'social': 'Social Profile',
    };
    return labels[type] ?? type;
  }
}
