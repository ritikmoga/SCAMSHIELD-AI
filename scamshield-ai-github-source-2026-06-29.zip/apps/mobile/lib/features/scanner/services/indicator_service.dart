import '../../../shared/models/extracted_indicators.dart';

class IndicatorService {
  static ExtractedIndicators extractIndicators(String input) {
    final urls = _matches(input, RegExp(r'\bhttps?:\/\/[^\s<>]+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s<>]+)?', caseSensitive: false))
        .map(_normalizeUrl)
        .toSet()
        .toList();
    final domains = urls.map((url) {
      try {
        return Uri.parse(url).host.toLowerCase();
      } catch (_) {
        return url;
      }
    }).where((domain) => domain.isNotEmpty).toSet().toList();
    final emails = _matches(input, RegExp(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', caseSensitive: false)).toSet().toList();
    final phones = _matches(input, RegExp(r'(?:\+?91[\s-]?)?[6-9]\d{9}\b')).toSet().toList();
    final upiIds = _matches(input, RegExp(r'\b[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}\b')).toSet().toList();
    final suspicious = _keywords(input, ['otp', 'upi pin', 'cvv', 'password', 'urgent', 'limited time', 'account blocked', 'kyc expires', 'refund', 'collect request', 'remote access', 'apk']);
    final payments = _keywords(input, ['upi', 'refund', 'collect', 'payment', 'cashback', 'loan', 'deposit', 'security fee']);
    final brands = _keywords(input, ['paytm', 'phonepe', 'gpay', 'sbi', 'hdfc', 'icici', 'axis', 'amazon', 'flipkart', 'whatsapp', 'telegram']);

    return ExtractedIndicators(
      urls: urls,
      domains: domains,
      emails: emails,
      phoneNumbers: phones,
      upiIds: upiIds,
      suspiciousKeywords: suspicious,
      paymentWords: payments,
      brandTerms: brands,
    );
  }

  static List<String> _matches(String input, RegExp pattern) {
    return pattern.allMatches(input).map((match) => match.group(0) ?? '').where((value) => value.isNotEmpty).toList();
  }

  static List<String> _keywords(String input, List<String> words) {
    final lower = input.toLowerCase();
    return words.where((word) => lower.contains(word)).toSet().toList();
  }

  static String _normalizeUrl(String raw) {
    final trimmed = raw.replaceAll(RegExp(r'[),.;]+$'), '');
    if (trimmed.startsWith(RegExp(r'https?://', caseSensitive: false))) return trimmed;
    return 'https://$trimmed';
  }
}
