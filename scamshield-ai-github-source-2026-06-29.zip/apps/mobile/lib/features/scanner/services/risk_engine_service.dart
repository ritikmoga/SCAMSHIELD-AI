import '../../../core/security/redaction_service.dart';
import '../../../shared/models/extracted_indicators.dart';
import '../../../shared/models/risk_flag.dart';
import '../../../shared/models/scan_result.dart';
import 'indicator_service.dart';

class RiskEngineService {
  static String normalizeInput(String input) => input.trim().replaceAll(RegExp(r'\s+'), ' ');

  static String redactSensitiveSecrets(String input) => RedactionService.redactSensitiveSecrets(input);

  static ExtractedIndicators extractIndicators(String input) => IndicatorService.extractIndicators(input);

  static List<RiskFlag> runHeuristicChecks(String input, ExtractedIndicators indicators, {String inputType = 'message'}) {
    final flags = <RiskFlag>[];
    final lower = input.toLowerCase();
    _add(flags, lower, RegExp(r'\botp\b|one[-\s]?time password|verification code|share.*code', caseSensitive: false), 'Requests OTP or verification code', 'critical', 34);
    _add(flags, lower, RegExp(r'upi\s*pin|enter.*pin|pin डाल|collect request', caseSensitive: false), 'Asks for UPI PIN or collect request', 'critical', 38);
    _add(flags, lower, RegExp(r'\bcvv\b|card pin|card number|password|passcode', caseSensitive: false), 'Requests card, CVV, PIN, or password', 'critical', 36);
    _add(flags, lower, RegExp(r'account.*blocked|kyc.*expire|urgent|limited time|last chance|expires today', caseSensitive: false), 'Uses urgency or account-block pressure', 'high', 24);
    _add(flags, lower, RegExp(r'registration fee|security deposit|processing fee|interview.*fee|pay.*before.*interview', caseSensitive: false), 'Job offer asks for a fee or deposit', 'critical', 36);
    _add(flags, lower, RegExp(r'refund|collect request|cashback|receive money', caseSensitive: false), 'Uses refund or collect-request language', 'high', 24);
    _add(flags, lower, RegExp(r'customer care|helpline|support number', caseSensitive: false), 'Unknown customer-care framing', 'medium', 16);
    _add(flags, lower, RegExp(r'anydesk|teamviewer|screen share|remote access', caseSensitive: false), 'Requests remote access or screen sharing', 'critical', 36);
    _add(flags, lower, RegExp(r'download.*apk|install.*apk|unknown apk', caseSensitive: false), 'Unknown APK download request', 'critical', 36);
    _add(flags, lower, RegExp(r'lottery|prize|winner|claim.*fee', caseSensitive: false), 'Prize or lottery fee lure', 'critical', 32);
    _add(flags, lower, RegExp(r'guaranteed returns|double your money|investment.*return', caseSensitive: false), 'Guaranteed investment return claim', 'critical', 34);
    _add(flags, lower, RegExp(r'loan.*approval.*fee|pay.*loan.*fee', caseSensitive: false), 'Loan approval fee request', 'critical', 34);

    if (indicators.urls.any((url) => RegExp(r'bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|cutt\.ly|rebrand\.ly', caseSensitive: false).hasMatch(url))) {
      flags.add(const RiskFlag(id: 'short-url', label: 'Shortened URL hides the destination', severity: 'medium', points: 18));
    }
    for (final domain in indicators.domains) {
      final brandy = RegExp(r'(paytm|phonepe|gpay|sbi|hdfc|icici|axis|amazon|flipkart|whatsapp|telegram)', caseSensitive: false).hasMatch(domain);
      if (brandy && !_isOfficialDomain(domain)) {
        flags.add(RiskFlag(id: 'brand-lookalike-$domain', label: 'Possible brand lookalike domain', severity: 'critical', points: 40, evidence: domain));
      }
    }
    if (inputType == 'email' && RegExp(r'reply-to:.*@(gmail|yahoo|outlook|hotmail)\.', caseSensitive: false).hasMatch(input)) {
      flags.add(const RiskFlag(id: 'free-mail-replyto', label: 'Company-looking email replies to free mail', severity: 'medium', points: 18));
    }
    if (inputType == 'qr' && RegExp(r'upi://pay', caseSensitive: false).hasMatch(input) && RegExp(r'collect|am=|pa=', caseSensitive: false).hasMatch(input)) {
      flags.add(const RiskFlag(id: 'qr-payment-intent', label: 'QR payload contains payment intent', severity: 'critical', points: 42));
    }
    return _dedupe(flags);
  }

  static int calculateRiskScore(List<RiskFlag> flags) {
    final base = flags.fold<double>(0, (sum, flag) => sum + flag.points * _multiplier(flag.severity));
    final floor = flags.any((flag) => flag.severity == 'critical')
        ? 72
        : flags.any((flag) => flag.severity == 'high')
            ? 48
            : flags.any((flag) => flag.severity == 'medium')
                ? 32
                : 0;
    return base.round().clamp(floor, 100).toInt();
  }

  static String getVerdict(int score) {
    if (score >= 70) return 'Dangerous';
    if (score >= 35) return 'Suspicious';
    return 'Safe';
  }

  static String getConfidence(List<RiskFlag> flags, ExtractedIndicators indicators) {
    final value = 50 + (flags.length * 7).clamp(0, 34) + ([...indicators.urls, ...indicators.upiIds, ...indicators.phoneNumbers].length * 4).clamp(0, 16);
    if (value >= 75) return 'High';
    if (value >= 56) return 'Medium';
    return 'Low';
  }

  static String generateHumanExplanation(ScanResult result) {
    if (result.redFlags.isEmpty) {
      return 'No strong scam pattern was detected. This is risk guidance, not a guarantee, so verify independently before acting.';
    }
    final top = result.redFlags.take(3).map((flag) => flag.label.toLowerCase()).join(', ');
    return 'This looks ${result.verdict.toLowerCase()} because ScamShield found $top. Verify through the official app, website, or phone number before clicking, paying, or replying.';
  }

  static ScanResult createScanResult({required String inputType, required String rawInput}) {
    final normalized = normalizeInput(rawInput);
    final indicators = extractIndicators(normalized);
    final flags = runHeuristicChecks(normalized, indicators, inputType: inputType)
        .map((flag) => RiskFlag(id: flag.id, label: flag.label, severity: flag.severity, points: flag.points, evidence: flag.evidence == null ? null : redactSensitiveSecrets(flag.evidence!)))
        .toList();
    final score = calculateRiskScore(flags);
    final verdict = getVerdict(score);
    final redactedPreview = RedactionService.preview(normalized, maxLength: 220);
    final shell = ScanResult(
      id: 'scan-${DateTime.now().millisecondsSinceEpoch}',
      inputType: inputType,
      timestamp: DateTime.now(),
      redactedPreview: redactedPreview,
      riskScore: score,
      verdict: verdict,
      confidence: getConfidence(flags, indicators),
      redFlags: flags,
      extractedIndicators: indicators,
      explanation: '',
      saferNextSteps: _nextSteps(verdict, inputType),
      demoMode: true,
      source: 'local-risk-engine',
    );
    return ScanResult(
      id: shell.id,
      inputType: shell.inputType,
      timestamp: shell.timestamp,
      redactedPreview: shell.redactedPreview,
      riskScore: shell.riskScore,
      verdict: shell.verdict,
      confidence: shell.confidence,
      redFlags: shell.redFlags,
      extractedIndicators: shell.extractedIndicators,
      explanation: generateHumanExplanation(shell),
      saferNextSteps: shell.saferNextSteps,
      demoMode: true,
      source: 'local-risk-engine',
    );
  }

  static void _add(List<RiskFlag> flags, String lowerInput, RegExp pattern, String label, String severity, int points) {
    final match = pattern.firstMatch(lowerInput);
    if (match != null) {
      flags.add(RiskFlag(id: label.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-'), label: label, severity: severity, points: points, evidence: match.group(0)));
    }
  }

  static List<RiskFlag> _dedupe(List<RiskFlag> flags) {
    final map = <String, RiskFlag>{};
    for (final flag in flags) {
      if (!map.containsKey(flag.id) || map[flag.id]!.points < flag.points) map[flag.id] = flag;
    }
    return map.values.toList()..sort((a, b) => b.points.compareTo(a.points));
  }

  static double _multiplier(String severity) {
    if (severity == 'critical') return 1.15;
    if (severity == 'high') return 1.0;
    if (severity == 'medium') return 0.76;
    return 0.45;
  }

  static bool _isOfficialDomain(String domain) {
    const official = ['paytm.com', 'phonepe.com', 'google.com', 'googlepay.com', 'sbi.co.in', 'hdfcbank.com', 'icicibank.com', 'axisbank.com', 'amazon.in', 'amazon.com', 'flipkart.com', 'whatsapp.com', 'telegram.org'];
    return official.any((item) => domain == item || domain.endsWith('.$item'));
  }

  static List<String> _nextSteps(String verdict, String inputType) {
    final steps = [
      'Do not share OTP, UPI PIN, CVV, passwords, or full identity documents.',
      'Verify through the official app, website, or a phone number you found independently.',
    ];
    if (verdict == 'Dangerous') steps.insert(0, 'Stop immediately. Do not click links, pay money, scan QR codes, or install apps.');
    if (verdict == 'Suspicious') steps.insert(0, 'Pause before acting. Treat this request as suspicious until verified.');
    if (inputType == 'upi' || inputType == 'qr') steps.add('Receiving money never requires entering a UPI PIN.');
    if (inputType == 'job') steps.add('Do not pay registration, laptop, training, or security fees for a job offer.');
    return steps;
  }
}
