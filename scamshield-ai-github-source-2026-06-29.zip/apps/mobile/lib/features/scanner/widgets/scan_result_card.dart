export '../../../shared/widgets/scan_result_card.dart';
