import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../core/constants/mock_data.dart';
import '../../../shared/models/scan_result.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/section_header.dart';
import '../../scanner/services/risk_engine_service.dart';
import '../services/ocr_service.dart';

class ScreenshotScannerScreen extends StatefulWidget {
  const ScreenshotScannerScreen({super.key});

  @override
  State<ScreenshotScannerScreen> createState() => _ScreenshotScannerScreenState();
}

class _ScreenshotScannerScreenState extends State<ScreenshotScannerScreen> {
  final textController = TextEditingController(text: MockData.samples['screenshot']);
  final picker = ImagePicker();
  final ocr = OcrService();
  File? image;
  bool loading = false;
  String? error;
  ScanResult? result;

  Future<void> pick(ImageSource source) async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      if (source == ImageSource.camera) await Permission.camera.request();
      final picked = await picker.pickImage(source: source, imageQuality: 78);
      if (picked == null) {
        setState(() => loading = false);
        return;
      }
      image = File(picked.path);
      textController.text = await ocr.extractText(picked.path);
    } catch (_) {
      error = 'Image selection or OCR failed. You can paste screenshot text manually.';
    }
    setState(() => loading = false);
  }

  void analyze() {
    setState(() => result = RiskEngineService.createScanResult(inputType: 'screenshot', rawInput: textController.text));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Screenshot Scanner')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'Upload or capture screenshot'),
                const SizedBox(height: 8),
                const Text('OCR is demo-ready. Correct extracted text before scanning. Images are not executed and links are not opened.'),
                const SizedBox(height: 12),
                if (image != null) ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(image!, height: 180, fit: BoxFit.cover)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    AppButton(label: 'Pick from gallery', icon: Icons.photo, onPressed: () => pick(ImageSource.gallery)),
                    AppButton(label: 'Capture image', icon: Icons.camera_alt, secondary: true, onPressed: () => pick(ImageSource.camera)),
                    AppButton(label: 'Load demo text', icon: Icons.refresh, secondary: true, onPressed: () => setState(() => textController.text = MockData.samples['screenshot']!)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(controller: textController, minLines: 6, maxLines: 12, decoration: const InputDecoration(labelText: 'OCR text / manual correction')),
          const SizedBox(height: 12),
          if (loading) const Center(child: CircularProgressIndicator()),
          if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          AppButton(label: 'Analyze screenshot text', icon: Icons.radar, onPressed: analyze),
          const SizedBox(height: 16),
          if (result != null) ScanResultCard(result: result!, onScanAgain: () => setState(() => result = null)),
        ],
      ),
    );
  }
}
