class OcrService {
  Future<String> extractText(String imagePath) async {
    await Future<void>.delayed(const Duration(milliseconds: 700));
    return 'Demo OCR text from screenshot: delivery failed, pay Rs 2 at http://shorturl.example/pay and enter card details.';
  }
}
