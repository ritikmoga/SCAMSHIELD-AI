import 'package:flutter/material.dart';

class ScreenshotPreviewCard extends StatelessWidget {
  const ScreenshotPreviewCard({super.key, required this.label});
  final String label;
  @override
  Widget build(BuildContext context) => Text(label);
}
