class ProviderStatus {
  ProviderStatus(this.data);
  final Map<String, dynamic> data;
}
