import 'package:flutter/material.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/utils/clipboard_utils.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/provider_status_card.dart';
import '../../../shared/widgets/section_header.dart';

class SecurityLabScreen extends StatefulWidget {
  const SecurityLabScreen({super.key});

  @override
  State<SecurityLabScreen> createState() => _SecurityLabScreenState();
}

class _SecurityLabScreenState extends State<SecurityLabScreen> {
  bool loading = false;
  String? message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Security Lab')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Row(children: [SectionHeader(title: 'Provider status'), Spacer(), DemoDataBadge()]),
          const SizedBox(height: 8),
          const Text('Advanced defensive section. API keys stay server-side; the app only shows environment variable names.'),
          if (loading) const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator())),
          if (message != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(message!)),
          const SizedBox(height: 12),
          ...MockData.providers.map((provider) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ProviderStatusCard(
                  provider: provider,
                  onCopyEnv: () => ClipboardUtils.copy(provider['envVar']),
                  onTest: () => setState(() => message = '${provider['name']} demo test completed safely.'),
                ),
              )),
        ],
      ),
    );
  }
}
