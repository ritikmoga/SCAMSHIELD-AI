import '../../../core/constants/mock_data.dart';
import '../../../core/network/api_client.dart';

class SecurityLabService {
  SecurityLabService({ApiClient? client}) : client = client ?? ApiClient();
  final ApiClient client;

  Future<List<Map<String, dynamic>>> providers() async {
    final result = await client.getJson('/integrations/status');
    if (result.isSuccess && result.data?['providers'] is List) {
      return List<Map<String, dynamic>>.from((result.data!['providers'] as List).map((item) => Map<String, dynamic>.from(item)));
    }
    return MockData.providers;
  }
}
