import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/storage/app_state.dart';
import '../../../core/utils/clipboard_utils.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/confirm_dialog.dart';
import '../../../shared/widgets/demo_data_badge.dart';
import '../../../shared/widgets/section_header.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<ScamShieldAppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Row(children: [SectionHeader(title: 'Settings'), Spacer(), DemoDataBadge()]),
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Theme mode'),
                const Text('Dark / System. Dark mode is active for the cyber-security theme.'),
                const SizedBox(height: 12),
                SegmentedButton<String>(
                  segments: const [ButtonSegment(value: 'en', label: Text('English')), ButtonSegment(value: 'hi', label: Text('Hindi'))],
                  selected: {app.language},
                  onSelectionChanged: (value) => app.setLanguage(value.first),
                ),
                SwitchListTile(value: app.saveRedactedHistory, onChanged: app.setSaveRedactedHistory, title: const Text('Save redacted scan history')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'Privacy settings'),
                AppButton(label: 'Delete local scan history', icon: Icons.delete, destructive: true, onPressed: () async { if (await showConfirmDialog(context, title: 'Clear history?', message: 'This deletes local redacted scan history.')) app.clearHistory(); }),
                AppButton(label: 'Clear local reports', icon: Icons.report, secondary: true, onPressed: app.clearReports),
                AppButton(label: 'Clear quiz progress', icon: Icons.school, secondary: true, onPressed: app.resetQuizProgress),
                AppButton(label: 'Clear followed alerts', icon: Icons.notifications_off, secondary: true, onPressed: app.clearFollowedAlerts),
                AppButton(label: 'Export local data', icon: Icons.download, secondary: true, onPressed: () => ClipboardUtils.copy(app.exportHistoryJson())),
                AppButton(label: 'Delete all local data', icon: Icons.delete_forever, destructive: true, onPressed: () async {
                  if (await showConfirmDialog(context, title: 'Delete all local data?', message: 'This clears history, reports, progress, and followed alerts.')) {
                    await app.clearHistory();
                    await app.clearReports();
                    await app.resetQuizProgress();
                    await app.clearFollowedAlerts();
                  }
                }),
              ],
            ),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'About app'),
                const Text('ScamShield AI gives risk guidance, safer next steps, and layered security education. It does not guarantee detection.'),
                const SizedBox(height: 8),
                const Text('Contact support: support@example.com'),
                const Text('App version: ${AppConstants.version}'),
                const Text('Demo mode indicator: Demo data may appear when backend is unavailable.'),
                TextButton(onPressed: () => Navigator.pushNamed(context, '/terms'), child: const Text('Terms & Privacy')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
