class SettingsService {
  const SettingsService();
}
