import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/storage/app_state.dart';
import '../../../core/theme/app_colors.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      final state = context.read<ScamShieldAppState>();
      Navigator.pushReplacementNamed(context, state.onboardingComplete ? '/home' : '/onboarding');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          radialGradient: RadialGradient(colors: [Color(0xFF143928), AppColors.background], radius: 1.2),
        ),
        child: const SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.shield, size: 96, color: AppColors.primary),
              SizedBox(height: 20),
              Text(AppConstants.appName, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 34),
                child: Text(AppConstants.tagline, textAlign: TextAlign.center),
              ),
              SizedBox(height: 28),
              CircularProgressIndicator(),
            ],
          ),
        ),
      ),
    );
  }
}
