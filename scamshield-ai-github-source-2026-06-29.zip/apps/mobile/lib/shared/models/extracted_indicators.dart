class ExtractedIndicators {
  const ExtractedIndicators({
    this.urls = const [],
    this.domains = const [],
    this.emails = const [],
    this.phoneNumbers = const [],
    this.upiIds = const [],
    this.suspiciousKeywords = const [],
    this.paymentWords = const [],
    this.brandTerms = const [],
  });

  final List<String> urls;
  final List<String> domains;
  final List<String> emails;
  final List<String> phoneNumbers;
  final List<String> upiIds;
  final List<String> suspiciousKeywords;
  final List<String> paymentWords;
  final List<String> brandTerms;

  Map<String, dynamic> toJson() => {
        'urls': urls,
        'domains': domains,
        'emails': emails,
        'phoneNumbers': phoneNumbers,
        'upiIds': upiIds,
        'suspiciousKeywords': suspiciousKeywords,
        'paymentWords': paymentWords,
        'brandTerms': brandTerms,
      };

  factory ExtractedIndicators.fromJson(Map<String, dynamic> json) => ExtractedIndicators(
        urls: List<String>.from(json['urls'] ?? const []),
        domains: List<String>.from(json['domains'] ?? const []),
        emails: List<String>.from(json['emails'] ?? const []),
        phoneNumbers: List<String>.from(json['phoneNumbers'] ?? const []),
        upiIds: List<String>.from(json['upiIds'] ?? const []),
        suspiciousKeywords: List<String>.from(json['suspiciousKeywords'] ?? const []),
        paymentWords: List<String>.from(json['paymentWords'] ?? const []),
        brandTerms: List<String>.from(json['brandTerms'] ?? const []),
      );
}
