class RiskFlag {
  const RiskFlag({
    required this.id,
    required this.label,
    required this.severity,
    required this.points,
    this.evidence,
  });

  final String id;
  final String label;
  final String severity;
  final int points;
  final String? evidence;

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'severity': severity,
        'points': points,
        'evidence': evidence,
      };

  factory RiskFlag.fromJson(Map<String, dynamic> json) => RiskFlag(
        id: json['id'] ?? 'flag',
        label: json['label'] ?? 'Risk flag',
        severity: json['severity'] ?? 'medium',
        points: (json['points'] ?? 0) as int,
        evidence: json['evidence'],
      );
}
