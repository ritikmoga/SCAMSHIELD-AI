import 'extracted_indicators.dart';
import 'risk_flag.dart';

class ScanResult {
  const ScanResult({
    required this.id,
    required this.inputType,
    required this.timestamp,
    required this.redactedPreview,
    required this.riskScore,
    required this.verdict,
    required this.confidence,
    required this.redFlags,
    required this.extractedIndicators,
    required this.explanation,
    required this.saferNextSteps,
    required this.demoMode,
    required this.source,
  });

  final String id;
  final String inputType;
  final DateTime timestamp;
  final String redactedPreview;
  final int riskScore;
  final String verdict;
  final String confidence;
  final List<RiskFlag> redFlags;
  final ExtractedIndicators extractedIndicators;
  final String explanation;
  final List<String> saferNextSteps;
  final bool demoMode;
  final String source;

  Map<String, dynamic> toJson() => {
        'id': id,
        'inputType': inputType,
        'timestamp': timestamp.toIso8601String(),
        'redactedPreview': redactedPreview,
        'riskScore': riskScore,
        'verdict': verdict,
        'confidence': confidence,
        'redFlags': redFlags.map((flag) => flag.toJson()).toList(),
        'extractedIndicators': extractedIndicators.toJson(),
        'explanation': explanation,
        'saferNextSteps': saferNextSteps,
        'demoMode': demoMode,
        'source': source,
      };

  factory ScanResult.fromJson(Map<String, dynamic> json) => ScanResult(
        id: json['id'] ?? 'scan',
        inputType: json['inputType'] ?? json['type'] ?? 'message',
        timestamp: DateTime.tryParse(json['timestamp'] ?? json['createdAt'] ?? '') ?? DateTime.now(),
        redactedPreview: json['redactedPreview'] ?? json['inputPreview'] ?? 'Redacted preview unavailable',
        riskScore: (json['riskScore'] ?? 0) as int,
        verdict: json['verdict'] ?? 'Safe',
        confidence: json['confidence'] is String ? json['confidence'] : 'Medium',
        redFlags: (json['redFlags'] as List? ?? const []).map((item) => RiskFlag.fromJson(Map<String, dynamic>.from(item))).toList(),
        extractedIndicators: ExtractedIndicators.fromJson(Map<String, dynamic>.from(json['extractedIndicators'] ?? const {})),
        explanation: json['explanation'] ?? 'Risk guidance generated from local checks.',
        saferNextSteps: List<String>.from(json['saferNextSteps'] ?? const []),
        demoMode: json['demoMode'] ?? true,
        source: json['source'] ?? 'local-demo',
      );
}
