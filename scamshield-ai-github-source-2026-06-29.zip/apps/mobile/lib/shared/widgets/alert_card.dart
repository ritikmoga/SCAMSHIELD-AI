import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/storage/app_state.dart';
import 'app_button.dart';
import 'app_card.dart';
import 'demo_data_badge.dart';
import 'risk_badge.dart';

class AlertCard extends StatelessWidget {
  const AlertCard({super.key, required this.alert});
  final Map<String, dynamic> alert;

  @override
  Widget build(BuildContext context) {
    final followed = context.watch<ScamShieldAppState>().followedAlertIds.contains(alert['id']);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [RiskBadge(label: alert['severity']), const Spacer(), const DemoDataBadge()]),
          const SizedBox(height: 10),
          Text(alert['title'], style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text('${alert['category']} - Last updated ${alert['lastUpdated']}'),
          const SizedBox(height: 8),
          Text(alert['summary']),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              AppButton(label: followed ? 'Following' : 'Follow alert', icon: Icons.notifications, onPressed: () => context.read<ScamShieldAppState>().toggleFollowAlert(alert['id'])),
              AppButton(label: 'View details', icon: Icons.open_in_new, secondary: true, onPressed: () => Navigator.pushNamed(context, '/alertDetail', arguments: alert['id'])),
            ],
          ),
        ],
      ),
    );
  }
}
