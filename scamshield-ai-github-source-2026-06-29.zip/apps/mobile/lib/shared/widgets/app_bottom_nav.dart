import 'package:flutter/material.dart';

class AppBottomNav extends StatelessWidget {
  const AppBottomNav({super.key, required this.index, required this.onChanged});
  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return NavigationBar(
      selectedIndex: index,
      onDestinationSelected: onChanged,
      destinations: const [
        NavigationDestination(icon: Icon(Icons.radar), label: 'Scan'),
        NavigationDestination(icon: Icon(Icons.notifications_active), label: 'Alerts'),
        NavigationDestination(icon: Icon(Icons.school), label: 'Learn'),
        NavigationDestination(icon: Icon(Icons.report), label: 'Report'),
        NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
      ],
    );
  }
}
