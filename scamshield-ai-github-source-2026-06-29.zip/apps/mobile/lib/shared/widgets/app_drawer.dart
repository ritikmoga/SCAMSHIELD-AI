import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Home', Icons.home, '/home'),
      ('QR Scanner', Icons.qr_code_scanner, '/qr'),
      ('Screenshot Scanner', Icons.image_search, '/screenshot'),
      ('Security Lab', Icons.security, '/securityLab'),
      ('Scam Database', Icons.storage, '/databaseTab'),
      ('Integration Status', Icons.hub, '/integrations'),
      ('Admin Reports Demo', Icons.admin_panel_settings, '/adminReports'),
      ('Login', Icons.login, '/login'),
      ('Signup', Icons.person_add, '/signup'),
      ('Settings', Icons.settings, '/settings'),
      ('Terms of Use', Icons.description, '/terms'),
      ('Privacy Policy', Icons.privacy_tip, '/privacy'),
    ];
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            const ListTile(
              leading: Icon(Icons.shield),
              title: Text(AppConstants.appName),
              subtitle: Text(AppConstants.tagline),
            ),
            const Divider(),
            ...items.map((item) => ListTile(
                  leading: Icon(item.$2),
                  title: Text(item.$1),
                  onTap: () {
                    Navigator.pop(context);
                    if (item.$3 == '/databaseTab') {
                      Navigator.pushNamed(context, '/main', arguments: 5);
                    } else {
                      Navigator.pushNamed(context, item.$3);
                    }
                  },
                )),
          ],
        ),
      ),
    );
  }
}
