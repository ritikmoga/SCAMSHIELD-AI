import 'package:flutter/material.dart';

import '../../features/alerts/screens/alerts_screen.dart';
import '../../features/dashboard/screens/dashboard_screen.dart';
import '../../features/database/screens/scam_database_screen.dart';
import '../../features/learn/screens/learn_screen.dart';
import '../../features/report/screens/report_screen.dart';
import '../../features/scanner/screens/scanner_screen.dart';
import 'app_bottom_nav.dart';
import 'app_drawer.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final arg = ModalRoute.of(context)?.settings.arguments;
    if (arg is int && arg >= 0 && arg <= 5) index = arg == 5 ? 5 : arg;
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      const ScannerScreen(embed: true),
      const AlertsScreen(embed: true),
      const LearnScreen(embed: true),
      const ReportScreen(embed: true),
      const DashboardScreen(embed: true),
      const ScamDatabaseScreen(embed: true),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(index == 5 ? 'Scam Database' : ['Scan', 'Alerts', 'Learn', 'Report', 'Dashboard'][index])),
      drawer: const AppDrawer(),
      body: screens[index],
      bottomNavigationBar: index == 5 ? null : AppBottomNav(index: index, onChanged: (value) => setState(() => index = value)),
    );
  }
}
