import 'package:flutter/material.dart';

class CompletionBadge extends StatelessWidget {
  const CompletionBadge({super.key, required this.completed});
  final bool completed;

  @override
  Widget build(BuildContext context) {
    if (!completed) return const SizedBox.shrink();
    return const Chip(label: Text('Completion badge earned'), avatar: Icon(Icons.workspace_premium));
  }
}
