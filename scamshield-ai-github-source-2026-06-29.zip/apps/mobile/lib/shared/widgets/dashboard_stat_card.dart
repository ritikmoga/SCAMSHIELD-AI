import 'package:flutter/material.dart';

import 'app_card.dart';
import 'demo_data_badge.dart';

class DashboardStatCard extends StatelessWidget {
  const DashboardStatCard({super.key, required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Icon(icon), const Spacer(), const DemoDataBadge()]),
          const SizedBox(height: 12),
          Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
          Text(label),
        ],
      ),
    );
  }
}
