import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';

class DemoDataBadge extends StatelessWidget {
  const DemoDataBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.cyan.withOpacity(0.14),
        border: Border.all(color: AppColors.cyan.withOpacity(0.45)),
        borderRadius: BorderRadius.circular(999),
      ),
      child: const Text(AppConstants.demoData, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
    );
  }
}
