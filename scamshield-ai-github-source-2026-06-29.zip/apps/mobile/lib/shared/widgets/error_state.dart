import 'package:flutter/material.dart';

import 'app_button.dart';
import 'app_card.dart';

class ErrorState extends StatelessWidget {
  const ErrorState({super.key, required this.message, this.onRetry});
  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        children: [
          const Icon(Icons.error_outline, size: 40),
          const SizedBox(height: 8),
          Text(message, textAlign: TextAlign.center),
          if (onRetry != null) ...[
            const SizedBox(height: 12),
            AppButton(label: 'Retry', icon: Icons.refresh, onPressed: onRetry),
          ],
        ],
      ),
    );
  }
}
