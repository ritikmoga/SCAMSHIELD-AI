import 'package:flutter/material.dart';

import '../models/extracted_indicators.dart';
import 'app_card.dart';
import 'section_header.dart';

class ExtractedIndicatorsCard extends StatelessWidget {
  const ExtractedIndicatorsCard({super.key, required this.indicators});
  final ExtractedIndicators indicators;

  @override
  Widget build(BuildContext context) {
    final groups = {
      'URLs': indicators.urls,
      'Domains': indicators.domains,
      'Emails': indicators.emails,
      'Phone numbers': indicators.phoneNumbers,
      'UPI IDs': indicators.upiIds,
      'Suspicious keywords': indicators.suspiciousKeywords,
      'Payment words': indicators.paymentWords,
      'Brand terms': indicators.brandTerms,
    };
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(title: 'Extracted indicators'),
          ...groups.entries.map((entry) => Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('${entry.key}: ${entry.value.isEmpty ? 'None found' : entry.value.join(', ')}'),
              )),
        ],
      ),
    );
  }
}
