import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/storage/app_state.dart';

class LanguageToggle extends StatelessWidget {
  const LanguageToggle({super.key});

  @override
  Widget build(BuildContext context) {
    final language = context.watch<ScamShieldAppState>().language;
    return SegmentedButton<String>(
      segments: const [
        ButtonSegment(value: 'en', label: Text('EN')),
        ButtonSegment(value: 'hi', label: Text('HI')),
      ],
      selected: {language},
      onSelectionChanged: (value) => context.read<ScamShieldAppState>().setLanguage(value.first),
    );
  }
}
