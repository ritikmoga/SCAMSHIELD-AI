import 'package:flutter/material.dart';

class ProgressTracker extends StatelessWidget {
  const ProgressTracker({super.key, required this.score, required this.total});
  final int score;
  final int total;

  @override
  Widget build(BuildContext context) {
    final progress = total == 0 ? 0.0 : score / total;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Progress: $score / $total'),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: progress.clamp(0.0, 1.0).toDouble()),
      ],
    );
  }
}
