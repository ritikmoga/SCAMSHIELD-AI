import 'package:flutter/material.dart';

import 'app_button.dart';
import 'app_card.dart';
import 'demo_data_badge.dart';
import 'risk_badge.dart';

class ProviderStatusCard extends StatelessWidget {
  const ProviderStatusCard({super.key, required this.provider, this.onTest, this.onCopyEnv});
  final Map<String, dynamic> provider;
  final VoidCallback? onTest;
  final VoidCallback? onCopyEnv;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Expanded(child: Text(provider['name'], style: Theme.of(context).textTheme.titleMedium)), const DemoDataBadge()]),
          const SizedBox(height: 8),
          Text(provider['purpose']),
          const SizedBox(height: 10),
          RiskBadge(label: provider['status'] == 'Demo Mode' ? 'Safe' : provider['status']),
          const SizedBox(height: 10),
          Text('Required env: ${provider['envVar']}'),
          Text('Last checked: Demo fallback'),
          Text('Rate limit: ${provider['rateLimitNote']}'),
          Text('Last test result: ${provider['lastTestResult']}'),
          const SizedBox(height: 12),
          const Text('Setup checklist: keep keys server-side, configure env vars, cache repeat checks.'),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              AppButton(label: 'Test provider', icon: Icons.science, onPressed: onTest),
              AppButton(label: 'Copy env name', icon: Icons.copy, secondary: true, onPressed: onCopyEnv),
            ],
          ),
        ],
      ),
    );
  }
}
