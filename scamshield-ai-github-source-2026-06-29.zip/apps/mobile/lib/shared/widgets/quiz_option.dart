import 'package:flutter/material.dart';

class QuizOption extends StatelessWidget {
  const QuizOption({super.key, required this.label, required this.selected, required this.correct, required this.revealed, required this.onTap});
  final String label;
  final bool selected;
  final bool correct;
  final bool revealed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    Color? color;
    if (revealed && correct) color = Colors.green.withOpacity(0.22);
    if (revealed && selected && !correct) color = Colors.red.withOpacity(0.22);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        tileColor: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: selected ? Theme.of(context).colorScheme.primary : Colors.white12)),
        title: Text(label),
        onTap: onTap,
      ),
    );
  }
}
