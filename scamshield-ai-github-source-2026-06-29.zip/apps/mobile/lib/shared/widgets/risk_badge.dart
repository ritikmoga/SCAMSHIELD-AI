import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

class RiskBadge extends StatelessWidget {
  const RiskBadge({super.key, required this.label});
  final String label;

  @override
  Widget build(BuildContext context) {
    final color = label == 'Dangerous'
        ? AppColors.red
        : label == 'Suspicious' || label == 'High Risk'
            ? AppColors.yellow
            : AppColors.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.16),
        border: Border.all(color: color.withOpacity(0.55)),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
    );
  }
}
