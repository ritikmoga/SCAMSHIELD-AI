import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

class RiskScoreGauge extends StatelessWidget {
  const RiskScoreGauge({super.key, required this.score, required this.verdict, required this.confidence});
  final int score;
  final String verdict;
  final String confidence;

  @override
  Widget build(BuildContext context) {
    final color = verdict == 'Dangerous'
        ? AppColors.red
        : verdict == 'Suspicious'
            ? AppColors.yellow
            : AppColors.primary;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('$score/100', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900, color: color)),
            const Spacer(),
            Text('$confidence confidence', style: const TextStyle(color: AppColors.muted)),
          ],
        ),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            minHeight: 12,
            value: score / 100,
            color: color,
            backgroundColor: AppColors.surfaceAlt,
          ),
        ),
      ],
    );
  }
}
