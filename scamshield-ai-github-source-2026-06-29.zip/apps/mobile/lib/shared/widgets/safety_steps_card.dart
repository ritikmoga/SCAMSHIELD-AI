import 'package:flutter/material.dart';

import 'app_card.dart';
import 'section_header.dart';

class SafetyStepsCard extends StatelessWidget {
  const SafetyStepsCard({super.key, required this.steps});
  final List<String> steps;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(title: 'Safer next steps'),
          ...steps.map((step) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.shield_outlined),
                title: Text(step),
              )),
        ],
      ),
    );
  }
}
