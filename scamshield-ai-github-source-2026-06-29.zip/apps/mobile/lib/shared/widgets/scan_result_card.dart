import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/storage/app_state.dart';
import '../../core/utils/clipboard_utils.dart';
import '../models/scan_result.dart';
import 'app_button.dart';
import 'app_card.dart';
import 'extracted_indicators_card.dart';
import 'risk_badge.dart';
import 'risk_score_gauge.dart';
import 'safety_steps_card.dart';
import 'section_header.dart';

class ScanResultCard extends StatelessWidget {
  const ScanResultCard({super.key, required this.result, required this.onScanAgain});
  final ScanResult result;
  final VoidCallback onScanAgain;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [RiskBadge(label: result.verdict), const Spacer(), const Text('Demo data')]),
              const SizedBox(height: 16),
              RiskScoreGauge(score: result.riskScore, verdict: result.verdict, confidence: result.confidence),
              const SizedBox(height: 16),
              const SectionHeader(title: 'Redacted preview'),
              Text(result.redactedPreview),
              const SizedBox(height: 16),
              const SectionHeader(title: 'Simple explanation'),
              Text(result.explanation),
              const SizedBox(height: 16),
              const SectionHeader(title: 'Red flags'),
              if (result.redFlags.isEmpty) const Text('No strong red flags detected.'),
              ...result.redFlags.map((flag) => ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.warning_amber_rounded),
                    title: Text(flag.label),
                    subtitle: flag.evidence == null ? Text(flag.severity) : Text('${flag.severity} - ${flag.evidence}'),
                  )),
            ],
          ),
        ),
        const SizedBox(height: 12),
        ExtractedIndicatorsCard(indicators: result.extractedIndicators),
        const SizedBox(height: 12),
        SafetyStepsCard(steps: result.saferNextSteps),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            AppButton(label: 'Copy report', icon: Icons.copy, onPressed: () => ClipboardUtils.copy(_reportText(result))),
            AppButton(label: 'Export JSON', icon: Icons.data_object, secondary: true, onPressed: () => ClipboardUtils.copy(const JsonEncoder.withIndent('  ').convert(result.toJson()))),
            AppButton(label: 'Save to history', icon: Icons.save, secondary: true, onPressed: () => context.read<ScamShieldAppState>().saveScan(result)),
            AppButton(label: 'Scan again', icon: Icons.refresh, secondary: true, onPressed: onScanAgain),
          ],
        ),
      ],
    );
  }

  String _reportText(ScanResult result) {
    return [
      'ScamShield AI Scan Report',
      'Type: ${result.inputType}',
      'Risk score: ${result.riskScore}/100',
      'Verdict: ${result.verdict}',
      'Confidence: ${result.confidence}',
      'Preview: ${result.redactedPreview}',
      'Explanation: ${result.explanation}',
      'Safer next steps:',
      ...result.saferNextSteps.map((step) => '- $step'),
    ].join('\n');
  }
}
