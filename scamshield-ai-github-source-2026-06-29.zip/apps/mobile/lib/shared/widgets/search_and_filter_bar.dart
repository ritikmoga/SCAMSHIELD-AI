import 'package:flutter/material.dart';

class SearchAndFilterBar extends StatelessWidget {
  const SearchAndFilterBar({
    super.key,
    required this.searchController,
    required this.onChanged,
    required this.filters,
    required this.selectedFilter,
    required this.onFilterChanged,
    this.hint = 'Search',
  });

  final TextEditingController searchController;
  final ValueChanged<String> onChanged;
  final List<String> filters;
  final String selectedFilter;
  final ValueChanged<String> onFilterChanged;
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: searchController,
          onChanged: onChanged,
          decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: hint),
        ),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: filters
                .map((filter) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        selected: selectedFilter == filter,
                        label: Text(filter),
                        onSelected: (_) => onFilterChanged(filter),
                      ),
                    ))
                .toList(),
          ),
        ),
      ],
    );
  }
}
