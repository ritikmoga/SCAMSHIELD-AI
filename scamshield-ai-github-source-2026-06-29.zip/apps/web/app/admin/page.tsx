import { ActivitySquare, Gauge, ShieldCheck, UserCog } from "lucide-react";
import { ReportModeration } from "@/components/admin/report-moderation";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const queues = [
  { label: "Pending reports", value: 28, tone: "warning" as const },
  { label: "Dangerous scans 24h", value: 17, tone: "danger" as const },
  { label: "Alerts drafted", value: 4, tone: "info" as const },
  { label: "Moderators active", value: 3, tone: "default" as const }
];

export default function AdminPage() {
  return (
    <>
      <PageHeader
        eyebrow="Admin panel"
        title="Moderate reports, publish alerts, manage users, and monitor security operations."
        description="Role-gated APIs support super admin and moderator workflows with audit logging."
      />
      <section className="container grid gap-4 pb-8 md:grid-cols-4">
        {queues.map((item) => (
          <Card key={item.label} className="glass">
            <CardHeader>
              <Badge tone={item.tone}>{item.label}</Badge>
              <CardTitle className="text-3xl">{item.value}</CardTitle>
            </CardHeader>
          </Card>
        ))}
      </section>
      <section className="container grid gap-4 pb-14 lg:grid-cols-3">
        {[
          { title: "Moderation Queue", icon: ShieldCheck, text: "Verify reports, reject false positives, and promote confirmed indicators." },
          { title: "Security Monitoring", icon: ActivitySquare, text: "Track failed logins, suspicious scan bursts, API usage, and admin activity." },
          { title: "User & Role Control", icon: UserCog, text: "Manage account status, moderator access, MFA readiness, and abuse controls." }
        ].map((item) => {
          const Icon = item.icon;
          return (
            <Card key={item.title} className="glass">
              <CardHeader>
                <Icon className="h-6 w-6 text-primary" />
                <CardTitle>{item.title}</CardTitle>
                <CardDescription>{item.text}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Gauge className="h-4 w-4 text-primary" />
                  API-backed production workflow
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>
      <ReportModeration />
    </>
  );
}
