import { ReportModeration } from "@/components/admin/report-moderation";
import { PageHeader } from "@/components/page-header";

export default function AdminReportsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Admin reports"
        title="Moderate scam reports with audit-ready actions."
        description="Demo moderation data is shown until role-gated backend access and MongoDB persistence are connected."
      />
      <ReportModeration />
    </>
  );
}
