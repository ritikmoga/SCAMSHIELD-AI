import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Flag } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { alertRecords } from "@/lib/mock-intel";

export default async function AlertDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const alert = alertRecords.find((item) => item.id === id);
  if (!alert) notFound();

  return (
    <>
      <PageHeader eyebrow="Alert detail" title={alert.title} description={alert.summary} />
      <section className="container grid gap-6 pb-14 lg:grid-cols-[minmax(0,1fr)_360px]">
        <Card className="glass">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <CardTitle>Campaign Brief</CardTitle>
              <Badge tone={alert.severity === "Critical" || alert.severity === "High" ? "danger" : "warning"}>{alert.severity}</Badge>
            </div>
            <CardDescription>{alert.category} · {alert.count.toLocaleString("en-IN")} demo signals · Last updated {alert.lastUpdated}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <DetailBlock title="Common script" items={[alert.commonScript]} />
            <DetailBlock title="Red flags" items={alert.redFlags} />
            <DetailBlock title="What to do" items={alert.whatToDo} />
            <DetailBlock title="What not to do" items={alert.whatNotToDo} />
            <DetailBlock title="Related indicators" items={alert.relatedIndicators} />
          </CardContent>
        </Card>
        <Card className="glass">
          <CardHeader>
            <CardTitle>Actions</CardTitle>
            <CardDescription>Help improve community protection.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Button asChild>
              <Link href="/report">
                <Flag className="h-4 w-4" />
                Report similar scam
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/alerts">
                <ArrowLeft className="h-4 w-4" />
                Back to alerts
              </Link>
            </Button>
          </CardContent>
        </Card>
      </section>
    </>
  );
}

function DetailBlock({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="space-y-2">
      <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">{title}</h2>
      {items.map((item) => (
        <div key={item} className="rounded-md border border-border bg-background/60 p-3 text-sm leading-6 text-muted-foreground">
          {item}
        </div>
      ))}
    </div>
  );
}
