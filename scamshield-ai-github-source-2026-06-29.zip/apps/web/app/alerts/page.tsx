import { AlertsWorkspace } from "@/components/alerts/alerts-workspace";
import { PageHeader } from "@/components/page-header";

export default function AlertsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Real-time alerts"
        title="Track trending scams before they reach your inbox."
        description="Publish and follow scam campaigns such as fake KYC, courier, job, investment, UPI, phishing, and malware waves."
      />
      <AlertsWorkspace />
    </>
  );
}
