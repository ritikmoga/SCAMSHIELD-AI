import { spawn } from "node:child_process";
import { access } from "node:fs/promises";
import path from "node:path";
import { NextResponse, type NextRequest } from "next/server";
import {
  analyzeTextHeuristics,
  analyzeUrlHeuristics,
  buildScanResult,
  clampScore,
  extractIndicators,
  getRiskLevel,
  redactSensitive,
  type DetectionSignal,
  type RiskLevel,
  type ScanBreakdown,
  type ScanResult,
  type ScanType
} from "@scamshield/shared";

export const runtime = "nodejs";

const scanTypes = new Set<ScanType>([
  "url",
  "message",
  "email",
  "upi",
  "qr",
  "screenshot",
  "phone",
  "job",
  "shopping",
  "social"
]);

const riskLevels: RiskLevel[] = ["Safe", "Low Risk", "Suspicious", "High Risk", "Dangerous"];
const categories: DetectionSignal["category"][] = [
  "identity",
  "financial",
  "urgency",
  "technical",
  "reputation",
  "privacy",
  "social-engineering",
  "content"
];
const severities: DetectionSignal["severity"][] = ["info", "low", "medium", "high", "critical"];

let cachedScannerPath: string | null = null;

type PythonScanPayload = Partial<ScanResult> & {
  ok?: boolean;
  error?: string;
  engine?: string;
};

export async function POST(request: NextRequest, { params }: { params: Promise<{ type: string }> }) {
  const { type: rawType } = await params;
  const type = rawType as ScanType;

  if (!scanTypes.has(type)) {
    return NextResponse.json({ error: { message: "Unsupported scan type" } }, { status: 400 });
  }

  const body = (await request.json().catch(() => null)) as { input?: string; locale?: "en" | "hi" } | null;
  const input = body?.input?.trim();

  if (!input) {
    return NextResponse.json({ error: { message: "Scan input is required" } }, { status: 400 });
  }

  try {
    const pythonPayload = await runPythonScanner(type, input, body?.locale ?? "en");
    return NextResponse.json({
      result: toScanResult(type, input, pythonPayload)
    });
  } catch {
    return NextResponse.json({
      result: buildTypescriptFallback(type, input)
    });
  }
}

async function runPythonScanner(type: ScanType, input: string, locale: "en" | "hi") {
  const scannerPath = await resolveScannerPath();
  if (!scannerPath) {
    throw new Error("Python scanner not found");
  }

  const pythonBin = process.env.SCAMSHIELD_PYTHON_BIN?.trim() || process.env.PYTHON_BIN?.trim() || "python3";
  const allowNetwork = type === "url" && process.env.SCAMSHIELD_ENABLE_URL_NETWORK !== "0";
  const payload = JSON.stringify({
    type,
    input,
    locale,
    allow_network: allowNetwork
  });

  return new Promise<PythonScanPayload>((resolve, reject) => {
    const child = spawn(pythonBin, [scannerPath, "--json"], {
      cwd: path.dirname(scannerPath),
      env: {
        ...process.env,
        PYTHONUNBUFFERED: "1"
      },
      stdio: ["pipe", "pipe", "pipe"]
    });

    let stdout = "";
    let stderr = "";
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, 8500);

    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
      if (stdout.length > 1_000_000) {
        child.kill("SIGKILL");
      }
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", (error) => {
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", (code) => {
      clearTimeout(timeout);
      if (timedOut) {
        reject(new Error("Python scanner timed out"));
        return;
      }
      if (code !== 0) {
        reject(new Error(stderr || `Python scanner exited with code ${code}`));
        return;
      }
      try {
        const parsed = JSON.parse(stdout) as PythonScanPayload;
        if (parsed.ok === false) {
          reject(new Error(parsed.error ?? "Python scanner failed"));
          return;
        }
        resolve(parsed);
      } catch (error) {
        reject(error);
      }
    });

    child.stdin.end(payload);
  });
}

async function resolveScannerPath() {
  if (cachedScannerPath) return cachedScannerPath;

  const candidates = [process.env.SCAMSHIELD_PYTHON_SCANNER_PATH].filter(Boolean) as string[];

  for (const candidate of candidates) {
    if (await fileExists(candidate)) {
      cachedScannerPath = candidate;
      return candidate;
    }
  }

  return null;
}

async function fileExists(filePath: string) {
  try {
    await access(filePath);
    return true;
  } catch {
    return false;
  }
}

function toScanResult(type: ScanType, input: string, payload: PythonScanPayload): ScanResult {
  const riskScore = clampScore(Number(payload.riskScore ?? 0));
  const riskLevel = isRiskLevel(payload.riskLevel) ? payload.riskLevel : getRiskLevel(riskScore);
  const signals = sanitizeSignals(payload.signals);

  return {
    id: `python-${Date.now()}`,
    type,
    inputPreview: typeof payload.inputPreview === "string" ? payload.inputPreview : redactSensitive(input),
    riskScore,
    riskLevel,
    confidence: clampScore(Number(payload.confidence ?? 70)),
    explanation:
      typeof payload.explanation === "string"
        ? payload.explanation
        : "Python scanner completed a defensive scan and returned structured warning signals.",
    recommendedAction:
      typeof payload.recommendedAction === "string"
        ? payload.recommendedAction
        : "Verify through official channels before clicking, paying, or sharing sensitive details.",
    signals,
    breakdown: sanitizeBreakdown(payload.breakdown, riskScore, signals),
    extracted: {
      ...extractIndicators(input),
      ...payload.extracted
    },
    analysis: payload.analysis ?? {
      engine: payload.engine ?? "python-scamshield-v1",
      source: "python"
    },
    createdAt: new Date().toISOString()
  };
}

function sanitizeSignals(value: unknown): DetectionSignal[] {
  if (!Array.isArray(value)) return [];

  const signals: DetectionSignal[] = [];
  value.forEach((item, index) => {
    if (!item || typeof item !== "object") return;
    const signal = item as Partial<DetectionSignal>;
    const rawCategory = signal.category as DetectionSignal["category"];
    const rawSeverity = signal.severity as DetectionSignal["severity"];
    const category: DetectionSignal["category"] = categories.includes(rawCategory) ? rawCategory : "content";
    const severity: DetectionSignal["severity"] = severities.includes(rawSeverity) ? rawSeverity : "medium";

    signals.push({
      id: typeof signal.id === "string" ? signal.id : `python-signal-${index}`,
      label: typeof signal.label === "string" ? signal.label : "Python scanner warning",
      category,
      severity,
      weight: clampScore(Number(signal.weight ?? 10)),
      evidence: typeof signal.evidence === "string" ? signal.evidence : undefined
    });
  });

  return signals;
}

function sanitizeBreakdown(value: unknown, riskScore: number, signals: DetectionSignal[]): ScanBreakdown {
  if (value && typeof value === "object") {
    const candidate = value as Partial<ScanBreakdown>;
    return {
      ai: clampScore(Number(candidate.ai ?? riskScore * 0.35)),
      reputation: clampScore(Number(candidate.reputation ?? 0)),
      heuristics: clampScore(Number(candidate.heuristics ?? riskScore)),
      userReports: clampScore(Number(candidate.userReports ?? 0)),
      technical: clampScore(Number(candidate.technical ?? signals.filter((item) => item.category === "technical").length * 18))
    };
  }

  return {
    ai: clampScore(riskScore * 0.35),
    reputation: clampScore(signals.filter((item) => item.category === "reputation").length * 18),
    heuristics: riskScore,
    userReports: 0,
    technical: clampScore(signals.filter((item) => item.category === "technical").length * 18)
  };
}

function buildTypescriptFallback(type: ScanType, input: string): ScanResult {
  const signals = type === "url" ? analyzeUrlHeuristics(input) : analyzeTextHeuristics(input, type);
  const result = buildScanResult({
    type,
    input,
    signals,
    explanation: buildLocalExplanation(type, input, signals.length),
    recommendedAction:
      signals.length > 0
        ? "Do not click or share sensitive details until you verify this through the official app, website, or phone number."
        : "No strong scam pattern was found. Still verify the sender and avoid sharing OTPs, passwords, or UPI PINs."
  });

  return {
    ...result,
    id: `local-${Date.now()}`,
    analysis: {
      engine: "typescript-heuristic-fallback",
      source: "local"
    }
  };
}

function buildLocalExplanation(type: ScanType, input: string, signalCount: number) {
  if (type === "url") {
    try {
      const url = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
      const details = [
        `domain ${url.hostname}`,
        `protocol ${url.protocol.replace(":", "").toUpperCase()}`,
        url.pathname && url.pathname !== "/" ? `path ${url.pathname}` : "root path",
        url.search ? "query parameters present" : "no query parameters"
      ];

      return signalCount > 0
        ? `Local URL analysis found ${signalCount} warning signal(s) for ${details.join(", ")}. The scan checks protocol, impersonation keywords, path intent, obfuscation, shorteners, and known scam wording.`
        : `Local URL analysis did not find strong warning signs for ${details.join(", ")}. This does not replace live reputation checks.`;
    } catch {
      return "The URL could not be parsed cleanly, so ScamShield treated it as suspicious input.";
    }
  }

  return signalCount > 0
    ? `Local analysis found ${signalCount} scam or social-engineering warning signal(s).`
    : "Local analysis did not find strong scam patterns in the submitted content.";
}

function isRiskLevel(value: unknown): value is RiskLevel {
  return typeof value === "string" && riskLevels.includes(value as RiskLevel);
}
