import crypto from "node:crypto";
import dns from "node:dns/promises";
import net from "node:net";
import tls from "node:tls";
import { NextResponse, type NextRequest } from "next/server";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import {
  clampScore,
  getRiskLevel,
  type RiskLevel,
  type SecurityFinding,
  type SecurityFindingSeverity,
  type SecurityLabResult,
  type SecurityLabScanType
} from "@scamshield/shared";

export const runtime = "nodejs";

const scanTypes = new Set<SecurityLabScanType>(["file", "link", "dns", "tls", "headers", "ports", "exposure", "osint"]);
const defaultPorts = [21, 22, 25, 53, 80, 110, 143, 443, 445, 993, 995, 8080];
const exposurePaths = [
  "/.well-known/security.txt",
  "/robots.txt",
  "/sitemap.xml",
  "/.git/HEAD",
  "/admin",
  "/login",
  "/wp-admin/",
  "/backup.zip"
];

type JsonBody = {
  target?: string;
  authorized?: boolean;
  ports?: number[];
};

type DnsDetails = {
  hostname: string;
  a?: string[];
  aaaa?: string[];
  mx?: Array<{ exchange: string; priority: number }>;
  ns?: string[];
  txt?: string[];
  caa?: unknown[];
  soa?: unknown;
  dmarc?: string[];
  errors?: Record<string, string>;
};

export async function POST(request: NextRequest, { params }: { params: Promise<{ type: string }> }) {
  if (!verifyCsrf(request)) return csrfError();

  const { type: rawType } = await params;
  const type = rawType as SecurityLabScanType;

  if (!scanTypes.has(type)) {
    return NextResponse.json({ error: { message: "Unsupported security scan type" } }, { status: 400 });
  }

  try {
    const result = type === "file" ? await scanFile(request) : await scanTarget(type, request);
    return NextResponse.json({ result });
  } catch (error) {
    return NextResponse.json(
      {
        error: {
          message: error instanceof Error ? error.message : "Security scan failed"
        }
      },
      { status: 400 }
    );
  }
}

async function scanTarget(type: SecurityLabScanType, request: NextRequest): Promise<SecurityLabResult> {
  const body = (await request.json().catch(() => null)) as JsonBody | null;
  const target = body?.target?.trim();
  if (!target) throw new Error("Target is required");
  if (target.length > 500) throw new Error("Target is too long");

  if (type === "link") return scanLink(target);
  if (type === "dns") return scanDnsTarget(target);
  if (type === "tls") return scanTlsTarget(target);
  if (type === "headers") return scanHeadersTarget(target);
  if (type === "ports") return scanPortsTarget(target, Boolean(body?.authorized), body?.ports);
  if (type === "exposure") return scanExposureTarget(target, Boolean(body?.authorized));
  if (type === "osint") return scanOsintTarget(target);

  throw new Error("Unsupported target scan type");
}

async function scanFile(request: NextRequest): Promise<SecurityLabResult> {
  const formData = await request.formData();
  const file = formData.get("file");
  const authorized = formData.get("authorized") === "true";
  if (!(file instanceof File)) throw new Error("Upload a file to scan");
  if (file.size > 15 * 1024 * 1024) throw new Error("File must be 15MB or smaller");

  const buffer = Buffer.from(await file.arrayBuffer());
  const sha256 = crypto.createHash("sha256").update(buffer).digest("hex");
  const extension = file.name.includes(".") ? `.${file.name.split(".").pop()?.toLowerCase() ?? ""}` : "";
  const findings: SecurityFinding[] = [];
  const riskyExtensions = new Set([".exe", ".dll", ".scr", ".bat", ".cmd", ".js", ".vbs", ".jar", ".msi", ".apk", ".ps1", ".com"]);

  if (riskyExtensions.has(extension)) {
    findings.push(finding("file-risky-extension", "Risky executable or script extension", "high", "malware", extension, "Open this only in a sandbox and verify it with antivirus reputation services first."));
  }

  const textPreview = buffer.subarray(0, Math.min(buffer.length, 800_000)).toString("latin1");
  const signatures = [
    { id: "eicar", label: "EICAR antivirus test string detected", severity: "critical" as const, pattern: "EICAR-STANDARD-ANTIVIRUS-TEST-FILE" },
    { id: "powershell", label: "PowerShell execution string detected", severity: "high" as const, pattern: "powershell" },
    { id: "wscript", label: "Windows Script Host automation string detected", severity: "high" as const, pattern: "WScript.Shell" },
    { id: "macro", label: "Office macro automation string detected", severity: "medium" as const, pattern: "AutoOpen" },
    { id: "shell", label: "Shell command execution string detected", severity: "medium" as const, pattern: "cmd.exe" },
    { id: "apk", label: "Android package marker detected", severity: "medium" as const, pattern: "AndroidManifest.xml" }
  ];

  for (const signature of signatures) {
    if (textPreview.toLowerCase().includes(signature.pattern.toLowerCase())) {
      findings.push(finding(`file-${signature.id}`, signature.label, signature.severity, "malware", signature.pattern, "Treat this file as suspicious until a trusted malware scanner clears it."));
    }
  }

  const entropy = calculateEntropy(buffer);
  if (entropy > 7.4 && buffer.length > 4096) {
    findings.push(finding("file-high-entropy", "High entropy content can indicate packing or encryption", "medium", "malware", entropy.toFixed(2), "Use reputation scanning and sandbox analysis before trusting this file."));
  }

  const vt = await lookupVirusTotalFile(sha256);
  if (vt.malicious > 0 || vt.suspicious > 0) {
    findings.push(finding("file-virustotal-detection", "VirusTotal engines reported this file hash", vt.malicious > 2 ? "critical" : "high", "malware", `${vt.malicious} malicious, ${vt.suspicious} suspicious`, "Do not open the file. Quarantine it and verify the source."));
  } else if (!vt.enabled) {
    findings.push(finding("file-av-not-configured", "External antivirus reputation is not configured", "info", "policy", "Set VIRUSTOTAL_API_KEY to enable hash lookups", "Use this local static result as a first pass, not a full malware verdict."));
  }

  return buildSecurityResult({
    type: "file",
    target: file.name,
    authorizedRequired: false,
    authorized,
    findings,
    details: {
      fileName: file.name,
      sizeBytes: file.size,
      mimeType: file.type || "unknown",
      extension,
      sha256,
      entropy,
      virusTotal: vt
    },
    safeSummary: "Static file triage completed without executing the file."
  });
}

async function scanLink(target: string): Promise<SecurityLabResult> {
  const url = parseHttpUrl(target);
  await assertPublicHost(url.hostname);
  const findings: SecurityFinding[] = [];

  if (url.protocol !== "https:") {
    findings.push(finding("link-http", "Link does not use HTTPS", "high", "network", url.protocol, "Avoid entering credentials or payment details on non-HTTPS links."));
  }
  if (/(login|verify|kyc|otp|password|refund|claim|bonus|gift|airdrop)/i.test(`${url.hostname}${url.pathname}${url.search}`)) {
    findings.push(finding("link-lure-words", "Link contains high-risk action words", "medium", "privacy", url.href.slice(0, 180), "Verify the request through the official app or website before clicking."));
  }
  if (/@|%[0-9a-f]{2}|xn--/i.test(url.href)) {
    findings.push(finding("link-obfuscation", "Link contains obfuscation markers", "high", "network", url.href.slice(0, 180), "Do not open links that hide the actual destination."));
  }

  const [dnsDetails, headDetails, vt] = await Promise.all([
    collectDns(url.hostname),
    fetchHead(url),
    lookupVirusTotalUrl(url.href)
  ]);
  findings.push(...analyzeHeaderFindings(headDetails.headers));
  if (headDetails.redirectLocation) {
    findings.push(finding("link-redirect", "Link returns a redirect", "medium", "network", headDetails.redirectLocation, "Check the final destination before trusting the link."));
  }
  if (vt.malicious > 0 || vt.suspicious > 0) {
    findings.push(finding("link-virustotal-detection", "VirusTotal reported URL detections", vt.malicious > 2 ? "critical" : "high", "malware", `${vt.malicious} malicious, ${vt.suspicious} suspicious`, "Do not open this link."));
  }

  return buildSecurityResult({
    type: "link",
    target: url.href,
    authorizedRequired: false,
    authorized: false,
    findings,
    details: {
      url: url.href,
      hostname: url.hostname,
      dns: dnsDetails,
      http: headDetails,
      virusTotal: vt
    },
    safeSummary: "Link threat scan completed with DNS, HTTP metadata, headers, and optional reputation checks."
  });
}

async function scanDnsTarget(target: string): Promise<SecurityLabResult> {
  const hostname = getHostname(target);
  rejectObviousInternalHost(hostname);
  const dnsDetails = await collectDns(hostname);
  const findings = analyzeDnsFindings(dnsDetails);

  return buildSecurityResult({
    type: "dns",
    target: hostname,
    authorizedRequired: false,
    authorized: false,
    findings,
    details: dnsDetails,
    safeSummary: "DNS lookup completed using passive resolver queries."
  });
}

async function scanTlsTarget(target: string): Promise<SecurityLabResult> {
  const url = parseHttpUrl(target);
  await assertPublicHost(url.hostname);
  const tlsDetails = await probeTls(url.hostname, Number(url.port || 443));
  const findings = analyzeTlsFindings(tlsDetails);

  return buildSecurityResult({
    type: "tls",
    target: url.hostname,
    authorizedRequired: false,
    authorized: false,
    findings,
    details: tlsDetails,
    safeSummary: "TLS certificate and negotiated security metadata checked."
  });
}

async function scanHeadersTarget(target: string): Promise<SecurityLabResult> {
  const url = parseHttpUrl(target);
  await assertPublicHost(url.hostname);
  const headDetails = await fetchHead(url);
  const findings = analyzeHeaderFindings(headDetails.headers);

  return buildSecurityResult({
    type: "headers",
    target: url.href,
    authorizedRequired: false,
    authorized: false,
    findings,
    details: headDetails,
    safeSummary: "HTTP security header scan completed with a single metadata request."
  });
}

async function scanPortsTarget(target: string, authorized: boolean, requestedPorts?: number[]): Promise<SecurityLabResult> {
  if (!authorized) throw new Error("Confirm authorization before running an active port scan");
  const hostname = getHostname(target);
  await assertPublicHost(hostname);
  const ports = sanitizePorts(requestedPorts);
  const results = await Promise.all(ports.map((port) => probePort(hostname, port)));
  const findings: SecurityFinding[] = [];
  const sensitivePorts = new Set([21, 22, 23, 25, 445, 3306, 3389, 5432, 6379]);

  for (const result of results) {
    if (result.open && sensitivePorts.has(result.port)) {
      findings.push(finding(`port-${result.port}-open`, `Sensitive port ${result.port} is reachable`, result.port === 23 || result.port === 445 ? "high" : "medium", "network", `${hostname}:${result.port}`, "Restrict this service with firewall rules, VPN, or IP allowlisting if it is not intentionally public."));
    } else if (result.open) {
      findings.push(finding(`port-${result.port}-open`, `Port ${result.port} is reachable`, "low", "network", `${hostname}:${result.port}`, "Confirm this service is expected and patched."));
    }
  }

  return buildSecurityResult({
    type: "ports",
    target: hostname,
    authorizedRequired: true,
    authorized,
    findings,
    details: {
      mode: "low-noise TCP connect scan",
      ports: results
    },
    safeSummary: "Authorized TCP port check completed with a small allowlisted port set."
  });
}

async function scanExposureTarget(target: string, authorized: boolean): Promise<SecurityLabResult> {
  if (!authorized) throw new Error("Confirm authorization before running exposure path checks");
  const baseUrl = parseHttpUrl(target);
  await assertPublicHost(baseUrl.hostname);
  const results = await Promise.all(exposurePaths.map((item) => fetchPathStatus(baseUrl, item)));
  const findings: SecurityFinding[] = [];

  for (const result of results) {
    if (result.status && result.status >= 200 && result.status < 300) {
      if (result.path === "/.git/HEAD" || result.path === "/backup.zip") {
        findings.push(finding(`exposure-${result.path}`, `Sensitive path ${result.path} is publicly reachable`, "critical", "exposure", `${result.status}`, "Remove the exposed resource and check server deployment rules immediately."));
      } else if (result.path.includes("admin") || result.path.includes("wp-admin")) {
        findings.push(finding(`exposure-${result.path}`, `Administrative path ${result.path} is reachable`, "medium", "exposure", `${result.status}`, "Protect admin paths with MFA, rate limits, and IP restrictions."));
      } else {
        findings.push(finding(`exposure-${result.path}`, `Public metadata path ${result.path} exists`, "info", "exposure", `${result.status}`, "Review the content to ensure it does not disclose sensitive information."));
      }
    }
  }

  return buildSecurityResult({
    type: "exposure",
    target: baseUrl.origin,
    authorizedRequired: true,
    authorized,
    findings,
    details: {
      mode: "limited safe path exposure check",
      checkedPaths: results
    },
    safeSummary: "Authorized exposure check completed with a small safe wordlist."
  });
}

async function scanOsintTarget(target: string): Promise<SecurityLabResult> {
  const hostname = getHostname(target);
  rejectObviousInternalHost(hostname);
  const domain = registeredDomain(hostname);
  const [dnsDetails, rdap] = await Promise.all([collectDns(domain), lookupRdap(domain)]);
  const findings = analyzeDnsFindings(dnsDetails);
  if (!rdap.enabled) {
    findings.push(finding("osint-rdap-unavailable", "RDAP lookup unavailable", "info", "policy", rdap.error ?? "No response", "Use registrar records directly if ownership verification is needed."));
  }

  return buildSecurityResult({
    type: "osint",
    target: domain,
    authorizedRequired: false,
    authorized: false,
    findings,
    details: {
      dns: dnsDetails,
      rdap,
      privacyNote: "This scan does not harvest personal emails or scrape search engines."
    },
    safeSummary: "Passive OSINT snapshot completed with DNS, mail-auth, nameserver, and RDAP metadata."
  });
}

async function collectDns(hostname: string): Promise<DnsDetails> {
  const details: DnsDetails = { hostname, errors: {} };
  const tasks = {
    a: dns.resolve4(hostname),
    aaaa: dns.resolve6(hostname),
    mx: dns.resolveMx(hostname),
    ns: dns.resolveNs(hostname),
    txt: dns.resolveTxt(hostname),
    caa: dns.resolveCaa(hostname),
    soa: dns.resolveSoa(hostname),
    dmarc: dns.resolveTxt(`_dmarc.${hostname}`)
  };

  const entries = await Promise.all(
    Object.entries(tasks).map(async ([key, task]) => {
      try {
        return [key, await task] as const;
      } catch (error) {
        return [key, error instanceof Error ? error.message : "lookup failed"] as const;
      }
    })
  );

  for (const [key, value] of entries) {
    if (typeof value === "string") {
      details.errors = { ...details.errors, [key]: value };
    } else if (key === "txt" || key === "dmarc") {
      details[key] = (value as string[][]).map((item) => item.join(""));
    } else {
      details[key as "a"] = value as never;
    }
  }

  return details;
}

async function fetchHead(url: URL) {
  const started = Date.now();
  try {
    const response = await fetch(url, {
      method: "HEAD",
      redirect: "manual",
      signal: AbortSignal.timeout(5000),
      headers: {
        "User-Agent": "ScamShieldAI-SecurityLab/1.0"
      }
    });
    return {
      ok: true,
      status: response.status,
      redirected: response.status >= 300 && response.status < 400,
      redirectLocation: response.headers.get("location"),
      elapsedMs: Date.now() - started,
      headers: headersToObject(response.headers)
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : "request failed",
      elapsedMs: Date.now() - started,
      headers: {}
    };
  }
}

async function fetchPathStatus(baseUrl: URL, relativePath: string) {
  const url = new URL(relativePath, baseUrl.origin);
  const result = await fetchHead(url);
  return {
    path: relativePath,
    status: result.status,
    ok: result.ok,
    elapsedMs: result.elapsedMs,
    error: result.error
  };
}

function probeTls(hostname: string, port: number) {
  return new Promise<Record<string, unknown>>((resolve) => {
    const started = Date.now();
    const socket = tls.connect({
      host: hostname,
      port,
      servername: hostname,
      rejectUnauthorized: false,
      timeout: 5000
    });

    socket.once("secureConnect", () => {
      const cert = socket.getPeerCertificate();
      const cipher = socket.getCipher();
      const validTo = cert.valid_to ? new Date(cert.valid_to) : null;
      resolve({
        authorized: socket.authorized,
        authorizationError: socket.authorizationError,
        protocol: socket.getProtocol(),
        cipher: cipher?.name,
        issuer: cert.issuer,
        subject: cert.subject,
        validFrom: cert.valid_from,
        validTo: cert.valid_to,
        expiresInDays: validTo ? Math.round((validTo.getTime() - Date.now()) / 86_400_000) : null,
        elapsedMs: Date.now() - started
      });
      socket.end();
    });

    socket.once("timeout", () => {
      socket.destroy();
      resolve({ error: "TLS connection timed out", elapsedMs: Date.now() - started });
    });
    socket.once("error", (error) => {
      resolve({ error: error.message, elapsedMs: Date.now() - started });
    });
  });
}

function probePort(hostname: string, port: number) {
  return new Promise<{ port: number; open: boolean; elapsedMs: number; error?: string }>((resolve) => {
    const started = Date.now();
    const socket = net.createConnection({ host: hostname, port });
    const done = (open: boolean, error?: string) => {
      socket.destroy();
      resolve({ port, open, elapsedMs: Date.now() - started, error });
    };
    socket.setTimeout(900);
    socket.once("connect", () => done(true));
    socket.once("timeout", () => done(false, "timeout"));
    socket.once("error", (error) => done(false, error.message));
  });
}

async function lookupVirusTotalFile(sha256: string) {
  const apiKey = process.env.VIRUSTOTAL_API_KEY?.trim();
  if (!apiKey) return { enabled: false, malicious: 0, suspicious: 0 };
  try {
    const response = await fetch(`https://www.virustotal.com/api/v3/files/${sha256}`, {
      headers: { "x-apikey": apiKey },
      signal: AbortSignal.timeout(6000)
    });
    if (!response.ok) return { enabled: true, status: response.status, malicious: 0, suspicious: 0 };
    const body = (await response.json()) as { data?: { attributes?: { last_analysis_stats?: { malicious?: number; suspicious?: number } } } };
    const stats = body.data?.attributes?.last_analysis_stats;
    return { enabled: true, malicious: stats?.malicious ?? 0, suspicious: stats?.suspicious ?? 0 };
  } catch (error) {
    return { enabled: true, error: error instanceof Error ? error.message : "VirusTotal lookup failed", malicious: 0, suspicious: 0 };
  }
}

async function lookupVirusTotalUrl(url: string) {
  const apiKey = process.env.VIRUSTOTAL_API_KEY?.trim();
  if (!apiKey) return { enabled: false, malicious: 0, suspicious: 0 };
  try {
    const id = Buffer.from(url).toString("base64url");
    const response = await fetch(`https://www.virustotal.com/api/v3/urls/${id}`, {
      headers: { "x-apikey": apiKey },
      signal: AbortSignal.timeout(6000)
    });
    if (!response.ok) return { enabled: true, status: response.status, malicious: 0, suspicious: 0 };
    const body = (await response.json()) as { data?: { attributes?: { last_analysis_stats?: { malicious?: number; suspicious?: number } } } };
    const stats = body.data?.attributes?.last_analysis_stats;
    return { enabled: true, malicious: stats?.malicious ?? 0, suspicious: stats?.suspicious ?? 0 };
  } catch (error) {
    return { enabled: true, error: error instanceof Error ? error.message : "VirusTotal lookup failed", malicious: 0, suspicious: 0 };
  }
}

async function lookupRdap(domain: string) {
  try {
    const response = await fetch(`https://rdap.org/domain/${encodeURIComponent(domain)}`, {
      signal: AbortSignal.timeout(6000),
      headers: { "User-Agent": "ScamShieldAI-SecurityLab/1.0" }
    });
    if (!response.ok) return { enabled: true, status: response.status, error: "RDAP record not found" };
    const body = (await response.json()) as Record<string, unknown>;
    return {
      enabled: true,
      handle: body.handle,
      ldhName: body.ldhName,
      status: body.status,
      events: body.events,
      secureDns: body.secureDNS,
      notices: body.notices
    };
  } catch (error) {
    return { enabled: false, error: error instanceof Error ? error.message : "RDAP lookup failed" };
  }
}

function analyzeDnsFindings(details: DnsDetails): SecurityFinding[] {
  const findings: SecurityFinding[] = [];
  const txt = details.txt ?? [];
  const dmarc = details.dmarc ?? [];
  if (!txt.some((record) => record.toLowerCase().startsWith("v=spf1"))) {
    findings.push(finding("dns-missing-spf", "SPF record not found", "medium", "dns", details.hostname, "Add SPF to reduce sender spoofing risk for this domain."));
  }
  if (!dmarc.some((record) => record.toLowerCase().startsWith("v=dmarc1"))) {
    findings.push(finding("dns-missing-dmarc", "DMARC record not found", "medium", "dns", `_dmarc.${details.hostname}`, "Add DMARC with an enforcement policy after monitoring."));
  }
  if (!details.a?.length && !details.aaaa?.length) {
    findings.push(finding("dns-no-address", "No A or AAAA records found", "low", "dns", details.hostname, "Confirm the domain is active and configured correctly."));
  }
  return findings;
}

function analyzeHeaderFindings(headers: Record<string, string>): SecurityFinding[] {
  const findings: SecurityFinding[] = [];
  const required = [
    ["strict-transport-security", "HSTS is missing", "high", "Add Strict-Transport-Security after HTTPS is stable."],
    ["content-security-policy", "Content Security Policy is missing", "medium", "Add a CSP to reduce XSS and content injection risk."],
    ["x-frame-options", "Clickjacking protection header is missing", "medium", "Add X-Frame-Options or frame-ancestors in CSP."],
    ["x-content-type-options", "MIME sniffing protection is missing", "low", "Add X-Content-Type-Options: nosniff."],
    ["referrer-policy", "Referrer Policy is missing", "low", "Add a privacy-preserving Referrer-Policy."],
    ["permissions-policy", "Permissions Policy is missing", "low", "Restrict browser features that the app does not need."]
  ] as const;

  for (const [header, title, severity, recommendation] of required) {
    if (!headers[header]) {
      findings.push(finding(`header-missing-${header}`, title, severity, "headers", header, recommendation));
    }
  }
  if (headers.server) {
    findings.push(finding("header-server-disclosure", "Server header discloses platform information", "info", "headers", headers.server, "Consider reducing version disclosure on public services."));
  }
  return findings;
}

function analyzeTlsFindings(details: Record<string, unknown>): SecurityFinding[] {
  const findings: SecurityFinding[] = [];
  if (typeof details.error === "string") {
    findings.push(finding("tls-error", "TLS connection failed", "high", "tls", details.error, "Check certificate installation and public HTTPS availability."));
    return findings;
  }
  if (details.authorized === false) {
    findings.push(finding("tls-untrusted", "Certificate is not trusted by the default trust store", "high", "tls", String(details.authorizationError ?? "unknown"), "Install a valid certificate from a trusted CA."));
  }
  const expiresInDays = typeof details.expiresInDays === "number" ? details.expiresInDays : null;
  if (expiresInDays !== null && expiresInDays < 14) {
    findings.push(finding("tls-expiring", "Certificate expires soon", "medium", "tls", `${expiresInDays} days`, "Renew the certificate before expiry."));
  }
  if (!details.protocol || String(details.protocol).includes("TLSv1.1") || String(details.protocol).includes("TLSv1 ")) {
    findings.push(finding("tls-old-protocol", "Old or unknown TLS protocol negotiated", "medium", "tls", String(details.protocol ?? "unknown"), "Disable legacy TLS versions and prefer TLS 1.2 or 1.3."));
  }
  return findings;
}

function buildSecurityResult(params: {
  type: SecurityLabScanType;
  target: string;
  authorizedRequired: boolean;
  authorized: boolean;
  findings: SecurityFinding[];
  details: Record<string, unknown>;
  safeSummary: string;
}): SecurityLabResult {
  const score = scoreFindings(params.findings);
  const level = getRiskLevel(score);
  return {
    id: `security-${Date.now()}`,
    type: params.type,
    target: params.target,
    riskScore: score,
    riskLevel: level,
    summary: buildSummary(params.safeSummary, level, params.findings),
    authorizedRequired: params.authorizedRequired,
    authorized: params.authorized,
    findings: params.findings.sort((a, b) => severityValue(b.severity) - severityValue(a.severity)),
    details: params.details,
    createdAt: new Date().toISOString()
  };
}

function buildSummary(base: string, level: RiskLevel, findings: SecurityFinding[]) {
  if (findings.length === 0) return `${base} No major warning signs were found.`;
  const top = findings.slice(0, 3).map((item) => item.title.toLowerCase()).join(", ");
  return `${base} ${level} because ScamShield found ${top}.`;
}

function finding(
  id: string,
  title: string,
  severity: SecurityFindingSeverity,
  category: SecurityFinding["category"],
  evidence: string,
  recommendation: string
): SecurityFinding {
  return { id, title, severity, category, evidence, recommendation };
}

function scoreFindings(findings: SecurityFinding[]) {
  return clampScore(findings.reduce((sum, item) => sum + severityValue(item.severity), 0));
}

function severityValue(severity: SecurityFindingSeverity) {
  switch (severity) {
    case "critical":
      return 36;
    case "high":
      return 24;
    case "medium":
      return 14;
    case "low":
      return 7;
    case "info":
      return 2;
  }
}

function calculateEntropy(buffer: Buffer) {
  if (buffer.length === 0) return 0;
  const counts = new Array<number>(256).fill(0);
  for (const byte of buffer) counts[byte] = (counts[byte] ?? 0) + 1;
  return counts.reduce((entropy, count) => {
    if (count === 0) return entropy;
    const p = count / buffer.length;
    return entropy - p * Math.log2(p);
  }, 0);
}

function parseHttpUrl(rawTarget: string) {
  const normalized = /^[a-z][a-z0-9+.-]*:\/\//i.test(rawTarget.trim()) ? rawTarget.trim() : `https://${rawTarget.trim()}`;
  const url = new URL(normalized);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Only HTTP and HTTPS targets are supported");
  return url;
}

function getHostname(target: string) {
  if (target.includes("://")) return parseHttpUrl(target).hostname.toLowerCase();
  const value = target.trim().replace(/\/.*$/, "").toLowerCase();
  if (!/^[a-z0-9.-]+$/i.test(value) && !net.isIP(value)) throw new Error("Enter a valid domain, host, or URL");
  return value;
}

function registeredDomain(hostname: string) {
  const labels = hostname.split(".").filter(Boolean);
  if (labels.length <= 2) return hostname;
  const last = labels.at(-1);
  const second = labels.at(-2);
  const third = labels.at(-3);
  if (last === "in" && third && ["co", "com", "net", "org", "gov", "ac"].includes(second ?? "")) {
    return `${third}.${second}.${last}`;
  }
  return `${second}.${last}`;
}

function sanitizePorts(value: number[] | undefined) {
  const ports = (value?.length ? value : defaultPorts)
    .map((port) => Number(port))
    .filter((port) => Number.isInteger(port) && port > 0 && port <= 65535);
  return Array.from(new Set(ports)).slice(0, 12);
}

async function assertPublicHost(hostname: string) {
  rejectObviousInternalHost(hostname);
  const records = await dns.lookup(hostname, { all: true }).catch(() => []);
  if (records.some((record) => isPrivateAddress(record.address))) {
    throw new Error("Private, loopback, link-local, and internal targets are blocked in Security Lab");
  }
}

function rejectObviousInternalHost(hostname: string) {
  const lower = hostname.toLowerCase();
  if (lower === "localhost" || lower.endsWith(".local") || lower.endsWith(".internal") || lower.endsWith(".lan")) {
    throw new Error("Private, loopback, link-local, and internal targets are blocked in Security Lab");
  }
  if (net.isIP(lower) && isPrivateAddress(lower)) {
    throw new Error("Private, loopback, link-local, and internal targets are blocked in Security Lab");
  }
}

function isPrivateAddress(address: string) {
  if (net.isIPv4(address)) {
    const parts = address.split(".").map(Number);
    const [a = 0, b = 0] = parts;
    return (
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 0 && b === 0)
    );
  }
  if (net.isIPv6(address)) {
    const lower = address.toLowerCase();
    return lower === "::1" || lower.startsWith("fc") || lower.startsWith("fd") || lower.startsWith("fe80:");
  }
  return false;
}

function headersToObject(headers: Headers) {
  const output: Record<string, string> = {};
  headers.forEach((value, key) => {
    output[key.toLowerCase()] = value;
  });
  return output;
}
