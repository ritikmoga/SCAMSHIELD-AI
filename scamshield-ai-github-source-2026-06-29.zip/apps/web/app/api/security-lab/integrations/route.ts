import { NextResponse } from "next/server";
import { getSecurityIntegrationStatuses } from "@/lib/security-integrations.server";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({
    integrations: getSecurityIntegrationStatuses()
  });
}
