import { NextResponse, type NextRequest } from "next/server";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { runSecurityIntegration } from "@/lib/security-integrations.server";
import type { SecurityIntegrationId } from "@/lib/security-integration-types";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();

  const body = (await request.json().catch(() => null)) as {
    toolId?: SecurityIntegrationId;
    target?: string;
    authorized?: boolean;
  } | null;

  if (!body?.toolId || !body.target?.trim()) {
    return NextResponse.json({ error: { message: "Tool and target are required" } }, { status: 400 });
  }

  try {
    const result = await runSecurityIntegration({
      toolId: body.toolId,
      target: body.target,
      authorized: body.authorized
    });
    return NextResponse.json({ result });
  } catch (error) {
    return NextResponse.json(
      {
        error: {
          message: error instanceof Error ? error.message : "Integration run failed"
        }
      },
      { status: 400 }
    );
  }
}
