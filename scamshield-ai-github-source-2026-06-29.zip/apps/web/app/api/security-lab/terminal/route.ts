import { NextResponse, type NextRequest } from "next/server";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { getSecurityIntegrationStatuses, runSecurityIntegration } from "@/lib/security-integrations.server";
import type { SecurityIntegrationId } from "@/lib/security-integration-types";

export const runtime = "nodejs";

type TerminalResponse = {
  command: string;
  exitCode: number;
  stdout: string[];
  stderr: string[];
  json?: unknown;
};

const aliases: Record<string, SecurityIntegrationId> = {
  vt: "virustotal",
  virustotal: "virustotal",
  urlscan: "urlscan",
  safebrowsing: "google-safe-browsing",
  gsb: "google-safe-browsing",
  abuseipdb: "abuseipdb",
  shodan: "shodan",
  otx: "alienvault-otx",
  observatory: "mozilla-observatory",
  ssllabs: "ssl-labs",
  hibp: "hibp",
  malwarebazaar: "malwarebazaar",
  whoisxml: "whoisxml",
  cfdns: "cloudflare-dns",
  googledns: "google-dns",
  zap: "owasp-zap",
  owaspzap: "owasp-zap",
  nmap: "nmap",
  nuclei: "nuclei",
  clamav: "clamav",
  clamscan: "clamav",
  yara: "yara",
  trivy: "trivy",
  gitleaks: "gitleaks",
  semgrep: "semgrep",
  mobsf: "mobsf",
  wazuh: "wazuh",
  exiftool: "exiftool",
  pefile: "pefile",
  pdfid: "pdfid",
  pdfparser: "pdf-parser",
  wappalyzer: "wappalyzer",
  phishtank: "phishtank",
  talos: "cisco-talos",
  xforce: "ibm-xforce",
  mxtoolbox: "mxtoolbox",
  hybrid: "hybrid-analysis",
  cuckoo: "cuckoo-sandbox",
  joe: "joe-sandbox",
  anyrun: "anyrun",
  securityheaders: "securityheaders"
};

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();

  const body = (await request.json().catch(() => null)) as { command?: string } | null;
  const command = body?.command?.trim() ?? "";

  if (!command) {
    return NextResponse.json({ output: response(command, 1, [], ["Command is required"]) }, { status: 400 });
  }
  if (command.length > 900) {
    return NextResponse.json({ output: response(command, 1, [], ["Command is too long"]) }, { status: 400 });
  }

  try {
    const output = await executeTerminalCommand(command);
    return NextResponse.json({ output });
  } catch (error) {
    return NextResponse.json({
      output: response(command, 1, [], [error instanceof Error ? error.message : "Terminal command failed"])
    });
  }
}

async function executeTerminalCommand(command: string): Promise<TerminalResponse> {
  const tokens = tokenize(command);
  const [nameRaw, ...rest] = tokens;
  const name = nameRaw?.toLowerCase();

  if (!name) return response(command, 1, [], ["Command is required"]);
  if (name === "help") return response(command, 0, helpText(), []);
  if (name === "clear") return response(command, 0, ["__SCAMSHIELD_CLEAR__"], []);
  if (name === "tools") return listTools(command);
  if (name === "status") return status(command);

  if (name === "run") {
    const [toolName, ...targetTokens] = rest;
    if (!toolName) return response(command, 1, [], ["Usage: run <tool> <target> [--authorized]"]);
    return runTool(command, toolName, targetTokens);
  }

  if (aliases[name]) return runTool(command, name, rest);

  return response(command, 127, [], [`Unknown command: ${name}. Try: help`]);
}

async function runTool(command: string, toolName: string, args: string[]): Promise<TerminalResponse> {
  const toolId = aliases[toolName.toLowerCase()] ?? (toolName as SecurityIntegrationId);
  const authorized = args.includes("--authorized") || args.includes("-A");
  const target = args.filter((item) => item !== "--authorized" && item !== "-A").join(" ").trim();
  if (!target) return response(command, 1, [], [`Usage: ${toolName} <target> [--authorized]`]);

  const result = await runSecurityIntegration({ toolId, target, authorized });
  const stdout = [
    `${result.toolName}: ${result.status}`,
    result.summary,
    `target: ${result.target}`,
    `created: ${result.createdAt}`
  ];
  const exitCode = result.status === "ok" ? 0 : result.status === "blocked" ? 3 : result.status === "not_configured" ? 4 : 2;

  return {
    command,
    exitCode,
    stdout,
    stderr: result.status === "ok" ? [] : [result.summary],
    json: result
  };
}

function listTools(command: string): TerminalResponse {
  const lines = getSecurityIntegrationStatuses().map((item) => {
    const active = item.activeScan ? " active" : " passive";
    return `${item.id.padEnd(22)} ${item.statusLabel.padEnd(21)} ${item.category}/${item.mode}${active}`;
  });
  return response(command, 0, lines, []);
}

function status(command: string): TerminalResponse {
  const items = getSecurityIntegrationStatuses();
  const ready = items.filter((item) => item.status === "ready").length;
  const needsKey = items.filter((item) => item.status === "needs_key").length;
  const needsService = items.filter((item) => item.status === "needs_service").length;
  const disabled = items.filter((item) => item.status === "disabled").length;
  return response(command, 0, [
    `providers: ${ready}/${items.length} ready`,
    `needs_api_key: ${needsKey}`,
    `connect_service: ${needsService}`,
    `disabled: ${disabled}`,
    `active_tools: ${process.env.SCAMSHIELD_ENABLE_ACTIVE_TOOLS === "1" ? "enabled" : "disabled"}`
  ], []);
}

function helpText() {
  return [
    "ScamShield terminal commands:",
    "  help",
    "  clear",
    "  status",
    "  tools",
    "  run <tool> <target> [--authorized]",
    "  <alias> <target> [--authorized]",
    "Aliases: vt, urlscan, gsb, otx, zap, nmap, nuclei, clamav, yara, trivy, gitleaks, semgrep, mobsf, wazuh, exiftool, pefile, pdfid, pdfparser, wappalyzer, phishtank, talos, xforce, mxtoolbox, hybrid, cuckoo, joe, anyrun, securityheaders"
  ];
}

function response(command: string, exitCode: number, stdout: string[], stderr: string[], json?: unknown): TerminalResponse {
  return { command, exitCode, stdout, stderr, json };
}

function tokenize(value: string) {
  const tokens: string[] = [];
  const pattern = /"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|(\S+)/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(value))) {
    const token = match[1] ?? match[2] ?? match[3] ?? "";
    tokens.push(token.replace(/\\"/g, "\"").replace(/\\'/g, "'"));
  }
  return tokens;
}
