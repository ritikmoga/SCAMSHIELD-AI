import crypto from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";

const csrfCookieName = "scamshield_csrf";

export async function GET(request: NextRequest) {
  const existing = request.cookies.get(csrfCookieName)?.value;
  const csrfToken = existing && existing.length >= 24 ? existing : crypto.randomBytes(32).toString("base64url");
  const response = NextResponse.json({ csrfToken });

  response.cookies.set(csrfCookieName, csrfToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 2 * 60 * 60
  });

  return response;
}
