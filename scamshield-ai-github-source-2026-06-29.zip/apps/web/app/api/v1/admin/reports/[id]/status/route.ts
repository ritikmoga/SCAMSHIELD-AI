import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { updateAdminReportStatus } from "@/lib/server/data-store";

export const runtime = "nodejs";

const statusSchema = z.object({
  status: z.enum(["Pending", "Verified", "Rejected", "Duplicate", "Escalated"]),
  note: z.string().trim().max(500).optional()
});

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyCsrf(request)) return csrfError();
  const { id } = await params;
  const parsed = statusSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "A valid moderation status is required." } }, { status: 400 });
  }
  const update = await updateAdminReportStatus({
    request,
    reportId: id,
    status: parsed.data.status,
    note: parsed.data.note
  });

  return NextResponse.json({
    ok: true,
    demo: false,
    reportId: id,
    status: parsed.data.status,
    matched: update.matched,
    storageMode: update.storageMode,
    auditLog: {
      action: update.auditLog.action,
      redactedReportId: id,
      createdAt: update.auditLog.createdAt
    }
  });
}
