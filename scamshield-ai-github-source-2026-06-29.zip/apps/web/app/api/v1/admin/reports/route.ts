import { NextResponse, type NextRequest } from "next/server";
import { listAdminReports } from "@/lib/server/data-store";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const status = request.nextUrl.searchParams.get("status") ?? "All";
  return NextResponse.json(await listAdminReports(status));
}
