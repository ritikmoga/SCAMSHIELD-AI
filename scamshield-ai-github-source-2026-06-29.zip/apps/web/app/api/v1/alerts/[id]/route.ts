import { NextResponse } from "next/server";
import { alertRecords } from "@/lib/mock-intel";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const alert = alertRecords.find((item) => item.id === id);
  if (!alert) {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Alert not found." } }, { status: 404 });
  }
  return NextResponse.json({ demo: true, alert });
}
