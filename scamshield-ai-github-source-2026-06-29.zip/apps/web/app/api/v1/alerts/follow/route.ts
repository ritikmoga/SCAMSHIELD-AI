import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";

const followSchema = z.object({
  alertId: z.string().trim().min(3).max(80)
});

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();
  const parsed = followSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Alert id is required." } }, { status: 400 });
  }
  return NextResponse.json({ ok: true, demo: true, followed: parsed.data.alertId });
}
