import { NextResponse, type NextRequest } from "next/server";
import { alertRecords } from "@/lib/mock-intel";

export async function GET(request: NextRequest) {
  const severity = request.nextUrl.searchParams.get("severity") ?? "All";
  const category = request.nextUrl.searchParams.get("category") ?? "All";
  const search = request.nextUrl.searchParams.get("q")?.toLowerCase() ?? "";
  const filtered = alertRecords.filter((alert) => {
    const matchesSearch = !search || `${alert.title} ${alert.summary} ${alert.category}`.toLowerCase().includes(search);
    return matchesSearch && (severity === "All" || alert.severity === severity) && (category === "All" || alert.category === category);
  });
  return NextResponse.json({ demo: true, alerts: filtered });
}
