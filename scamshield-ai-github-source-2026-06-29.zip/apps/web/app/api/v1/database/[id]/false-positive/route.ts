import { NextResponse, type NextRequest } from "next/server";
import { databaseRecords } from "@/lib/mock-intel";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyCsrf(request)) return csrfError();
  const { id } = await params;
  const record = databaseRecords.find((item) => item.id === id);
  if (!record) {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Indicator not found." } }, { status: 404 });
  }
  return NextResponse.json({
    ok: true,
    demo: true,
    id,
    status: "false_positive_review_queued",
    note: "False-positive reports are reviewed before an indicator is removed."
  });
}
