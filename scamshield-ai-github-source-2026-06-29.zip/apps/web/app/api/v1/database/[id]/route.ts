import { NextResponse } from "next/server";
import { databaseRecords } from "@/lib/mock-intel";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const record = databaseRecords.find((item) => item.id === id);
  if (!record) {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Indicator not found." } }, { status: 404 });
  }
  return NextResponse.json({ demo: true, record });
}
