import { NextResponse, type NextRequest } from "next/server";
import { databaseRecords } from "@/lib/mock-intel";

export async function GET(request: NextRequest) {
  const search = request.nextUrl.searchParams.get("q")?.toLowerCase() ?? "";
  const type = request.nextUrl.searchParams.get("type") ?? "All";
  const risk = request.nextUrl.searchParams.get("risk") ?? "All";
  const page = Math.max(1, Number(request.nextUrl.searchParams.get("page") ?? 1));
  const pageSize = 5;

  const filtered = databaseRecords.filter((record) => {
    const matchesSearch = !search || `${record.type} ${record.value} ${record.tags.join(" ")}`.toLowerCase().includes(search);
    const matchesType = type === "All" || record.type === type;
    const matchesRisk = risk === "All" || record.risk === risk;
    return matchesSearch && matchesType && matchesRisk;
  });

  const sorted = filtered.sort((a, b) => new Date(b.lastVerified).getTime() - new Date(a.lastVerified).getTime());

  return NextResponse.json({
    demo: true,
    page,
    pageSize,
    total: sorted.length,
    records: sorted.slice((page - 1) * pageSize, page * pageSize)
  });
}
