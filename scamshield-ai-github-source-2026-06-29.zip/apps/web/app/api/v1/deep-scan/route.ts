import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import type { ScanType } from "@scamshield/shared";
import { getRiskLevel } from "@scamshield/shared";
import { extractIndicators } from "@/lib/indicators";
import { runDeepScan } from "@/lib/multiscan/engine";
import type { DeepScanResult, DeepScanType } from "@/lib/multiscan/types";
import { maxUploadBytes, safePreview } from "@/lib/multiscan/utils";
import type { ScanResult } from "@/lib/risk-engine/types";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { attachGuestCookie, getCommunityReportSummary, getGuestId, saveScanResult } from "@/lib/server/data-store";

export const runtime = "nodejs";

const deepScanTypes = [
  "url",
  "message",
  "email",
  "email-header",
  "upi",
  "qr",
  "image",
  "screenshot",
  "pdf",
  "office",
  "archive",
  "binary",
  "script",
  "phone",
  "job",
  "shopping",
  "social",
  "file"
] as const;

const jsonSchema = z
  .object({
    scanType: z.enum(deepScanTypes).optional(),
    type: z.enum(deepScanTypes).optional(),
    input: z.string().trim().max(120_000).optional(),
    text: z.string().trim().max(120_000).optional(),
    url: z.string().trim().max(4096).optional()
  })
  .refine((value) => Boolean(value.input || value.text || value.url), {
    message: "A URL, text input, or file upload is required."
  });

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();

  try {
    const guestId = getGuestId(request);
    const contentType = request.headers.get("content-type") ?? "";
    const payload = contentType.includes("multipart/form-data") ? await parseMultipart(request) : await parseJson(request);

    if (!payload.ok) {
      return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: payload.message } }, { status: payload.status ?? 400 });
    }

    const communityInput = payload.text || payload.url || payload.file?.originalName || "";
    const community = communityInput
      ? await getCommunityReportSummary(communityInput, extractIndicators(communityInput))
      : { totalReports: 0, verifiedReports: 0, pendingReports: 0 };

    const result = await runDeepScan({
      scanType: payload.scanType,
      text: payload.text,
      url: payload.url,
      file: payload.file,
      communityReports: {
        totalReports: community.totalReports,
        verifiedReports: community.verifiedReports
      }
    });

    const displayResult = toHistoryResult(result);
    const saved = await saveScanResult({
      request,
      guestId,
      originalInput: historyMatchInput(payload, result),
      result: displayResult
    });

    const response = NextResponse.json({
      result,
      displayResult,
      storage: {
        saved: true,
        mode: saved.storageMode,
        rawInputStored: false
      },
      privacy: {
        rawInputStored: false,
        note: "Raw scan input is not stored by default. History stores redacted previews, hashes, scores, and metadata only."
      }
    });
    attachGuestCookie(response, guestId);
    return response;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Deep scan failed safely.";
    return NextResponse.json(
      {
        error: {
          code: "DEEP_SCAN_FAILED",
          message: `${message} The item was not marked safe because this check failed.`
        }
      },
      { status: 500 }
    );
  }
}

type ParsedDeepScan =
  | {
      ok: true;
      scanType?: DeepScanType;
      text?: string;
      url?: string;
      file?: { buffer: Buffer; originalName: string; claimedMimeType?: string };
    }
  | { ok: false; message: string; status?: number };

async function parseJson(request: NextRequest): Promise<ParsedDeepScan> {
  const body = await request.json().catch(() => null);
  const parsed = jsonSchema.safeParse(body);
  if (!parsed.success) return { ok: false, message: "A URL or text input is required." };
  return {
    ok: true,
    scanType: parsed.data.scanType ?? parsed.data.type,
    text: parsed.data.text ?? parsed.data.input,
    url: parsed.data.url
  };
}

async function parseMultipart(request: NextRequest): Promise<ParsedDeepScan> {
  const formData = await request.formData();
  const rawType = String(formData.get("scanType") ?? formData.get("type") ?? "file");
  const parsedType = z.enum(deepScanTypes).safeParse(rawType);
  if (!parsedType.success) return { ok: false, message: "Unsupported scan type." };

  const file = firstFile(formData, ["file", "image", "document", "archive", "attachment"]);
  const text = String(formData.get("text") ?? formData.get("input") ?? "");
  const url = String(formData.get("url") ?? "");
  if (!file && !text && !url) return { ok: false, message: "A file, URL, or text input is required." };
  if (file && file.size > maxUploadBytes) {
    return { ok: false, message: `File is too large. Maximum upload size is ${Math.round(maxUploadBytes / 1024 / 1024)}MB.`, status: 413 };
  }

  return {
    ok: true,
    scanType: parsedType.data,
    text: text || undefined,
    url: url || undefined,
    file: file
      ? {
          buffer: Buffer.from(await file.arrayBuffer()),
          originalName: file.name,
          claimedMimeType: file.type || "application/octet-stream"
        }
      : undefined
  };
}

function firstFile(formData: FormData, names: string[]) {
  for (const name of names) {
    const value = formData.get(name);
    if (value instanceof File && value.size > 0) return value;
  }
  return undefined;
}

function historyMatchInput(payload: Extract<ParsedDeepScan, { ok: true }>, result: DeepScanResult) {
  if (payload.url) return payload.url;
  if (payload.text) return payload.text;
  return `deep-file-scan:${result.hashes.sha256 || result.scanId}:${result.input.originalName}`;
}

function toHistoryResult(result: DeepScanResult): ScanResult {
  const type = toScanType(result.scanType);
  const verdict = result.riskScore >= 61 ? "Dangerous" : result.riskScore >= 41 ? "Suspicious" : "Safe";
  return {
    id: result.scanId,
    type,
    inputPreview: result.input.originalName ? safePreview(result.input.originalName, 160) : safePreview(result.summary, 160),
    riskScore: result.riskScore,
    riskLevel: getRiskLevel(result.riskScore),
    verdict,
    verdictLabel: toDetailedVerdict(result.verdict),
    confidence: result.confidence >= 75 ? "High" : result.confidence >= 55 ? "Medium" : "Low",
    confidenceScore: result.confidence,
    mainReason: result.findings[0]?.title ?? "No major risk found in available checks",
    redFlags: result.findings.slice(0, 12).map((finding, index) => ({
      id: `deep-${index}`,
      label: finding.title,
      severity: finding.severity,
      evidence: finding.evidence,
      points: finding.scoreImpact
    })),
    extractedIndicators: {
      urls: result.extractedIndicators.filter((item) => item.type === "url").map((item) => item.value),
      domains: result.extractedIndicators.filter((item) => item.type === "domain").map((item) => item.value),
      phoneNumbers: result.extractedIndicators.filter((item) => item.type === "phone").map((item) => item.value),
      upiIds: result.extractedIndicators.filter((item) => item.type === "upi").map((item) => item.value),
      emails: result.extractedIndicators.filter((item) => item.type === "email").map((item) => item.value),
      keywords: result.findings.slice(0, 10).map((finding) => finding.title)
    },
    categoryScores: result.categoryScores.filter((item) =>
      ["phishing", "malware", "scam", "domainReputation", "redirect", "privacy", "payment", "brandImpersonation"].includes(item.key)
    ) as ScanResult["categoryScores"],
    evidence: [
      { label: "Deep scan ID", value: result.scanId, status: "success" },
      { label: "Detected MIME type", value: result.input.detectedMimeType, status: result.input.extensionMismatch ? "warning" : "success" },
      { label: "SHA256", value: result.hashes.sha256 || "Not available", status: result.hashes.sha256 ? "success" : "warning" },
      ...result.findings.slice(0, 12).map((finding) => ({ label: finding.title, value: finding.evidence, status: finding.severity === "low" ? "warning" : "warning" as const }))
    ],
    scanTimeline: result.scanTimeline.map((item) => ({
      step: item.step,
      status: item.status,
      message: item.message,
      durationMs: item.timeTakenMs
    })),
    apiStatuses: Object.entries(result.externalResults).map(([providerName, status]) => ({
      provider: providerName,
      status: status.status === "not_configured" ? "missing_key" : status.status === "checked" ? "checked" : status.status === "pending" ? "pending" : status.status === "rate_limited" ? "rate_limited" : status.status === "error" ? "error" : "skipped",
      message: status.message,
      scoreImpact: status.scoreImpact,
      checkedAt: status.checkedAt
    })),
    technicalDetails: {
      deepScan: true,
      input: result.input,
      hashes: result.hashes,
      metadata: result.metadata,
      externalResults: result.externalResults
    },
    reportDisclaimer: result.disclaimer,
    explanation: result.summary,
    saferNextSteps: result.recommendations,
    rawInputStored: false,
    createdAt: new Date().toISOString()
  };
}

function toScanType(type: DeepScanType): ScanType {
  if (type === "email-header") return "email";
  if (type === "image" || type === "pdf" || type === "office" || type === "archive" || type === "binary" || type === "script" || type === "file") return "screenshot";
  const allowed: ScanType[] = ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"];
  return allowed.includes(type as ScanType) ? (type as ScanType) : "message";
}

function toDetailedVerdict(verdict: DeepScanResult["verdict"]): ScanResult["verdictLabel"] {
  if (verdict === "Critical") return "Critical Risk";
  if (verdict === "Dangerous" || verdict === "Risky") return "High Risk";
  return verdict;
}
