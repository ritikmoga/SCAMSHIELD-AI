import { NextResponse } from "next/server";
import { getSecurityPosture } from "@/lib/security/posture";
import { getStorageHealth } from "@/lib/server/data-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const storage = await getStorageHealth();
  const posture = getSecurityPosture();
  const degraded = !storage.connected;

  return NextResponse.json(
    {
      status: degraded ? "degraded" : "ok",
      service: "ScamShield AI",
      checkedAt: new Date().toISOString(),
      components: {
        scanner: {
          status: "ready",
          deepScan: true,
          activeLocalTools: process.env.SCAMSHIELD_ENABLE_ACTIVE_TOOLS === "1"
        },
        storage,
        privacy: {
          rawScanInputStoredByDefault: false,
          sensitiveLogging: false
        },
        perimeter: {
          publicPorts: posture.publicAttackSurface.productionPorts,
          closedByDesign: posture.publicAttackSurface.closedByDesign,
          activeLocalTools: posture.scanRuntime.activeLocalTools
        }
      }
    },
    {
      status: 200,
      headers: {
        "Cache-Control": "no-store"
      }
    }
  );
}
