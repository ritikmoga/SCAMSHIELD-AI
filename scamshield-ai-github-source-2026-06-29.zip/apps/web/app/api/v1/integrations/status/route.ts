import { NextResponse } from "next/server";
import { getProviderStatuses } from "@/lib/integrations/status";

export async function GET() {
  return NextResponse.json({ providers: getProviderStatuses() });
}
