import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { getProviderStatus } from "@/lib/integrations/status";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";

const testSchema = z.object({
  providerId: z.string().trim().min(3).max(80)
});

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();
  const parsed = testSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Provider id is required." } }, { status: 400 });
  }

  const provider = getProviderStatus(parsed.data.providerId);
  if (!provider) {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Provider not found." } }, { status: 404 });
  }

  return NextResponse.json({
    providerId: provider.id,
    status: provider.status,
    ok: provider.status === "Connected" || provider.status === "Demo Mode",
    message:
      provider.status === "Connected"
        ? `${provider.name} is configured. Live provider queries should run server-side only.`
        : provider.status === "Demo Mode"
          ? `${provider.name} is running with demo fallback data for risk guidance.`
        : `${provider.name} needs ${provider.envVar ?? "configuration"} before testing.`
  });
}
