import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { buildSafePreview } from "@/lib/redaction";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { attachGuestCookie, getGuestId, hashForMatching, saveCommunityReport } from "@/lib/server/data-store";

export const runtime = "nodejs";

const reportTypes = ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"] as const;

const reportSchema = z
  .object({
    type: z.enum(reportTypes).optional(),
    value: z.string().trim().min(3).max(2000).optional(),
    reportType: z.enum(reportTypes).optional(),
    suspiciousValue: z.string().trim().min(3).max(2000).optional(),
    description: z.string().trim().min(12).max(4000),
    sourcePlatform: z.string().trim().max(120).optional().default("Unknown"),
    userContact: z.string().trim().max(180).optional().default(""),
    consent: z.literal(true)
  })
  .transform((value) => ({
    type: value.type ?? value.reportType,
    value: value.value ?? value.suspiciousValue,
    description: value.description,
    sourcePlatform: value.sourcePlatform,
    userContact: value.userContact,
    consent: value.consent
  }))
  .refine((value) => Boolean(value.type && value.value), {
    message: "Report type and suspicious value are required."
  });

type NormalizedReport = {
  type: (typeof reportTypes)[number];
  value: string;
  description: string;
  sourcePlatform: string;
  userContact: string;
  consent: true;
};

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();

  const contentType = request.headers.get("content-type") ?? "";
  const formData = contentType.includes("multipart/form-data") ? await request.formData() : null;
  const payload = formData ? await formDataToObject(formData) : ((await request.json().catch(() => null)) as unknown);

  const parsed = reportSchema.safeParse(payload);
  if (!parsed.success) {
    return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Report type, suspicious value, description, and consent are required." } }, { status: 400 });
  }
  const report = parsed.data as NormalizedReport;
  const screenshot = formData ? extractEvidenceFile(formData) : undefined;
  if (screenshot && !isAllowedEvidenceImage(screenshot)) {
    return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Screenshot evidence must be PNG, JPG, or WebP and below 5MB." } }, { status: 400 });
  }

  const guestId = getGuestId(request);
  const saved = await saveCommunityReport({
    request,
    guestId,
    type: report.type,
    value: report.value,
    description: report.description,
    sourcePlatform: report.sourcePlatform,
    userContact: report.userContact,
    evidenceFile: screenshot
  });

  const response = NextResponse.json(
    {
      ok: true,
      demo: false,
      storageMode: saved.storageMode,
      report: {
        id: saved.report.id,
        status: saved.report.status,
        type: report.type,
        valuePreview: buildSafePreview(report.value, 140),
        indicatorHash: hashForMatching(report.value).slice(0, 16),
        descriptionPreview: buildSafePreview(report.description, 180),
        sourcePlatform: report.sourcePlatform,
        duplicateReports: saved.report.duplicates,
        privateUserDataPublic: false
      },
      note: "Reports are hashed for matching and reviewed before becoming verified indicators."
    },
    { status: 201 }
  );
  attachGuestCookie(response, guestId);
  return response;
}

async function formDataToObject(formData: FormData) {
  return {
    type: String(formData.get("type") ?? ""),
    value: String(formData.get("value") ?? ""),
    reportType: String(formData.get("reportType") ?? ""),
    suspiciousValue: String(formData.get("suspiciousValue") ?? ""),
    description: String(formData.get("description") ?? ""),
    sourcePlatform: String(formData.get("sourcePlatform") ?? ""),
    userContact: String(formData.get("userContact") ?? ""),
    consent: String(formData.get("consent") ?? "") === "true",
    screenshotAttached: Boolean(formData.get("screenshot"))
  };
}

function extractEvidenceFile(formData: FormData) {
  const value = formData.get("screenshot") ?? formData.get("image") ?? formData.get("evidence");
  return value instanceof File && value.size > 0 ? value : undefined;
}

function isAllowedEvidenceImage(file: File) {
  return /^image\/(png|jpeg|webp)$/.test(file.type) && file.size <= 5 * 1024 * 1024;
}
