import { NextResponse, type NextRequest } from "next/server";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { attachGuestCookie, deleteScanById, getGuestId } from "@/lib/server/data-store";

export const runtime = "nodejs";

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!verifyCsrf(request)) return csrfError();
  const { id } = await params;
  const guestId = getGuestId(request);
  const result = await deleteScanById(guestId, id);
  const response = NextResponse.json({
    ok: true,
    demo: false,
    deletedId: id,
    deleted: result.deleted,
    storageMode: result.storageMode,
    note: "Deleted this redacted scan record for the current guest/session."
  });
  attachGuestCookie(response, guestId);
  return response;
}
