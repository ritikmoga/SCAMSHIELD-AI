import { NextResponse, type NextRequest } from "next/server";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { attachGuestCookie, deleteScanHistory, getGuestId, listScanHistory } from "@/lib/server/data-store";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const guestId = getGuestId(request);
  const payload = await listScanHistory(guestId);
  const response = NextResponse.json(payload);
  attachGuestCookie(response, guestId);
  return response;
}

export async function DELETE(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();
  const guestId = getGuestId(request);
  const result = await deleteScanHistory(guestId);
  const response = NextResponse.json({
    ok: true,
    demo: false,
    deleted: result.deleted,
    storageMode: result.storageMode,
    note: "Deleted redacted scan history for this guest/session."
  });
  attachGuestCookie(response, guestId);
  return response;
}
