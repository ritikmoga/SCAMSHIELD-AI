import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { extractIndicators } from "@/lib/indicators";
import { analyzeUploadedImage } from "@/lib/scanners/imageScanner";
import { scanRiskIntelligence } from "@/lib/scanners/riskEngine";
import { csrfError, verifyCsrf } from "@/lib/security/api-guard";
import { attachGuestCookie, getCommunityReportSummary, getGuestId, saveScanResult } from "@/lib/server/data-store";

export const runtime = "nodejs";

const scanSchema = z.object({
  type: z.enum(["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"]),
  input: z.string().trim().min(2).max(12000),
  locale: z.enum(["en", "hi"]).optional().default("en")
});

export async function POST(request: NextRequest) {
  if (!verifyCsrf(request)) return csrfError();

  try {
    const guestId = getGuestId(request);
    const contentType = request.headers.get("content-type") ?? "";
    const parsedPayload = contentType.includes("multipart/form-data")
      ? await parseMultipartScan(request)
      : await parseJsonScan(request);

    if (!parsedPayload.ok) {
      return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: parsedPayload.message } }, { status: 400 });
    }

    const indicators = extractIndicators(parsedPayload.inputForScoring);
    const community = await getCommunityReportSummary(parsedPayload.inputForScoring, indicators);
    const result = await scanRiskIntelligence(parsedPayload.type, parsedPayload.inputForScoring, {
      community,
      additionalEvidence: parsedPayload.additionalEvidence,
      additionalTimeline: parsedPayload.additionalTimeline,
      categoryBoosts: parsedPayload.categoryBoosts,
      confidenceDelta: parsedPayload.confidenceDelta,
      technicalDetails: parsedPayload.technicalDetails
    });

    const saved = await saveScanResult({
      request,
      guestId,
      originalInput: parsedPayload.inputForScoring,
      result
    });

    const response = NextResponse.json({
      result,
      storage: {
        saved: true,
        mode: saved.storageMode,
        rawInputStored: false
      },
      privacy: {
        rawInputStored: false,
        note: "Raw scan input is redacted for display and is not stored by default."
      }
    });
    attachGuestCookie(response, guestId);
    return response;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Scan failed. Try a smaller or simpler input.";
    return NextResponse.json({ error: { code: "SCAN_FAILED", message } }, { status: 500 });
  }
}

type ParsedScanPayload =
  | {
      ok: true;
      type: z.infer<typeof scanSchema>["type"];
      inputForScoring: string;
      additionalEvidence?: Awaited<ReturnType<typeof analyzeUploadedImage>>["evidence"];
      additionalTimeline?: Awaited<ReturnType<typeof analyzeUploadedImage>>["timeline"];
      categoryBoosts?: Awaited<ReturnType<typeof analyzeUploadedImage>>["categoryBoosts"];
      confidenceDelta?: number;
      technicalDetails?: Record<string, unknown>;
    }
  | { ok: false; message: string };

async function parseJsonScan(request: NextRequest): Promise<ParsedScanPayload> {
  const body = await request.json().catch(() => null);
  const parsed = scanSchema.safeParse(body);
  if (!parsed.success) return { ok: false, message: "Scan type and input are required." };
  return { ok: true, type: parsed.data.type, inputForScoring: parsed.data.input };
}

async function parseMultipartScan(request: NextRequest): Promise<ParsedScanPayload> {
  const formData = await request.formData();
  const type = String(formData.get("type") ?? "screenshot");
  const locale = String(formData.get("locale") ?? "en");
  const manualInput = String(formData.get("input") ?? "");
  const image = firstFile(formData, ["image", "screenshot", "qr", "file"]);

  const parsed = scanSchema
    .extend({
      input: z.string().trim().max(12000).optional().default("")
    })
    .safeParse({ type, input: manualInput || "Image upload", locale });
  if (!parsed.success) return { ok: false, message: "Valid scan type and image input are required." };
  if (!image) return { ok: false, message: "A QR or screenshot image file is required for image scanning." };

  const imageAnalysis = await analyzeUploadedImage(image, parsed.data.type, manualInput);
  return {
    ok: true,
    type: parsed.data.type,
    inputForScoring: imageAnalysis.scanText,
    additionalEvidence: imageAnalysis.evidence,
    additionalTimeline: imageAnalysis.timeline,
    categoryBoosts: imageAnalysis.categoryBoosts,
    confidenceDelta: imageAnalysis.confidenceDelta,
    technicalDetails: imageAnalysis.technicalDetails
  };
}

function firstFile(formData: FormData, names: string[]) {
  for (const name of names) {
    const value = formData.get(name);
    if (value instanceof File && value.size > 0) return value;
  }
  return undefined;
}
