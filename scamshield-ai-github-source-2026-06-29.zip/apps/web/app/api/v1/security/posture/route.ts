import { NextResponse } from "next/server";
import { getSecurityPosture } from "@/lib/security/posture";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(
    {
      status: "ok",
      service: "ScamShield AI",
      posture: getSecurityPosture()
    },
    {
      headers: {
        "Cache-Control": "no-store"
      }
    }
  );
}
