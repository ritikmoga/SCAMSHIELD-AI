import { PageHeader } from "@/components/page-header";
import { AuthReadyPanel } from "@/components/auth/auth-ready-panel";
import { AuthPanel } from "@/components/auth-panel";

export default function AuthPage() {
  return (
    <>
      <PageHeader
        eyebrow="Secure access"
        title="Login, register, and prepare MFA-backed scam history."
        description="Guest users can scan with limits. Signed-in users get saved scan history, report tracking, followed alerts, and account security stats."
      />
      <section className="container grid gap-6 pb-14 lg:grid-cols-[minmax(0,1fr)_380px]">
        <AuthPanel />
        <AuthReadyPanel />
      </section>
    </>
  );
}
