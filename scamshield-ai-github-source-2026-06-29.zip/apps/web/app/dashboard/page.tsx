import { DashboardPreview } from "@/components/dashboard/dashboard-preview";
import { PageHeader } from "@/components/page-header";

export default function DashboardPage() {
  return (
    <>
      <PageHeader
        eyebrow="User dashboard"
        title="Your scan history, saved reports, account security, and followed alerts."
        description="Demo preview until authentication is connected. Production history should store only redacted previews, hashes, or encrypted snapshots after consent."
      />
      <DashboardPreview />
    </>
  );
}
