import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { databaseRecords } from "@/lib/mock-intel";

export default async function IndicatorDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const record = databaseRecords.find((item) => item.id === id);
  if (!record) notFound();

  return (
    <>
      <PageHeader
        eyebrow="Indicator details"
        title={record.value}
        description="Demo indicator profile. Production details should be populated from verified reports and moderator notes only."
      />
      <section className="container grid gap-6 pb-14 lg:grid-cols-[minmax(0,1fr)_360px]">
        <Card className="glass">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <CardTitle>Risk Profile</CardTitle>
              <Badge tone={record.risk === "Dangerous" ? "danger" : "warning"}>{record.risk}</Badge>
            </div>
            <CardDescription>
              {record.type} · Last verified {record.lastVerified} · {record.reports} matching reports · {record.sourceConfidence} source confidence
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border border-border bg-background/60 p-4">
              <div className="text-sm font-semibold">Why it is listed</div>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                This indicator matches known scam patterns and community report clusters. It should be treated as risk guidance, not a guarantee.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {record.tags.map((tag) => (
                <Badge key={tag} tone="muted">
                  {tag}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="glass">
          <CardHeader>
            <CardTitle>Actions</CardTitle>
            <CardDescription>False positives are reviewed before removal.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Button variant="secondary">Report false positive</Button>
            <Button asChild>
              <Link href="/report">Report similar scam</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/database">
                <ArrowLeft className="h-4 w-4" />
                Back to database
              </Link>
            </Button>
          </CardContent>
        </Card>
      </section>
    </>
  );
}
