import { ScamDatabaseWorkspace } from "@/components/database/scam-database-workspace";
import { PageHeader } from "@/components/page-header";

export default function ScamDatabasePage() {
  return (
    <>
      <PageHeader
        eyebrow="Scam database"
        title="Search known scam indicators and verified reports."
        description="A privacy-aware intelligence database for scam websites, phone numbers, UPI IDs, fake shopping pages, and known message templates."
      />
      <ScamDatabaseWorkspace />
    </>
  );
}
