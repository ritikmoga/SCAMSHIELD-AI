import { EducationHub } from "@/components/education/education-hub";
import { PageHeader } from "@/components/page-header";

export default function EducationPage() {
  return (
    <>
      <PageHeader
        eyebrow="Education hub"
        title="Short, practical lessons for safer everyday decisions."
        description="Phishing awareness, UPI safety, QR scam awareness, fake website detection, job scam checks, and cyber safety basics."
      />
      <EducationHub />
    </>
  );
}
