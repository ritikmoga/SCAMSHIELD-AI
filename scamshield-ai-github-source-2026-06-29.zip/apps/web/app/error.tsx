"use client";

import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <section className="container flex min-h-[60vh] items-center justify-center py-16">
      <Card className="glass max-w-xl">
        <CardHeader>
          <AlertTriangle className="h-7 w-7 text-yellow-200" />
          <CardTitle>Something needs a retry</CardTitle>
          <CardDescription>ScamShield hit a safe error boundary. No raw scan input is shown here.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={reset}>Retry</Button>
        </CardContent>
      </Card>
    </section>
  );
}
