import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { AppShell } from "@/components/app-shell";

const inter = Inter({ subsets: ["latin"], display: "swap" });

export const metadata: Metadata = {
  title: {
    default: "ScamShield AI",
    template: "%s | ScamShield AI"
  },
  description: "AI-powered scam detection for links, messages, UPI, QR codes, emails, screenshots, and phone numbers.",
  manifest: "/manifest.webmanifest",
  applicationName: "ScamShield AI",
  keywords: ["scam detection", "phishing scanner", "UPI scam checker", "cybersecurity", "AI security"],
  authors: [{ name: "ScamShield AI" }],
  robots: {
    index: true,
    follow: true
  }
};

export const viewport: Viewport = {
  themeColor: "#071014",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
