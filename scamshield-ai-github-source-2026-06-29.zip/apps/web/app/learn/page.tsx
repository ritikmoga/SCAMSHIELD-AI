import { redirect } from "next/navigation";

export default function LearnAliasPage() {
  redirect("/education");
}
