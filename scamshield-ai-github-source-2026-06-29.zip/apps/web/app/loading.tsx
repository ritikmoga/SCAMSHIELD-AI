import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function LoadingPage() {
  return (
    <section className="container grid gap-6 py-14">
      <Card className="glass">
        <CardHeader>
          <div className="h-5 w-40 animate-pulse rounded bg-secondary" />
          <div className="h-8 w-3/4 animate-pulse rounded bg-secondary" />
        </CardHeader>
        <CardContent className="grid gap-3">
          <div className="h-28 animate-pulse rounded-lg bg-secondary/70" />
          <div className="h-28 animate-pulse rounded-lg bg-secondary/50" />
        </CardContent>
      </Card>
    </section>
  );
}
