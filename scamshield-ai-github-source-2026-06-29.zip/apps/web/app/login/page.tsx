import { AuthReadyPanel } from "@/components/auth/auth-ready-panel";
import { AuthPanel } from "@/components/auth-panel";
import { PageHeader } from "@/components/page-header";

export default function LoginPage() {
  return (
    <>
      <PageHeader
        eyebrow="Login"
        title="Sign in to save redacted scan history and followed alerts."
        description="Auth is ready for short-lived sessions, MFA, and layered security controls when the backend is connected."
      />
      <section className="container grid gap-6 pb-14 lg:grid-cols-[minmax(0,1fr)_380px]">
        <AuthPanel initialMode="login" />
        <AuthReadyPanel mode="login" />
      </section>
    </>
  );
}
