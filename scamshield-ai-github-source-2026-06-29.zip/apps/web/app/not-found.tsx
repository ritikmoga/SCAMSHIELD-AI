import Link from "next/link";
import { SearchX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function NotFoundPage() {
  return (
    <section className="container flex min-h-[60vh] items-center justify-center py-16">
      <Card className="glass max-w-xl">
        <CardHeader>
          <SearchX className="h-7 w-7 text-primary" />
          <CardTitle>Page not found</CardTitle>
          <CardDescription>This route does not exist, but the scanner and risk guidance pages are ready.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button asChild>
            <Link href="/scanner">Go to Scanner</Link>
          </Button>
        </CardContent>
      </Card>
    </section>
  );
}
