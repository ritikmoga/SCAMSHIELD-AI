import Link from "next/link";
import {
  AlertTriangle,
  BadgeCheck,
  Brain,
  CheckCircle2,
  Database,
  Eye,
  Fingerprint,
  GraduationCap,
  Link2,
  Mail,
  MessageSquare,
  Phone,
  QrCode,
  Shield,
  ShoppingBag,
  UserSearch,
  WalletCards,
  Zap
} from "lucide-react";
import { EnergyButton } from "@/components/ui/EnergyButton";
import { PowerCard } from "@/components/ui/PowerCard";
import { Section } from "@/components/ui/AnimeSection";
import { SeverityBadge } from "@/components/ui/SeverityBadge";
import { LazyThreeScannerCore } from "@/components/ui/LazyThreeScannerCore";
import { demoAlerts, scanTypes } from "@/lib/demo-data";

const coverage = [
  ["URL Scanner", "Detect phishing links, unsafe redirects, and suspicious domains.", Link2, "/scanner/url"],
  ["Message Checker", "Review scammy wording, urgency traps, and fake rewards.", MessageSquare, "/scanner/message"],
  ["Email Checker", "Inspect sender signals, spoofing clues, and phishing language.", Mail, "/scanner/email"],
  ["UPI Checker", "Check payment requests, collect scams, and risky UPI handles.", WalletCards, "/scanner/upi"],
  ["QR Scanner", "Analyze QR payloads before opening hidden destinations.", QrCode, "/scanner/qr"],
  ["Screenshot Analyzer", "Extract visual scam signals from screenshots.", Eye, "/scanner/screenshot"],
  ["Phone Risk Check", "Review risky caller patterns and fraud reports.", Phone, "/scanner/phone"],
  ["Job Offer Check", "Spot deposit scams and fake part-time offers.", BadgeCheck, "/scanner/job"],
  ["Shopping Site Check", "Inspect fake stores, suspicious prices, and checkout risks.", ShoppingBag, "/scanner/shopping"],
  ["Social Profile Check", "Identify impersonation and trust-signal gaps.", UserSearch, "/scanner/social"]
] as const;

const corePowers = [
  ["AI explanation engine", "Plain-language reasoning for risk signals and safer next steps.", Brain],
  ["Security Lab", "Defensive checks for headers, DNS, TLS, and authorized assessments.", Zap],
  ["Reputation checks", "Domain, URL, UPI, phone, and pattern reputation signals.", Fingerprint],
  ["Privacy-first scanning", "Avoids unnecessary storage and explains sensitive handling.", Shield],
  ["Live scam intelligence", "Threat trends, alert feeds, and report-backed patterns.", Database],
  ["Education hub", "Training modules for phishing, QR, UPI, jobs, and shopping scams.", GraduationCap]
] as const;

const faqs = [
  {
    q: "Does ScamShield AI open suspicious links or make payments?",
    a: "No. It only analyzes risk signals and gives safer next steps before you act."
  },
  {
    q: "Is the scan result a guarantee?",
    a: "No. ScamShield AI provides risk guidance using layered security signals, not absolute guarantees."
  },
  {
    q: "Is demo data clearly labelled?",
    a: "Yes. Demo intelligence is labelled until real backend integrations and persistence are connected."
  }
];

export default function LandingPage() {
  return (
    <>
      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-10 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <p className="mb-4 text-sm font-bold uppercase tracking-[0.35em] text-energy">Cyber domain activated</p>
          <h1 className="text-5xl font-black tracking-tight md:text-7xl">
            <span className="anime-text-energy">ScamShield</span> <span className="text-energy">AI</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
            Scam defense for suspicious links, payment requests, QR payloads, fake jobs, phishing emails,
            scam screenshots, and phone numbers, redesigned as a 3D anime-powered security command center.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <EnergyButton href="/scanner">Start Scanning</EnergyButton>
            <EnergyButton href="/education" variant="ghost">
              Learn Safety Basics
            </EnergyButton>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {["Threat-intel APIs", "OWASP-aligned", "Privacy-first", "Live risk demo"].map((item) => (
              <div key={item} className="glass-panel perspective-card flex items-center gap-2 rounded-2xl px-4 py-3 text-sm text-slate-200">
                <CheckCircle2 className="h-4 w-4 text-safe" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
        <LazyThreeScannerCore />
      </section>

      <Section eyebrow="Live threat signals" title="Scam attacks visualized like energy traces">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {demoAlerts.map((alert) => {
            const level = alert.severity === "Critical" ? "Critical" : alert.severity === "High" ? "High" : alert.severity === "Medium" ? "Medium" : "Low";
            return (
              <PowerCard
                key={alert.title}
                title={alert.title}
                description={`${alert.category} • ${alert.count.toLocaleString("en-IN")} reports • Demo data`}
                severity={level === "Critical" ? "critical" : level === "High" ? "high" : level === "Medium" ? "medium" : "low"}
                icon={<AlertTriangle />}
              >
                <SeverityBadge level={level} />
              </PowerCard>
            );
          })}
        </div>
      </Section>

      <Section eyebrow="Scan coverage" title="Every scanner becomes an ability tile">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-5">
          {coverage.map(([title, desc, Icon, href]) => (
            <PowerCard key={title} title={title} description={desc} icon={<Icon size={22} />}>
              <EnergyButton href={href} variant="ghost">
                Open Scanner
              </EnergyButton>
            </PowerCard>
          ))}
        </div>
      </Section>

      <Section eyebrow="Core powers" title="Cybersecurity features with cinematic depth">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {corePowers.map(([title, desc, Icon]) => (
            <PowerCard key={title} title={title} description={desc} icon={<Icon size={22} />} />
          ))}
        </div>
      </Section>

      <Section eyebrow="Trust model" title="Risk guidance without false promises">
        <div className="grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
          <PowerCard
            title="Layered security posture"
            description="ScamShield AI combines local heuristics, redaction, provider-ready integrations, demo intelligence, and safer next steps. It does not open risky links, initiate payments, or ask for OTP, UPI PIN, CVV, passwords, or full identity documents."
            icon={<Shield />}
          >
            <div className="flex flex-wrap gap-3">
              {scanTypes.slice(0, 6).map((item) => (
                <Link key={item.href} href={item.href} className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-slate-200 hover:bg-white/10">
                  {item.title}
                </Link>
              ))}
            </div>
          </PowerCard>
          <div className="grid gap-4">
            {faqs.map((item) => (
              <PowerCard key={item.q} title={item.q} description={item.a} />
            ))}
          </div>
        </div>
      </Section>
    </>
  );
}
