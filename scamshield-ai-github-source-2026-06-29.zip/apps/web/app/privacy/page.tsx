import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PrivacyPage() {
  return (
    <>
      <PageHeader
        eyebrow="Privacy policy"
        title="Privacy-first scam detection."
        description="ScamShield AI is designed to minimize sensitive data retention while still enabling safety analysis and community intelligence."
      />
      <section className="container grid gap-4 pb-14">
        {[
          ["Data minimization", "Scan previews are redacted. Raw content is encrypted only when an authenticated user explicitly enables retention."],
          ["Sensitive secrets", "Users should never submit OTPs, UPI PINs, passwords, CVV codes, or full identity documents."],
          ["External APIs", "Reputation and AI providers are optional and should be configured with privacy review, logging controls, and data processing terms."],
          ["Retention", "Default scan metadata retention is limited. Verified reports may be retained for security research and scam prevention."]
        ].map(([title, text]) => (
          <Card key={title} className="glass">
            <CardHeader>
              <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent className="text-sm leading-6 text-muted-foreground">{text}</CardContent>
          </Card>
        ))}
      </section>
    </>
  );
}
