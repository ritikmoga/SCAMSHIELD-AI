import { PageHeader } from "@/components/page-header";
import { ReportForm } from "@/components/report-form";

export default function ReportPage() {
  return (
    <>
      <PageHeader
        eyebrow="Community reporting"
        title="Report scam URLs, phone numbers, UPI IDs, fake jobs, and suspicious websites."
        description="Moderator verification helps convert reports into confirmed indicators that improve future scans."
      />
      <section className="container pb-14">
        <ReportForm />
      </section>
    </>
  );
}
