import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function EmailCheckerPage() {
  return (
    <>
      <PageHeader
        eyebrow="Email checker"
        title="Review suspicious sender details, links, invoice traps, and credential-harvesting attempts."
        description="Paste headers and body text to identify spoofing patterns, reply-to mismatch, urgent language, and dangerous URLs."
      />
      <ScannerWorkspace type="email" />
    </>
  );
}
