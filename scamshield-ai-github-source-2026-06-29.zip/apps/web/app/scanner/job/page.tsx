import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function JobOfferPage() {
  return (
    <>
      <PageHeader
        eyebrow="Job offer check"
        title="Detect fake recruiter messages, deposits, registration fees, and document harvesting."
        description="Useful for students, freelancers, and job seekers evaluating offers from WhatsApp, Telegram, email, or social media."
      />
      <ScannerWorkspace type="job" />
    </>
  );
}
