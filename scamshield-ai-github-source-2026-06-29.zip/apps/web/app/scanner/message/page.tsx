import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function MessageCheckerPage() {
  return (
    <>
      <PageHeader
        eyebrow="Message checker"
        title="Detect urgency, OTP requests, fake KYC alerts, job scams, and social engineering."
        description="Paste WhatsApp, SMS, Telegram, or social messages and get a risk score with plain-language reasoning."
      />
      <ScannerWorkspace type="message" />
    </>
  );
}
