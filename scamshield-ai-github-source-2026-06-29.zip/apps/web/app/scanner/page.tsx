import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { scanTypes } from "@/lib/demo-data";

export default function ScannerPage() {
  return (
    <>
      <PageHeader
        eyebrow="Unified scanner"
        title="Scan links, messages, emails, UPI requests, QR payloads, screenshots, and phone numbers."
        description="Use the general scanner for quick triage, or jump into a focused workflow for a specific scam category."
      />
      <section className="container grid gap-4 pb-8 sm:grid-cols-2 lg:grid-cols-4">
        {scanTypes.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.title} href={item.href} className="rounded-lg border border-border bg-card p-4 transition hover:border-primary/45 hover:bg-secondary/45">
              <Icon className="h-5 w-5 text-primary" />
              <h2 className="mt-3 font-semibold">{item.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{item.description}</p>
            </Link>
          );
        })}
      </section>
      <ScannerWorkspace type="message" />
      <section className="container grid gap-4 pb-14 md:grid-cols-3">
        {["Never enter UPI PIN to receive money", "Never share OTP or CVV", "Verify links through official apps"].map((item) => (
          <Card key={item} className="glass">
            <CardHeader>
              <CardTitle className="text-base">{item}</CardTitle>
              <CardDescription>ScamShield flags risks, but final safety comes from independent verification.</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </section>
    </>
  );
}
