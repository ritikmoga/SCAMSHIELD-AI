import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function PhoneRiskPage() {
  return (
    <>
      <PageHeader
        eyebrow="Phone risk check"
        title="Check suspicious phone numbers and fake customer-care scripts."
        description="Analyze number patterns, scam reports, remote-access requests, and impersonation language."
      />
      <ScannerWorkspace type="phone" />
    </>
  );
}
