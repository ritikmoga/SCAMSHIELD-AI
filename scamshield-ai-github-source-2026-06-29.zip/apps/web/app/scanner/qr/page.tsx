import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function QrScannerPage() {
  return (
    <>
      <PageHeader
        eyebrow="QR scanner"
        title="Decode QR payloads and inspect embedded links, UPI requests, and text before opening."
        description="Paste decoded QR content or route screenshots through OCR to reveal hidden URLs and payment requests."
      />
      <ScannerWorkspace type="qr" />
    </>
  );
}
