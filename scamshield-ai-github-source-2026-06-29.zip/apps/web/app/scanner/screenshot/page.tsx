import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function ScreenshotAnalyzerPage() {
  return (
    <>
      <PageHeader
        eyebrow="Screenshot analyzer"
        title="Extract text from screenshots and identify dangerous sections."
        description="Upload chat screenshots, payment requests, emails, delivery alerts, or fake job offers for OCR-driven analysis."
      />
      <ScannerWorkspace type="screenshot" />
    </>
  );
}
