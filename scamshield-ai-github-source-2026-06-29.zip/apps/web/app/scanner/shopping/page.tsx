import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function ShoppingPage() {
  return (
    <>
      <PageHeader
        eyebrow="Shopping site check"
        title="Review fake shopping websites, prize links, and suspicious checkout pages."
        description="Scan discount pages, brand lookalikes, payment links, and too-good-to-be-true offers."
      />
      <ScannerWorkspace type="shopping" />
    </>
  );
}
