import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function SocialPage() {
  return (
    <>
      <PageHeader
        eyebrow="Social profile check"
        title="Analyze social profile links, romance scam scripts, and account recovery traps."
        description="Detect pressure tactics, identity impersonation, private-code requests, and suspicious links."
      />
      <ScannerWorkspace type="social" />
    </>
  );
}
