import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function UpiCheckerPage() {
  return (
    <>
      <PageHeader
        eyebrow="UPI checker"
        title="Check UPI IDs, collect requests, fake refunds, and payment screenshots safely."
        description="ScamShield never requests a UPI PIN and never processes payments. It only analyzes security risk."
      />
      <ScannerWorkspace type="upi" />
    </>
  );
}
