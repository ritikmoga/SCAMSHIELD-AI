import { PageHeader } from "@/components/page-header";
import { ScannerWorkspace } from "@/components/scanner/scanner-workspace";

export default function UrlScannerPage() {
  return (
    <>
      <PageHeader
        eyebrow="URL scanner"
        title="Analyze phishing links, fake domains, redirects, and malware indicators."
        description="Checks HTTPS, shorteners, brand impersonation, suspicious keywords, reputation matches, and technical red flags."
      />
      <ScannerWorkspace type="url" />
    </>
  );
}
