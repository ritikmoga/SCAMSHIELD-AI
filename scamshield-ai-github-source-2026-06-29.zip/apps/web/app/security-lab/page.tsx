import { PageHeader } from "@/components/page-header";
import { SecurityPostureStrip } from "@/components/security-lab/security-posture-strip";
import { SecurityLabWorkspace } from "@/components/security-lab/security-lab-workspace";

export const metadata = {
  title: "Security Lab"
};

export default function SecurityLabPage() {
  return (
    <>
      <PageHeader
        eyebrow="Defensive security testing"
        title="Security Lab for files, links, domains, headers, TLS, OSINT, and authorized probes."
        description="Run safe triage checks for assets you own or are allowed to test. Active probes require explicit authorization."
      />
      <SecurityPostureStrip />
      <SecurityLabWorkspace />
    </>
  );
}
