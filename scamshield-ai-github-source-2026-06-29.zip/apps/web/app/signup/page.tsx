import { AuthReadyPanel } from "@/components/auth/auth-ready-panel";
import { AuthPanel } from "@/components/auth-panel";
import { PageHeader } from "@/components/page-header";

export default function SignupPage() {
  return (
    <>
      <PageHeader
        eyebrow="Signup"
        title="Create an account for saved reports, followed alerts, and dashboard history."
        description="Guest scanning remains available. Signed-in mode is prepared for privacy controls and MFA."
      />
      <section className="container grid gap-6 pb-14 lg:grid-cols-[minmax(0,1fr)_380px]">
        <AuthPanel initialMode="register" />
        <AuthReadyPanel mode="signup" />
      </section>
    </>
  );
}
