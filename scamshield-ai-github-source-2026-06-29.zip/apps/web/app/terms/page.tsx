import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function TermsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Terms of use"
        title="Safety guidance, not financial or legal advice."
        description="ScamShield AI provides risk analysis to help users make safer decisions. It does not process payments or guarantee outcomes."
      />
      <section className="container grid gap-4 pb-14">
        {[
          ["Acceptable use", "Use ScamShield for defensive scam detection, education, reporting, and moderation workflows only."],
          ["No payment processing", "The platform never asks for UPI PINs and never initiates or approves financial transactions."],
          ["Risk results", "Risk scores are probabilistic and should be combined with independent verification through official channels."],
          ["Security", "The system follows layered security practices, but no software should be described as immune to compromise."]
        ].map(([title, text]) => (
          <Card key={title} className="glass">
            <CardHeader>
              <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent className="text-sm leading-6 text-muted-foreground">{text}</CardContent>
          </Card>
        ))}
      </section>
    </>
  );
}
