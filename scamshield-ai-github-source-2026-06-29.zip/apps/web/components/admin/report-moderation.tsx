"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import { AlertTriangle, CheckCircle2, CopyCheck, Eye, ShieldCheck, XCircle, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getAdminReports, updateAdminReportStatus } from "@/lib/api";

const statuses = ["Pending", "Verified", "Rejected", "Duplicate", "Escalated"] as const;
type ReportStatus = (typeof statuses)[number];
type AdminReport = {
  id: string;
  type: string;
  valuePreview: string;
  sourcePlatform: string;
  status: ReportStatus;
  duplicates: number;
  risk: string;
  riskHints: string[];
  submittedAt: string;
  descriptionPreview?: string;
};

export function ReportModeration() {
  const [reports, setReports] = useState<AdminReport[]>([]);
  const [filter, setFilter] = useState<ReportStatus>("Pending");
  const [message, setMessage] = useState<string | null>(null);
  const [selected, setSelected] = useState<AdminReport | null>(null);
  const [storageMode, setStorageMode] = useState<"mongodb" | "memory" | "fallback">("fallback");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const visible = useMemo(() => reports.filter((report) => report.status === filter), [filter, reports]);

  useEffect(() => {
    let mounted = true;
    getAdminReports("All")
      .then((payload) => {
        if (!mounted) return;
        setReports(payload.reports);
        setStorageMode(payload.storageMode ?? "fallback");
      })
      .catch(() => {
        if (!mounted) return;
        setError("Admin report API was unavailable. No private user data is shown.");
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  function moderate(id: string, status: ReportStatus) {
    startTransition(async () => {
      setMessage(null);
      try {
        await updateAdminReportStatus(id, status);
        setReports((items) => items.map((item) => (item.id === id ? { ...item, status } : item)));
        setMessage(`Moderation action audit-logged: ${id} marked ${status}.`);
      } catch {
        setMessage(`Could not update ${id}. Check backend connectivity and CSRF session.`);
      }
    });
  }

  const dataBadge = storageMode === "mongodb" ? "Live data" : storageMode === "memory" ? "Local fallback" : "Backend data";

  return (
    <section className="container space-y-6 pb-14">
      <div className="grid gap-4 md:grid-cols-5">
        {statuses.map((status) => {
          const count = reports.filter((report) => report.status === status).length;
          return (
            <button
              key={status}
              type="button"
              onClick={() => setFilter(status)}
              className={`rounded-lg border p-4 text-left transition ${
                filter === status ? "border-primary/60 bg-primary/10 shadow-glow" : "border-border bg-card hover:border-primary/35 hover:bg-secondary/45"
              }`}
            >
              <Badge tone={statusTone(status)}>{status} reports</Badge>
              <div className="mt-3 text-3xl font-semibold">{count}</div>
            </button>
          );
        })}
      </div>

      <Card className="glass">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Report Moderation Queue</CardTitle>
              <CardDescription>Private user data is not shown publicly. Moderator actions should be role-gated and audit logged.</CardDescription>
            </div>
            <Badge tone={storageMode === "mongodb" ? "default" : "muted"}>{dataBadge}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {loading ? <div className="h-28 animate-pulse rounded-lg border border-border bg-secondary/50" /> : null}
          {error ? <div className="rounded-lg border border-yellow-300/25 bg-yellow-300/10 p-4 text-sm text-yellow-50">{error}</div> : null}
          {visible.map((report) => (
            <div key={report.id} className="rounded-lg border border-border bg-background/60 p-4">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={report.risk === "Dangerous" ? "danger" : "warning"}>{report.risk}</Badge>
                    <Badge tone="muted">{report.type}</Badge>
                    <Badge tone="info">{report.sourcePlatform}</Badge>
                    <Badge tone={statusTone(report.status)}>{report.status}</Badge>
                    <span className="text-xs text-muted-foreground">{report.submittedAt}</span>
                  </div>
                  <p className="mt-3 font-medium">{report.valuePreview}</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {report.duplicates} matching report(s), hashed indicator matching only. Risk hints: {report.riskHints.join(", ")}.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => setSelected(report)}>
                    <Eye className="h-4 w-4" />
                    View details
                  </Button>
                  <Button size="sm" disabled={isPending} onClick={() => moderate(report.id, "Verified")}>
                    <CheckCircle2 className="h-4 w-4" />
                    Verify
                  </Button>
                  <Button size="sm" variant="outline" disabled={isPending} onClick={() => moderate(report.id, "Rejected")}>
                    <XCircle className="h-4 w-4" />
                    Reject
                  </Button>
                  <Button size="sm" variant="secondary" disabled={isPending} onClick={() => moderate(report.id, "Duplicate")}>
                    <CopyCheck className="h-4 w-4" />
                    Mark Duplicate
                  </Button>
                  <Button size="sm" variant="outline" disabled={isPending} onClick={() => moderate(report.id, "Escalated")}>
                    <Zap className="h-4 w-4" />
                    Escalate
                  </Button>
                </div>
              </div>
            </div>
          ))}
          {!loading && visible.length === 0 ? (
            <div className="rounded-lg border border-border bg-background/60 p-5 text-sm text-muted-foreground">No reports in this queue.</div>
          ) : null}
          {message ? (
            <div className="flex items-start gap-2 rounded-md border border-cyan-300/25 bg-cyan-300/10 p-3 text-sm text-cyan-50">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
              {message}
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Card className="glass">
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-yellow-200" />
            <CardTitle>Moderation Rules</CardTitle>
          </div>
          <CardDescription>Verified indicators can feed the scanner only after review. False positives must stay removable.</CardDescription>
        </CardHeader>
      </Card>

      {selected ? (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <Card className="glass max-w-lg">
            <CardHeader>
              <CardTitle>Report Details</CardTitle>
              <CardDescription>Only redacted indicator previews and risk hints are shown.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="rounded-lg border border-border bg-background/60 p-3">
                <div className="font-medium">{selected.valuePreview}</div>
                <div className="mt-1 text-muted-foreground">{selected.descriptionPreview || "No additional public description preview."}</div>
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                <Badge tone="muted">{selected.type}</Badge>
                <Badge tone={statusTone(selected.status)}>{selected.status}</Badge>
                <Badge tone="info">{selected.sourcePlatform}</Badge>
                <Badge tone={selected.risk === "Dangerous" ? "danger" : "warning"}>{selected.risk}</Badge>
              </div>
              <p className="text-muted-foreground">Risk hints: {selected.riskHints.length ? selected.riskHints.join(", ") : "No strong hints yet"}.</p>
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setSelected(null)}>
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}
    </section>
  );
}

function statusTone(status: string) {
  if (status === "Pending") return "warning";
  if (status === "Verified") return "default";
  if (status === "Rejected") return "danger";
  if (status === "Escalated") return "warning";
  return "info";
}
