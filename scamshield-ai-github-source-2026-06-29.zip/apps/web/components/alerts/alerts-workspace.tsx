"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { BellRing, Eye, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { alertRecords } from "@/lib/mock-intel";
import { formatNumber } from "@/lib/utils";

const severities = ["All", "Critical", "High", "Medium", "Low"];
const categories = ["All", "Banking", "Delivery", "Jobs", "UPI", "Shopping", "Investment"];

export function AlertsWorkspace() {
  const [severity, setSeverity] = useState("All");
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [followedIds, setFollowedIds] = useState<string[]>([]);
  const [message, setMessage] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      alertRecords.filter((alert) => {
        const search = `${alert.title} ${alert.summary} ${alert.category}`.toLowerCase();
        return (!query || search.includes(query.toLowerCase())) && (severity === "All" || alert.severity === severity) && (category === "All" || alert.category === category);
      }),
    [category, query, severity]
  );

  return (
    <section className="container space-y-5 pb-14">
      <Card className="glass">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Trending Scam Alerts</CardTitle>
              <CardDescription>Demo data until live intelligence feeds are connected.</CardDescription>
            </div>
            <Badge tone="muted">Demo data</Badge>
          </div>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-[minmax(0,1fr)_180px_180px]">
          <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search alerts" />
          <select value={severity} onChange={(event) => setSeverity(event.target.value)} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
            {severities.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
          <select value={category} onChange={(event) => setCategory(event.target.value)} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
            {categories.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {filtered.map((alert) => (
          <Card key={alert.id} className="glass">
            <CardHeader>
              <div className="flex items-center justify-between gap-3">
                <BellRing className="h-6 w-6 text-primary" />
                <Badge tone={alert.severity === "Critical" || alert.severity === "High" ? "danger" : "warning"}>{alert.severity}</Badge>
              </div>
              <CardTitle>{alert.title}</CardTitle>
              <CardDescription>{alert.summary}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <TrendingUp className="h-4 w-4 text-yellow-200" />
                {formatNumber(alert.count)} community signal(s) · {alert.category}
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    setFollowedIds((value) => (value.includes(alert.id) ? value.filter((id) => id !== alert.id) : [...value, alert.id]));
                    setMessage(`${followedIds.includes(alert.id) ? "Unfollowed" : "Following"} ${alert.title}. Demo alert preference saved locally.`);
                  }}
                >
                  {followedIds.includes(alert.id) ? "Following" : "Follow alert"}
                </Button>
                <Button asChild size="sm" variant="outline">
                  <Link href={`/alerts/${alert.id}`}>
                    <Eye className="h-4 w-4" />
                    Details
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {message ? <p className="rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">{message}</p> : null}
    </section>
  );
}
