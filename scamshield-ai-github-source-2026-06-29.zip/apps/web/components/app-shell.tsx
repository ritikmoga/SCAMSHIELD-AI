"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BellRing, BookOpenCheck, Flag, LayoutDashboard, Menu, Moon, ScanLine, ShieldCheck, Sun, X } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { EnergyButton } from "@/components/ui/EnergyButton";
import { AnimeBackground } from "@/components/ui/AnimeBackground";
import { disableInspectMode } from "@/lib/disable-inspect";
import { advancedNavItems, navItems } from "@/lib/demo-data";
import { cn } from "@/lib/utils";
import { ThemeProvider } from "./theme-provider";

const bottomNavItems = [
  { href: "/scanner", label: "Scan", icon: ScanLine },
  { href: "/alerts", label: "Alerts", icon: BellRing },
  { href: "/education", label: "Learn", icon: BookOpenCheck },
  { href: "/report", label: "Report", icon: Flag },
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider>
      <ShellContent>{children}</ShellContent>
    </ThemeProvider>
  );
}

function ShellContent({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    return disableInspectMode();
  }, []);

  return (
    <div className="cyber-depth-root min-h-screen">
      <AnimeBackground />
      <header className="sticky top-3 z-50 px-3 md:px-4">
        <div className="container glass-panel flex min-h-16 items-center justify-between gap-4 rounded-3xl px-4 py-3">
          <Link href="/" className="flex items-center gap-3 font-black tracking-wide text-white" aria-label="ScamShield AI home">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-cursed/25 text-energy shadow-cursed">
              <ShieldCheck className="h-5 w-5" aria-hidden />
            </span>
            <span>ScamShield AI</span>
          </Link>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Primary navigation">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-2xl px-3 py-2 text-sm text-slate-300 transition hover:bg-white/10 hover:text-white",
                  pathname === item.href && "bg-cursed/20 text-energy shadow-energy"
                )}
              >
                {item.label}
              </Link>
            ))}
            <span className="mx-1 h-5 w-px bg-white/15" aria-hidden />
            {advancedNavItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-2xl px-3 py-2 text-sm text-slate-300 transition hover:bg-white/10 hover:text-white",
                  pathname === item.href && "bg-cursed/20 text-energy shadow-energy"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="relative rounded-2xl bg-white/5 hover:bg-white/10"
              aria-label="Toggle color theme"
              title="Toggle color theme"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              <Sun className="h-4 w-4 scale-100 rotate-0 transition dark:scale-0 dark:-rotate-90" />
              <Moon className="absolute h-4 w-4 scale-0 rotate-90 transition dark:scale-100 dark:rotate-0" />
            </Button>
            <div className="hidden sm:block">
              <EnergyButton href="/scanner">Scan Now</EnergyButton>
            </div>
            <Button variant="outline" size="icon" className="rounded-2xl bg-white/5 md:hidden" aria-label="Open menu" onClick={() => setOpen(true)}>
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {open ? (
          <div className="container glass-panel mt-3 rounded-3xl p-4 md:hidden">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold">Navigation</span>
              <Button variant="ghost" size="icon" aria-label="Close menu" onClick={() => setOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <nav className="grid gap-1" aria-label="Mobile navigation">
              <span className="px-3 pt-2 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">Main</span>
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-3 py-2 text-sm text-slate-300 hover:bg-white/10 hover:text-white"
                >
                  {item.label}
                </Link>
              ))}
              <span className="px-3 pt-4 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">Advanced</span>
              {advancedNavItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="rounded-2xl px-3 py-2 text-sm text-slate-300 hover:bg-white/10 hover:text-white"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        ) : null}
      </header>

      <main className="relative z-10 pb-20 pt-4 md:pb-0">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-white/10 bg-void/88 px-2 py-2 shadow-[0_-18px_48px_rgba(0,0,0,0.36)] backdrop-blur-xl md:hidden" aria-label="Mobile bottom navigation">
        <div className="grid grid-cols-5 gap-1">
          {bottomNavItems.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href || (item.href === "/scanner" && pathname.startsWith("/scanner/"));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex min-h-12 flex-col items-center justify-center gap-1 rounded-2xl text-[11px] font-semibold transition",
                  active ? "bg-cursed/20 text-energy shadow-energy" : "text-slate-400 hover:bg-white/10 hover:text-white"
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label === "Dashboard" ? "Dash" : item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      <footer className="relative z-10 mt-10 border-t border-white/10 py-8">
        <div className="container flex flex-col gap-4 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p>ScamShield AI helps users assess risk before clicking, sharing OTPs, or sending money.</p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-foreground">
              Privacy
            </Link>
            <Link href="/terms" className="hover:text-foreground">
              Terms
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
