"use client";

import { useState, useTransition } from "react";
import { Chrome, KeyRound, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getCsrfToken } from "@/lib/api";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000/api/v1";

export function AuthPanel({ initialMode = "login" }: { initialMode?: "login" | "register" }) {
  const [mode, setMode] = useState<"login" | "register">(initialMode);
  const [email, setEmail] = useState("demo@scamshield.ai");
  const [password, setPassword] = useState("DemoPassword!2026");
  const [name, setName] = useState("Demo User");
  const [status, setStatus] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function submit(event: React.FormEvent) {
    event.preventDefault();
    setStatus(null);
    startTransition(async () => {
      try {
        const token = await getCsrfToken();
        const response = await fetch(`${API_BASE_URL}/auth/${mode}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-CSRF-Token": token
          },
          credentials: "include",
          body: JSON.stringify(mode === "register" ? { name, email, password } : { email, password })
        });
        if (!response.ok) throw new Error("Authentication failed");
        setStatus("Signed in. HttpOnly cookies and short-lived access token issued.");
      } catch {
        setStatus("Auth UI is ready. Start the API and MongoDB to complete this flow.");
      }
    });
  }

  return (
    <Card className="glass mx-auto max-w-lg">
      <CardHeader>
        <CardTitle>{mode === "login" ? "Welcome back" : "Create your account"}</CardTitle>
        <CardDescription>JWT sessions use HttpOnly cookies, refresh token rotation, and MFA-ready account records.</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="grid gap-4" onSubmit={submit}>
          <div className="flex rounded-md border border-border bg-background/70 p-1">
            <button
              type="button"
              className={`flex-1 rounded px-3 py-2 text-sm font-semibold ${mode === "login" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              onClick={() => setMode("login")}
            >
              Login
            </button>
            <button
              type="button"
              className={`flex-1 rounded px-3 py-2 text-sm font-semibold ${mode === "register" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              onClick={() => setMode("register")}
            >
              Register
            </button>
          </div>
          {mode === "register" ? (
            <label className="grid gap-2 text-sm font-medium">
              Name
              <Input value={name} onChange={(event) => setName(event.target.value)} required />
            </label>
          ) : null}
          <label className="grid gap-2 text-sm font-medium">
            Email
            <Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </label>
          <label className="grid gap-2 text-sm font-medium">
            Password
            <Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} minLength={10} required />
          </label>
          {status ? <p className="rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">{status}</p> : null}
          <Button disabled={isPending}>
            <Mail className="h-4 w-4" />
            {isPending ? "Working..." : mode === "login" ? "Login with Email" : "Create Account"}
          </Button>
          <Button type="button" variant="outline">
            <Chrome className="h-4 w-4" />
            Google Login Ready
          </Button>
          <Button type="button" variant="ghost">
            <KeyRound className="h-4 w-4" />
            Password Reset
          </Button>
          <p className="rounded-md border border-border bg-background/60 p-3 text-sm text-muted-foreground">
            Continue as guest from the scanner. Guest scans are limited and history is not saved until sign-in is connected.
          </p>
        </form>
      </CardContent>
    </Card>
  );
}
