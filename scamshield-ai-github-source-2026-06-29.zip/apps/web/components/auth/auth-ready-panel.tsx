"use client";

import Link from "next/link";
import { LogIn, ShieldCheck, UserPlus, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { authNotice, guestLimits, type AuthMode } from "@/lib/auth";

export function AuthReadyPanel({ mode = "guest" }: { mode?: AuthMode }) {
  return (
    <Card className="glass">
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Auth-ready access
            </CardTitle>
            <CardDescription>{authNotice(mode)}</CardDescription>
          </div>
          <Badge tone="muted">Auth placeholder</Badge>
        </div>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="rounded-md border border-border bg-background/60 p-3 text-sm text-muted-foreground">
          Guest scan limit: {guestLimits.scansPerDay} scans/day. Sign in to save history.
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild>
            <Link href="/login">
              <LogIn className="h-4 w-4" />
              Login
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/signup">
              <UserPlus className="h-4 w-4" />
              Signup
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href="/scanner">
              <Users className="h-4 w-4" />
              Continue as Guest
            </Link>
          </Button>
        </div>
        <div className="rounded-md border border-border bg-background/60 p-3 text-sm text-muted-foreground">
          Account menu placeholder: MFA, sessions, export data, delete history, and privacy controls.
        </div>
      </CardContent>
    </Card>
  );
}
