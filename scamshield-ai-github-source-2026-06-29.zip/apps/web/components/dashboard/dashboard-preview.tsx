"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import { Activity, Download, FileClock, Search, ShieldAlert, ShieldCheck, Trash2 } from "lucide-react";
import { SecurityChart } from "@/components/sections/security-chart";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { clearScanHistory, deleteScanHistoryItem, getScanHistory } from "@/lib/api";

type HistoryItem = {
  id: string;
  type: string;
  preview: string;
  riskScore: number;
  verdict: string;
  createdAt: string;
};

const fallbackScans: HistoryItem[] = [
  { id: "hist-001", type: "message", preview: "Fake KYC SMS asking for OTP", riskScore: 91, verdict: "Dangerous", createdAt: "2026-06-05T09:30:00.000Z" },
  { id: "hist-002", type: "upi", preview: "Refund collect request with UPI PIN pressure", riskScore: 88, verdict: "Dangerous", createdAt: "2026-06-04T17:12:00.000Z" },
  { id: "hist-003", type: "url", preview: "Brand lookalike KYC login domain", riskScore: 82, verdict: "Dangerous", createdAt: "2026-06-03T14:45:00.000Z" },
  { id: "hist-004", type: "email", preview: "Invoice email with free-mail reply-to", riskScore: 58, verdict: "Suspicious", createdAt: "2026-06-02T10:20:00.000Z" }
];

const typeFilters = ["All", "message", "upi", "url", "email", "phone", "job", "shopping", "social"];
const verdictFilters = ["All", "Safe", "Suspicious", "Dangerous"];

export function DashboardPreview() {
  const [scans, setScans] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [storageMode, setStorageMode] = useState<"mongodb" | "memory" | "fallback">("fallback");
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All");
  const [verdict, setVerdict] = useState("All");
  const [date, setDate] = useState("All");
  const [confirmDelete, setConfirmDelete] = useState<"all" | string | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    let mounted = true;
    getScanHistory()
      .then((response) => {
        if (!mounted) return;
        setStorageMode(response.storageMode ?? "fallback");
        setScans(response.scans);
      })
      .catch(() => {
        if (!mounted) return;
        setError("History API was unavailable. Showing local fallback records so the dashboard remains usable.");
        setStorageMode("fallback");
        setScans(fallbackScans);
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const lower = query.toLowerCase();
    const now = Date.now();
    return scans.filter((scan) => {
      const matchesSearch = !lower || `${scan.type} ${scan.preview} ${scan.verdict}`.toLowerCase().includes(lower);
      const matchesType = type === "All" || scan.type === type;
      const matchesVerdict = verdict === "All" || scan.verdict === verdict;
      const ageDays = (now - new Date(scan.createdAt).getTime()) / 86_400_000;
      const matchesDate = date === "All" || (date === "7d" && ageDays <= 7) || (date === "30d" && ageDays <= 30);
      return matchesSearch && matchesType && matchesVerdict && matchesDate;
    });
  }, [date, query, scans, type, verdict]);

  const metrics = [
    { label: "Total scans", value: String(scans.length), icon: Activity },
    { label: "Dangerous scans blocked", value: String(scans.filter((scan) => scan.verdict === "Dangerous").length), icon: ShieldAlert },
    { label: "Reports submitted", value: "0", icon: FileClock },
    { label: "Followed alerts", value: "0", icon: ShieldCheck }
  ];

  function deleteHistory() {
    startTransition(async () => {
      try {
        await clearScanHistory();
      } catch {
        // Demo fallback still clears local preview state.
      }
      setScans([]);
      setConfirmDelete(null);
      setStatus("All redacted scan history for this session was cleared.");
    });
  }

  function deleteOne(id: string) {
    startTransition(async () => {
      try {
        await deleteScanHistoryItem(id);
      } catch {
        // Demo fallback still deletes local preview state.
      }
      setScans((value) => value.filter((scan) => scan.id !== id));
      setConfirmDelete(null);
      setStatus(`Scan ${id} deleted from this session.`);
    });
  }

  function exportHistory(format: "json" | "csv") {
    const body =
      format === "json"
        ? JSON.stringify({ demo: storageMode === "fallback", storageMode, scans: filtered, exportedAt: new Date().toISOString() }, null, 2)
        : ["id,type,preview,riskScore,verdict,createdAt", ...filtered.map((scan) => [scan.id, scan.type, `"${scan.preview.replace(/"/g, '""')}"`, scan.riskScore, scan.verdict, scan.createdAt].join(","))].join("\n");
    const blob = new Blob([body], { type: format === "json" ? "application/json;charset=utf-8" : "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `scamshield-history.${format}`;
    anchor.click();
    URL.revokeObjectURL(url);
    setStatus(`Redacted scan history exported as ${format.toUpperCase()}.`);
  }

  const dataBadge = storageMode === "mongodb" ? "Live data" : storageMode === "memory" ? "Local fallback" : "Fallback data";

  return (
    <>
      <section className="container grid gap-4 pb-8 md:grid-cols-4">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.label} className="glass">
              <CardHeader>
                <div className="flex items-center justify-between gap-3">
                  <Icon className="h-5 w-5 text-primary" />
                  <Badge tone={storageMode === "mongodb" ? "default" : "muted"}>{dataBadge}</Badge>
                </div>
                <CardDescription>{metric.label}</CardDescription>
                <CardTitle className="text-2xl">{loading ? "..." : metric.value}</CardTitle>
              </CardHeader>
            </Card>
          );
        })}
      </section>

      <section className="container grid gap-6 pb-14 xl:grid-cols-[minmax(0,1fr)_380px]">
        <div className="space-y-6">
          <Card className="glass">
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Risk Timeline</CardTitle>
                  <CardDescription>Risk trend chart for this session. Analytics backends can replace this visual with live aggregate data.</CardDescription>
                </div>
                <Badge tone={storageMode === "mongodb" ? "default" : "muted"}>{dataBadge}</Badge>
              </div>
            </CardHeader>
            <CardContent>{loading ? <SkeletonBlock /> : <SecurityChart />}</CardContent>
          </Card>

          <Card className="glass">
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Recent Scan History</CardTitle>
                  <CardDescription>Redacted previews only. Raw scan input is not stored by default.</CardDescription>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" onClick={() => exportHistory("json")} disabled={!filtered.length}>
                    <Download className="h-4 w-4" />
                    JSON
                  </Button>
                  <Button variant="outline" onClick={() => exportHistory("csv")} disabled={!filtered.length}>
                    <Download className="h-4 w-4" />
                    CSV
                  </Button>
                  <Button variant="destructive" onClick={() => setConfirmDelete("all")} disabled={isPending || !scans.length}>
                    <Trash2 className="h-4 w-4" />
                    Delete All
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_150px_150px_150px]">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input className="pl-9" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search redacted history" />
                </div>
                <select value={type} onChange={(event) => setType(event.target.value)} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
                  {typeFilters.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
                <select value={verdict} onChange={(event) => setVerdict(event.target.value)} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
                  {verdictFilters.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
                <select value={date} onChange={(event) => setDate(event.target.value)} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
                  <option value="All">Any date</option>
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                </select>
              </div>

              {error ? <p className="rounded-md border border-yellow-300/25 bg-yellow-300/10 p-3 text-sm text-yellow-50">{error}</p> : null}
              {loading ? <SkeletonBlock /> : null}
              {!loading && filtered.length === 0 ? <EmptyHistory /> : null}
              {!loading && filtered.length ? (
                <div className="grid gap-3">
                  {filtered.map((scan) => (
                    <div key={scan.id} className="rounded-lg border border-border bg-background/60 p-4">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="flex flex-wrap gap-2">
                            <Badge tone="muted">{scan.type}</Badge>
                            <Badge tone={scan.verdict === "Dangerous" ? "danger" : scan.verdict === "Suspicious" ? "warning" : "default"}>{scan.verdict}</Badge>
                            <span className="text-xs text-muted-foreground">{new Date(scan.createdAt).toLocaleDateString()}</span>
                          </div>
                          <p className="mt-3 text-sm text-muted-foreground">{scan.preview}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-semibold">{scan.riskScore}</span>
                          <Button size="sm" variant="outline" onClick={() => setConfirmDelete(scan.id)}>
                            <Trash2 className="h-4 w-4" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
              {status ? <p className="rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">{status}</p> : null}
            </CardContent>
          </Card>
        </div>

        <Card className="glass">
          <CardHeader>
            <div className="flex items-center justify-between gap-3">
              <CardTitle>Account Security Posture</CardTitle>
              <Badge tone="default">Strong</Badge>
            </div>
            <CardDescription>Authenticated-user-ready posture checklist.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            {[
              ["Protected dashboard", "Placeholder until auth is connected"],
              ["Guest scans", "Limited preview mode"],
              ["History privacy", "Raw input off by default"],
              ["Session safety", "Ready for short-lived JWT"],
              ["Export controls", "Local JSON/CSV export"]
            ].map(([label, value]) => (
              <div key={label} className="rounded-md border border-border bg-background/60 p-3">
                <div className="text-sm font-medium">{label}</div>
                <div className="mt-1 text-xs text-muted-foreground">{value}</div>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>

      {confirmDelete ? (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <Card className="glass max-w-md">
            <CardHeader>
              <CardTitle>Confirm Delete</CardTitle>
              <CardDescription>
                {confirmDelete === "all" ? "Delete all redacted scan history from this session?" : "Delete this redacted scan record from the session?"}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap justify-end gap-2">
              <Button variant="outline" onClick={() => setConfirmDelete(null)}>
                Cancel
              </Button>
              <Button variant="destructive" disabled={isPending} onClick={() => (confirmDelete === "all" ? deleteHistory() : deleteOne(confirmDelete))}>
                Delete
              </Button>
            </CardContent>
          </Card>
        </div>
      ) : null}
    </>
  );
}

function SkeletonBlock() {
  return <div className="h-44 animate-pulse rounded-lg border border-border bg-secondary/50" />;
}

function EmptyHistory() {
  return (
    <div className="rounded-lg border border-border bg-background/60 p-8 text-center">
      <div className="text-base font-semibold">No scans found</div>
      <p className="mt-2 text-sm text-muted-foreground">Run a scan or adjust filters. Signed-in users will see saved redacted history here.</p>
    </div>
  );
}
