"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Search, ShieldAlert } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { databaseRecords } from "@/lib/mock-intel";

const typeFilters = ["All", "URL", "UPI", "Phone", "Email", "Message Template", "Job", "Shopping", "Social"];
const riskFilters = ["All", "Safe", "Suspicious", "High Risk", "Dangerous"];
const pageSize = 4;

export function ScamDatabaseWorkspace() {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All");
  const [risk, setRisk] = useState("All");
  const [sort, setSort] = useState("latest");
  const [page, setPage] = useState(1);
  const [message, setMessage] = useState<string | null>(null);
  const [falsePositiveId, setFalsePositiveId] = useState<string | null>(null);
  const [falsePositiveReason, setFalsePositiveReason] = useState("");

  const filtered = useMemo(() => {
    const lower = query.toLowerCase();
    const result = databaseRecords.filter((record) => {
      const search = `${record.type} ${record.value} ${record.tags.join(" ")}`.toLowerCase();
      return (!lower || search.includes(lower)) && (type === "All" || record.type === type) && (risk === "All" || record.risk === risk);
    });
    return result.sort((a, b) =>
      sort === "latest" ? new Date(b.lastVerified).getTime() - new Date(a.lastVerified).getTime() : b.reports - a.reports
    );
  }, [query, risk, sort, type]);

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const visible = filtered.slice((page - 1) * pageSize, page * pageSize);

  function updateFilter(callback: () => void) {
    callback();
    setPage(1);
  }

  return (
    <section className="container pb-14">
      <Card className="glass">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-primary" />
                Verified Indicators
              </CardTitle>
              <CardDescription>Demo data. Production connects to `/api/v1/database` with pagination and text search.</CardDescription>
            </div>
            <Badge tone="muted">Demo data</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_180px_180px_180px]">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" value={query} onChange={(event) => updateFilter(() => setQuery(event.target.value))} placeholder="Search URL, phone, UPI ID, tag, or template" />
            </div>
            <select value={type} onChange={(event) => updateFilter(() => setType(event.target.value))} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
              {typeFilters.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select value={risk} onChange={(event) => updateFilter(() => setRisk(event.target.value))} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
              {riskFilters.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select value={sort} onChange={(event) => updateFilter(() => setSort(event.target.value))} className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring">
              <option value="latest">Sort: latest verified</option>
              <option value="reports">Sort: most reports</option>
            </select>
          </div>

          <div className="grid gap-3">
            {visible.map((record) => (
              <div key={record.id} className="rounded-lg border border-border bg-background/60 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="break-all font-medium">{record.value}</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {record.type} · Last verified {record.lastVerified} · {record.reports} report(s) · {record.sourceConfidence} confidence
                    </p>
                  </div>
                  <Badge tone={record.risk === "Dangerous" ? "danger" : record.risk === "High Risk" || record.risk === "Suspicious" ? "warning" : "default"}>
                    {record.risk}
                  </Badge>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  {record.tags.map((tag) => (
                    <Badge key={tag} tone="muted">
                      {tag}
                    </Badge>
                  ))}
                  <Button asChild size="sm" variant="outline" className="ml-auto">
                    <Link href={`/database/${record.id}`}>Details</Link>
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setFalsePositiveId(record.id);
                      setFalsePositiveReason("");
                    }}
                  >
                    Report false positive
                  </Button>
                  <Button asChild size="sm" variant="outline">
                    <Link href="/report">Report similar scam</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-sm text-muted-foreground">
              Page {page} of {pages} · {filtered.length} result(s)
            </span>
            <div className="flex gap-2">
              <Button variant="outline" disabled={page <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))}>
                Previous
              </Button>
              <Button variant="outline" disabled={page >= pages} onClick={() => setPage((value) => Math.min(pages, value + 1))}>
                Next
              </Button>
            </div>
          </div>

          {message ? <p className="rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">{message}</p> : null}
        </CardContent>
      </Card>

      {falsePositiveId ? (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <Card className="glass w-full max-w-lg">
            <CardHeader>
              <CardTitle>Report False Positive</CardTitle>
              <CardDescription>
                Demo workflow for `/api/v1/database/{falsePositiveId}/false-positive`. Private details are not shown publicly.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={falsePositiveReason}
                onChange={(event) => setFalsePositiveReason(event.target.value)}
                placeholder="Explain why this indicator may be safe or incorrectly classified."
                className="min-h-[120px]"
              />
              <div className="flex flex-wrap justify-end gap-2">
                <Button variant="outline" onClick={() => setFalsePositiveId(null)}>
                  Cancel
                </Button>
                <Button
                  disabled={falsePositiveReason.trim().length < 8}
                  onClick={() => {
                    setMessage(`False-positive review queued for ${falsePositiveId}. Demo data updated locally.`);
                    setFalsePositiveId(null);
                  }}
                >
                  Submit Review
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}
    </section>
  );
}
