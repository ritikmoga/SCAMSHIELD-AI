"use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LanguageToggle } from "./language-toggle";
import { ProgressTracker } from "./progress-tracker";
import { QuizCard, type QuizModule } from "./quiz-card";
import { SpotScamGame } from "./spot-scam-game";

const modules: QuizModule[] = [
  {
    id: "upi",
    title: { en: "UPI safety quiz", hi: "UPI सुरक्षा क्विज" },
    topic: "Payments",
    question: { en: "When do you enter UPI PIN?", hi: "UPI PIN कब डालना चाहिए?" },
    explanation: { en: "A UPI PIN is only needed when sending money, never to receive money.", hi: "UPI PIN सिर्फ पैसे भेजते समय चाहिए, पैसे पाने के लिए नहीं।" },
    choices: [
      { label: { en: "To receive money", hi: "पैसे पाने के लिए" }, safe: false },
      { label: { en: "Only when sending money", hi: "सिर्फ पैसे भेजते समय" }, safe: true },
      { label: { en: "When customer care asks", hi: "जब कस्टमर केयर मांगे" }, safe: false }
    ]
  },
  {
    id: "domain",
    title: { en: "Phishing domain quiz", hi: "फिशिंग डोमेन क्विज" },
    topic: "Web",
    question: { en: "Which domain is suspicious?", hi: "कौन सा डोमेन संदिग्ध है?" },
    explanation: { en: "Brand words inside a different domain can indicate impersonation.", hi: "किसी अलग डोमेन में ब्रांड शब्द होना impersonation का संकेत हो सकता है।" },
    choices: [
      { label: { en: "sbi.co.in", hi: "sbi.co.in" }, safe: false },
      { label: { en: "sbi-verify-login.example.com", hi: "sbi-verify-login.example.com" }, safe: true },
      { label: { en: "onlinesbi.sbi", hi: "onlinesbi.sbi" }, safe: false }
    ]
  },
  {
    id: "job",
    title: { en: "Fake job offer quiz", hi: "फेक जॉब ऑफर क्विज" },
    topic: "Careers",
    question: { en: "Which job signal is dangerous?", hi: "कौन सा जॉब संकेत खतरनाक है?" },
    explanation: { en: "Legitimate employers do not ask candidates to pay registration or security fees.", hi: "असली कंपनियां उम्मीदवारों से registration या security fees नहीं मांगतीं।" },
    choices: [
      { label: { en: "Official company email", hi: "कंपनी का आधिकारिक ईमेल" }, safe: false },
      { label: { en: "Refundable registration fee before interview", hi: "इंटरव्यू से पहले रिफंडेबल फीस" }, safe: true },
      { label: { en: "Written role description", hi: "लिखित रोल विवरण" }, safe: false }
    ]
  },
  {
    id: "qr",
    title: { en: "QR scam awareness quiz", hi: "QR स्कैम जागरूकता क्विज" },
    topic: "QR",
    question: { en: "What should you do before scanning a payment QR?", hi: "पेमेंट QR स्कैन करने से पहले क्या करें?" },
    explanation: { en: "Always confirm payee and amount before approving payment.", hi: "पेमेंट approve करने से पहले payee और amount जरूर जांचें।" },
    choices: [
      { label: { en: "Check payee and amount", hi: "पेयी और राशि जांचें" }, safe: true },
      { label: { en: "Enter PIN to receive refund", hi: "रिफंड पाने के लिए PIN डालें" }, safe: false },
      { label: { en: "Trust any shop poster", hi: "किसी भी पोस्टर पर भरोसा करें" }, safe: false }
    ]
  }
];

const miniGame = {
  text: "URGENT: Your account is blocked. Click http://sbi-verify-login.example.com and share OTP to restore service.",
  flags: ["URGENT", "blocked", "http://sbi-verify-login.example.com", "share OTP"]
};

export function EducationHub() {
  const [locale, setLocale] = useState<"en" | "hi">("en");
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [foundFlags, setFoundFlags] = useState<string[]>([]);
  const correctAnswers = useMemo(
    () => modules.filter((module) => answers[module.id] !== undefined && module.choices[answers[module.id]!]?.safe).length,
    [answers]
  );
  const score = correctAnswers + foundFlags.length;
  const total = modules.length + miniGame.flags.length;

  function resetProgress() {
    setAnswers({});
    setFoundFlags([]);
  }

  return (
    <section className="container space-y-6 pb-14">
      <Card className="glass">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Interactive Safety Modules</CardTitle>
              <CardDescription>Short beginner-friendly lessons with score tracking and demo progress.</CardDescription>
            </div>
            <LanguageToggle locale={locale} onChange={setLocale} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <ProgressTracker score={score} total={total} />
          <Button variant="outline" onClick={resetProgress}>
            Reset progress
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {modules.map((module) => (
          <QuizCard
            key={module.id}
            module={module}
            locale={locale}
            answer={answers[module.id]}
            onAnswer={(choiceIndex) => setAnswers((value) => ({ ...value, [module.id]: choiceIndex }))}
          />
        ))}
      </div>

      <SpotScamGame
        text={miniGame.text}
        flags={miniGame.flags}
        foundFlags={foundFlags}
        onFind={(flag) => setFoundFlags((value) => (value.includes(flag) ? value : [...value, flag]))}
      />
    </section>
  );
}
