"use client";

import { Languages } from "lucide-react";

export function LanguageToggle({ locale, onChange }: { locale: "en" | "hi"; onChange: (locale: "en" | "hi") => void }) {
  return (
    <div className="flex items-center gap-2">
      <Languages className="h-4 w-4 text-primary" />
      <div className="flex rounded-md border border-border bg-background/70 p-1">
        {(["en", "hi"] as const).map((item) => (
          <button
            key={item}
            type="button"
            className={`rounded px-3 py-1.5 text-xs font-semibold ${locale === item ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
            onClick={() => onChange(item)}
          >
            {item.toUpperCase()}
          </button>
        ))}
      </div>
    </div>
  );
}
