"use client";

import { Award } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export function ProgressTracker({ score, total }: { score: number; total: number }) {
  const progress = total ? Math.round((score / total) * 100) : 0;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">{progress}% demo progress · {score}/{total} actions completed</p>
        {score === total ? (
          <Badge tone="default" className="gap-2">
            <Award className="h-4 w-4" />
            Completion badge
          </Badge>
        ) : null}
      </div>
      <Progress value={progress} />
    </div>
  );
}
