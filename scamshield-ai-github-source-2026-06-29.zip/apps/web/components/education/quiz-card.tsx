"use client";

import { BookOpenCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { QuizOption } from "./quiz-option";

export type QuizModule = {
  id: string;
  title: Record<"en" | "hi", string>;
  topic: string;
  question: Record<"en" | "hi", string>;
  explanation: Record<"en" | "hi", string>;
  choices: Array<{ label: Record<"en" | "hi", string>; safe: boolean }>;
};

export function QuizCard({
  module,
  locale,
  answer,
  onAnswer
}: {
  module: QuizModule;
  locale: "en" | "hi";
  answer: number | undefined;
  onAnswer: (choiceIndex: number) => void;
}) {
  const answered = answer !== undefined;
  const correct = answered ? module.choices[answer]?.safe === true : false;
  return (
    <Card className="glass">
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <BookOpenCheck className="h-6 w-6 text-primary" />
          <Badge tone="info">{module.topic}</Badge>
        </div>
        <CardTitle>{module.title[locale]}</CardTitle>
        <CardDescription>{module.question[locale]}</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-2">
        {module.choices.map((choice, index) => (
          <QuizOption
            key={choice.label.en}
            label={choice.label[locale]}
            selected={answer === index}
            correct={choice.safe}
            answered={answered}
            onClick={() => onAnswer(index)}
          />
        ))}
        {answered ? (
          <p className="rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">
            {correct ? "Correct. " : "Wrong answer. "}
            {module.explanation[locale]}
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}
