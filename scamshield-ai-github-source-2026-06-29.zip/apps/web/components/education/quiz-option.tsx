"use client";

import { CheckCircle2, XCircle } from "lucide-react";

export function QuizOption({
  label,
  selected,
  correct,
  answered,
  onClick
}: {
  label: string;
  selected: boolean;
  correct: boolean;
  answered: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-h-12 items-center justify-between gap-3 rounded-md border p-3 text-left text-sm transition ${
        selected ? "border-primary/50 bg-primary/10" : "border-border bg-background/60 hover:border-primary/35"
      }`}
    >
      <span>{label}</span>
      {answered ? correct ? <CheckCircle2 className="h-4 w-4 text-primary" /> : selected ? <XCircle className="h-4 w-4 text-red-200" /> : null : null}
    </button>
  );
}
