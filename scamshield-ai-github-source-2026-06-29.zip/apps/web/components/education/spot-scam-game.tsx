"use client";

import { CheckCircle2, Gamepad2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function SpotScamGame({
  text,
  flags,
  foundFlags,
  onFind
}: {
  text: string;
  flags: string[];
  foundFlags: string[];
  onFind: (flag: string) => void;
}) {
  return (
    <Card className="glass">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Gamepad2 className="h-6 w-6 text-primary" />
          <CardTitle>Spot The Scam Mini-Game</CardTitle>
        </div>
        <CardDescription>Tap every suspicious phrase in the message. Score: {foundFlags.length}/{flags.length}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="rounded-lg border border-border bg-background/60 p-4 text-sm leading-7 text-muted-foreground">{text}</p>
        <div className="flex flex-wrap gap-2">
          {flags.map((flag) => {
            const active = foundFlags.includes(flag);
            return (
              <Button key={flag} type="button" variant={active ? "secondary" : "outline"} onClick={() => onFind(flag)}>
                {active ? <CheckCircle2 className="h-4 w-4" /> : null}
                {flag}
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
