"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, ShieldCheck, X } from "lucide-react";
import { useState } from "react";
import { EnergyButton } from "@/components/ui/EnergyButton";

const links: Array<{ label: string; href: string }> = [
  { label: "Scan", href: "/scanner" },
  { label: "Alerts", href: "/alerts" },
  { label: "Learn", href: "/education" },
  { label: "Report", href: "/report" },
  { label: "Dashboard", href: "/dashboard" },
  { label: "Security Lab", href: "/security-lab" },
  { label: "Database", href: "/database" }
];

export function Navbar() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed left-0 right-0 top-4 z-50 px-4">
      <nav className="mx-auto flex max-w-7xl items-center justify-between rounded-3xl glass-panel px-4 py-3">
        <Link href="/" className="flex items-center gap-3 font-black tracking-wide text-white">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-cursed/25 text-energy shadow-cursed"><ShieldCheck size={22} /></span>
          ScamShield AI
        </Link>
        <div className="hidden items-center gap-1 lg:flex">
          {links.map(({ label, href }) => (
            <Link key={href} href={href} className={`rounded-2xl px-3 py-2 text-sm transition hover:bg-white/10 ${path === href ? "bg-cursed/20 text-energy shadow-energy" : "text-slate-300"}`}>{label}</Link>
          ))}
        </div>
        <div className="hidden lg:block"><EnergyButton href="/scanner">Scan Now</EnergyButton></div>
        <button className="grid h-10 w-10 place-items-center rounded-2xl bg-white/10 lg:hidden" onClick={() => setOpen(!open)} aria-label="Open menu">{open ? <X /> : <Menu />}</button>
      </nav>
      {open && (
        <div className="mx-auto mt-3 max-w-7xl rounded-3xl glass-panel p-4 lg:hidden">
          <div className="grid gap-2">
            {links.map(({ label, href }) => <Link key={href} href={href} onClick={() => setOpen(false)} className="rounded-2xl px-4 py-3 text-slate-200 hover:bg-white/10">{label}</Link>)}
          </div>
        </div>
      )}
    </header>
  );
}
