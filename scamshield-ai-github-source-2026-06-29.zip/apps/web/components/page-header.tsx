import { Badge } from "@/components/ui/badge";

export function PageHeader({
  eyebrow,
  title,
  description
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <section className="container holo-panel scroll-mt-24 pt-16 pb-10 md:pt-20 md:pb-14">
      <div className="glass-panel scan-line rounded-3xl p-6 md:p-8">
        <Badge tone="info" className="border-energy/30 bg-energy/10 text-energy">
          {eyebrow}
        </Badge>
        <h1 className="mt-4 max-w-3xl text-3xl font-black leading-tight tracking-normal text-balance text-white md:text-4xl lg:text-5xl">
          {title}
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-7 text-slate-300 md:text-lg">{description}</p>
      </div>
    </section>
  );
}
