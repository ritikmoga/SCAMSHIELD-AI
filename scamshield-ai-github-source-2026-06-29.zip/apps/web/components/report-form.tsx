"use client";

import { useState, useTransition } from "react";
import { AlertCircle, CheckCircle2, Upload } from "lucide-react";
import type { ScanType } from "@scamshield/shared";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { submitReport } from "@/lib/api";
import { buildSafePreview } from "@/lib/redaction";

const reportTypes: ScanType[] = ["url", "phone", "upi", "qr", "message", "email", "job", "shopping", "social", "screenshot"];
const platforms = ["WhatsApp", "SMS", "Email", "Telegram", "Instagram", "Facebook", "Shopping website", "Phone call", "Other"];
const reportSchema = z.object({
  type: z.string().min(1, "Choose a report type."),
  value: z.string().trim().min(3, "Enter the suspicious value."),
  description: z.string().trim().min(12, "Describe the scam attempt in at least 12 characters."),
  sourcePlatform: z.string().min(1, "Choose a source platform."),
  consent: z.literal(true, {
    errorMap: () => ({ message: "Consent is required for moderator review." })
  })
});

export function ReportForm() {
  const [type, setType] = useState<ScanType>("url");
  const [value, setValue] = useState("");
  const [description, setDescription] = useState("");
  const [sourcePlatform, setSourcePlatform] = useState("WhatsApp");
  const [userContact, setUserContact] = useState("");
  const [anonymous, setAnonymous] = useState(true);
  const [screenshotName, setScreenshotName] = useState("");
  const [screenshotFile, setScreenshotFile] = useState<File | undefined>();
  const [screenshotError, setScreenshotError] = useState<string | null>(null);
  const [consent, setConsent] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const valid = value.trim().length >= 3 && description.trim().length >= 12 && consent && !screenshotError;

  function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setStatus(null);
    setError(null);
    setFieldErrors({});

    const parsed = reportSchema.safeParse({ type, value, description, sourcePlatform, consent });
    if (!parsed.success || screenshotError) {
      setFieldErrors(
        Object.fromEntries(parsed.error?.issues.map((issue) => [String(issue.path[0]), issue.message]) ?? [])
      );
      setError(screenshotError ?? "Fix the highlighted fields before submitting.");
      return;
    }

    startTransition(async () => {
      try {
        await submitReport({ type, value, description, sourcePlatform, userContact: anonymous ? "" : userContact, consent, screenshot: screenshotFile });
        setStatus("Report submitted for moderator verification. Private contact details are not shown publicly.");
        setValue("");
        setDescription("");
        setUserContact("");
        setAnonymous(true);
        setScreenshotName("");
        setScreenshotFile(undefined);
        setConsent(false);
      } catch {
        setError("Report submission failed. Please check your connection and try again.");
      }
    });
  }

  return (
    <Card className="glass">
      <CardHeader>
        <CardTitle>Submit Scam Report</CardTitle>
        <CardDescription>Reports are hashed for matching and reviewed before becoming verified indicators.</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="grid gap-5" onSubmit={onSubmit}>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm font-medium">
              Report type
              <select
                value={type}
                onChange={(event) => setType(event.target.value as ScanType)}
                className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring"
              >
                {reportTypes.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            {fieldErrors.type ? <p className="-mt-2 text-xs text-red-200">{fieldErrors.type}</p> : null}
            <label className="grid gap-2 text-sm font-medium">
              Source platform
              <select
                value={sourcePlatform}
                onChange={(event) => setSourcePlatform(event.target.value)}
                className="h-11 rounded-md border border-input bg-background/80 px-3 text-sm focus-ring"
              >
                {platforms.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            {fieldErrors.sourcePlatform ? <p className="-mt-2 text-xs text-red-200">{fieldErrors.sourcePlatform}</p> : null}
          </div>

          <label className="grid gap-2 text-sm font-medium">
            Suspicious value
            <Input value={value} onChange={(event) => setValue(event.target.value)} placeholder="URL, phone, UPI ID, email, QR payload, or message snippet" />
          </label>
          {fieldErrors.value ? <p className="-mt-3 text-xs text-red-200">{fieldErrors.value}</p> : null}
          {value.trim() ? (
            <div className="rounded-md border border-border bg-background/60 p-3 text-xs text-muted-foreground">
              Redacted preview before submit: {buildSafePreview(value, 160)}
            </div>
          ) : null}

          <label className="grid gap-2 text-sm font-medium">
            Description
            <Textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Describe what happened, pressure tactics, payment requests, links, or impersonation claims."
              className="min-h-[150px]"
            />
          </label>
          {fieldErrors.description ? <p className="-mt-3 text-xs text-red-200">{fieldErrors.description}</p> : null}

          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm font-medium">
              Optional screenshot upload
              <span className="flex min-h-24 cursor-pointer items-center justify-center gap-3 rounded-lg border border-dashed border-primary/35 bg-primary/5 p-4 text-center text-sm text-muted-foreground hover:bg-primary/10">
                <Upload className="h-5 w-5 text-primary" />
                {screenshotName || "Choose PNG/JPG evidence"}
                <input
                  type="file"
                  className="sr-only"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    setScreenshotError(null);
                    setScreenshotName("");
                    setScreenshotFile(undefined);
                    if (!file) return;
                    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) {
                      setScreenshotError("Screenshot must be PNG, JPG, or WebP.");
                      return;
                    }
                    if (file.size > 5 * 1024 * 1024) {
                      setScreenshotError("Screenshot must be below 5MB.");
                      return;
                    }
                    setScreenshotName(file.name);
                    setScreenshotFile(file);
                  }}
                />
              </span>
              {screenshotError ? <span className="text-xs text-red-200">{screenshotError}</span> : null}
            </label>
            <label className="grid gap-2 text-sm font-medium">
              User contact optional
              <Input value={userContact} onChange={(event) => setUserContact(event.target.value)} placeholder="Email or phone for moderator follow-up" disabled={anonymous} />
              <span className="text-xs text-muted-foreground">Not shown publicly. Leave blank for anonymous reporting.</span>
              <span className="flex items-center gap-2 text-xs text-muted-foreground">
                <input type="checkbox" checked={anonymous} onChange={(event) => setAnonymous(event.target.checked)} className="h-4 w-4 accent-primary" />
                Submit anonymously
              </span>
            </label>
          </div>

          <div className="rounded-lg border border-cyan-300/25 bg-cyan-300/10 p-4 text-sm leading-6 text-cyan-50">
            Reports are hashed for matching and reviewed before becoming verified indicators.
          </div>

          <label className="flex items-start gap-3 rounded-lg border border-border bg-background/60 p-4 text-sm leading-6 text-muted-foreground">
            <input
              type="checkbox"
              checked={consent}
              onChange={(event) => setConsent(event.target.checked)}
              className="mt-1 h-4 w-4 accent-primary"
            />
            <span>I consent to ScamShield reviewing this report for defensive scam detection. I understand my contact is optional and not shown publicly.</span>
          </label>

          {error ? (
            <p className="flex items-start gap-2 rounded-md border border-red-400/25 bg-red-400/10 p-3 text-sm text-red-100">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              {error}
            </p>
          ) : null}
          {status ? (
            <p className="flex items-start gap-2 rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              {status}
            </p>
          ) : null}

          <Button disabled={isPending || !valid}>{isPending ? "Submitting..." : "Submit Report"}</Button>
        </form>
      </CardContent>
    </Card>
  );
}
