import { Badge } from "@/components/ui/badge";
import type { ApiScanStatus } from "@/lib/risk-engine/types";

export function ApiStatusPanel({ statuses }: { statuses: ApiScanStatus[] | undefined }) {
  const items = statuses ?? [];
  return (
    <div className="grid gap-2">
      {items.map((item) => (
        <div key={item.provider} className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-sm font-semibold">{item.provider}</span>
            <Badge tone={item.status === "checked" ? "default" : item.status === "missing_key" || item.status === "rate_limited" ? "warning" : "muted"}>
              {item.status.replace("_", " ")}
            </Badge>
          </div>
          <p className="mt-2 text-xs leading-5 text-slate-400">{item.message}</p>
        </div>
      ))}
    </div>
  );
}

