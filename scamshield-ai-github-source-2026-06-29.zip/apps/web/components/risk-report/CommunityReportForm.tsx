import Link from "next/link";

export function CommunityReportForm({ value }: { value?: string }) {
  const href = value ? `/report?value=${encodeURIComponent(value)}` : "/report";
  return (
    <Link href={href} className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-200 hover:bg-white/10">
      Report this indicator
    </Link>
  );
}

