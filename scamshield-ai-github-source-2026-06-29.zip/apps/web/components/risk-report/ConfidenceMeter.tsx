export function ConfidenceMeter({ score }: { score: number }) {
  const safeScore = Math.max(0, Math.min(100, Math.round(score)));
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="flex items-center justify-between gap-3 text-sm">
        <span className="font-semibold">Confidence</span>
        <span className="text-slate-300">{safeScore}%</span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
        <div className="h-full rounded-full bg-gradient-to-r from-cursed to-energy" style={{ width: `${safeScore}%` }} />
      </div>
      <p className="mt-2 text-xs text-slate-400">
        Confidence reflects available evidence, completed API checks, domain data, page analysis, and community signals.
      </p>
    </div>
  );
}

