import type { EvidenceItem } from "@/lib/risk-engine/types";

export function EvidencePanel({ evidence }: { evidence: EvidenceItem[] | undefined }) {
  const items = evidence ?? [];
  return (
    <div className="grid gap-2">
      {items.length ? (
        items.slice(0, 18).map((item) => (
          <div key={`${item.label}-${String(item.value)}`} className="grid gap-2 rounded-2xl border border-white/10 bg-white/5 p-3 text-sm sm:grid-cols-[210px_1fr]">
            <span className="font-medium text-slate-200">{item.label}</span>
            <span className="break-words text-slate-400">{String(item.value)}</span>
          </div>
        ))
      ) : (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-slate-400">No evidence available.</div>
      )}
    </div>
  );
}

