import type { HttpsInfo } from "@/lib/risk-engine/types";

export function HttpsEducationCard({ info }: { info: HttpsInfo | undefined }) {
  if (!info) return null;
  return (
    <div className="rounded-2xl border border-amber-300/25 bg-amber-300/10 p-4">
      <h4 className="text-sm font-semibold text-amber-100">HTTPS is not the same as trust</h4>
      <p className="mt-2 text-sm leading-6 text-amber-50">{info.note}</p>
      <div className="mt-3 grid gap-2 text-xs text-amber-50 sm:grid-cols-3">
        <span>HTTPS: {info.present ? "Present" : "Not present / unknown"}</span>
        <span>Encryption: {info.encryption}</span>
        <span>Trust level: {info.trustLevel}</span>
      </div>
    </div>
  );
}

