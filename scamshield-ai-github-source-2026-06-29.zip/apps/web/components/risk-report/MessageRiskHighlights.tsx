export function MessageRiskHighlights({ keywords }: { keywords: string[] | undefined }) {
  if (!keywords?.length) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {keywords.map((keyword) => (
        <span key={keyword} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300">
          {keyword}
        </span>
      ))}
    </div>
  );
}

