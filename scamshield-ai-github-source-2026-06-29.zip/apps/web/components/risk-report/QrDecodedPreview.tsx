export function QrDecodedPreview({ payload }: { payload?: string }) {
  if (!payload) return null;
  const type = /^upi:\/\//i.test(payload) ? "UPI Payment" : /^https?:\/\//i.test(payload) ? "URL" : "Text / Unknown";
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm">
      <div className="font-semibold">QR decoded preview</div>
      <p className="mt-2 text-slate-400">QR Type: {type}</p>
      <p className="mt-1 break-all text-slate-300">{payload}</p>
    </div>
  );
}

