export function RecommendedActions({ actions }: { actions: string[] | undefined }) {
  return (
    <div className="grid gap-2">
      {(actions ?? []).map((action) => (
        <div key={action} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm leading-6 text-slate-300">
          {action}
        </div>
      ))}
    </div>
  );
}

