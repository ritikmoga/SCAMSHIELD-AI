import type { RedirectHop } from "@/lib/risk-engine/types";

export function RedirectChainViewer({ chain }: { chain: RedirectHop[] | undefined }) {
  const hops = chain ?? [];
  if (!hops.length) return <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-slate-400">No redirect chain captured.</div>;
  return (
    <div className="grid gap-2">
      {hops.map((hop, index) => (
        <div key={`${hop.url}-${index}`} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm">
          <span className="text-slate-400">Hop {index + 1}{hop.status ? ` · HTTP ${hop.status}` : ""}</span>
          <p className="mt-1 break-all text-slate-200">{hop.url}</p>
        </div>
      ))}
    </div>
  );
}

