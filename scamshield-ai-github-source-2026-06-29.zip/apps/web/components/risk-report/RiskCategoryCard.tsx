import { Badge } from "@/components/ui/badge";
import type { RiskCategoryScore } from "@/lib/risk-engine/types";

export function RiskCategoryCard({ category }: { category: RiskCategoryScore }) {
  const tone = category.score >= 61 ? "danger" : category.score >= 41 ? "warning" : "muted";
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h4 className="text-sm font-semibold">{category.label}</h4>
          <p className="mt-2 text-xs leading-5 text-slate-400">{category.reason}</p>
        </div>
        <Badge tone={tone}>{category.score}/100</Badge>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {category.evidenceTags.map((tag) => (
          <span key={tag} className="rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-slate-300">
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
}

