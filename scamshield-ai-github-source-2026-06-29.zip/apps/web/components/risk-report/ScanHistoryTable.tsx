export function ScanHistoryTable() {
  return null;
}

