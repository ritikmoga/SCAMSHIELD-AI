import type { ScanTimelineItem } from "@/lib/risk-engine/types";

export function ScanTimeline({ timeline }: { timeline: ScanTimelineItem[] | undefined }) {
  const items = timeline ?? [];
  return (
    <div className="grid gap-2">
      {items.map((item, index) => (
        <div key={`${item.step}-${index}`} className="rounded-2xl border border-white/10 bg-white/5 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-sm font-semibold">{index + 1}. {item.step}</span>
            <span className="text-xs uppercase tracking-[0.16em] text-slate-400">{item.status} · {item.durationMs}ms</span>
          </div>
          <p className="mt-2 text-xs leading-5 text-slate-400">{item.message}</p>
        </div>
      ))}
    </div>
  );
}

