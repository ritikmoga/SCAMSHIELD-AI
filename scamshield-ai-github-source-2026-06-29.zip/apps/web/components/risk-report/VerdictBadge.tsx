import { Badge } from "@/components/ui/badge";
import type { DetailedVerdict } from "@/lib/risk-engine/types";

export function VerdictBadge({ verdict }: { verdict: DetailedVerdict | undefined }) {
  const label = verdict ?? "Suspicious";
  const tone = label === "Critical Risk" || label === "High Risk" ? "danger" : label === "Suspicious" || label === "Low Risk" ? "warning" : "default";
  return <Badge tone={tone}>{label}</Badge>;
}

