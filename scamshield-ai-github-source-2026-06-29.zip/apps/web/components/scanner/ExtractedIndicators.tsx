"use client";

import { Badge } from "@/components/ui/badge";
import type { ExtractedIndicators as ExtractedIndicatorsType } from "@/lib/indicators";

export function ExtractedIndicators({ indicators }: { indicators: ExtractedIndicatorsType }) {
  return (
    <div className="grid gap-2">
      <IndicatorGroup label="URLs" values={indicators.urls} />
      <IndicatorGroup label="Domains" values={indicators.domains} />
      <IndicatorGroup label="Emails" values={indicators.emails} />
      <IndicatorGroup label="Phone numbers" values={indicators.phoneNumbers} />
      <IndicatorGroup label="UPI IDs" values={indicators.upiIds} />
      <IndicatorGroup label="Suspicious keywords" values={indicators.keywords} />
    </div>
  );
}

function IndicatorGroup({ label, values }: { label: string; values: string[] }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="mb-2 text-xs font-semibold text-slate-400">{label}</div>
      <div className="flex flex-wrap gap-2">
        {values.length ? (
          values.slice(0, 10).map((value) => (
            <Badge key={value} tone="muted" className="max-w-full break-all border-white/10 bg-white/10">
              {value}
            </Badge>
          ))
        ) : (
          <span className="text-xs text-slate-500">None found</span>
        )}
      </div>
    </div>
  );
}
