"use client";

import { AlertTriangle, CheckCircle2, ShieldAlert } from "lucide-react";
import type { ScanVerdict } from "@/lib/risk-engine/types";
import { Badge } from "@/components/ui/badge";

export function RiskBadge({ verdict }: { verdict: ScanVerdict }) {
  const Icon = verdict === "Dangerous" ? ShieldAlert : verdict === "Suspicious" ? AlertTriangle : CheckCircle2;
  const tone = verdict === "Dangerous" ? "danger" : verdict === "Suspicious" ? "warning" : "default";
  return (
    <Badge tone={tone} className="gap-2">
      <Icon className="h-4 w-4" />
      {verdict}
    </Badge>
  );
}
