"use client";

import Link from "next/link";
import { useState } from "react";
import { Copy, FileJson, FileText, FileDown, ScanLine } from "lucide-react";
import { SCAN_TYPE_LABELS } from "@scamshield/shared";
import { ApiStatusPanel } from "@/components/risk-report/ApiStatusPanel";
import { CommunityReportForm } from "@/components/risk-report/CommunityReportForm";
import { ConfidenceMeter } from "@/components/risk-report/ConfidenceMeter";
import { EvidencePanel } from "@/components/risk-report/EvidencePanel";
import { HttpsEducationCard } from "@/components/risk-report/HttpsEducationCard";
import { MessageRiskHighlights } from "@/components/risk-report/MessageRiskHighlights";
import { QrDecodedPreview } from "@/components/risk-report/QrDecodedPreview";
import { RecommendedActions } from "@/components/risk-report/RecommendedActions";
import { RedirectChainViewer } from "@/components/risk-report/RedirectChainViewer";
import { RiskCategoryCard } from "@/components/risk-report/RiskCategoryCard";
import { ScanTimeline } from "@/components/risk-report/ScanTimeline";
import { VerdictBadge } from "@/components/risk-report/VerdictBadge";
import { RiskMeter as AnimeRiskMeter } from "@/components/ui/AnimeRiskMeter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { ScanResult } from "@/lib/risk-engine/types";
import { ExtractedIndicators } from "./ExtractedIndicators";
import { RiskBadge } from "./RiskBadge";

export function ScanResultCard({ result, onScanAgain }: { result: ScanResult; onScanAgain: () => void }) {
  const [copied, setCopied] = useState(false);

  async function copyReport() {
    await navigator.clipboard.writeText(buildReport(result));
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `scamshield-${result.type}-${result.id}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  function exportPdf() {
    const printWindow = window.open("", "_blank", "noopener,noreferrer,width=900,height=1000");
    if (!printWindow) return;
    printWindow.document.write(buildPrintableReport(result));
    printWindow.document.close();
    printWindow.focus();
    window.setTimeout(() => printWindow.print(), 250);
  }

  return (
    <div className="space-y-6">
      <AnimeRiskMeter score={result.riskScore} />
      <Card className="glass-panel rounded-3xl">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Final Verdict: {result.verdictLabel ?? result.verdict}</CardTitle>
              <CardDescription>{result.mainReason ?? result.inputPreview}</CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              <VerdictBadge verdict={result.verdictLabel} />
              <RiskBadge verdict={result.verdict} />
              <Badge tone="muted">{result.confidenceScore}% confidence</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid gap-3 md:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-sm text-slate-400">Scan ID</div>
              <div className="mt-1 break-all text-sm font-semibold">{result.id}</div>
              <div className="mt-3 text-sm text-slate-400">Scan date/time</div>
              <div className="mt-1 text-sm font-semibold">{new Date(result.createdAt).toLocaleString()}</div>
            </div>
            <ConfidenceMeter score={result.confidenceScore} />
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
              <FileText className="h-4 w-4 text-energy" />
              Why this score?
            </div>
            <p className="text-sm leading-6 text-slate-300">{result.explanation}</p>
          </div>

          <ResultSection title="Risk Category Breakdown">
            <div className="grid gap-3 md:grid-cols-2">
              {(result.categoryScores ?? []).map((category) => (
                <RiskCategoryCard key={category.key} category={category} />
              ))}
            </div>
          </ResultSection>

          <ResultSection title="Red Flags">
            {result.redFlags.length ? (
              result.redFlags.map((flag) => (
                <div key={flag.id} className="rounded-md border border-border bg-background/60 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium">{flag.label}</span>
                  <Badge tone={flag.severity === "critical" || flag.severity === "high" ? "danger" : "warning"}>{flag.severity}</Badge>
                </div>
                  {flag.evidence ? <p className="mt-1 text-xs text-slate-400">Evidence: {flag.evidence}</p> : null}
                </div>
              ))
            ) : (
              <EmptyLine>No strong red flags detected.</EmptyLine>
            )}
          </ResultSection>

          <ResultSection title="Extracted Indicators">
            <ExtractedIndicators indicators={result.extractedIndicators} />
          </ResultSection>

          {result.type === "qr" ? (
            <ResultSection title="QR Decoded Preview">
              <QrDecodedPreview payload={result.inputPreview} />
            </ResultSection>
          ) : null}

          <ResultSection title="Message Risk Highlights">
            <MessageRiskHighlights keywords={result.extractedIndicators.keywords} />
          </ResultSection>

          <ResultSection title="Evidence">
            <EvidencePanel evidence={result.evidence} />
          </ResultSection>

          <ResultSection title="Redirect Chain">
            <RedirectChainViewer chain={result.redirectChain} />
          </ResultSection>

          <ResultSection title="HTTPS Explanation">
            <HttpsEducationCard info={result.httpsInfo} />
          </ResultSection>

          <ResultSection title="API Status">
            <ApiStatusPanel statuses={result.apiStatuses} />
          </ResultSection>

          <ResultSection title="Scan Timeline">
            <ScanTimeline timeline={result.scanTimeline} />
          </ResultSection>

          <ResultSection title="Safer Next Steps">
            <RecommendedActions actions={result.saferNextSteps} />
          </ResultSection>

          <ResultSection title="Technical Details">
            <pre className="max-h-72 overflow-auto rounded-2xl border border-white/10 bg-black/30 p-3 text-xs leading-5 text-slate-300">
              {JSON.stringify(result.technicalDetails ?? { formula: result.scoreFormula }, null, 2)}
            </pre>
          </ResultSection>

          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3">
            <span className="text-xs text-slate-400">Raw input stored: No. Result uses redacted preview and extracted indicators only.</span>
            <div className="flex flex-wrap gap-2">
              <CommunityReportForm value={result.inputPreview} />
              <Button type="button" variant="outline" onClick={copyReport}>
                <Copy className="h-4 w-4" />
                {copied ? "Copied" : "Copy Report"}
              </Button>
              <Button type="button" variant="outline" onClick={exportPdf}>
                <FileDown className="h-4 w-4" />
                Export PDF
              </Button>
              <Button type="button" variant="outline" onClick={exportJson}>
                <FileJson className="h-4 w-4" />
                Export JSON
              </Button>
              <Button type="button" variant="secondary" onClick={onScanAgain}>
                <ScanLine className="h-4 w-4" />
                Scan Again
              </Button>
              <Button asChild variant="outline">
                <Link href="/dashboard">Save / View History</Link>
              </Button>
            </div>
          </div>
          {result.reportDisclaimer ? <p className="text-xs leading-5 text-slate-500">{result.reportDisclaimer}</p> : null}
        </CardContent>
      </Card>
    </div>
  );
}

function ResultSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-energy">{title}</h3>
      <div className="grid gap-2">{children}</div>
    </div>
  );
}

function EmptyLine({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-slate-400">{children}</div>;
}

function buildReport(result: ScanResult) {
  return [
    "ScamShield AI Scan Report",
    `Type: ${SCAN_TYPE_LABELS[result.type]}`,
    `Risk score: ${result.riskScore}/100`,
    `Verdict: ${result.verdictLabel ?? result.verdict}`,
    `Confidence: ${result.confidenceScore}%`,
    `Main reason: ${result.mainReason ?? "No major risk found in available checks"}`,
    `Preview: ${result.inputPreview}`,
    "",
    "Explanation:",
    result.explanation,
    "",
    "Red flags:",
    ...(result.redFlags.length ? result.redFlags.map((item) => `- ${item.label} (${item.severity})`) : ["- No strong red flags detected"]),
    "",
    "Category breakdown:",
    ...((result.categoryScores ?? []).map((item) => `- ${item.label}: ${item.score}/100 - ${item.reason}`)),
    "",
    "Evidence:",
    ...((result.evidence ?? []).slice(0, 12).map((item) => `- ${item.label}: ${String(item.value)}`)),
    "",
    "Safer next steps:",
    ...result.saferNextSteps.map((item) => `- ${item}`),
    "",
    result.reportDisclaimer ?? "This report is based on available signals and does not guarantee complete safety."
  ].join("\n");
}

function buildPrintableReport(result: ScanResult) {
  const escape = (value: unknown) =>
    String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  const rows = (result.evidence ?? []).map((item) => `<tr><td>${escape(item.label)}</td><td>${escape(item.value)}</td></tr>`).join("");
  const categories = (result.categoryScores ?? []).map((item) => `<li><strong>${escape(item.label)}:</strong> ${item.score}/100 - ${escape(item.reason)}</li>`).join("");
  const timeline = (result.scanTimeline ?? []).map((item) => `<li><strong>${escape(item.step)}:</strong> ${escape(item.status)} - ${escape(item.message)} (${item.durationMs}ms)</li>`).join("");
  return `<!doctype html>
<html>
<head>
  <title>ScamShield AI Report ${escape(result.id)}</title>
  <style>
    body { font-family: Arial, sans-serif; color: #111827; margin: 32px; line-height: 1.5; }
    h1, h2 { color: #111827; }
    .box { border: 1px solid #d1d5db; border-radius: 12px; padding: 16px; margin: 16px 0; }
    table { width: 100%; border-collapse: collapse; }
    td { border-bottom: 1px solid #e5e7eb; padding: 8px; vertical-align: top; }
    .muted { color: #4b5563; font-size: 12px; }
  </style>
</head>
<body>
  <h1>ScamShield AI Scan Report</h1>
  <div class="box">
    <p><strong>Scan ID:</strong> ${escape(result.id)}</p>
    <p><strong>Date/time:</strong> ${escape(new Date(result.createdAt).toLocaleString())}</p>
    <p><strong>Input type:</strong> ${escape(SCAN_TYPE_LABELS[result.type])}</p>
    <p><strong>Final verdict:</strong> ${escape(result.verdictLabel ?? result.verdict)}</p>
    <p><strong>Risk score:</strong> ${result.riskScore}/100</p>
    <p><strong>Confidence:</strong> ${result.confidenceScore}%</p>
    <p><strong>Main reason:</strong> ${escape(result.mainReason ?? "No major risk found in available checks")}</p>
  </div>
  <h2>Explanation</h2>
  <p>${escape(result.explanation)}</p>
  <h2>Category Breakdown</h2>
  <ul>${categories}</ul>
  <h2>Evidence</h2>
  <table>${rows}</table>
  <h2>Timeline</h2>
  <ul>${timeline}</ul>
  <h2>Recommended Actions</h2>
  <ul>${result.saferNextSteps.map((item) => `<li>${escape(item)}</li>`).join("")}</ul>
  <p class="muted">${escape(result.reportDisclaimer ?? "This report is based on available signals and does not guarantee complete safety.")}</p>
</body>
</html>`;
}
