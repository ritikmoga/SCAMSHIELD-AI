"use client";

import { AlertTriangle, ClipboardPaste, Eraser, Loader2, RotateCcw, ScanLine, ShieldCheck, Upload } from "lucide-react";
import { SCAN_TYPE_LABELS, type ScanType } from "@scamshield/shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { scanTypes } from "@/lib/demo-data";
import { cn } from "@/lib/utils";

export function ScannerForm({
  activeType,
  input,
  locale,
  scanState,
  status,
  onTypeChange,
  onInputChange,
  onLocaleChange,
  onRunScan,
  onPaste,
  onClear,
  onLoadSample,
  onScreenshotText,
  selectedFileName
}: {
  activeType: ScanType;
  input: string;
  locale: "en" | "hi";
  scanState: "idle" | "scanning" | "completed" | "error";
  status: string | null;
  onTypeChange: (type: ScanType) => void;
  onInputChange: (value: string) => void;
  onLocaleChange: (locale: "en" | "hi") => void;
  onRunScan: () => void;
  onPaste: () => void;
  onClear: () => void;
  onLoadSample: () => void;
  onScreenshotText: (file: File | undefined) => void;
  selectedFileName?: string;
}) {
  const selectedMeta = scanTypes.find((item) => item.type === activeType);
  const ActiveIcon = selectedMeta?.icon ?? ShieldCheck;
  const scanning = scanState === "scanning";

  return (
    <Card className="glass-panel scan-line rounded-3xl">
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <Badge tone="info" className="mb-3">
              Unified scanner
            </Badge>
            <CardTitle className="flex items-center gap-2">
              <ActiveIcon className="h-5 w-5 text-primary" />
              {SCAN_TYPE_LABELS[activeType]}
            </CardTitle>
            <CardDescription className="mt-2">
              Defensive-only risk guidance. ScamShield does not open links, initiate payments, or store raw scan input by default.
            </CardDescription>
          </div>
          <div className="flex rounded-2xl border border-white/15 bg-white/5 p-1">
            {(["en", "hi"] as const).map((item) => (
              <button
                key={item}
                type="button"
                className={cn("rounded-xl px-3 py-1.5 text-xs font-semibold", locale === item ? "bg-cursed/25 text-energy shadow-energy" : "text-slate-400 hover:text-white")}
                onClick={() => onLocaleChange(item)}
              >
                {item.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
          {scanTypes.map((item) => {
            const Icon = item.icon;
            const active = activeType === item.type;
            return (
              <button
                key={item.type}
                type="button"
                onClick={() => onTypeChange(item.type)}
                className={cn(
                  "perspective-card min-h-20 rounded-2xl border p-3 text-left transition",
                  active ? "border-energy/60 bg-cursed/15 shadow-energy" : "border-white/10 bg-white/5 hover:border-energy/40 hover:bg-white/10"
                )}
              >
                <Icon className="h-4 w-4 text-energy" />
                <span className="mt-2 block text-xs font-semibold">{inputLabel(item.type)}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-start gap-3 rounded-2xl border border-warning/30 bg-warning/10 p-4 text-sm leading-6 text-yellow-50">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-yellow-200" />
          <span>Never enter OTP, UPI PIN, CVV, passwords, or full identity documents.</span>
        </div>

        {activeType === "screenshot" || activeType === "qr" ? (
          <label className="flex min-h-[118px] cursor-pointer flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-energy/40 bg-energy/5 p-5 text-center transition hover:bg-energy/10">
            <Upload className="h-6 w-6 text-energy" />
            <span className="text-sm font-semibold">{selectedFileName || (activeType === "qr" ? "Upload QR image for safe decoding" : "Upload screenshot for OCR")}</span>
            <span className="text-xs text-muted-foreground">
              Backend decodes QR/OCR/metadata only. Links are not opened and payments are not initiated.
            </span>
            <input type="file" className="sr-only" accept="image/png,image/jpeg,image/webp" onChange={(event) => onScreenshotText(event.target.files?.[0])} />
          </label>
        ) : null}

        <Textarea
          value={input}
          onChange={(event) => onInputChange(event.target.value)}
          placeholder={placeholderFor(activeType)}
          className="min-h-[280px] resize-y rounded-3xl border-white/15 bg-void/60 text-base leading-7 sm:min-h-[320px]"
        />

        {status ? <div className="rounded-2xl border border-energy/25 bg-energy/10 p-3 text-sm text-cyan-50">{status}</div> : null}

        <div className="flex flex-wrap gap-3">
          <Button type="button" variant="outline" onClick={onPaste} disabled={scanning}>
            <ClipboardPaste className="h-4 w-4" />
            Paste
          </Button>
          <Button type="button" variant="outline" onClick={onClear} disabled={scanning}>
            <Eraser className="h-4 w-4" />
            Clear
          </Button>
          <Button type="button" variant="secondary" onClick={onLoadSample} disabled={scanning}>
            <RotateCcw className="h-4 w-4" />
            Load Sample
          </Button>
          <Button type="button" onClick={onRunScan} disabled={scanning || (!input.trim() && !selectedFileName)} className="sm:ml-auto">
            {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <ScanLine className="h-4 w-4" />}
            {scanning ? "Scanning..." : "Run Scan"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function inputLabel(type: ScanType) {
  const labels: Record<ScanType, string> = {
    url: "URL",
    message: "Message",
    email: "Email",
    upi: "UPI ID",
    qr: "QR payload",
    screenshot: "Screenshot text",
    phone: "Phone number",
    job: "Job offer",
    shopping: "Shopping site",
    social: "Social profile"
  };
  return labels[type];
}

function placeholderFor(type: ScanType) {
  const labels: Record<ScanType, string> = {
    url: "Paste a suspicious URL. ScamShield will inspect text indicators without opening it.",
    message: "Paste an SMS, WhatsApp, Telegram, or social message.",
    email: "Paste email sender details, headers, body text, and visible links.",
    upi: "Paste a UPI ID, collect request text, or payment message. Never enter UPI PIN.",
    qr: "Paste decoded QR payload such as upi://pay?... or visible QR text.",
    screenshot: "Paste OCR text from a screenshot, including visible URLs, numbers, UPI IDs, and message text.",
    phone: "Paste a phone number plus any message or call script connected to it.",
    job: "Paste job offer text, recruiter messages, salary claims, fees, and requested documents.",
    shopping: "Paste shopping site URL, offer text, checkout warning, or seller message.",
    social: "Paste social profile link or chat text asking for codes, money, or recovery help."
  };
  return labels[type];
}
