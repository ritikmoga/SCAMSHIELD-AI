"use client";

import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, ShieldAlert } from "lucide-react";
import type { RiskLevel } from "@scamshield/shared";
import { RISK_LEVELS } from "@scamshield/shared";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const iconMap = {
  Safe: CheckCircle2,
  "Low Risk": CheckCircle2,
  Suspicious: AlertTriangle,
  "High Risk": ShieldAlert,
  Dangerous: ShieldAlert
};

export function RiskMeter({ score, level, confidence }: { score: number; level: RiskLevel; confidence: number }) {
  const color = RISK_LEVELS[level].color;
  const Icon = iconMap[level];
  const circumference = 2 * Math.PI * 54;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="grid gap-5 rounded-lg border border-border bg-background/60 p-5 sm:grid-cols-[160px_1fr]">
      <div className="relative mx-auto h-40 w-40">
        <svg viewBox="0 0 128 128" className="h-full w-full -rotate-90">
          <circle cx="64" cy="64" r="54" fill="none" stroke="rgba(148,163,184,.18)" strokeWidth="10" />
          <motion.circle
            cx="64"
            cy="64"
            r="54"
            fill="none"
            stroke={color}
            strokeLinecap="round"
            strokeWidth="10"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-4xl font-semibold">{score}</span>
          <span className="text-xs text-muted-foreground">risk score</span>
        </div>
      </div>
      <div className="flex flex-col justify-center gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <Badge
            tone={level === "Dangerous" || level === "High Risk" ? "danger" : level === "Suspicious" ? "warning" : "default"}
            className="gap-2 text-sm"
          >
            <Icon className="h-4 w-4" />
            {level}
          </Badge>
          <Badge tone="muted">{confidence}% confidence</Badge>
        </div>
        <div className="grid grid-cols-5 gap-1" aria-label="Risk scale">
          {Object.entries(RISK_LEVELS).map(([name, meta]) => (
            <div
              key={name}
              className={cn("h-2 rounded-full", score >= meta.min ? "opacity-100" : "opacity-25")}
              style={{ backgroundColor: meta.color }}
              title={name}
            />
          ))}
        </div>
        <p className="text-sm leading-6 text-muted-foreground">{RISK_LEVELS[level].tone}</p>
      </div>
    </div>
  );
}
