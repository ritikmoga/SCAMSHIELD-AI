"use client";

import { useEffect, useRef, useState } from "react";
import { ShieldAlert } from "lucide-react";
import type { ScanType } from "@scamshield/shared";
import { PowerCard } from "@/components/ui/PowerCard";
import { ScanLoader } from "@/components/ui/ScanLoader";
import { runDeepScanWithApi, runUnifiedImageScan, runUnifiedScan } from "@/lib/api";
import { sampleInputs } from "@/lib/demo-data";
import { createScanResult, type ScanResult } from "@/lib/risk-engine";
import { ScannerForm } from "./ScannerForm";
import { ScanResultCard } from "./ScanResultCard";

type ScanState = "idle" | "scanning" | "completed" | "error";

export function ScannerWorkspace({ type = "message" }: { type?: ScanType }) {
  const [activeType, setActiveType] = useState<ScanType>(type);
  const [input, setInput] = useState(sampleInputs[type]);
  const [locale, setLocale] = useState<"en" | "hi">("en");
  const [scanState, setScanState] = useState<ScanState>("idle");
  const [result, setResult] = useState<ScanResult | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const resultRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    setActiveType(type);
    setInput(sampleInputs[type]);
    setResult(null);
    setSelectedFile(null);
    setScanState("idle");
    setStatus(null);
  }, [type]);

  useEffect(() => {
    if (scanState === "completed" && result) resultRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [result, scanState]);

  function changeType(nextType: ScanType) {
    setActiveType(nextType);
    setInput(sampleInputs[nextType]);
    setResult(null);
    setSelectedFile(null);
    setStatus(null);
    setScanState("idle");
  }

  async function runScan() {
    const trimmed = input.trim();
    if (!trimmed && !selectedFile) {
      setScanState("error");
      setStatus("Add suspicious content before running a scan.");
      return;
    }

    setScanState("scanning");
    setStatus(selectedFile ? "Running deep backend QR/OCR/metadata and file safety analysis. Links are not opened." : "Running deep backend risk intelligence. Suspicious links are not opened on your device.");
    try {
      const response = await runDeepScanWithApi({
        scanType: activeType,
        input: trimmed || undefined,
        file: selectedFile ?? undefined
      });
      setResult(response.displayResult);
      setScanState("completed");
      setStatus(response.storage.mode === "mongodb" ? "Deep scan completed and redacted history was saved to MongoDB." : "Deep scan completed. Redacted history is using temporary memory storage until MongoDB is connected.");
    } catch {
      try {
        const response =
          selectedFile && (activeType === "qr" || activeType === "screenshot")
            ? await runUnifiedImageScan({ type: activeType, file: selectedFile, input: trimmed, locale })
            : await runUnifiedScan({ type: activeType, input: trimmed, locale });
        setResult(response.result);
        setScanState("completed");
        setStatus("Deep scan was unavailable. The standard backend risk engine completed the scan instead.");
      } catch {
        try {
          if (!trimmed) throw new Error("No text fallback available for selected image.");
          const nextResult = createScanResult(activeType, trimmed);
          setResult({
            ...nextResult,
            apiStatuses: [
              {
                provider: "Backend Risk Intelligence",
                status: "error",
                message: "Backend scan unavailable. Local heuristic fallback used with limited confidence.",
                scoreImpact: 0,
                checkedAt: new Date().toISOString()
              }
            ],
            reportDisclaimer:
              "This fallback report is based on local heuristics only and does not guarantee complete safety. Always verify sensitive requests through official sources."
          });
          setScanState("completed");
          setStatus("Backend scans were unavailable. Showing local heuristic fallback with limited confidence.");
        } catch {
          setResult(null);
          setScanState("error");
          setStatus("The scanner could not analyze this input. Try a smaller file or shorter text sample.");
        }
      }
    }
  }

  async function pasteInput() {
    try {
      const text = await navigator.clipboard.readText();
      if (text) setInput(text);
    } catch {
      setStatus("Clipboard permission was not available. Paste manually into the box.");
    }
  }

  function handleScreenshotText(file: File | undefined) {
    if (!file) return;
    if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 5 * 1024 * 1024) {
      setScanState("error");
      setStatus("Screenshot must be PNG, JPG, or WebP and below 5MB.");
      return;
    }
    setSelectedFile(file);
    if (input === sampleInputs[activeType]) setInput("");
    setStatus(`${activeType === "qr" ? "QR image" : "Screenshot"} selected: ${file.name}. Backend will decode/OCR safely without opening links.`);
    setScanState("idle");
  }

  return (
    <section className="container holo-panel grid gap-6 pb-14 xl:grid-cols-[minmax(0,1fr)_440px]">
      <ScannerForm
        activeType={activeType}
        input={input}
        locale={locale}
        scanState={scanState}
        status={status}
        onTypeChange={changeType}
        onInputChange={(value) => {
          setInput(value);
          if (scanState !== "scanning") setScanState("idle");
        }}
        onLocaleChange={setLocale}
        onRunScan={runScan}
        onPaste={pasteInput}
        onClear={() => {
          setInput("");
          setResult(null);
          setSelectedFile(null);
          setStatus(null);
          setScanState("idle");
        }}
        onLoadSample={() => {
          setInput(sampleInputs[activeType]);
          setResult(null);
          setSelectedFile(null);
          setStatus(null);
          setScanState("idle");
        }}
        onScreenshotText={handleScreenshotText}
        selectedFileName={selectedFile?.name}
      />

      <aside ref={resultRef} className="space-y-6">
        {scanState === "completed" && result ? (
          <ScanResultCard
            result={result}
            onScanAgain={() => {
              setResult(null);
              setStatus(null);
              setScanState("idle");
            }}
          />
        ) : scanState === "scanning" ? (
          <ScanLoader />
        ) : (
          <PowerCard
            title={scanState === "error" ? "Input Needs Attention" : "Ready To Scan"}
            description={
              scanState === "error"
                ? status ?? "Fix the input and run the scan again."
                : "Run a scan to see score, verdict, confidence, red flags, extracted indicators, and safer next steps."
            }
            icon={<ShieldAlert className="h-6 w-6" />}
            severity={scanState === "error" ? "medium" : "low"}
          >
            <div className="grid gap-3 text-sm text-slate-300">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">No links are opened automatically.</div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">Raw input is redacted before previews and demo history.</div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">Guest mode uses local risk guidance and demo limits.</div>
            </div>
          </PowerCard>
        )}
      </aside>
    </section>
  );
}
