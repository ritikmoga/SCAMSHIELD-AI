"use client";

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const data = [
  { day: "Mon", scams: 42, blocked: 34 },
  { day: "Tue", scams: 58, blocked: 49 },
  { day: "Wed", scams: 51, blocked: 45 },
  { day: "Thu", scams: 73, blocked: 68 },
  { day: "Fri", scams: 66, blocked: 59 },
  { day: "Sat", scams: 89, blocked: 80 },
  { day: "Sun", scams: 77, blocked: 71 }
];

export function SecurityChart() {
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ left: -20, right: 10, top: 10, bottom: 0 }}>
          <defs>
            <linearGradient id="blocked" x1="0" x2="0" y1="0" y2="1">
              <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.45} />
              <stop offset="95%" stopColor="#22d3ee" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="scams" x1="0" x2="0" y1="0" y2="1">
              <stop offset="5%" stopColor="#ff315a" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#ff315a" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="rgba(148,163,184,.16)" vertical={false} />
          <XAxis dataKey="day" stroke="rgba(226,232,240,.55)" tickLine={false} axisLine={false} />
          <YAxis stroke="rgba(226,232,240,.55)" tickLine={false} axisLine={false} />
          <Tooltip
            contentStyle={{
              background: "#060b0f",
              border: "1px solid rgba(148,163,184,.25)",
              borderRadius: 8,
              color: "#fff"
            }}
          />
          <Area type="monotone" dataKey="scams" stroke="#ff315a" fill="url(#scams)" strokeWidth={2} />
          <Area type="monotone" dataKey="blocked" stroke="#22d3ee" fill="url(#blocked)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
