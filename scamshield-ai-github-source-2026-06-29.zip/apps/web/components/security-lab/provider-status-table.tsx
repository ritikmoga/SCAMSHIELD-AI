"use client";

import { useEffect, useState, useTransition } from "react";
import { Copy, PlugZap, Settings, TestTube2 } from "lucide-react";
import type { ProviderStatusItem } from "@/lib/integrations/status";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getProviderConnectionStatuses, testProviderConnection } from "@/lib/api";

export function ProviderStatusTable() {
  const [providers, setProviders] = useState<ProviderStatusItem[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    let mounted = true;
    getProviderConnectionStatuses()
      .then((response) => {
        if (mounted) setProviders(response.providers);
      })
      .catch(() => {
        if (mounted) setMessage("Could not load provider status.");
      });
    return () => {
      mounted = false;
    };
  }, []);

  function testProvider(providerId: string) {
    setMessage(null);
    startTransition(async () => {
      try {
        const response = await testProviderConnection(providerId);
        setMessage(response.message);
      } catch (error) {
        setMessage(error instanceof Error ? error.message : "Provider test failed.");
      }
    });
  }

  return (
    <section className="container holo-panel pb-8">
      <Card className="glass">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <PlugZap className="h-5 w-5 text-primary" />
                Provider Status
              </CardTitle>
              <CardDescription>Server-side API key checks. Keys are never exposed to the frontend.</CardDescription>
            </div>
            <Badge tone="info">{displayProviders(providers).length} providers</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="text-xs uppercase tracking-[0.16em] text-muted-foreground">
              <tr>
                <th className="py-3 pr-4">Provider</th>
                <th className="py-3 pr-4">Purpose</th>
                <th className="py-3 pr-4">Status</th>
                <th className="py-3 pr-4">Last checked</th>
                <th className="py-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {displayProviders(providers).map((provider) => (
                <tr key={provider.id} className="border-t border-border">
                  <td className="py-3 pr-4 font-medium">{provider.name}</td>
                  <td className="py-3 pr-4 text-muted-foreground">{provider.purpose}</td>
                  <td className="py-3 pr-4">
                    <Badge tone={statusTone(provider.status)}>{provider.status}</Badge>
                  </td>
                  <td className="py-3 pr-4 text-muted-foreground">{provider.lastChecked ? new Date(provider.lastChecked).toLocaleString() : "Demo fallback"}</td>
                  <td className="py-3">
                    <div className="flex flex-wrap gap-2">
                      <Button size="sm" variant="outline" title={provider.envVar ? `Set ${provider.envVar} on the server` : "Internal provider is built in"}>
                        <Settings className="h-4 w-4" />
                        Configure
                      </Button>
                      {provider.envVar ? (
                        <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(provider.envVar ?? "")}>
                          <Copy className="h-4 w-4" />
                          Env
                        </Button>
                      ) : null}
                      <Button size="sm" variant="secondary" onClick={() => testProvider(provider.id)} disabled={isPending}>
                        <TestTube2 className="h-4 w-4" />
                        Test
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {message ? <p className="rounded-md border border-border bg-secondary p-3 text-sm text-muted-foreground">{message}</p> : null}
        </CardContent>
      </Card>
    </section>
  );
}

function statusTone(status: ProviderStatusItem["status"]) {
  if (status === "Connected") return "default";
  if (status === "Demo Mode") return "info";
  if (status === "Missing API Key") return "warning";
  return "danger";
}

function displayProviders(providers: ProviderStatusItem[]): ProviderStatusItem[] {
  if (providers.length) return providers;
  return [
    ["google-safe-browsing", "Google Safe Browsing", "Malware and social-engineering URL reputation", "GOOGLE_SAFE_BROWSING_API_KEY"],
    ["virustotal", "VirusTotal", "URL, domain, IP, and hash reputation", "VIRUSTOTAL_API_KEY"],
    ["urlscan", "urlscan.io", "Passive URL and domain scan intelligence", "URLSCAN_API_KEY"],
    ["ipqualityscore", "IPQualityScore", "URL, phone, fraud, proxy, and abuse risk scoring", "IPQUALITYSCORE_API_KEY"],
    ["hibp", "Have I Been Pwned", "Email breach exposure checks with user consent", "HIBP_API_KEY"],
    ["abuseipdb", "AbuseIPDB", "IP abuse confidence and report history", "ABUSEIPDB_API_KEY"],
    ["internal-scam-database", "Internal Scam Database", "Verified community reports and hashed matching", undefined]
  ].map(([id, name, purpose, envVar]) => ({
    id: id ?? "provider",
    name: name ?? "Provider",
    purpose: purpose ?? "Provider purpose",
    envVar,
    status: "Demo Mode",
    lastChecked: "",
    rateLimitNote: "Demo fallback until server status responds.",
    docsUrl: "Documentation placeholder",
    lastTestResult: "Not tested yet"
  }));
}
