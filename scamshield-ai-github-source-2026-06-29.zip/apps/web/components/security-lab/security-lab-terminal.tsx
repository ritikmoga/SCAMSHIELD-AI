"use client";

import { FormEvent, useEffect, useRef, useState, useTransition } from "react";
import { AlertCircle, Loader2, Send, Terminal } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { runSecurityTerminalCommand, type SecurityTerminalOutput } from "@/lib/api";

type TerminalEntry = {
  id: string;
  command: string;
  output?: SecurityTerminalOutput;
  error?: string;
};

const starters = ["status", "tools", "vt 44d88612fea8a8f36de82e1278abb02f", "zap https://example.com --authorized", "nmap example.com --authorized"];

export function SecurityLabTerminal() {
  const [command, setCommand] = useState("status");
  const [history, setHistory] = useState<TerminalEntry[]>([
    {
      id: "welcome",
      command: "boot",
      output: {
        command: "boot",
        exitCode: 0,
        stdout: ["ScamShield terminal online", "Type help for commands"],
        stderr: []
      }
    }
  ]);
  const [isPending, startTransition] = useTransition();
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [history]);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextCommand = command.trim();
    if (!nextCommand || isPending) return;
    setCommand("");

    startTransition(async () => {
      try {
        const response = await runSecurityTerminalCommand(nextCommand);
        if (response.output.stdout.includes("__SCAMSHIELD_CLEAR__")) {
          setHistory([]);
          return;
        }
        setHistory((items) => [
          ...items,
          {
            id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
            command: nextCommand,
            output: response.output
          }
        ]);
      } catch (error) {
        setHistory((items) => [
          ...items,
          {
            id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
            command: nextCommand,
            error: error instanceof Error ? error.message : "Command failed"
          }
        ]);
      }
    });
  }

  return (
    <section className="container holo-panel pb-14">
      <Card className="glass overflow-hidden">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5 text-primary" />
                Tool Terminal
              </CardTitle>
              <CardDescription>Allowlisted scanner console</CardDescription>
            </div>
            <Badge tone="warning">no shell access</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {starters.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setCommand(item)}
                className="shrink-0 rounded-md border border-border bg-background/70 px-3 py-2 font-mono text-xs text-muted-foreground transition hover:border-primary/50 hover:text-foreground"
              >
                {item}
              </button>
            ))}
          </div>

          <div
            ref={scrollRef}
            className="min-h-[420px] max-h-[520px] overflow-auto rounded-lg border border-primary/20 bg-[#020806]/95 p-4 font-mono text-xs leading-6 shadow-[inset_0_0_40px_rgba(34,197,94,0.08)]"
            aria-live="polite"
          >
            {history.map((entry) => (
              <div key={entry.id} className="mb-5">
                <div className="flex items-center gap-2 text-primary">
                  <span>scamshield@lab</span>
                  <span className="text-muted-foreground">$</span>
                  <span className="break-all text-foreground">{entry.command}</span>
                </div>
                {entry.error ? (
                  <div className="mt-2 flex items-start gap-2 rounded-md border border-red-400/25 bg-red-400/10 p-3 text-red-100">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>{entry.error}</span>
                  </div>
                ) : null}
                {entry.output ? <TerminalOutput output={entry.output} /> : null}
              </div>
            ))}
            {isPending ? (
              <div className="flex items-center gap-2 text-primary">
                <Loader2 className="h-4 w-4 animate-spin" />
                running command
              </div>
            ) : null}
          </div>

          <form onSubmit={submit} className="grid gap-3 md:grid-cols-[minmax(0,1fr)_auto]">
            <Input
              value={command}
              onChange={(event) => setCommand(event.target.value)}
              spellCheck={false}
              className="font-mono"
              placeholder="run <tool> <target> --authorized"
            />
            <Button type="submit" disabled={isPending || !command.trim()}>
              {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Execute
            </Button>
          </form>
        </CardContent>
      </Card>
    </section>
  );
}

function TerminalOutput({ output }: { output: SecurityTerminalOutput }) {
  const ok = output.exitCode === 0;
  return (
    <div className="mt-2 space-y-2">
      <div className={ok ? "text-cyan-100" : "text-yellow-100"}>
        {output.stdout.map((line) => (
          <div key={line} className="break-words">
            {line}
          </div>
        ))}
      </div>
      {output.stderr.length ? (
        <div className="rounded-md border border-yellow-300/25 bg-yellow-300/10 p-3 text-yellow-100">
          {output.stderr.map((line) => (
            <div key={line} className="break-words">
              {line}
            </div>
          ))}
        </div>
      ) : null}
      {output.json ? (
        <details className="rounded-md border border-border bg-background/30 p-3 text-muted-foreground">
          <summary className="cursor-pointer text-foreground">json</summary>
          <pre className="mt-3 max-h-[280px] overflow-auto whitespace-pre-wrap break-words">{JSON.stringify(output.json, null, 2)}</pre>
        </details>
      ) : null}
    </div>
  );
}
