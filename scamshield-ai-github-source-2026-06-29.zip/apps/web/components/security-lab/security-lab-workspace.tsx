"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import {
  Activity,
  AlertCircle,
  Bug,
  CheckCircle2,
  Copy,
  ExternalLink,
  FileScan,
  Globe,
  HardDriveUpload,
  KeyRound,
  Loader2,
  Network,
  Radar,
  ScanSearch,
  ServerCrash,
  ShieldCheck
} from "lucide-react";
import type { SecurityFindingSeverity, SecurityLabResult, SecurityLabScanType } from "@scamshield/shared";
import type {
  SecurityIntegrationId,
  SecurityIntegrationRunResult,
  SecurityIntegrationStatusItem,
  SecurityIntegrationTargetType
} from "@/lib/security-integration-types";
import { securityIntegrationCatalog } from "@/lib/security-integration-types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getSecurityIntegrations, runSecurityFileScan, runSecurityIntegration, runSecurityLabScan } from "@/lib/api";
import { RiskMeter } from "@/components/scanner/risk-meter";
import { SecurityLabTerminal } from "@/components/security-lab/security-lab-terminal";
import { ProviderStatusTable } from "@/components/security-lab/provider-status-table";

const tools: Array<{
  type: SecurityLabScanType;
  label: string;
  description: string;
  placeholder: string;
  icon: typeof ShieldCheck;
  authorizedRequired?: boolean;
  file?: boolean;
}> = [
  {
    type: "link",
    label: "Link Threat",
    description: "URL reputation, redirect, DNS, and header checks.",
    placeholder: "https://example.com/login",
    icon: Globe
  },
  {
    type: "file",
    label: "File Malware",
    description: "Hash, extension, entropy, local signatures, and VirusTotal-ready lookup.",
    placeholder: "",
    icon: FileScan,
    file: true
  },
  {
    type: "dns",
    label: "DNS Lookup",
    description: "A, AAAA, MX, TXT, NS, CAA, SOA, SPF, and DMARC records.",
    placeholder: "example.com",
    icon: Network
  },
  {
    type: "tls",
    label: "TLS Check",
    description: "Certificate trust, issuer, expiry, protocol, and cipher metadata.",
    placeholder: "https://example.com",
    icon: KeyRound
  },
  {
    type: "headers",
    label: "Headers",
    description: "HSTS, CSP, frame, MIME, referrer, and permissions policy checks.",
    placeholder: "https://example.com",
    icon: ShieldCheck
  },
  {
    type: "ports",
    label: "Authorized Ports",
    description: "Small TCP connect check for common public service ports.",
    placeholder: "example.com",
    icon: Activity,
    authorizedRequired: true
  },
  {
    type: "exposure",
    label: "Exposure Paths",
    description: "Limited check for security.txt, robots, sitemap, admin, backup, and git paths.",
    placeholder: "https://example.com",
    icon: ServerCrash,
    authorizedRequired: true
  },
  {
    type: "osint",
    label: "Passive OSINT",
    description: "DNS, mail-auth, nameserver, and RDAP snapshot without email harvesting.",
    placeholder: "example.com",
    icon: ScanSearch
  }
];

const sampleTargets: Record<SecurityLabScanType, string> = {
  link: "https://example.com/login",
  file: "",
  dns: "example.com",
  tls: "https://example.com",
  headers: "https://example.com",
  ports: "example.com",
  exposure: "https://example.com",
  osint: "example.com"
};

export function SecurityLabWorkspace() {
  const [type, setType] = useState<SecurityLabScanType>("link");
  const [target, setTarget] = useState(sampleTargets.link);
  const [ports, setPorts] = useState("21,22,80,443,8080");
  const [authorized, setAuthorized] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<SecurityLabResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const activeTool = useMemo(() => tools.find((item) => item.type === type) ?? tools[0]!, [type]);
  const Icon = activeTool.icon;

  function selectTool(nextType: SecurityLabScanType) {
    setType(nextType);
    setTarget(sampleTargets[nextType]);
    setResult(null);
    setError(null);
    setAuthorized(false);
  }

  function runScan() {
    setError(null);
    startTransition(async () => {
      try {
        if (type === "file") {
          if (!file) throw new Error("Choose a file first");
          const response = await runSecurityFileScan(file, authorized);
          setResult(response.result);
          return;
        }

        const response = await runSecurityLabScan({
          type,
          target,
          authorized,
          ports: type === "ports" ? parsePorts(ports) : undefined
        });
        setResult(response.result);
      } catch (scanError) {
        setError(scanError instanceof Error ? scanError.message : "Security scan failed");
      }
    });
  }

  const canRun = type === "file" ? Boolean(file) : Boolean(target.trim());

  return (
    <>
    <section className="container holo-panel grid gap-6 pb-8 lg:grid-cols-[minmax(0,1fr)_430px]">
      <div className="space-y-6">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {tools.map((item) => {
            const ToolIcon = item.icon;
            const isActive = item.type === type;
            return (
              <button
                key={item.type}
                type="button"
                onClick={() => selectTool(item.type)}
                className={`rounded-lg border p-4 text-left transition ${
                  isActive ? "border-primary/60 bg-primary/10 shadow-glow" : "border-border bg-card hover:border-primary/35 hover:bg-secondary/45"
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <ToolIcon className="h-5 w-5 text-primary" />
                  {item.authorizedRequired ? <Badge tone="warning">auth</Badge> : null}
                </div>
                <h2 className="mt-3 text-sm font-semibold">{item.label}</h2>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">{item.description}</p>
              </button>
            );
          })}
        </div>

        <Card className="glass">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Icon className="h-5 w-5 text-primary" />
                  {activeTool.label}
                </CardTitle>
                <CardDescription>{activeTool.description}</CardDescription>
              </div>
              <Badge tone={activeTool.authorizedRequired ? "warning" : "info"}>
                {activeTool.authorizedRequired ? "authorized only" : "passive"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeTool.file ? (
              <label className="flex min-h-[150px] cursor-pointer flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-primary/40 bg-primary/5 p-6 text-center transition hover:bg-primary/10">
                <HardDriveUpload className="h-8 w-8 text-primary" />
                <span className="text-sm font-semibold">{file ? file.name : "Choose file"}</span>
                <span className="text-xs text-muted-foreground">{file ? `${formatBytes(file.size)} selected` : "Static triage only; files are never executed"}</span>
                <input
                  type="file"
                  className="sr-only"
                  onChange={(event) => {
                    setFile(event.target.files?.[0] ?? null);
                    setResult(null);
                  }}
                />
              </label>
            ) : (
              <Input value={target} onChange={(event) => setTarget(event.target.value)} placeholder={activeTool.placeholder} />
            )}

            {type === "ports" ? (
              <Input value={ports} onChange={(event) => setPorts(event.target.value)} placeholder="21,22,80,443,8080" />
            ) : null}

            {activeTool.authorizedRequired ? (
              <label className="flex items-start gap-3 rounded-md border border-yellow-300/25 bg-yellow-300/10 p-3 text-sm text-yellow-100">
                <input
                  type="checkbox"
                  checked={authorized}
                  onChange={(event) => setAuthorized(event.target.checked)}
                  className="mt-1 h-4 w-4 accent-primary"
                />
                <span>I am authorized to test this target and accept a low-noise defensive scan.</span>
              </label>
            ) : null}

            {error ? (
              <div className="flex items-start gap-2 rounded-md border border-red-400/25 bg-red-400/10 p-3 text-sm text-red-100">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            ) : null}

            <div className="flex flex-wrap gap-3">
              <Button onClick={runScan} disabled={isPending || !canRun || (Boolean(activeTool.authorizedRequired) && !authorized)}>
                {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Radar className="h-4 w-4" />}
                Run Security Scan
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setTarget(sampleTargets[type]);
                  setError(null);
                  setResult(null);
                }}
                disabled={type === "file"}
              >
                Load Sample
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <aside className="space-y-6">
        {result ? (
          <>
            <RiskMeter score={result.riskScore} level={result.riskLevel} confidence={Math.max(65, Math.min(96, 72 + result.findings.length * 4))} />
            <Card className="glass">
              <CardHeader>
                <CardTitle>Security Findings</CardTitle>
                <CardDescription>{result.summary}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {result.findings.length > 0 ? (
                  result.findings.slice(0, 8).map((item) => (
                    <div key={item.id} className="rounded-md border border-border bg-background/60 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-medium">{item.title}</span>
                        <Badge tone={severityTone(item.severity)}>{item.severity}</Badge>
                      </div>
                      {item.evidence ? <p className="mt-1 text-xs text-muted-foreground">Evidence: {item.evidence}</p> : null}
                      <p className="mt-2 text-xs leading-5 text-muted-foreground">{item.recommendation}</p>
                    </div>
                  ))
                ) : (
                  <div className="rounded-md border border-border bg-background/60 p-3 text-sm text-muted-foreground">No major findings.</div>
                )}
              </CardContent>
            </Card>
            <Card className="glass">
              <CardHeader>
                <CardTitle>Scan Evidence</CardTitle>
                <CardDescription>{result.target}</CardDescription>
              </CardHeader>
              <CardContent>
                <pre className="max-h-[340px] overflow-auto rounded-md border border-border bg-background/70 p-3 text-xs leading-5 text-muted-foreground">
                  {JSON.stringify(result.details, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </>
        ) : (
          <Card className="glass scanline">
            <CardHeader>
              <Bug className="h-6 w-6 text-primary" />
              <CardTitle>Security Lab Ready</CardTitle>
              <CardDescription>
                Passive checks run without touching private networks. Active checks stay consent-gated and low-noise.
              </CardDescription>
            </CardHeader>
          </Card>
        )}
      </aside>
    </section>
    <ProviderStatusTable />
    <IntegrationHub />
    <SecurityLabTerminal />
    </>
  );
}

function IntegrationHub() {
  const [items, setItems] = useState<SecurityIntegrationStatusItem[]>([]);
  const [selectedId, setSelectedId] = useState<SecurityIntegrationId>("virustotal");
  const [target, setTarget] = useState("https://example.com/login");
  const [authorized, setAuthorized] = useState(false);
  const [result, setResult] = useState<SecurityIntegrationRunResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    let mounted = true;
    getSecurityIntegrations()
      .then((response) => {
        if (!mounted) return;
        setItems(response.integrations);
      })
      .catch((loadError) => {
        if (!mounted) return;
        setError(loadError instanceof Error ? loadError.message : "Could not load integrations");
      });
    return () => {
      mounted = false;
    };
  }, []);

  const displayItems = useMemo(() => (items.length ? items : fallbackIntegrationItems()), [items]);
  const selected = useMemo(() => displayItems.find((item) => item.id === selectedId) ?? displayItems[0], [displayItems, selectedId]);
  const readyCount = displayItems.filter((item) => item.status === "ready").length;

  function selectIntegration(item: SecurityIntegrationStatusItem) {
    setSelectedId(item.id);
    setTarget(sampleTargetForIntegration(item.targetTypes[0]));
    setAuthorized(false);
    setResult(null);
    setError(null);
  }

  function runProvider() {
    if (!selected) return;
    setError(null);
    startTransition(async () => {
      try {
        const response = await runSecurityIntegration({
          toolId: selected.id,
          target,
          authorized
        });
        setResult(response.result);
      } catch (runError) {
        setError(runError instanceof Error ? runError.message : "Integration run failed");
      }
    });
  }

  return (
    <section className="container holo-panel pb-14">
      <Card className="glass">
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Integration Hub</CardTitle>
              <CardDescription>
                {`${readyCount}/${displayItems.length} providers ready. Add API keys, install CLI tools, or connect services to unlock more providers.`}
              </CardDescription>
            </div>
            <Badge tone={items.length ? "info" : "muted"}>{items.length ? `${items.length}-tool matrix` : "demo fallback matrix"}</Badge>
          </div>
        </CardHeader>
        <CardContent className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_430px]">
          <div className="grid max-h-[620px] gap-3 overflow-auto pr-1 sm:grid-cols-2 lg:grid-cols-3">
            {displayItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => selectIntegration(item)}
                className={`rounded-lg border p-3 text-left transition ${
                  selected?.id === item.id ? "border-primary/60 bg-primary/10" : "border-border bg-background/55 hover:border-primary/35 hover:bg-secondary/45"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <span className="text-sm font-semibold">{item.name}</span>
                  <Badge tone={integrationTone(item.status)}>{item.statusLabel}</Badge>
                </div>
                <p className="mt-2 line-clamp-2 text-xs leading-5 text-muted-foreground">{item.description}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <Badge tone={item.activeScan ? "warning" : "muted"}>{item.mode}</Badge>
                  <Badge tone="muted">{item.category}</Badge>
                  {item.envVars?.[0] ? <Badge tone="info">{item.envVars[0]}</Badge> : null}
                </div>
              </button>
            ))}
          </div>

          <div className="space-y-4">
            <Card className="border-border bg-background/55">
              <CardHeader>
                <CardTitle className="text-base">{selected?.name ?? "Select provider"}</CardTitle>
                <CardDescription>{selected?.setup ?? "Choose an integration to inspect setup status."}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Input value={target} onChange={(event) => setTarget(event.target.value)} placeholder="URL, domain, IP, hash, or email" />
                <div className="grid gap-2">
                  {setupChecklist(selected).map((item) => (
                    <div key={item} className="flex items-start gap-2 rounded-md border border-border bg-background/70 p-3 text-xs text-muted-foreground">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
                {selected?.activeScan ? (
                  <label className="flex items-start gap-3 rounded-md border border-yellow-300/25 bg-yellow-300/10 p-3 text-sm text-yellow-100">
                    <input
                      type="checkbox"
                      checked={authorized}
                      onChange={(event) => setAuthorized(event.target.checked)}
                      className="mt-1 h-4 w-4 accent-primary"
                    />
                    <span>I am authorized to test this target with this provider.</span>
                  </label>
                ) : null}
                <div className="flex flex-wrap gap-2">
                  {selected?.targetTypes.map((item) => (
                    <Badge key={item} tone="muted">
                      {item}
                    </Badge>
                  ))}
                </div>
                {selected?.envVars?.length ? (
                  <div className="space-y-2 rounded-md border border-border bg-background/70 p-3 text-xs text-muted-foreground">
                    <div>API key / service env name(s): {selected.envVars.join(", ")}</div>
                    <div className="flex flex-wrap gap-2">
                      {selected.envVars.map((envName) => (
                        <Button key={envName} size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(envName)}>
                          <Copy className="h-4 w-4" />
                          Copy {envName}
                        </Button>
                      ))}
                    </div>
                  </div>
                ) : null}
                <div className="rounded-md border border-border bg-background/70 p-3 text-xs leading-5 text-muted-foreground">
                  Rate limit notes: cache repeat lookups, debounce user scans, and keep provider requests server-side.
                </div>
                <a
                  href="#"
                  onClick={(event) => event.preventDefault()}
                  className="inline-flex items-center gap-2 text-xs font-semibold text-primary hover:text-foreground"
                >
                  <ExternalLink className="h-4 w-4" />
                  Documentation placeholder
                </a>
                {error ? (
                  <div className="flex items-start gap-2 rounded-md border border-red-400/25 bg-red-400/10 p-3 text-sm text-red-100">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                ) : null}
                <Button
                  onClick={runProvider}
                  disabled={!selected || !target.trim() || isPending || (Boolean(selected.activeScan) && !authorized)}
                >
                  {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Radar className="h-4 w-4" />}
                  Test Provider
                </Button>
                {result ? <p className="text-xs text-muted-foreground">Last test result: {result.status}</p> : null}
              </CardContent>
            </Card>

            {result ? (
              <Card className="border-border bg-background/55">
                <CardHeader>
                  <div className="flex items-center justify-between gap-3">
                    <CardTitle className="text-base">{result.toolName}</CardTitle>
                    <Badge tone={result.status === "ok" ? "default" : result.status === "blocked" ? "danger" : "warning"}>{result.status}</Badge>
                  </div>
                  <CardDescription>{result.summary}</CardDescription>
                </CardHeader>
                <CardContent>
                  <pre className="max-h-[300px] overflow-auto rounded-md border border-border bg-background/80 p-3 text-xs leading-5 text-muted-foreground">
                    {JSON.stringify(result.details, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}

function fallbackIntegrationItems(): SecurityIntegrationStatusItem[] {
  return securityIntegrationCatalog.map((item) => ({
    ...item,
    configured: !item.envVars?.length,
    status: item.envVars?.length ? "needs_key" : "ready",
    statusLabel: item.envVars?.length ? "Needs API key" : "Demo ready"
  }));
}

function setupChecklist(selected: SecurityIntegrationStatusItem | undefined) {
  if (!selected) return ["Select a provider to view setup details."];
  const checklist = [
    selected.envVars?.length ? `Set ${selected.envVars.join(", ")} on the server environment.` : "No API key required for this demo/public connector.",
    selected.activeScan ? "Confirm authorization before running active checks." : "Passive lookup by default.",
    "Do not expose key values in browser code or client logs."
  ];
  return checklist;
}

function parsePorts(value: string) {
  return value
    .split(",")
    .map((item) => Number(item.trim()))
    .filter((item) => Number.isInteger(item) && item > 0 && item <= 65535);
}

function severityTone(severity: SecurityFindingSeverity) {
  if (severity === "critical" || severity === "high") return "danger";
  if (severity === "medium") return "warning";
  if (severity === "low") return "info";
  return "muted";
}

function integrationTone(status: SecurityIntegrationStatusItem["status"]) {
  if (status === "ready") return "default";
  if (status === "disabled" || status === "blocked") return "danger";
  if (status === "needs_key" || status === "needs_service") return "warning";
  return "muted";
}

function sampleTargetForIntegration(type: SecurityIntegrationTargetType | undefined) {
  switch (type) {
    case "ip":
      return "93.184.216.34";
    case "hash":
      return "44d88612fea8a8f36de82e1278abb02f";
    case "email":
      return "security@example.com";
    case "domain":
      return "example.com";
    case "repository":
      return "packages";
    case "apk":
      return "app-release.apk";
    case "file":
      return "package.json";
    case "url":
    default:
      return "https://example.com/login";
  }
}

function formatBytes(value: number) {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}
