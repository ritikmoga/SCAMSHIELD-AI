import { Fingerprint, LockKeyhole, ShieldCheck, Server, TerminalSquare, WifiOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const postureItems = [
  {
    label: "Consent gate",
    detail: "Active probes require explicit authorization.",
    icon: ShieldCheck,
    tone: "default" as const
  },
  {
    label: "Target guard",
    detail: "Private and loopback targets stay blocked.",
    icon: LockKeyhole,
    tone: "info" as const
  },
  {
    label: "API throttle",
    detail: "Security Lab routes include request limits.",
    icon: Fingerprint,
    tone: "warning" as const
  },
  {
    label: "HTTPS edge",
    detail: "Production exposes public HTTPS only; DB and worker ports stay private.",
    icon: Server,
    tone: "default" as const
  },
  {
    label: "Closed ports",
    detail: "No SSH, MongoDB, ZAP, MobSF, or scanner daemon port is exposed by the web app.",
    icon: WifiOff,
    tone: "info" as const
  },
  {
    label: "Safe terminal",
    detail: "Commands route through allowlisted tools only.",
    icon: TerminalSquare,
    tone: "muted" as const
  }
];

export function SecurityPostureStrip() {
  return (
    <section className="container holo-panel pb-8">
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {postureItems.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="card-3d rounded-lg border border-border/70 bg-background/62 p-4 backdrop-blur-xl">
              <div className="flex items-center justify-between gap-3">
                <Icon className="h-5 w-5 text-primary" />
                <Badge tone={item.tone}>{item.label}</Badge>
              </div>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">{item.detail}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
