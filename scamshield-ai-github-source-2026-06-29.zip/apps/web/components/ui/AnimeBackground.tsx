const particles = Array.from({ length: 26 }, (_, i) => ({
  id: i,
  left: `${(i * 37) % 100}%`,
  top: `${(i * 19) % 100}%`,
  animationDelay: `${(i % 8) * 0.35}s`,
  opacity: 0.25 + (i % 5) * 0.11
}));

export function AnimeBackground() {
  return (
    <div aria-hidden="true" className="fixed inset-0 z-0 overflow-hidden bg-void">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_15%,rgba(139,92,246,0.28),transparent_32%),radial-gradient(circle_at_80%_20%,rgba(56,189,248,0.18),transparent_30%),radial-gradient(circle_at_50%_95%,rgba(244,63,94,0.12),transparent_34%)]" />
      <div className="absolute -top-40 left-1/2 h-[540px] w-[540px] -translate-x-1/2 rounded-full bg-cursed/20 blur-3xl animate-aura motion-reduce:animate-none" />
      <div className="absolute bottom-[-22rem] left-1/2 h-[40rem] w-[82rem] -translate-x-1/2 cyber-grid opacity-35" />
      <div className="absolute inset-0 opacity-[0.13]" style={{ backgroundImage: "url('data:image/svg+xml,%3Csvg viewBox=%220 0 256 256%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22n%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.9%22 numOctaves=%224%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23n)%22 opacity=%220.35%22/%3E%3C/svg%3E')" }} />
      {particles.map((particle) => (
        <span
          key={particle.id}
          className="absolute h-1 w-1 rounded-full bg-energy/70 shadow-energy animate-float motion-reduce:hidden"
          style={{
            left: particle.left,
            top: particle.top,
            animationDelay: particle.animationDelay,
            opacity: particle.opacity,
          }}
        />
      ))}
    </div>
  );
}
