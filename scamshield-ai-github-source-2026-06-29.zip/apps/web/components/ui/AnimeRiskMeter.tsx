type Props = { score: number };
export function RiskMeter({ score }: Props) {
  const safeScore = Math.max(0, Math.min(100, score));
  const color = safeScore > 75 ? "text-danger" : safeScore > 45 ? "text-warning" : "text-safe";
  return (
    <div className="relative mx-auto grid h-56 w-56 place-items-center rounded-full energy-border">
      <div className="absolute inset-5 rounded-full border border-white/10 bg-white/5" />
      <div className="relative text-center">
        <p className={`text-6xl font-black ${color}`}>{safeScore}</p>
        <p className="mt-1 text-sm uppercase tracking-[0.35em] text-slate-300">Risk Score</p>
      </div>
    </div>
  );
}
