import { ReactNode } from "react";

export function Section({ eyebrow, title, children }: { eyebrow?: string; title: string; children: ReactNode }) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16">
      <div className="mb-8 max-w-3xl">
        {eyebrow && <p className="mb-3 text-sm font-bold uppercase tracking-[0.35em] text-energy">{eyebrow}</p>}
        <h2 className="text-3xl font-black tracking-tight text-white md:text-5xl">{title}</h2>
      </div>
      {children}
    </section>
  );
}
