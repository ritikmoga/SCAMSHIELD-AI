import Link from "next/link";
import type { MouseEventHandler, ReactNode } from "react";

type Props = {
  children: ReactNode;
  href?: string;
  variant?: "primary" | "danger" | "safe" | "ghost";
  type?: "button" | "submit";
  onClick?: MouseEventHandler<HTMLButtonElement>;
  ariaLabel?: string;
  disabled?: boolean;
};

const variants = {
  primary: "from-cursed to-energy shadow-cursed",
  danger: "from-danger to-cursed shadow-danger",
  safe: "from-safe to-energy shadow-energy",
  ghost: "from-white/10 to-white/5 shadow-none border border-white/15",
};

export function EnergyButton({ children, href, variant = "primary", type = "button", onClick, ariaLabel, disabled }: Props) {
  const className = `group relative inline-flex items-center justify-center overflow-hidden rounded-2xl px-5 py-3 font-semibold text-white transition hover:scale-[1.03] focus:outline-none focus:ring-2 focus:ring-energy/70 bg-gradient-to-r ${variants[variant]}`;
  const inner = (
    <>
      <span className="absolute inset-0 translate-x-[-120%] bg-gradient-to-r from-transparent via-white/30 to-transparent transition duration-700 group-hover:translate-x-[120%]" />
      <span className="relative z-10">{children}</span>
    </>
  );
  if (href) return <Link href={href} aria-label={ariaLabel} className={className}>{inner}</Link>;
  return <button type={type} onClick={onClick} aria-label={ariaLabel} disabled={disabled} className={className}>{inner}</button>;
}
