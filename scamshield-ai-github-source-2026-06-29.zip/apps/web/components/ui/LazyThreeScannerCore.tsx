"use client";

import dynamic from "next/dynamic";

export const LazyThreeScannerCore = dynamic(() => import("@/components/ui/ThreeScannerCore").then((module) => module.ThreeScannerCore), {
  ssr: false,
  loading: () => <div className="relative h-[360px] w-full overflow-hidden rounded-[2rem] glass-panel" aria-hidden="true" />
});
