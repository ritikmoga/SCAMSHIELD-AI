import { ReactNode } from "react";

type Props = {
  title: string;
  description?: string;
  icon?: ReactNode;
  children?: ReactNode;
  severity?: "low" | "medium" | "high" | "critical";
};

const glow = {
  low: "hover:shadow-energy border-energy/20",
  medium: "hover:shadow-[0_0_35px_rgba(245,158,11,0.28)] border-warning/25",
  high: "hover:shadow-danger border-danger/25",
  critical: "hover:shadow-[0_0_45px_rgba(244,63,94,0.5)] border-danger/40",
};

export function PowerCard({ title, description, icon, children, severity = "low" }: Props) {
  return (
    <article className={`glass-panel scan-line perspective-card relative overflow-hidden rounded-3xl border p-5 ${glow[severity]}`}>
      <div className="absolute -right-14 -top-14 h-32 w-32 rounded-full bg-cursed/20 blur-2xl" aria-hidden="true" />
      <div className="relative z-10 flex items-start gap-4">
        {icon && <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/10 text-energy shadow-energy">{icon}</div>}
        <div>
          <h3 className="text-lg font-bold text-white">{title}</h3>
          {description && <p className="mt-2 text-sm leading-6 text-slate-300">{description}</p>}
        </div>
      </div>
      {children && <div className="relative z-10 mt-5">{children}</div>}
    </article>
  );
}
