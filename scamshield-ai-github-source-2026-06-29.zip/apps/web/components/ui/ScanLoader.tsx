const steps = ["Analyzing reputation", "Checking scam patterns", "Reviewing social engineering signals", "Preparing safety explanation"];
export function ScanLoader() {
  return (
    <div className="glass-panel rounded-3xl p-8 text-center" role="status" aria-live="polite" aria-label="Scanning risk signals">
      <div className="mx-auto mb-6 h-24 w-24 rounded-full energy-border animate-spinSlow motion-reduce:animate-none" aria-hidden="true" />
      <div className="space-y-2 text-sm text-slate-300">
        {steps.map((s) => <p key={s}>▸ {s}...</p>)}
      </div>
    </div>
  );
}
