type Props = { level: "Low" | "Medium" | "High" | "Critical" };
const styles = {
  Low: "bg-safe/15 text-safe border-safe/30",
  Medium: "bg-warning/15 text-warning border-warning/30",
  High: "bg-danger/15 text-rose-300 border-danger/30",
  Critical: "bg-danger/25 text-rose-100 border-danger/50 shadow-danger",
};
export function SeverityBadge({ level }: Props) {
  return <span className={`rounded-full border px-3 py-1 text-xs font-bold ${styles[level]}`}>{level}</span>;
}
