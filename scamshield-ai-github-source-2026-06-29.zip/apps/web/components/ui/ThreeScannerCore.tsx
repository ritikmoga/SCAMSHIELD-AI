"use client";

const signalLabels = [
  { label: "URL Risk", className: "anime-shield-chip-left" },
  { label: "UPI Risk", className: "anime-shield-chip-top" },
  { label: "QR Payload", className: "anime-shield-chip-right" },
  { label: "Threat Intel", className: "anime-shield-chip-bottom" }
];

export function ThreeScannerCore() {
  return (
    <div
      className="anime-shield-stage relative h-[360px] w-full overflow-hidden rounded-[2rem] glass-panel scan-line"
      role="img"
      aria-label="Anime-style ScamShield cyber shield protecting scam risk signals"
    >
      <div className="anime-shield-grid" aria-hidden="true" />
      <div className="anime-shield-field" aria-hidden="true" />
      <div className="anime-shield-wing anime-shield-wing-left" aria-hidden="true" />
      <div className="anime-shield-wing anime-shield-wing-right" aria-hidden="true" />
      <div className="anime-shield-blade anime-shield-blade-one" aria-hidden="true" />
      <div className="anime-shield-blade anime-shield-blade-two" aria-hidden="true" />
      <div className="anime-shield-blade anime-shield-blade-three" aria-hidden="true" />

      <div className="anime-shield-lockup" aria-hidden="true">
        <div className="anime-shield-shadow" />
        <svg className="anime-shield-svg" viewBox="0 0 360 420" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="scamshieldOuter" x1="61" x2="296" y1="30" y2="374" gradientUnits="userSpaceOnUse">
              <stop stopColor="#67e8f9" />
              <stop offset="0.35" stopColor="#8b5cf6" />
              <stop offset="0.72" stopColor="#312e81" />
              <stop offset="1" stopColor="#fb7185" />
            </linearGradient>
            <linearGradient id="scamshieldCore" x1="88" x2="271" y1="64" y2="330" gradientUnits="userSpaceOnUse">
              <stop stopColor="#13233f" />
              <stop offset="0.45" stopColor="#070712" />
              <stop offset="1" stopColor="#250948" />
            </linearGradient>
            <linearGradient id="scamshieldEdge" x1="90" x2="252" y1="86" y2="295" gradientUnits="userSpaceOnUse">
              <stop stopColor="#ecfeff" />
              <stop offset="0.48" stopColor="#22d3ee" />
              <stop offset="1" stopColor="#a78bfa" />
            </linearGradient>
            <filter id="scamshieldGlow" x="-35%" y="-35%" width="170%" height="170%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feColorMatrix
                in="blur"
                type="matrix"
                values="0 0 0 0 0.20 0 0 0 0 0.88 0 0 0 0 1 0 0 0 0.76 0"
              />
              <feBlend in="SourceGraphic" mode="screen" />
            </filter>
          </defs>

          <path
            d="M180 17L312 70L296 219C286 297 241 355 180 394C119 355 74 297 64 219L48 70L180 17Z"
            fill="rgba(5, 3, 10, 0.78)"
            stroke="url(#scamshieldOuter)"
            strokeWidth="12"
            strokeLinejoin="round"
            filter="url(#scamshieldGlow)"
          />
          <path
            d="M180 51L277 91L265 210C257 271 225 318 180 349C135 318 103 271 95 210L83 91L180 51Z"
            fill="url(#scamshieldCore)"
            stroke="rgba(255,255,255,0.16)"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path
            d="M180 69L252 100L244 198C237 248 214 288 180 315V69Z"
            fill="rgba(255,255,255,0.08)"
          />
          <path
            d="M92 104L180 68L268 104"
            stroke="url(#scamshieldEdge)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M107 212C116 266 143 306 180 333C217 306 244 266 253 212"
            stroke="#67e8f9"
            strokeOpacity="0.58"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M127 141L180 111L164 176H238L139 299L164 208H108L127 141Z"
            fill="#67e8f9"
            fillOpacity="0.95"
          />
          <path
            d="M139 151L171 134L156 188H211L153 259L170 196H125L139 151Z"
            fill="#05030A"
            fillOpacity="0.86"
          />
          <path
            d="M73 248L139 259L119 287L68 278L73 248Z"
            fill="#fb7185"
            fillOpacity="0.84"
          />
          <path
            d="M287 132L221 121L241 93L293 101L287 132Z"
            fill="#a78bfa"
            fillOpacity="0.9"
          />
          <path
            d="M110 115L148 99M250 158L219 146M112 230L151 239M238 253L210 273"
            stroke="white"
            strokeOpacity="0.24"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M122 96L180 74L238 96M104 123L180 92L256 123"
            stroke="#67e8f9"
            strokeOpacity="0.18"
            strokeWidth="2"
          />
        </svg>
        <div className="anime-shield-title">SCAMSHIELD CORE</div>
      </div>

      {signalLabels.map((signal) => (
        <span key={signal.label} className={`anime-shield-chip ${signal.className}`}>
          {signal.label}
        </span>
      ))}
    </div>
  );
}
