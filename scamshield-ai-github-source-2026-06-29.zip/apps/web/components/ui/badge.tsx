import * as React from "react";
import { cn } from "@/lib/utils";

const toneClasses = {
  default: "border-primary/30 bg-primary/10 text-primary",
  warning: "border-yellow-300/30 bg-yellow-300/10 text-yellow-200",
  danger: "border-red-400/30 bg-red-400/10 text-red-200",
  info: "border-cyan-300/30 bg-cyan-300/10 text-cyan-200",
  muted: "border-border bg-secondary text-muted-foreground"
};

export function Badge({
  className,
  tone = "default",
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { tone?: keyof typeof toneClasses }) {
  return (
    <span
      className={cn("inline-flex items-center rounded-md border px-2.5 py-1 text-xs font-semibold", toneClasses[tone], className)}
      {...props}
    />
  );
}
