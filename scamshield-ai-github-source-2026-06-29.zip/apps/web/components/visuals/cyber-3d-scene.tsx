"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

type ScenePoint = {
  mesh: THREE.Mesh;
  base: THREE.Vector3;
  speed: number;
  radius: number;
};

export function Cyber3DScene() {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const canvasHost = mount;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2("#010405", 0.043);

    const camera = new THREE.PerspectiveCamera(46, window.innerWidth / window.innerHeight, 0.1, 120);
    camera.position.set(0, 2.2, 12.5);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: "high-performance", preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, window.innerWidth < 768 ? 1.15 : 1.65));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.domElement.setAttribute("aria-hidden", "true");
    renderer.domElement.className = "h-full w-full";
    canvasHost.appendChild(renderer.domElement);

    const root = new THREE.Group();
    scene.add(root);

    const green = new THREE.Color("#67e8f9");
    const cyan = new THREE.Color("#22d3ee");
    const yellow = new THREE.Color("#fbbf24");
    const red = new THREE.Color("#ff315a");
    const violet = new THREE.Color("#94a3b8");

    scene.add(new THREE.AmbientLight("#67e8f9", 0.24));

    const beacon = new THREE.PointLight("#22d3ee", 12, 22);
    beacon.position.set(0, 1.2, 1);
    root.add(beacon);

    const cursorLight = new THREE.PointLight("#38bdf8", 16, 14);
    cursorLight.position.set(0, 0, 2.5);
    root.add(cursorLight);

    const floorGrid = new THREE.GridHelper(72, 72, green, cyan);
    const gridMaterial = floorGrid.material as THREE.Material | THREE.Material[];
    const setGridOpacity = (material: THREE.Material) => {
      material.transparent = true;
      material.opacity = 0.07;
      material.depthWrite = false;
    };
    if (Array.isArray(gridMaterial)) gridMaterial.forEach(setGridOpacity);
    else setGridOpacity(gridMaterial);
    floorGrid.position.set(0, -5.4, -8);
    floorGrid.rotation.x = Math.PI * 0.015;
    root.add(floorGrid);

    const horizonGrid = new THREE.GridHelper(64, 40, cyan, green);
    const horizonMaterial = horizonGrid.material as THREE.Material | THREE.Material[];
    if (Array.isArray(horizonMaterial)) horizonMaterial.forEach(setGridOpacity);
    else setGridOpacity(horizonMaterial);
    horizonGrid.position.set(0, 1.6, -19);
    horizonGrid.rotation.x = Math.PI / 2;
    root.add(horizonGrid);

    const coreMaterial = new THREE.MeshBasicMaterial({ color: green, wireframe: true, transparent: true, opacity: 0.2 });
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.8, 2), coreMaterial);
    core.position.set(3.5, -0.15, -4.2);
    root.add(core);

    const ringMaterial = new THREE.MeshBasicMaterial({ color: cyan, wireframe: true, transparent: true, opacity: 0.13 });
    const rings = [
      new THREE.Mesh(new THREE.TorusGeometry(2.75, 0.012, 10, 128), ringMaterial),
      new THREE.Mesh(new THREE.TorusGeometry(2.05, 0.011, 10, 128), ringMaterial.clone()),
      new THREE.Mesh(new THREE.TorusGeometry(1.35, 0.01, 10, 128), ringMaterial.clone())
    ];
    rings[0]?.rotation.set(Math.PI / 2.4, 0, 0.15);
    rings[1]?.rotation.set(0.25, Math.PI / 2.2, 0);
    rings[2]?.rotation.set(Math.PI / 2.05, Math.PI / 3, 0.25);
    rings.forEach((ring) => {
      ring.position.copy(core.position);
      root.add(ring);
    });

    const cursorGroup = new THREE.Group();
    scene.add(cursorGroup);

    const cursorHaloMaterial = new THREE.MeshBasicMaterial({
      color: cyan,
      transparent: true,
      opacity: 0.18,
      wireframe: true,
      depthWrite: false
    });
    const cursorHalo = new THREE.Mesh(new THREE.TorusGeometry(0.52, 0.012, 8, 80), cursorHaloMaterial);
    const cursorPulse = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.18, 1),
      new THREE.MeshBasicMaterial({ color: green, transparent: true, opacity: 0.3, wireframe: true, depthWrite: false })
    );
    cursorGroup.add(cursorHalo, cursorPulse);

    const particleCount = window.innerWidth < 768 ? 210 : 420;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const basePositions = new Float32Array(particleCount * 3);
    for (let index = 0; index < particleCount; index += 1) {
      const i = index * 3;
      const zBand = Math.random() < 0.62 ? -10 - Math.random() * 18 : -1 - Math.random() * 9;
      positions[i] = (Math.random() - 0.5) * 28;
      positions[i + 1] = (Math.random() - 0.5) * 13;
      positions[i + 2] = zBand;
      basePositions[i] = positions[i] ?? 0;
      basePositions[i + 1] = positions[i + 1] ?? 0;
      basePositions[i + 2] = positions[i + 2] ?? 0;
      const color = index % 29 === 0 ? red : index % 17 === 0 ? yellow : index % 11 === 0 ? violet : index % 2 === 0 ? cyan : green;
      colors[i] = color.r;
      colors[i + 1] = color.g;
      colors[i + 2] = color.b;
    }

    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    const particleMaterial = new THREE.PointsMaterial({
      size: window.innerWidth < 768 ? 0.045 : 0.035,
      vertexColors: true,
      transparent: true,
      opacity: 0.5,
      depthWrite: false
    });
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    root.add(particles);

    const nodeGeometry = new THREE.OctahedronGeometry(0.12, 0);
    const nodeMaterials = [
      new THREE.MeshBasicMaterial({ color: green, wireframe: true, transparent: true, opacity: 0.4 }),
      new THREE.MeshBasicMaterial({ color: cyan, wireframe: true, transparent: true, opacity: 0.34 }),
      new THREE.MeshBasicMaterial({ color: red, wireframe: true, transparent: true, opacity: 0.36 }),
      new THREE.MeshBasicMaterial({ color: yellow, wireframe: true, transparent: true, opacity: 0.28 })
    ];
    const nodeCount = window.innerWidth < 768 ? 12 : 22;
    const nodes: ScenePoint[] = [];
    for (let index = 0; index < nodeCount; index += 1) {
      const material = nodeMaterials[index % nodeMaterials.length]!;
      const mesh = new THREE.Mesh(nodeGeometry, material);
      const base = new THREE.Vector3((Math.random() - 0.5) * 18, (Math.random() - 0.5) * 7, -3 - Math.random() * 14);
      mesh.position.copy(base);
      mesh.scale.setScalar(index % 5 === 0 ? 1.9 : 1);
      root.add(mesh);
      nodes.push({ mesh, base, speed: 0.5 + Math.random() * 0.8, radius: 0.15 + Math.random() * 0.28 });
    }

    const linePositions = new Float32Array(Math.max(0, nodes.length - 1) * 6);
    const lineGeometry = new THREE.BufferGeometry();
    lineGeometry.setAttribute("position", new THREE.BufferAttribute(linePositions, 3));
    const lineMaterial = new THREE.LineBasicMaterial({ color: "#22d3ee", transparent: true, opacity: 0.08, depthWrite: false });
    const nodeLines = new THREE.LineSegments(lineGeometry, lineMaterial);
    root.add(nodeLines);

    const scanLines: THREE.Mesh[] = [];
    const scanMaterial = new THREE.MeshBasicMaterial({ color: green, transparent: true, opacity: 0.12, wireframe: true, depthWrite: false });
    for (let index = 0; index < 4; index += 1) {
      const line = new THREE.Mesh(new THREE.TorusGeometry(1.2 + index * 0.55, 0.008, 8, 96), scanMaterial.clone());
      line.rotation.x = Math.PI / 2;
      line.position.set(-4.2 + index * 1.8, -1.2 + index * 0.42, -5 - index * 2.1);
      scanLines.push(line);
      root.add(line);
    }

    const pointer = new THREE.Vector2(0, 0);
    const pointerTarget = new THREE.Vector2(0, 0);
    const worldPointer = new THREE.Vector3(0, 0, 2);
    const targetWorldPointer = new THREE.Vector3(0, 0, 2);
    let lastPointerAt = performance.now();
    let frame = 0;
    let animationFrame = 0;

    function updatePointer(clientX: number, clientY: number) {
      pointerTarget.x = (clientX / window.innerWidth) * 2 - 1;
      pointerTarget.y = -(clientY / window.innerHeight) * 2 + 1;
      targetWorldPointer.set(pointerTarget.x * 8.6, pointerTarget.y * 4.9, 1.2);
      canvasHost.style.setProperty("--cursor-x", `${clientX}px`);
      canvasHost.style.setProperty("--cursor-y", `${clientY}px`);
      lastPointerAt = performance.now();
    }

    function onPointerMove(event: PointerEvent) {
      updatePointer(event.clientX, event.clientY);
    }

    function onResize() {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, window.innerWidth < 768 ? 1.15 : 1.65));
      renderer.setSize(window.innerWidth, window.innerHeight);
    }

    updatePointer(window.innerWidth * 0.58, window.innerHeight * 0.42);

    function animate() {
      frame += reducedMotion ? 0.003 : 0.009;
      pointer.lerp(pointerTarget, 0.075);
      worldPointer.lerp(targetWorldPointer, 0.08);
      const pointerEnergy = Math.max(0, 1 - (performance.now() - lastPointerAt) / 1100);

      root.rotation.x += (pointer.y * 0.08 - root.rotation.x) * 0.035;
      root.rotation.y += (pointer.x * 0.12 - root.rotation.y) * 0.035;

      core.rotation.x += reducedMotion ? 0 : 0.004;
      core.rotation.y += reducedMotion ? 0 : 0.0065;
      core.scale.setScalar(1 + Math.sin(frame * 2.4) * 0.035 + pointerEnergy * 0.045);
      beacon.intensity = 9 + pointerEnergy * 10 + Math.sin(frame * 3) * 1.4;

      rings.forEach((ring, index) => {
        ring.rotation.z += reducedMotion ? 0 : 0.0025 + index * 0.0012;
        ring.scale.setScalar(1 + Math.sin(frame * 2 + index) * 0.025);
      });

      cursorGroup.position.copy(worldPointer);
      cursorGroup.lookAt(camera.position);
      cursorGroup.scale.setScalar(1 + pointerEnergy * 1.25);
      cursorHalo.rotation.z -= reducedMotion ? 0 : 0.02;
      cursorPulse.rotation.x += reducedMotion ? 0 : 0.025;
      cursorPulse.rotation.y += reducedMotion ? 0 : 0.018;
      cursorLight.position.copy(worldPointer);
      cursorLight.intensity = 6 + pointerEnergy * 24;
      cursorHaloMaterial.opacity = 0.1 + pointerEnergy * 0.3;

      const particleAttribute = particleGeometry.getAttribute("position") as THREE.BufferAttribute;
      for (let index = 0; index < particleCount; index += 1) {
        const i = index * 3;
        const baseX = basePositions[i] ?? 0;
        const baseY = basePositions[i + 1] ?? 0;
        const baseZ = basePositions[i + 2] ?? 0;
        const dx = baseX - worldPointer.x;
        const dy = baseY - worldPointer.y;
        const distance = Math.max(0.001, Math.sqrt(dx * dx + dy * dy));
        const influence = Math.max(0, 1 - distance / 4.2) * (0.25 + pointerEnergy * 0.75);
        positions[i] = baseX + (dx / distance) * influence * 0.42 + Math.sin(frame * 1.7 + index) * 0.025;
        positions[i + 1] = baseY + (dy / distance) * influence * 0.42 + Math.cos(frame * 1.45 + index) * 0.025;
        positions[i + 2] = baseZ + Math.sin(frame + index * 0.17) * 0.05;
      }
      particleAttribute.needsUpdate = true;
      particles.rotation.y = frame * 0.045;

      nodes.forEach((node, index) => {
        node.mesh.position.set(
          node.base.x + Math.sin(frame * node.speed + index) * node.radius,
          node.base.y + Math.cos(frame * node.speed * 1.35 + index) * node.radius,
          node.base.z + Math.sin(frame * 0.8 + index * 0.5) * node.radius
        );
        node.mesh.rotation.x += reducedMotion ? 0 : 0.006 + index * 0.0002;
        node.mesh.rotation.y -= reducedMotion ? 0 : 0.004;
        const distance = node.mesh.position.distanceTo(worldPointer);
        node.mesh.scale.setScalar((index % 5 === 0 ? 1.55 : 1) + Math.max(0, 1.6 - distance) * 0.28);
      });

      const lineAttribute = lineGeometry.getAttribute("position") as THREE.BufferAttribute;
      for (let index = 0; index < nodes.length - 1; index += 1) {
        const start = nodes[index]!.mesh.position;
        const end = nodes[(index + 3) % nodes.length]!.mesh.position;
        const i = index * 6;
        linePositions[i] = start.x;
        linePositions[i + 1] = start.y;
        linePositions[i + 2] = start.z;
        linePositions[i + 3] = end.x;
        linePositions[i + 4] = end.y;
        linePositions[i + 5] = end.z;
      }
      lineAttribute.needsUpdate = true;
      lineMaterial.opacity = 0.07 + pointerEnergy * 0.12;

      scanLines.forEach((line, index) => {
        const pulse = (Math.sin(frame * 2.2 + index * 1.4) + 1) / 2;
        line.scale.setScalar(0.85 + pulse * 0.55);
        line.position.x += Math.sin(frame * 0.5 + index) * 0.002;
        (line.material as THREE.MeshBasicMaterial).opacity = 0.08 + pulse * 0.16;
      });

      renderer.render(scene, camera);
      animationFrame = window.requestAnimationFrame(animate);
    }

    window.addEventListener("resize", onResize);
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    animate();

    return () => {
      window.cancelAnimationFrame(animationFrame);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onPointerMove);
      canvasHost.removeChild(renderer.domElement);
      floorGrid.geometry.dispose();
      horizonGrid.geometry.dispose();
      particleGeometry.dispose();
      particleMaterial.dispose();
      nodeGeometry.dispose();
      nodeMaterials.forEach((material) => material.dispose());
      lineGeometry.dispose();
      lineMaterial.dispose();
      core.geometry.dispose();
      coreMaterial.dispose();
      rings.forEach((ring) => {
        ring.geometry.dispose();
        (ring.material as THREE.Material).dispose();
      });
      cursorHalo.geometry.dispose();
      cursorHaloMaterial.dispose();
      cursorPulse.geometry.dispose();
      (cursorPulse.material as THREE.Material).dispose();
      scanLines.forEach((line) => {
        line.geometry.dispose();
        (line.material as THREE.Material).dispose();
      });
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={mountRef} className="cyber-3d-canvas" aria-hidden="true">
      <div className="cursor-energy" />
    </div>
  );
}
