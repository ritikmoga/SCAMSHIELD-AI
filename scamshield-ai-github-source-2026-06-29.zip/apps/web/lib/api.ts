import type { ScanResult, ScanType, SecurityLabResult, SecurityLabScanType } from "@scamshield/shared";
import type { ProviderStatusItem } from "@/lib/integrations/status";
import type { UnifiedScanResult } from "@/lib/risk-engine";
import type {
  SecurityIntegrationId,
  SecurityIntegrationRunResult,
  SecurityIntegrationStatusItem
} from "@/lib/security-integration-types";
import type { DeepScanResult, DeepScanType } from "@/lib/multiscan/types";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL?.trim() || "/api";
const SAME_ORIGIN_API_BASE_URL = "/api";
let csrfToken: string | null = null;

export async function getCsrfToken() {
  if (csrfToken) return csrfToken;
  const response = await fetch(`${API_BASE_URL}/security/csrf-token`, {
    credentials: "include"
  });
  if (!response.ok) throw new Error("Unable to load CSRF token");
  const body = (await response.json()) as { csrfToken: string };
  csrfToken = body.csrfToken;
  return csrfToken;
}

export async function scanWithApi(type: ScanType, input: string, locale: "en" | "hi" = "en") {
  const token = await getCsrfToken();
  const response = await fetch(`${API_BASE_URL}/scan/${type}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify({ input, locale })
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Scan failed");
  }

  return (await response.json()) as { result: ScanResult };
}

export async function scanScreenshotWithApi(file: File, locale: "en" | "hi" = "en") {
  const token = await getCsrfToken();
  const formData = new FormData();
  formData.append("screenshot", file);
  formData.append("locale", locale);

  const response = await fetch(`${API_BASE_URL}/scan/screenshot/image`, {
    method: "POST",
    headers: {
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: formData
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Screenshot scan failed");
  }

  return (await response.json()) as { result: ScanResult };
}

export async function submitReport(payload: {
  type: ScanType;
  value: string;
  description: string;
  sourcePlatform?: string;
  userContact?: string;
  consent?: boolean;
  evidenceUrls?: string[];
  screenshot?: File;
}) {
  const token = await getCsrfToken();
  const body = payload.screenshot ? new FormData() : JSON.stringify(payload);
  if (payload.screenshot && body instanceof FormData) {
    body.append("type", payload.type);
    body.append("value", payload.value);
    body.append("description", payload.description);
    body.append("sourcePlatform", payload.sourcePlatform ?? "Unknown");
    body.append("userContact", payload.userContact ?? "");
    body.append("consent", String(payload.consent === true));
    body.append("screenshot", payload.screenshot);
  }
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/report`, {
    method: "POST",
    headers: payload.screenshot
      ? {
          "X-CSRF-Token": token
        }
      : {
          "Content-Type": "application/json",
          "X-CSRF-Token": token
        },
    credentials: "include",
    body
  });

  if (!response.ok) throw new Error("Could not submit report");
  return response.json();
}

export async function runUnifiedScan(payload: { type: ScanType; input: string; locale?: "en" | "hi" }) {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/scan`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Scan failed");
  }

  return (await response.json()) as { result: UnifiedScanResult };
}

export async function runUnifiedImageScan(payload: { type: ScanType; file: File; input?: string; locale?: "en" | "hi" }) {
  const token = await getCsrfToken();
  const formData = new FormData();
  formData.append("type", payload.type);
  formData.append("locale", payload.locale ?? "en");
  formData.append("input", payload.input ?? "");
  formData.append("image", payload.file);

  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/scan`, {
    method: "POST",
    headers: {
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: formData
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Image scan failed");
  }

  return (await response.json()) as { result: UnifiedScanResult };
}

export async function runDeepScanWithApi(payload: { scanType?: DeepScanType; input?: string; text?: string; url?: string; file?: File }) {
  const token = await getCsrfToken();
  const hasFile = Boolean(payload.file);
  const body = hasFile ? new FormData() : JSON.stringify(payload);
  if (hasFile && body instanceof FormData) {
    body.append("scanType", payload.scanType ?? "file");
    if (payload.input) body.append("input", payload.input);
    if (payload.text) body.append("text", payload.text);
    if (payload.url) body.append("url", payload.url);
    if (payload.file) body.append("file", payload.file);
  }

  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/deep-scan`, {
    method: "POST",
    headers: hasFile
      ? {
          "X-CSRF-Token": token
        }
      : {
          "Content-Type": "application/json",
          "X-CSRF-Token": token
        },
    credentials: "include",
    body
  });

  if (!response.ok) {
    const errorBody = await response.json().catch(() => null);
    throw new Error(errorBody?.error?.message ?? "Deep scan failed");
  }

  return (await response.json()) as {
    result: DeepScanResult;
    displayResult: UnifiedScanResult;
    storage: { saved: boolean; mode?: "mongodb" | "memory"; rawInputStored: false };
    privacy: { rawInputStored: false; note: string };
  };
}

export async function clearScanHistory() {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/scan/history`, {
    method: "DELETE",
    headers: {
      "X-CSRF-Token": token
    },
    credentials: "include"
  });
  if (!response.ok) throw new Error("Could not clear scan history");
  return response.json();
}

export async function getScanHistory() {
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/scan/history`, {
    credentials: "include"
  });
  if (!response.ok) throw new Error("Could not load scan history");
  return response.json() as Promise<{
    demo: boolean;
    storageMode?: "mongodb" | "memory";
    scans: Array<{ id: string; type: string; preview: string; riskScore: number; verdict: string; createdAt: string }>;
    privacy: string;
  }>;
}

export async function getSystemHealth() {
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/health`, {
    credentials: "include",
    cache: "no-store"
  });
  if (!response.ok) throw new Error("Could not load system health");
  return response.json() as Promise<{
    status: "ok" | "degraded";
    service: string;
    checkedAt: string;
    components: {
      scanner: { status: "ready"; deepScan: boolean; activeLocalTools: boolean };
      storage: {
        configured: boolean;
        connected: boolean;
        mode: "mongodb" | "memory";
        database: string;
        latencyMs: number;
        message: string;
      };
      privacy: { rawScanInputStoredByDefault: false; sensitiveLogging: false };
    };
  }>;
}

export async function getAdminReports(status = "All") {
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/admin/reports?status=${encodeURIComponent(status)}`, {
    credentials: "include"
  });
  if (!response.ok) throw new Error("Could not load admin reports");
  return response.json() as Promise<{
    demo: boolean;
    storageMode?: "mongodb" | "memory";
    reports: Array<{
      id: string;
      type: string;
      valuePreview: string;
      sourcePlatform: string;
      status: "Pending" | "Verified" | "Rejected" | "Duplicate" | "Escalated";
      duplicates: number;
      risk: string;
      riskHints: string[];
      submittedAt: string;
      descriptionPreview?: string;
    }>;
  }>;
}

export async function updateAdminReportStatus(id: string, status: "Pending" | "Verified" | "Rejected" | "Duplicate" | "Escalated") {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/admin/reports/${encodeURIComponent(id)}/status`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify({ status })
  });
  if (!response.ok) throw new Error("Could not update report status");
  return response.json();
}

export async function deleteScanHistoryItem(id: string) {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/scan/history/${encodeURIComponent(id)}`, {
    method: "DELETE",
    headers: {
      "X-CSRF-Token": token
    },
    credentials: "include"
  });
  if (!response.ok) throw new Error("Could not delete scan");
  return response.json();
}

export async function getProviderConnectionStatuses() {
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/integrations/status`, {
    credentials: "include"
  });
  if (!response.ok) throw new Error("Could not load provider statuses");
  return (await response.json()) as { providers: ProviderStatusItem[] };
}

export async function testProviderConnection(providerId: string) {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/v1/integrations/test`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify({ providerId })
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Provider test failed");
  }

  return response.json() as Promise<{ providerId: string; status: string; ok: boolean; message: string }>;
}

export async function runSecurityLabScan(payload: {
  type: Exclude<SecurityLabScanType, "file">;
  target: string;
  authorized?: boolean;
  ports?: number[];
}) {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/security-lab/${payload.type}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Security scan failed");
  }

  return (await response.json()) as { result: SecurityLabResult };
}

export async function runSecurityFileScan(file: File, authorized = false) {
  const token = await getCsrfToken();
  const formData = new FormData();
  formData.append("file", file);
  formData.append("authorized", String(authorized));

  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/security-lab/file`, {
    method: "POST",
    headers: {
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: formData
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "File security scan failed");
  }

  return (await response.json()) as { result: SecurityLabResult };
}

export async function getSecurityIntegrations() {
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/security-lab/integrations`, {
    credentials: "include"
  });
  if (!response.ok) throw new Error("Could not load security integrations");
  return (await response.json()) as { integrations: SecurityIntegrationStatusItem[] };
}

export async function runSecurityIntegration(payload: {
  toolId: SecurityIntegrationId;
  target: string;
  authorized?: boolean;
}) {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/security-lab/integrations/run`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error?.message ?? "Integration run failed");
  }

  return (await response.json()) as { result: SecurityIntegrationRunResult };
}

export type SecurityTerminalOutput = {
  command: string;
  exitCode: number;
  stdout: string[];
  stderr: string[];
  json?: unknown;
};

export async function runSecurityTerminalCommand(command: string) {
  const token = await getCsrfToken();
  const response = await fetch(`${SAME_ORIGIN_API_BASE_URL}/security-lab/terminal`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": token
    },
    credentials: "include",
    body: JSON.stringify({ command })
  });

  const body = (await response.json().catch(() => null)) as { output?: SecurityTerminalOutput } | null;
  if (!response.ok || !body?.output) {
    throw new Error(body?.output?.stderr?.[0] ?? "Terminal command failed");
  }

  return body as { output: SecurityTerminalOutput };
}
