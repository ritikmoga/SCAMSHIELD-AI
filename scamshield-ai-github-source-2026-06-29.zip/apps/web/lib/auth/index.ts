export type AuthMode = "guest" | "login" | "signup";

export const guestLimits = {
  scansPerDay: 5,
  history: false,
  savedAlerts: false
};

export function authNotice(mode: AuthMode) {
  if (mode === "guest") return "Guest mode allows limited scans. Sign in to save redacted history and followed alerts.";
  if (mode === "signup") return "Create an account to save reports, followed alerts, and dashboard history.";
  return "Sign in to save redacted scan history and manage account security.";
}
