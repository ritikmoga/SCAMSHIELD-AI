import {
  AlertTriangle,
  BadgeCheck,
  BookOpenCheck,
  BrainCircuit,
  Database,
  FileImage,
  GlobeLock,
  KeyRound,
  MailWarning,
  MessageSquareWarning,
  QrCode,
  Radar,
  ShieldCheck,
  ShoppingCart,
  Smartphone,
  UsersRound,
  UserRoundSearch
} from "lucide-react";
import type { ScanType } from "@scamshield/shared";

export const navItems = [
  { href: "/scanner", label: "Scan" },
  { href: "/alerts", label: "Alerts" },
  { href: "/education", label: "Learn" },
  { href: "/report", label: "Report" },
  { href: "/dashboard", label: "Dashboard" }
];

export const advancedNavItems = [
  { href: "/security-lab", label: "Security Lab" },
  { href: "/database", label: "Database" },
  { href: "/admin/reports", label: "Admin" }
];

export const scanTypes: Array<{ type: ScanType; title: string; description: string; href: string; icon: typeof ShieldCheck }> = [
  { type: "url", title: "URL Scanner", description: "Detect phishing, malware links, fake domains, and redirects.", href: "/scanner/url", icon: GlobeLock },
  { type: "message", title: "Message Checker", description: "Analyze SMS, WhatsApp, Telegram, and social engineering text.", href: "/scanner/message", icon: MessageSquareWarning },
  { type: "email", title: "Email Checker", description: "Check spoofing, invoice fraud, fake login links, and sender risk.", href: "/scanner/email", icon: MailWarning },
  { type: "upi", title: "UPI Checker", description: "Review UPI IDs, collect requests, refund traps, and QR content.", href: "/scanner/upi", icon: Smartphone },
  { type: "qr", title: "QR Scanner", description: "Decode QR payloads safely before opening links or payment apps.", href: "/scanner/qr", icon: QrCode },
  { type: "screenshot", title: "Screenshot Analyzer", description: "Extract text with OCR and highlight risky links, UPI IDs, and numbers.", href: "/scanner/screenshot", icon: FileImage },
  { type: "phone", title: "Phone Risk Check", description: "Check suspicious customer-care and spam/scam numbers.", href: "/scanner/phone", icon: UserRoundSearch },
  { type: "job", title: "Job Offer Check", description: "Spot fake recruiter scripts, deposits, and document harvesting.", href: "/scanner/job", icon: BadgeCheck },
  { type: "shopping", title: "Shopping Site Check", description: "Review fake sale pages, checkout traps, and brand impersonation.", href: "/scanner/shopping", icon: ShoppingCart },
  { type: "social", title: "Social Profile Check", description: "Detect impersonation, romance scams, and account recovery traps.", href: "/scanner/social", icon: UsersRound }
];

export const productFeatures = [
  { title: "AI explanation engine", text: "Beginner-friendly risk explanations in English and Hindi with defensive next steps.", icon: BrainCircuit },
  { title: "Security Lab", text: "Defensive file, link, DNS, TLS, header, OSINT, and authorized low-noise network checks.", icon: Radar },
  { title: "Reputation checks", text: "Ready for Safe Browsing, VirusTotal, IPQualityScore, HIBP, and internal scam reports.", icon: Database },
  { title: "Privacy-first scanning", text: "Sensitive input is redacted in previews, hashed for matching, and encrypted only when retention is enabled.", icon: KeyRound },
  { title: "OWASP-aligned backend", text: "Secure headers, CSRF protection, rate limits, validation, audit logs, and token rotation.", icon: ShieldCheck },
  { title: "Live scam intelligence", text: "Trending KYC, courier, UPI, job, shopping, and phishing alerts for everyday users.", icon: AlertTriangle },
  { title: "Education hub", text: "Safety checklists, quizzes, and tutorials designed for students, parents, and small businesses.", icon: BookOpenCheck }
];

export const demoAlerts = [
  { title: "Fake KYC expiry SMS", severity: "High", category: "Banking", count: 1840 },
  { title: "Courier address fee scam", severity: "Medium", category: "Delivery", count: 932 },
  { title: "Part-time job deposit scam", severity: "High", category: "Jobs", count: 1288 },
  { title: "QR refund collect request", severity: "Critical", category: "UPI", count: 2214 }
];

export const educationCards = [
  { title: "UPI safety", minutes: 5, topic: "Payments", progress: 72 },
  { title: "Fake job offers", minutes: 4, topic: "Careers", progress: 58 },
  { title: "Phishing domains", minutes: 7, topic: "Web", progress: 81 },
  { title: "QR scam awareness", minutes: 3, topic: "Shopping", progress: 66 }
];

export const sampleInputs: Record<ScanType, string> = {
  url: "https://sbi-kyc-secure-login.example.com/verify?account=blocked",
  message: "URGENT: Your bank KYC expires today. Click link and share OTP to avoid account block.",
  email: "From: Billing Team <invoice@secure-payments.example>\nReply-To: helper123@gmail.com\nPlease open the invoice link and verify password immediately.",
  upi: "Refund pending. Accept collect request from refund-helpdesk@oksbi and enter UPI PIN to receive money.",
  qr: "upi://pay?pa=refund-helpdesk@oksbi&pn=Refund%20Desk&am=4999&cu=INR",
  screenshot: "Fake screenshot text: your delivery failed, pay 2 rupees at http://shorturl.example/pay",
  phone: "+91 98765 43210 fake customer care asks to install AnyDesk",
  job: "Work from home job. Salary 80000/month. Pay registration fee 1999 before interview.",
  shopping: "Massive branded sale at flipkart-prize.example, login and claim free gift",
  social: "Instagram support profile asking for password reset OTP"
};
