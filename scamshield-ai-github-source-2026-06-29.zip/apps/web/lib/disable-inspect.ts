export function disableInspectMode() {
  if (typeof window === "undefined") return () => {};

  let devtoolsOpen = false;
  const threshold = 160;

  const handleContextMenu = (event: MouseEvent) => {
    event.preventDefault();
  };

  const handleKeyDown = (event: KeyboardEvent) => {
    const key = event.key.toLowerCase();

    if (
      event.key === "F12" ||
      (event.ctrlKey && event.shiftKey && ["i", "j", "c"].includes(key)) ||
      (event.ctrlKey && ["u", "s"].includes(key)) ||
      (event.metaKey && event.altKey && ["i", "j", "c"].includes(key)) ||
      (event.metaKey && ["u", "s"].includes(key))
    ) {
      event.preventDefault();
      event.stopPropagation();
      window.alert("Inspect mode is disabled on this website.");
    }
  };

  const intervalId = window.setInterval(() => {
    const widthDiff = window.outerWidth - window.innerWidth;
    const heightDiff = window.outerHeight - window.innerHeight;

    if (widthDiff > threshold || heightDiff > threshold) {
      if (!devtoolsOpen) {
        devtoolsOpen = true;
        document.body.innerHTML = `
          <div style="
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            background:#050505;
            color:white;
            font-family:Arial, sans-serif;
            text-align:center;
            padding:30px;
          ">
            <div>
              <h1>Developer Tools Disabled</h1>
              <p>For security reasons, inspect mode is not allowed on this website.</p>
              <button onclick="location.reload()" style="
                padding:12px 20px;
                border:none;
                border-radius:8px;
                cursor:pointer;
                margin-top:15px;
              ">
                Reload Page
              </button>
            </div>
          </div>
        `;
      }
    } else {
      devtoolsOpen = false;
    }
  }, 1000);

  document.addEventListener("contextmenu", handleContextMenu);
  document.addEventListener("keydown", handleKeyDown);

  return () => {
    document.removeEventListener("contextmenu", handleContextMenu);
    document.removeEventListener("keydown", handleKeyDown);
    window.clearInterval(intervalId);
  };
}
