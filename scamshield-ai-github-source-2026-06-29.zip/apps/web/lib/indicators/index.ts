export type ExtractedIndicators = {
  urls: string[];
  domains: string[];
  phoneNumbers: string[];
  upiIds: string[];
  emails: string[];
  keywords: string[];
};

const suspiciousKeywords = [
  "otp",
  "upi pin",
  "cvv",
  "account blocked",
  "kyc",
  "expires today",
  "refund",
  "collect request",
  "registration fee",
  "security deposit",
  "remote access",
  "anydesk",
  "limited time",
  "claim reward",
  "verify immediately",
  "customer care"
];

export function normalizeInput(input: string) {
  return input.replace(/\r\n/g, "\n").replace(/\u00a0/g, " ").trim();
}

export function extractIndicators(input: string): ExtractedIndicators {
  const normalized = normalizeInput(input);
  const urls = unique(
    Array.from(normalized.matchAll(/\bhttps?:\/\/[^\s<>"')]+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s<>"')]+)?/gi)).map((match) =>
      cleanupIndicator(match[0])
    )
  );
  const emails = unique(Array.from(normalized.matchAll(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi)).map((match) => match[0]));
  const upiIds = unique(
    Array.from(normalized.matchAll(/\b[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}\b/g))
      .map((match) => match[0])
      .filter((value) => !emails.some((email) => email.toLowerCase() === value.toLowerCase()))
  );
  const phoneNumbers = unique(
    Array.from(normalized.matchAll(/(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}\b/g)).map((match) => match[0])
  );
  const domains = unique(
    urls
      .map((value) => {
        try {
          return new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`).hostname.toLowerCase();
        } catch {
          return "";
        }
      })
      .filter(Boolean)
  );
  const lower = normalized.toLowerCase();
  const keywords = suspiciousKeywords.filter((keyword) => lower.includes(keyword));

  return { urls, domains, phoneNumbers, upiIds, emails, keywords };
}

function cleanupIndicator(value: string) {
  return value.trim().replace(/[),.;\]]+$/g, "");
}

function unique<T>(items: T[]) {
  return Array.from(new Set(items));
}
