export type ProviderConnectionStatus = "Connected" | "Missing API Key" | "Rate Limited" | "Error" | "Demo Mode";

export type ProviderStatusItem = {
  id: string;
  name: string;
  purpose: string;
  envVar?: string;
  status: ProviderConnectionStatus;
  lastChecked: string;
  rateLimitNote: string;
  docsUrl: string;
  lastTestResult?: string;
};

const providers = [
  {
    id: "google-safe-browsing",
    name: "Google Safe Browsing",
    purpose: "Malware and social-engineering URL reputation",
    envVar: "GOOGLE_SAFE_BROWSING_API_KEY",
    rateLimitNote: "Respect Google quota and cache repeated URL checks.",
    docsUrl: "Documentation placeholder"
  },
  {
    id: "virustotal",
    name: "VirusTotal",
    purpose: "URL, domain, IP, and hash reputation",
    envVar: "VIRUSTOTAL_API_KEY",
    rateLimitNote: "Public API is quota-limited; batch and cache reputation lookups.",
    docsUrl: "Documentation placeholder"
  },
  {
    id: "urlscan",
    name: "urlscan.io",
    purpose: "Passive URL and domain scan intelligence",
    envVar: "URLSCAN_API_KEY",
    rateLimitNote: "Use passive search by default; submissions should be throttled.",
    docsUrl: "Documentation placeholder"
  },
  {
    id: "ipqualityscore",
    name: "IPQualityScore",
    purpose: "URL, phone, fraud, proxy, and abuse risk scoring",
    envVar: "IPQUALITYSCORE_API_KEY",
    rateLimitNote: "Use server-side fraud checks with per-user request throttles.",
    docsUrl: "Documentation placeholder"
  },
  {
    id: "hibp",
    name: "Have I Been Pwned",
    purpose: "Email breach exposure checks with user consent",
    envVar: "HIBP_API_KEY",
    rateLimitNote: "Only check emails with consent and avoid storing raw addresses.",
    docsUrl: "Documentation placeholder"
  },
  {
    id: "abuseipdb",
    name: "AbuseIPDB",
    purpose: "IP abuse confidence and report history",
    envVar: "ABUSEIPDB_API_KEY",
    rateLimitNote: "Cache IP reputation and avoid repeated checks for the same IP.",
    docsUrl: "Documentation placeholder"
  },
  {
    id: "internal-scam-database",
    name: "Internal Scam Database",
    purpose: "Verified community reports and hashed indicator matching",
    rateLimitNote: "Built-in demo data until MongoDB is connected.",
    docsUrl: "Internal playbook placeholder"
  }
];

export function getProviderStatuses(): ProviderStatusItem[] {
  const lastChecked = new Date().toISOString();

  return providers.map((provider) => {
    const configured = provider.envVar ? Boolean(process.env[provider.envVar]?.trim()) : true;
    return {
      ...provider,
      status: configured ? (provider.envVar ? "Connected" : "Demo Mode") : "Missing API Key",
      lastChecked,
      lastTestResult: configured ? "Ready for server-side test" : `Set ${provider.envVar}`
    };
  });
}

export function getProviderStatus(id: string) {
  return getProviderStatuses().find((item) => item.id === id);
}
