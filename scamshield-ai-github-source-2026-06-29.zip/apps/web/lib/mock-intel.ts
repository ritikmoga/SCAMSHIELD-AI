export const databaseRecords = [
  { id: "db-001", type: "URL", value: "sbi-kyc-secure-login.example.com", risk: "Dangerous", tags: ["kyc", "phishing"], lastVerified: "2026-06-04", reports: 184, sourceConfidence: "High" },
  { id: "db-002", type: "UPI", value: "refund-helpdesk@oksbi", risk: "Dangerous", tags: ["refund", "collect"], lastVerified: "2026-06-03", reports: 221, sourceConfidence: "High" },
  { id: "db-003", type: "Phone", value: "+91 98765 43210", risk: "High Risk", tags: ["customer-care", "remote access"], lastVerified: "2026-06-02", reports: 72, sourceConfidence: "Medium" },
  { id: "db-004", type: "Message Template", value: "KYC expires today. Share OTP.", risk: "Dangerous", tags: ["otp", "banking"], lastVerified: "2026-06-01", reports: 310, sourceConfidence: "High" },
  { id: "db-005", type: "Job", value: "Registration fee before interview", risk: "High Risk", tags: ["job", "deposit"], lastVerified: "2026-05-30", reports: 98, sourceConfidence: "Medium" },
  { id: "db-006", type: "Shopping", value: "flipkart-prize.example", risk: "Suspicious", tags: ["shopping", "brand"], lastVerified: "2026-05-29", reports: 33, sourceConfidence: "Medium" },
  { id: "db-007", type: "Email", value: "invoice-secure-payments.example", risk: "Suspicious", tags: ["invoice", "credential"], lastVerified: "2026-05-28", reports: 41, sourceConfidence: "Low" },
  { id: "db-008", type: "Social", value: "fake-support-profile recovery script", risk: "High Risk", tags: ["social", "otp"], lastVerified: "2026-05-27", reports: 66, sourceConfidence: "Medium" }
];

export const alertRecords = [
  {
    id: "alert-kyc",
    title: "Fake KYC expiry SMS",
    severity: "High",
    category: "Banking",
    count: 1840,
    summary: "Messages claim the bank account will be blocked unless KYC is updated through a link.",
    commonScript: "Your KYC expires today. Click this link and share OTP to avoid account block.",
    redFlags: ["Urgency", "OTP request", "Unofficial domain"],
    whatToDo: ["Open the official bank app yourself", "Call the number printed on the bank card"],
    whatNotToDo: ["Do not click SMS links", "Do not share OTP or passwords"],
    relatedIndicators: ["db-001", "db-004"],
    lastUpdated: "2026-06-05"
  },
  {
    id: "alert-courier",
    title: "Courier address fee scam",
    severity: "Medium",
    category: "Delivery",
    count: 932,
    summary: "Fake delivery updates ask for a tiny fee to confirm an address.",
    commonScript: "Package failed. Pay Rs. 2 now to reschedule delivery.",
    redFlags: ["Small payment lure", "Shortened URL", "Fake tracking"],
    whatToDo: ["Check the order inside the official shopping app"],
    whatNotToDo: ["Do not enter card or UPI PIN on unknown pages"],
    relatedIndicators: ["db-006"],
    lastUpdated: "2026-06-04"
  },
  {
    id: "alert-job",
    title: "Part-time job deposit scam",
    severity: "High",
    category: "Jobs",
    count: 1288,
    summary: "Recruiters promise high salary but ask for registration, training, or security fees.",
    commonScript: "Pay a refundable security deposit to receive your offer letter.",
    redFlags: ["Fee before interview", "Unrealistic salary", "Messaging-only recruiter"],
    whatToDo: ["Verify company domain and recruiter profile"],
    whatNotToDo: ["Do not pay to get a job"],
    relatedIndicators: ["db-005"],
    lastUpdated: "2026-06-03"
  },
  {
    id: "alert-upi",
    title: "QR refund collect request",
    severity: "Critical",
    category: "UPI",
    count: 2214,
    summary: "Scammers claim to send refunds but ask users to approve collect requests or enter UPI PIN.",
    commonScript: "Scan this QR to receive your refund and enter UPI PIN.",
    redFlags: ["UPI PIN to receive money", "QR collect request", "Refund pressure"],
    whatToDo: ["Reject collect requests you did not initiate"],
    whatNotToDo: ["Never enter UPI PIN to receive money"],
    relatedIndicators: ["db-002"],
    lastUpdated: "2026-06-05"
  }
];
