import type { ScanType } from "@scamshield/shared";
import type {
  ApiScanStatus,
  EvidenceItem,
  RedirectHop,
  RiskCategoryScore,
  RiskFlag,
  ScanTimelineItem
} from "@/lib/risk-engine/types";

export type UserModel = {
  id: string;
  email?: string;
  displayName?: string;
  role: "guest" | "user" | "moderator" | "admin" | "super_admin";
  mfaEnabled: boolean;
  createdAt: string;
  lastLoginAt?: string;
};

export type ScanResultModel = {
  id: string;
  userId?: string;
  inputType: ScanType;
  originalInput?: string;
  sanitizedInput: string;
  inputHash: string;
  finalUrl?: string;
  domain?: string;
  riskScore: number;
  confidenceScore: number;
  verdict: string;
  mainReason: string;
  categoryScores: RiskCategoryScore[];
  evidence: EvidenceItem[];
  riskSignals: RiskFlag[];
  redirectChain: RedirectHop[];
  recommendedActions: string[];
  scanTimeline: ScanTimelineItem[];
  apiStatuses: ApiScanStatus[];
  createdAt: string;
  expiresAt?: string;
};

export type RiskSignalModel = {
  id: string;
  scanId: string;
  category: string;
  label: string;
  severity: "low" | "medium" | "high" | "critical";
  evidencePreview?: string;
  points: number;
  createdAt: string;
};

export type CommunityReportModel = {
  id: string;
  reporterUserId?: string;
  reportType: ScanType | "other";
  valueHash: string;
  redactedPreview: string;
  category: string;
  description: string;
  evidenceScreenshotUrl?: string;
  status: "pending" | "verified" | "rejected" | "duplicate" | "false_positive";
  createdAt: string;
  reviewedAt?: string;
};

export type AdminReviewModel = {
  id: string;
  reviewerUserId: string;
  targetType: "scan" | "community_report" | "known_threat";
  targetId: string;
  action: "approve_scam_report" | "reject_false_report" | "mark_verified_threat" | "lower_risk" | "ban_spam_reporter" | "export_threat_data";
  notes?: string;
  createdAt: string;
};

export type KnownThreatModel = {
  id: string;
  indicatorType: ScanType | "domain" | "ip" | "hash";
  indicatorHash: string;
  redactedIndicator: string;
  category: string;
  riskScore: number;
  source: "internal" | "community" | "admin" | "threat_intel";
  verified: boolean;
  lastVerifiedAt?: string;
  createdAt: string;
};

export type ApiScanStatusModel = ApiScanStatus & {
  id: string;
  scanId: string;
};

export type ScanTimelineModel = ScanTimelineItem & {
  id: string;
  scanId: string;
};

export type SavedReportModel = {
  id: string;
  userId: string;
  scanId: string;
  title: string;
  tags: string[];
  createdAt: string;
};

