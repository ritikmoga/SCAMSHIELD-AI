import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { checkVirusTotalHash, runClamAvScan, runYaraScan } from "./tool-connectors";
import { extractDeepIndicators, urlsFromIndicators } from "./indicators";
import { analyzeStaticContent, inferTextScanType } from "./static-analysis";
import { runUrlIntel } from "./url-intel";
import type { DeepFinding, DeepScanRequest, DeepScanResult, DeepScanType, RiskCategoryKey } from "./types";
import {
  addFinding,
  addTimeline,
  buildInputSummary,
  bumpCategory,
  computeHashes,
  defaultExternalResults,
  detectMime,
  emptyHashes,
  maxUploadBytes,
  newScanId,
  normalizeText,
  randomStoredFilename,
  safePreview,
  verdictFromScore
} from "./utils";
import { buildCategoryScores, buildRecommendations, buildSummary, calculateConfidence, calculateDeepRiskScore } from "./scoring";

const disclaimer = "No scanner can guarantee complete safety. This result is based on available indicators.";

export async function runDeepScan(request: DeepScanRequest): Promise<DeepScanResult> {
  const scanId = newScanId();
  const startedAt = performance.now();
  let tempDir: string | undefined;
  let filePath: string | undefined;

  const timeline: DeepScanResult["scanTimeline"] = [];
  const findings: DeepFinding[] = [];
  const metadata: Record<string, unknown> = {};
  const externalResults = defaultExternalResults();
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  let scanType: DeepScanType = request.scanType ?? "message";
  let inputText = normalizeText(request.url ?? request.text ?? "");
  let input = buildInputSummary({
    originalName: "text-input.txt",
    size: Buffer.byteLength(inputText),
    claimedMimeType: "text/plain",
    detectedMimeType: "text/plain"
  });
  let hashes = inputText ? computeHashes(Buffer.from(inputText)) : emptyHashes();
  let confidenceSignals = 0;
  let confidencePenalties = 0;

  addTimeline(timeline, startedAt, "Input received", "success", "Input accepted for server-side defensive scanning. Links, files, and QR payloads are not opened on the user device.");

  try {
    if (request.file) {
      if (request.file.buffer.length > maxUploadBytes) {
        throw new Error(`File is too large. Maximum upload size is ${Math.round(maxUploadBytes / 1024 / 1024)}MB.`);
      }
      tempDir = await fs.mkdtemp(path.join(os.tmpdir(), `scamshield-${scanId}-`));
      filePath = path.join(tempDir, randomStoredFilename(request.file.originalName));
      await fs.writeFile(filePath, request.file.buffer, { mode: 0o600 });

      const detectedMimeType = detectMime(request.file.buffer, request.file.originalName);
      input = buildInputSummary({
        originalName: request.file.originalName,
        size: request.file.buffer.length,
        claimedMimeType: request.file.claimedMimeType,
        detectedMimeType
      });
      hashes = computeHashes(request.file.buffer);
      addTimeline(timeline, startedAt, "Input normalized", "success", "Upload was stored with a random name inside an isolated temporary scan folder.");
      addTimeline(timeline, startedAt, "Hashes generated", "success", "MD5, SHA1, and SHA256 fingerprints were generated for reputation and duplicate matching.");

      applyKnownHashChecks(hashes.sha256, findings, categoryScores);

      const staticAnalysis = await analyzeStaticContent({
        buffer: request.file.buffer,
        input,
        scanType: request.scanType
      });
      scanType = staticAnalysis.scanType;
      inputText = normalizeText([staticAnalysis.visibleText, staticAnalysis.qrPayloads.join("\n")].filter(Boolean).join("\n"));
      Object.assign(metadata, staticAnalysis.metadata);
      findings.push(...staticAnalysis.findings);
      Object.entries(staticAnalysis.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
      confidenceSignals += staticAnalysis.confidenceSignals;
      confidencePenalties += staticAnalysis.confidencePenalties;
      addTimeline(timeline, startedAt, "Static file analysis completed", "success", `File was analyzed as ${scanType}. Embedded text and indicators were extracted where possible.`);
    } else {
      scanType = inferTextScanType(inputText, request.scanType);
      addTimeline(timeline, startedAt, "Input normalized", "success", `Text input normalized and classified as ${scanType}.`);
    }

    if (!inputText && !request.file) {
      throw new Error("Scan input is required.");
    }

    const extraction = extractDeepIndicators(inputText);
    const indicators = extraction.indicators;
    metadata.indicatorExtraction = {
      suspiciousKeywords: extraction.suspiciousKeywords,
      decodedStringCount: extraction.decodedStrings.length,
      decodedPreviews: extraction.decodedStrings.map((value) => safePreview(value, 180))
    };
    addTimeline(timeline, startedAt, "Indicators extracted", indicators.length ? "success" : "warning", `${indicators.length} indicator(s) extracted from visible text, metadata, QR payloads, and decoded strings.`);

    applyUrlStructureHeuristics(indicators, findings, categoryScores);
    applyMessageAndContentHeuristics(scanType, inputText, extraction.suspiciousKeywords, findings, categoryScores);
    applyCommunityReports(request.communityReports, findings, categoryScores);

    const urls = indicators.filter((item) => item.type === "url").map((item) => item.value);
    const domains = indicators.filter((item) => item.type === "domain").map((item) => item.value);
    const ips = indicators.filter((item) => item.type === "ip").map((item) => item.value);
    const urlIntel = await runUrlIntel({
      urls,
      domains,
      ips,
      externalResults,
      findings,
      timeline,
      categoryScores,
      startedAt
    });
    confidenceSignals += Math.max(0, urlIntel.confidenceDelta);
    confidencePenalties += Math.max(0, -urlIntel.confidenceDelta);
    metadata.urlAnalysis = {
      finalUrl: urlIntel.finalUrl ? safePreview(urlIntel.finalUrl, 220) : null,
      redirectChain: urlIntel.redirectChain?.map((hop) => ({ ...hop, url: safePreview(hop.url, 220) })) ?? [],
      httpsExplanation:
        "HTTPS does not guarantee safety. It only protects the connection between your browser and the website. Scam, phishing, and malware websites can also use HTTPS."
    };

    if (request.file && filePath && tempDir) {
      const [clamav, yara, vtHash] = await Promise.all([runClamAvScan(filePath, tempDir), runYaraScan(filePath, tempDir), checkVirusTotalHash(hashes.sha256)]);
      externalResults.clamav = clamav;
      externalResults.yara = yara;
      if (vtHash.status !== "skipped") externalResults.virusTotal = strongestProvider(externalResults.virusTotal, vtHash);

      if (clamav.scoreImpact >= 70) {
        addFinding(findings, {
          severity: "critical",
          category: "Static Malware",
          title: "ClamAV malware signature match",
          description: "ClamAV reported a malware signature match.",
          source: "LEVEL 6 Static Malware Scanning",
          evidence: clamav.message,
          scoreImpact: 70
        });
        bumpCategory(categoryScores, "malware", 95);
      }
      if (yara.scoreImpact >= 60) {
        addFinding(findings, {
          severity: "critical",
          category: "Static Malware",
          title: "YARA malware rule match",
          description: "A configured YARA rule matched malware-like content.",
          source: "LEVEL 6 Static Malware Scanning",
          evidence: yara.message,
          scoreImpact: 60
        });
        bumpCategory(categoryScores, "malware", 90);
      } else if (yara.scoreImpact >= 30) {
        addFinding(findings, {
          severity: "medium",
          category: "Static Malware",
          title: "Suspicious YARA rule match",
          description: "A configured YARA rule matched suspicious static content.",
          source: "LEVEL 6 Static Malware Scanning",
          evidence: yara.message,
          scoreImpact: 30
        });
        bumpCategory(categoryScores, "malware", 60);
      }
      addTimeline(timeline, startedAt, "Static malware tools checked", "success", "ClamAV/YARA/hash reputation checks either ran or were recorded as unavailable without treating the file as safe.");
    }

    const riskScore = calculateDeepRiskScore(findings, externalResults);
    const categoryScoreItems = buildCategoryScores(categoryScores, findings);
    const confidence = calculateConfidence({
      findings,
      externalResults,
      confidenceSignals,
      confidencePenalties,
      hasFile: Boolean(request.file),
      hasExtractedIndicators: indicators.length > 0
    });
    const verdict = verdictFromScore(riskScore);
    const resultBase = {
      scanId,
      scanType,
      status: "completed" as const,
      riskScore,
      verdict,
      confidence,
      summary: "",
      input,
      hashes,
      findings: sortFindings(findings),
      extractedIndicators: indicators,
      metadata,
      externalResults,
      recommendations: buildRecommendations({ scanType, riskScore, findings }),
      disclaimer,
      categoryScores: categoryScoreItems,
      scanTimeline: timeline
    };
    resultBase.summary = buildSummary(resultBase);
    addTimeline(resultBase.scanTimeline, startedAt, "Final risk score generated", "success", `Risk score ${riskScore}/100, verdict ${verdict}, confidence ${confidence}%.`);
    return resultBase;
  } finally {
    if (tempDir) {
      await fs.rm(tempDir, { recursive: true, force: true }).catch(() => undefined);
    }
  }
}

function applyKnownHashChecks(sha256: string, findings: DeepFinding[], categoryScores: Partial<Record<RiskCategoryKey, number>>) {
  const knownBad = parseHashSet(process.env.SCAMSHIELD_KNOWN_BAD_HASHES);
  const knownSafe = parseHashSet(process.env.SCAMSHIELD_KNOWN_SAFE_HASHES);
  if (knownBad.has(sha256.toLowerCase())) {
    addFinding(findings, {
      severity: "critical",
      category: "Hash Reputation",
      title: "Known malicious hash",
      description: "The SHA256 hash matches a configured known-bad hash list.",
      source: "LEVEL 1 Hashing & Basic Fingerprinting",
      evidence: sha256,
      scoreImpact: 80
    });
    bumpCategory(categoryScores, "malware", 100);
  } else if (knownSafe.has(sha256.toLowerCase())) {
    addFinding(findings, {
      severity: "low",
      category: "Hash Reputation",
      title: "Known-safe hash match",
      description: "The SHA256 hash matches a configured known-safe hash list. This reduces uncertainty but does not guarantee complete safety.",
      source: "LEVEL 1 Hashing & Basic Fingerprinting",
      evidence: sha256,
      scoreImpact: 0
    });
  }
}

function applyUrlStructureHeuristics(
  indicators: ReturnType<typeof extractDeepIndicators>["indicators"],
  findings: DeepFinding[],
  categoryScores: Partial<Record<RiskCategoryKey, number>>
) {
  for (const urlValue of urlsFromIndicators(indicators).slice(0, 12)) {
    try {
      const url = new URL(urlValue);
      const hostname = url.hostname.toLowerCase();
      const joined = `${hostname}${url.pathname}${url.search}`.toLowerCase();
      if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname)) {
        addFinding(findings, {
          severity: "medium",
          category: "URL Structure",
          title: "IP address used instead of domain",
          description: "Raw IP-address URLs are harder for users to verify and are often used in risky links.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: hostname,
          scoreImpact: 20
        });
        bumpCategory(categoryScores, "domainReputation", 55);
      }
      if ((hostname.match(/-/g) ?? []).length >= 3) {
        addFinding(findings, {
          severity: "low",
          category: "URL Structure",
          title: "Unusually hyphenated domain",
          description: "Many hyphens can indicate throwaway or impersonation-style domains.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: hostname,
          scoreImpact: 10
        });
      }
      if (/[a-z0-9]{18,}|[a-z]{8,}\d{3,}/i.test(hostname.split(".")[0] ?? "")) {
        addFinding(findings, {
          severity: "low",
          category: "URL Structure",
          title: "Random-looking domain label",
          description: "The domain has a random-looking label that may indicate disposable infrastructure.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: hostname,
          scoreImpact: 10
        });
      }
      if (/bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|cutt\.ly|rebrand\.ly|shorturl/i.test(hostname)) {
        addFinding(findings, {
          severity: "medium",
          category: "URL Structure",
          title: "Shortened URL",
          description: "Shortened URLs hide the final destination and should be treated carefully.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: hostname,
          scoreImpact: 20
        });
        bumpCategory(categoryScores, "redirect", 55);
      }
      if (/xn--|%[0-9a-f]{2}/i.test(urlValue)) {
        addFinding(findings, {
          severity: "high",
          category: "URL Structure",
          title: "Punycode or encoded URL",
          description: "Encoded or punycode domains can be used for lookalike phishing.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: urlValue,
          scoreImpact: 35
        });
        bumpCategory(categoryScores, "brandImpersonation", 75);
      }
      if (/\.(zip|mov|top|xyz|click|cam|monster|bond|lol)$/i.test(hostname)) {
        addFinding(findings, {
          severity: "low",
          category: "URL Structure",
          title: "Suspicious or frequently abused TLD",
          description: "This TLD is often seen in risky campaigns. This is a weak signal by itself.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: hostname,
          scoreImpact: 10
        });
      }
      if (/(login|verify|otp|kyc|refund|account-block|password|secure|support)/i.test(joined)) {
        addFinding(findings, {
          severity: "medium",
          category: "URL Structure",
          title: "High-risk action words in URL",
          description: "The URL contains words often used in phishing or fake account-recovery links.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: safePreview(joined, 160),
          scoreImpact: 20
        });
        bumpCategory(categoryScores, "phishing", 55);
      }
      if (/(paytm|phonepe|gpay|sbi|hdfc|icici|axis|amazon|flipkart|whatsapp|telegram)/i.test(hostname) && !isLikelyOfficial(hostname)) {
        addFinding(findings, {
          severity: "critical",
          category: "Brand Impersonation",
          title: "Possible brand lookalike domain",
          description: "The domain uses a trusted brand word but does not match a known official domain pattern.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: hostname,
          scoreImpact: 35
        });
        bumpCategory(categoryScores, "brandImpersonation", 88);
        bumpCategory(categoryScores, "phishing", 80);
      }
      if (url.protocol === "http:" && /(login|password|payment|upi|card|checkout|verify)/i.test(joined)) {
        addFinding(findings, {
          severity: "high",
          category: "URL Structure",
          title: "HTTP-only login/payment style URL",
          description: "Sensitive login or payment-looking flow is using HTTP. HTTPS absence increases exposure risk.",
          source: "LEVEL 5 URL & Domain Reputation Scanning",
          evidence: urlValue,
          scoreImpact: 35
        });
        bumpCategory(categoryScores, "privacy", 70);
      }
    } catch {
      // Invalid URL indicators are already captured by validation and extraction.
    }
  }
}

function applyMessageAndContentHeuristics(
  scanType: DeepScanType,
  inputText: string,
  keywords: string[],
  findings: DeepFinding[],
  categoryScores: Partial<Record<RiskCategoryKey, number>>
) {
  const lower = inputText.toLowerCase();
  const checks: Array<[RegExp, DeepFinding["severity"], string, string, string, number, RiskCategoryKey]> = [
    [/\botp\b|one[-\s]?time password|verification code|share.*code/i, "high", "OTP/security code request", "Requesting OTPs or security codes is a dangerous social-engineering signal.", "Content Risk", 35, "privacy"],
    [/upi\s*pin|enter.*pin.*receive|pin.*refund/i, "critical", "UPI PIN pressure", "UPI PIN is never required to receive money. This is a strong UPI scam signal.", "Payment / UPI Risk", 55, "payment"],
    [/cvv|card pin|password|passcode|netbanking|aadhaar|pan card/i, "critical", "Sensitive data request", "The content asks for credentials, card details, or identity information.", "Privacy Risk", 45, "privacy"],
    [/account blocked|kyc.*expire|urgent|limited time|verify now|login immediately/i, "medium", "Urgency or account-block pressure", "Urgency language is commonly used to make users act without verification.", "Content Risk", 18, "scam"],
    [/refund|collect request|cashback|reward|lottery|claim prize|gift card/i, "medium", "Reward/refund lure", "Scam messages often promise refunds, prizes, rewards, or cashback to lure payment or credentials.", "Content Risk", 20, "scam"],
    [/job.*(registration|security|deposit|fee)|work from home.*earn|interview.*fee|training fee/i, "critical", "Fake job fee request", "Legitimate hiring rarely requires upfront registration, security, laptop, or training fees.", "Job Scam Risk", 55, "scam"],
    [/customer care|support.*number|anydesk|teamviewer|screen share|remote access/i, "critical", "Remote access/customer care scam pattern", "Unknown support numbers combined with remote-access requests are dangerous.", "Social Engineering", 50, "privacy"],
    [/apk|download app|install.*unknown|\.apk\b/i, "critical", "Unknown APK/download prompt", "Unknown APK download links can install malware or steal credentials.", "Malware Risk", 50, "malware"],
    [/guaranteed returns|double your money|crypto investment|risk free profit/i, "critical", "Guaranteed investment return claim", "Guaranteed returns are a common investment scam pattern.", "Investment Scam Risk", 45, "scam"],
    [/loan.*approval.*fee|processing fee.*loan/i, "critical", "Loan approval fee request", "Upfront loan approval fees are frequently used in financial scams.", "Financial Scam Risk", 45, "payment"],
    [/upi:\/\//i, "medium", "UPI payment payload", "A UPI/payment payload was found and should not be opened automatically.", "Payment / UPI Risk", 25, "payment"]
  ];

  for (const [pattern, severity, title, description, category, impact, categoryKey] of checks) {
    const match = lower.match(pattern);
    if (!match) continue;
    addFinding(findings, {
      severity,
      category,
      title,
      description,
      source: scanType === "email-header" ? "LEVEL 15 Email Header and Text Scanning" : "LEVEL 16 Message and Scam Text Scanning",
      evidence: match[0],
      scoreImpact: impact
    });
    bumpCategory(categoryScores, categoryKey, impact + 35);
  }

  if (scanType === "email" || scanType === "email-header") {
    if (/from:.*@(gmail|yahoo|outlook|hotmail)\./i.test(inputText) && /(bank|invoice|payment|security|account)/i.test(inputText)) {
      addFinding(findings, {
        severity: "medium",
        category: "Email",
        title: "Free-mail sender with business/banking context",
        description: "A free-mail sender is presenting banking, invoice, payment, or account-security context.",
        source: "LEVEL 15 Email Header and Email Text Scanning",
        evidence: "free-mail sender",
        scoreImpact: 20
      });
      bumpCategory(categoryScores, "phishing", 55);
    }
  }

  if (keywords.length) {
    bumpCategory(categoryScores, "scam", Math.min(80, keywords.length * 12 + 25));
  }
}

function applyCommunityReports(
  reports: DeepScanRequest["communityReports"],
  findings: DeepFinding[],
  categoryScores: Partial<Record<RiskCategoryKey, number>>
) {
  const total = reports?.totalReports ?? 0;
  const verified = reports?.verifiedReports ?? 0;
  if (reports?.falsePositiveReviewed) {
    addFinding(findings, {
      severity: "low",
      category: "Community Reports",
      title: "False-positive review exists",
      description: "A reviewer previously marked a matching indicator as a possible false positive, reducing risk pressure.",
      source: "LEVEL 17 Threat Intelligence Correlation",
      evidence: "false-positive reviewed",
      scoreImpact: 0
    });
    return;
  }
  if (!total && !verified) return;
  const impact = verified ? 70 : total >= 50 ? 30 : total >= 20 ? 20 : total >= 5 ? 10 : 5;
  addFinding(findings, {
    severity: verified ? "critical" : total >= 20 ? "medium" : "low",
    category: "Community Reports",
    title: verified ? "Admin-verified community scam report" : "Community reports found",
    description: "Matching community reports increase risk, especially after moderator verification.",
    source: "LEVEL 17 Threat Intelligence Correlation",
    evidence: `${total} total report(s), ${verified} verified`,
    scoreImpact: impact
  });
  bumpCategory(categoryScores, "scam", verified ? 92 : 50);
}

function strongestProvider<T extends { scoreImpact: number }>(left: T, right: T) {
  return right.scoreImpact > left.scoreImpact ? right : left;
}

function sortFindings(findings: DeepFinding[]) {
  const rank: Record<DeepFinding["severity"], number> = { critical: 4, high: 3, medium: 2, low: 1 };
  return findings
    .slice()
    .sort((a, b) => rank[b.severity] - rank[a.severity] || b.scoreImpact - a.scoreImpact)
    .slice(0, 80);
}

function parseHashSet(value?: string) {
  return new Set(
    (value ?? "")
      .split(/[,\s]+/)
      .map((item) => item.trim().toLowerCase())
      .filter(Boolean)
  );
}

function isLikelyOfficial(hostname: string) {
  return [
    "paytm.com",
    "phonepe.com",
    "google.com",
    "googlepay.com",
    "sbi.co.in",
    "hdfcbank.com",
    "icicibank.com",
    "axisbank.com",
    "amazon.in",
    "amazon.com",
    "flipkart.com",
    "whatsapp.com",
    "telegram.org"
  ].some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
}
