import { normalizeText, safePreview, uniqueIndicators } from "./utils";
import type { DeepExtractedIndicator, IndicatorReputation, IndicatorType } from "./types";

const suspiciousKeywords = [
  "urgent",
  "verify now",
  "account blocked",
  "kyc",
  "reward",
  "lottery",
  "claim prize",
  "password reset",
  "payment failed",
  "login immediately",
  "refund",
  "cashback",
  "gift card",
  "parcel failed",
  "bank blocked",
  "upi pin",
  "otp",
  "cvv",
  "remote access",
  "anydesk",
  "teamviewer",
  "security deposit",
  "registration fee",
  "guaranteed returns",
  "loan approval fee"
];

const urlPattern = /\bhttps?:\/\/[^\s<>"'`]+|\b(?:www\.)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s<>"'`]*)?/gi;
const emailPattern = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
const ipPattern = /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g;
const phonePattern = /(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,4}\)?[\s-]?)?\d{3,5}[\s-]?\d{4,6}\b/g;
const upiPattern = /\b[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}\b/g;
const sha256Pattern = /\b[a-f0-9]{64}\b/gi;
const cryptoPattern = /\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b|\b0x[a-fA-F0-9]{40}\b/g;

export type IndicatorExtractionResult = {
  indicators: DeepExtractedIndicator[];
  suspiciousKeywords: string[];
  decodedStrings: string[];
};

export function extractDeepIndicators(input: string): IndicatorExtractionResult {
  const normalized = normalizeText(input);
  const decodedStrings = decodeLikelyEncodedStrings(normalized);
  const combined = [normalized, ...decodedStrings].join("\n");
  const urls = unique(matches(combined, urlPattern).map(cleanupUrl).map(normalizeUrlLike).filter(Boolean));
  const emails = unique(matches(combined, emailPattern));
  const upiIds = unique(matches(combined, upiPattern).filter((value) => !emails.some((email) => email.toLowerCase() === value.toLowerCase())));
  const ips = unique(matches(combined, ipPattern));
  const phones = unique(matches(combined, phonePattern).filter((value) => value.replace(/\D/g, "").length >= 8));
  const hashes = unique(matches(combined, sha256Pattern));
  const cryptoValues = unique(matches(combined, cryptoPattern));
  const domains = unique([...urls.map(domainFromUrl).filter(Boolean), ...extractBareDomains(combined)]);
  const keywords = suspiciousKeywords.filter((keyword) => combined.toLowerCase().includes(keyword));

  const indicators: DeepExtractedIndicator[] = [
    ...urls.map((value) => indicator("url", value, reputationForUrl(value), ["regex"])),
    ...domains.map((value) => indicator("domain", value, reputationForDomain(value), ["regex"])),
    ...ips.map((value) => indicator("ip", value, "unknown", ["regex"])),
    ...emails.map((value) => indicator("email", safePreview(value, 120), "unknown", ["regex"])),
    ...phones.map((value) => indicator("phone", maskPhone(value), "unknown", ["regex"])),
    ...upiIds.map((value) => indicator("upi", safePreview(value, 120), "suspicious", ["regex"])),
    ...hashes.map((value) => indicator("hash", value.toLowerCase(), "unknown", ["regex"])),
    ...cryptoValues.map((value) => indicator("crypto", value, "suspicious", ["regex"]))
  ];

  return {
    indicators: uniqueIndicators(indicators),
    suspiciousKeywords: keywords,
    decodedStrings: decodedStrings.slice(0, 12)
  };
}

export function urlsFromIndicators(indicators: DeepExtractedIndicator[]) {
  return indicators.filter((item) => item.type === "url").map((item) => item.value);
}

export function domainsFromIndicators(indicators: DeepExtractedIndicator[]) {
  return indicators.filter((item) => item.type === "domain").map((item) => item.value);
}

function indicator(type: IndicatorType, value: string, reputation: IndicatorReputation, sources: string[]): DeepExtractedIndicator {
  return { type, value, reputation, sources };
}

function matches(input: string, pattern: RegExp) {
  return Array.from(input.matchAll(pattern)).map((match) => match[0]);
}

function unique(items: string[]) {
  return Array.from(new Set(items.map((item) => item.trim()).filter(Boolean)));
}

function cleanupUrl(value: string) {
  return value.trim().replace(/[),.;\]\s]+$/g, "");
}

function normalizeUrlLike(value: string) {
  const clean = cleanupUrl(value);
  if (!clean) return "";
  if (/^https?:\/\//i.test(clean)) return clean;
  return `https://${clean}`;
}

function domainFromUrl(value: string) {
  try {
    return new URL(value).hostname.toLowerCase();
  } catch {
    return "";
  }
}

function extractBareDomains(input: string) {
  return matches(input, /\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b/gi)
    .map((value) => value.toLowerCase())
    .filter((value) => !value.includes("@"));
}

function reputationForUrl(value: string): IndicatorReputation {
  if (/bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|cutt\.ly|rebrand\.ly|shorturl/i.test(value)) return "suspicious";
  if (/(otp|kyc|login|verify|refund|free|bonus|apk|download|account-block)/i.test(value)) return "suspicious";
  return "unknown";
}

function reputationForDomain(value: string): IndicatorReputation {
  if (/xn--|\.zip$|\.mov$|\.top$|\.xyz$|\.click$|\.cam$|\.monster$/i.test(value)) return "suspicious";
  if (/(paytm|phonepe|sbi|hdfc|icici|axis|amazon|flipkart|whatsapp).*(login|verify|secure|kyc)|(?:login|verify|secure).*(paytm|phonepe|sbi|hdfc|icici|axis)/i.test(value)) {
    return "suspicious";
  }
  return "unknown";
}

function maskPhone(value: string) {
  const digits = value.replace(/\D/g, "");
  if (digits.length < 6) return value;
  return `${digits.slice(0, 2)}***${digits.slice(-2)}`;
}

function decodeLikelyEncodedStrings(input: string) {
  const decoded = new Set<string>();
  for (const match of input.matchAll(/(?:[A-Za-z0-9+/]{32,}={0,2})/g)) {
    try {
      const text = Buffer.from(match[0], "base64").toString("utf8");
      if (/https?:\/\/|<script|powershell|cmd\.exe|upi|otp|password/i.test(text)) decoded.add(text.slice(0, 4000));
    } catch {
      // Ignore malformed base64-like blobs.
    }
  }
  for (const match of input.matchAll(/(?:%[0-9a-fA-F]{2}){4,}/g)) {
    try {
      const text = decodeURIComponent(match[0]);
      if (text !== match[0]) decoded.add(text.slice(0, 4000));
    } catch {
      // Ignore malformed percent-encoding.
    }
  }
  return Array.from(decoded);
}
