import type { DeepFinding, DeepScanResult, ExternalResults, RiskCategoryKey, RiskCategoryScore } from "./types";
import { clamp, verdictFromScore } from "./utils";

const categoryLabels: Record<RiskCategoryKey, string> = {
  phishing: "Phishing Risk",
  malware: "Malware Risk",
  scam: "Scam / Social Engineering Risk",
  domainReputation: "Domain Reputation Risk",
  redirect: "Redirect Risk",
  privacy: "Privacy / Data Theft Risk",
  payment: "Payment / UPI Risk",
  brandImpersonation: "Brand Impersonation Risk",
  fileStructure: "File Structure Risk",
  hiddenContent: "Hidden Content Risk"
};

export function calculateDeepRiskScore(findings: DeepFinding[], externalResults: ExternalResults) {
  const findingScore = findings.reduce((score, finding) => score + finding.scoreImpact, 0);
  const externalScore = Object.values(externalResults).reduce((score, result) => score + result.scoreImpact, 0);
  const criticalFloor = findings.some((finding) => finding.severity === "critical") ? 72 : 0;
  const highFloor = findings.some((finding) => finding.severity === "high") ? 55 : 0;
  return clamp(Math.max(findingScore + externalScore, criticalFloor, highFloor));
}

export function calculateConfidence(input: {
  findings: DeepFinding[];
  externalResults: ExternalResults;
  confidenceSignals: number;
  confidencePenalties: number;
  hasFile: boolean;
  hasExtractedIndicators: boolean;
}) {
  const checkedProviders = Object.values(input.externalResults).filter((item) => item.status === "checked").length;
  const unavailableProviders = Object.values(input.externalResults).filter((item) => ["missing_key", "not_configured", "rate_limited", "error"].includes(item.status)).length;
  const diverseCategories = new Set(input.findings.map((finding) => finding.category)).size;
  return clamp(
    42 +
      checkedProviders * 5 -
      unavailableProviders * 3 +
      diverseCategories * 4 +
      input.confidenceSignals -
      input.confidencePenalties +
      (input.hasFile ? 6 : 0) +
      (input.hasExtractedIndicators ? 8 : -6)
  );
}

export function buildCategoryScores(scores: Partial<Record<RiskCategoryKey, number>>, findings: DeepFinding[]): RiskCategoryScore[] {
  const byCategory = new Map<string, DeepFinding[]>();
  for (const finding of findings) {
    const items = byCategory.get(finding.category) ?? [];
    items.push(finding);
    byCategory.set(finding.category, items);
  }

  return (Object.keys(categoryLabels) as RiskCategoryKey[]).map((key) => {
    const score = clamp(scores[key] ?? scoreFromFindingCategory(key, findings));
    const tags = evidenceTagsFor(key, score);
    return {
      key,
      label: categoryLabels[key],
      score,
      reason:
        score >= 70
          ? `Strong ${categoryLabels[key].toLowerCase()} signals detected.`
          : score >= 40
            ? `Some ${categoryLabels[key].toLowerCase()} signals detected.`
            : score >= 20
              ? `Low-level ${categoryLabels[key].toLowerCase()} signals detected.`
              : "No major risk found in available checks.",
      evidenceTags: tags
    };
  });
}

export function buildSummary(result: Pick<DeepScanResult, "riskScore" | "verdict" | "confidence" | "findings">) {
  const top = result.findings
    .slice()
    .sort((a, b) => b.scoreImpact - a.scoreImpact)
    .slice(0, 3)
    .map((finding) => finding.title.toLowerCase());
  if (!top.length) {
    return `No major risk found in available checks. Confidence is ${result.confidence}%, so continue verifying sensitive requests through official sources.`;
  }
  const confidenceNote =
    result.confidence < 55
      ? " Confidence is limited because some checks were unavailable or only limited evidence was available."
      : "";
  return `${result.verdict} result because ${top.join(", ")}. Treat this as risk guidance, not a guarantee.${confidenceNote}`;
}

export function buildRecommendations(input: { scanType: string; riskScore: number; findings: DeepFinding[] }) {
  const base = [
    "Do not enter OTP, UPI PIN, CVV, passwords, or full identity documents into suspicious pages or messages.",
    "Verify requests through official apps, official websites, or phone numbers you found independently.",
    "Use this report as risk guidance, not a guarantee of complete safety."
  ];
  if (input.scanType === "qr" || input.scanType === "upi") {
    return ["Do not open QR payloads or payment intents automatically.", "Never enter UPI PIN to receive money.", "Confirm the receiver name and source before paying.", ...base];
  }
  if (input.scanType === "email" || input.scanType === "email-header") {
    return ["Do not download unexpected attachments.", "Check sender, reply-to, and official domain carefully.", "Visit login/payment pages manually instead of using email links.", ...base];
  }
  if (input.scanType === "pdf" || input.scanType === "office" || input.scanType === "archive") {
    return ["Do not open suspicious attachments on your main device.", "Ask the sender to verify through a trusted channel.", "Scan attachments in an isolated environment before handling them.", ...base];
  }
  if (input.scanType === "binary" || input.scanType === "script") {
    return ["Do not run this file on your main system.", "Use a dedicated malware-analysis sandbox for dynamic behavior checks.", "Delete the file if you did not request it or cannot verify the source.", ...base];
  }
  if (input.riskScore >= 46) {
    return ["Do not log in, pay, download files, or share personal data.", "Close the page/message and report it if it impersonates a brand.", ...base];
  }
  return ["No major risk found in available checks, but do not rely on HTTPS alone.", "Check domain spelling, sender identity, and context before acting.", ...base];
}

export function buildVerdict(score: number) {
  return verdictFromScore(score);
}

function scoreFromFindingCategory(key: RiskCategoryKey, findings: DeepFinding[]) {
  const categoryMatchers: Record<RiskCategoryKey, RegExp> = {
    phishing: /phishing|email|page behavior|url reputation/i,
    malware: /malware|binary|script|clamav|yara|office|pdf|archive/i,
    scam: /message|scam|social|job|shopping/i,
    domainReputation: /domain|ip reputation/i,
    redirect: /redirect|url/i,
    privacy: /privacy|metadata|credential|sensitive/i,
    payment: /payment|upi|card|qr/i,
    brandImpersonation: /brand|impersonation/i,
    fileStructure: /file type|structure/i,
    hiddenContent: /hidden|embedded|archive/i
  };
  return Math.max(0, ...findings.filter((finding) => categoryMatchers[key].test(finding.category) || categoryMatchers[key].test(finding.title)).map((finding) => finding.scoreImpact + 20));
}

function evidenceTagsFor(key: RiskCategoryKey, score: number) {
  if (score <= 20) return ["no-major-signal"];
  const map: Record<RiskCategoryKey, string[]> = {
    phishing: ["login", "sender", "credential"],
    malware: ["signature", "static-analysis", "payload"],
    scam: ["urgency", "reward", "pressure"],
    domainReputation: ["whois", "dns", "reputation"],
    redirect: ["redirect-chain", "shortener", "final-url"],
    privacy: ["metadata", "credentials", "sensitive-fields"],
    payment: ["upi", "card", "collect-request"],
    brandImpersonation: ["brand-word", "domain-mismatch", "lookalike"],
    fileStructure: ["magic-bytes", "extension", "mime"],
    hiddenContent: ["embedded-file", "archive", "steganography"]
  };
  return map[key];
}
