import jsQR from "jsqr";
import sharp from "sharp";
import type { DeepFinding, DeepScanType, InputSummary, RiskCategoryKey } from "./types";
import { addFinding, bumpCategory, printableStrings, safePreview, shannonEntropy, textFromBuffer } from "./utils";

type StaticAnalysisResult = {
  scanType: DeepScanType;
  visibleText: string;
  metadata: Record<string, unknown>;
  findings: DeepFinding[];
  qrPayloads: string[];
  categoryScores: Partial<Record<RiskCategoryKey, number>>;
  confidenceSignals: number;
  confidencePenalties: number;
};

const executableExtensions = new Set([".exe", ".dll", ".msi", ".jar", ".apk", ".dmg", ".iso", ".elf"]);
const scriptExtensions = new Set([".js", ".html", ".htm", ".php", ".py", ".sh", ".bat", ".ps1", ".vbs", ".hta"]);
const officeExtensions = new Set([".doc", ".docx", ".xls", ".xlsx", ".xlsm", ".ppt", ".pptx", ".odt", ".rtf"]);
const archiveExtensions = new Set([".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"]);

export async function analyzeStaticContent(input: {
  buffer: Buffer;
  input: InputSummary;
  scanType?: DeepScanType;
}): Promise<StaticAnalysisResult> {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const metadata: Record<string, unknown> = {};
  const ext = extension(input.input.originalName);
  const detected = input.input.detectedMimeType;
  const scanType = input.scanType && input.scanType !== "file" ? input.scanType : inferScanType(detected, ext);
  let visibleText = "";
  let confidenceSignals = 0;
  let confidencePenalties = 0;
  const qrPayloads: string[] = [];

  if (input.input.extensionMismatch) {
    addFinding(findings, {
      severity: "high",
      category: "File Type",
      title: "File extension does not match detected type",
      description: "The claimed extension/MIME type does not match magic-byte detection. This is common in disguised payloads.",
      source: "LEVEL 2 File Type Verification",
      evidence: `${input.input.originalName} claimed=${input.input.claimedMimeType} detected=${detected}`,
      scoreImpact: 30
    });
    bumpCategory(categoryScores, "fileStructure", 55);
  }

  if (hasDoubleExtension(input.input.originalName)) {
    addFinding(findings, {
      severity: "high",
      category: "File Type",
      title: "Double extension detected",
      description: "The filename uses multiple extensions, which can hide executable content from non-technical users.",
      source: "LEVEL 2 File Type Verification",
      evidence: input.input.originalName,
      scoreImpact: 30
    });
    bumpCategory(categoryScores, "fileStructure", 55);
  }

  if (isExecutableMime(detected) && !executableExtensions.has(ext)) {
    addFinding(findings, {
      severity: "critical",
      category: "File Type",
      title: "Executable content disguised as another file type",
      description: "Magic bytes indicate executable content even though the filename does not clearly identify it as executable.",
      source: "LEVEL 2 File Type Verification",
      evidence: `${input.input.originalName} -> ${detected}`,
      scoreImpact: 60
    });
    bumpCategory(categoryScores, "fileStructure", 80);
    bumpCategory(categoryScores, "malware", 70);
  }

  if (detected.startsWith("image/")) {
    const image = await analyzeImage(input.buffer).catch((error) => ({ error: error instanceof Error ? error.message : "Image analysis failed" }));
    metadata.image = image;
    if ("text" in image && image.text) visibleText += `\n${image.text}`;
    if ("qrPayloads" in image) qrPayloads.push(...image.qrPayloads);
    if ("hasExif" in image && image.hasExif) {
      addFinding(findings, {
        severity: image.hasGpsHint ? "medium" : "low",
        category: "Metadata",
        title: image.hasGpsHint ? "Possible GPS metadata in image" : "EXIF metadata present",
        description: "Image metadata can reveal device, software, timestamp, or location hints. This is privacy-relevant even if not malicious.",
        source: "LEVEL 3 Metadata Extraction",
        evidence: safePreview(JSON.stringify(image), 260),
        scoreImpact: image.hasGpsHint ? 18 : 8
      });
      bumpCategory(categoryScores, "privacy", image.hasGpsHint ? 42 : 24);
    }
    if (qrPayloads.length) {
      addFinding(findings, {
        severity: "medium",
        category: "QR",
        title: "QR/barcode payload decoded safely",
        description: "A QR payload was found and scanned as text. It was not opened or executed.",
        source: "LEVEL 8 QR and Barcode Scanning",
        evidence: safePreview(qrPayloads.join(" | "), 260),
        scoreImpact: qrPayloads.some((payload) => /upi:\/\//i.test(payload)) ? 30 : 12
      });
      bumpCategory(categoryScores, qrPayloads.some((payload) => /upi:\/\//i.test(payload)) ? "payment" : "redirect", 45);
    }
    confidenceSignals += 14;
  }

  if (detected === "application/pdf") {
    const pdf = analyzePdf(input.buffer);
    metadata.pdf = pdf.metadata;
    visibleText += `\n${pdf.text}`;
    findings.push(...pdf.findings);
    Object.entries(pdf.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
    confidenceSignals += 14;
  }

  if (isOfficeDocument(detected, ext)) {
    const office = analyzeOffice(input.buffer, input.input.originalName);
    metadata.office = office.metadata;
    visibleText += `\n${office.text}`;
    findings.push(...office.findings);
    Object.entries(office.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
    confidenceSignals += 12;
  }

  if (isArchive(detected, ext)) {
    const archive = analyzeArchive(input.buffer);
    metadata.archive = archive.metadata;
    findings.push(...archive.findings);
    Object.entries(archive.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
    visibleText += `\n${archive.filenames.join("\n")}`;
    confidenceSignals += 10;
  }

  if (isExecutableMime(detected) || executableExtensions.has(ext)) {
    const binary = analyzeBinary(input.buffer);
    metadata.binary = binary.metadata;
    visibleText += `\n${binary.strings.join("\n")}`;
    findings.push(...binary.findings);
    Object.entries(binary.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
    confidenceSignals += 8;
  }

  if (isScript(detected, ext)) {
    const script = analyzeScript(textFromBuffer(input.buffer));
    visibleText += `\n${script.text}`;
    metadata.script = script.metadata;
    findings.push(...script.findings);
    Object.entries(script.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
    confidenceSignals += 10;
  }

  if (scanType === "email" || scanType === "email-header" || ext === ".eml") {
    const email = analyzeEmail(textFromBuffer(input.buffer));
    visibleText += `\n${email.text}`;
    metadata.email = email.metadata;
    findings.push(...email.findings);
    Object.entries(email.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));
    confidenceSignals += 10;
  }

  const hidden = analyzeHiddenContent(input.buffer, detected, input.input.originalName);
  findings.push(...hidden.findings);
  metadata.hiddenContent = hidden.metadata;
  Object.entries(hidden.categoryScores).forEach(([key, value]) => bumpCategory(categoryScores, key as RiskCategoryKey, value));

  if (!visibleText.trim()) visibleText = textFromBuffer(input.buffer, 120_000);
  if (!visibleText.trim()) confidencePenalties += 8;

  return {
    scanType,
    visibleText: visibleText.slice(0, 120_000),
    metadata,
    findings,
    qrPayloads,
    categoryScores,
    confidenceSignals,
    confidencePenalties
  };
}

export function inferTextScanType(text: string, requested?: DeepScanType): DeepScanType {
  if (requested && requested !== "file") return requested;
  if (/^https?:\/\//i.test(text.trim()) || /(?:[a-z0-9-]+\.)+[a-z]{2,}/i.test(text.trim())) return "url";
  if (/^upi:\/\//i.test(text.trim()) || /\b[\w.\-]{2,256}@[a-z]{2,64}\b/i.test(text)) return "upi";
  if (/^from:|^reply-to:|^return-path:|^dkim-signature:/im.test(text)) return "email-header";
  if (/otp|kyc|account blocked|refund|verify|urgent|password|cvv|upi pin/i.test(text)) return "message";
  return requested ?? "message";
}

function analyzePdf(buffer: Buffer) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const text = textFromBuffer(buffer);
  const lowered = text.toLowerCase();
  const checks: Array<[RegExp, string, string, number, DeepFinding["severity"], RiskCategoryKey]> = [
    [/\/JavaScript|\/JS\b/i, "PDF JavaScript found", "PDF contains JavaScript objects that can be abused for malicious behavior.", 25, "medium", "malware"],
    [/\/OpenAction/i, "PDF OpenAction found", "PDF contains an auto-open action. This can trigger behavior when the file is opened.", 35, "high", "malware"],
    [/\/Launch/i, "PDF Launch action found", "PDF contains a launch action that may start external programs or files.", 45, "critical", "malware"],
    [/\/EmbeddedFile|\/Filespec/i, "PDF embedded file found", "PDF appears to contain embedded files or attachments.", 35, "high", "hiddenContent"],
    [/\/AcroForm|\/XFA/i, "PDF interactive form found", "PDF contains form structures that may request sensitive information.", 18, "medium", "privacy"],
    [/\/Encrypt/i, "Encrypted PDF", "PDF is encrypted or protected, limiting analysis confidence.", 20, "medium", "hiddenContent"],
    [/\/URI/i, "PDF URI actions found", "PDF contains link actions. Extracted URLs are scanned separately where available.", 16, "medium", "phishing"]
  ];
  for (const [pattern, title, description, impact, severity, category] of checks) {
    if (!pattern.test(text)) continue;
    addFinding(findings, { severity, category: "PDF", title, description, source: "LEVEL 10 PDF-Specific Scanning", evidence: title, scoreImpact: impact });
    bumpCategory(categoryScores, category, impact + 25);
  }
  return {
    text: extractReadableText(text),
    metadata: {
      version: text.match(/%PDF-([0-9.]+)/)?.[1] ?? "unknown",
      javascript: /\/JavaScript|\/JS\b/i.test(text),
      openAction: /\/OpenAction/i.test(text),
      launchAction: /\/Launch/i.test(text),
      embeddedFiles: /\/EmbeddedFile|\/Filespec/i.test(text),
      encrypted: /\/Encrypt/i.test(text),
      objectCountHint: (lowered.match(/\bobj\b/g) ?? []).length
    },
    findings,
    categoryScores
  };
}

function analyzeOffice(buffer: Buffer, originalName: string) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const strings = printableStrings(buffer, 4, 1200);
  const text = strings.join("\n");
  const checks: Array<[RegExp, string, string, number, DeepFinding["severity"], RiskCategoryKey]> = [
    [/vbaProject\.bin|macros\/|_VBA_PROJECT|dir\x00/i, "Office macro indicators found", "Document contains VBA/macro structures.", 35, "high", "malware"],
    [/AutoOpen|Auto_Open|Workbook_Open|Document_Open/i, "Auto-open macro keyword found", "Macro-related strings suggest automatic execution when the document opens.", 50, "critical", "malware"],
    [/powershell|cmd\.exe|wscript|shell\.application|createobject|urlmon|winhttp|xmlhttp/i, "Suspicious command or downloader keyword", "Document strings include shell, scripting, or download-related keywords.", 60, "critical", "malware"],
    [/externalLink|TargetMode="External"|attachedTemplate|template\.dotm/i, "External template/link injection hint", "Office document appears to reference an external template or link.", 45, "high", "phishing"],
    [/\bDDE\b|DDEAUTO/i, "DDE link found", "Document contains DDE-related strings that can be abused for command execution.", 35, "high", "malware"],
    [/xl\/worksheets\/sheet\d+\.xml|state="hidden"|veryHidden/i, "Hidden sheet indicators", "Workbook strings suggest hidden sheet content.", 15, "medium", "hiddenContent"]
  ];
  for (const [pattern, title, description, impact, severity, category] of checks) {
    if (!pattern.test(text)) continue;
    addFinding(findings, { severity, category: "Office Document", title, description, source: "LEVEL 11 Office Document Scanning", evidence: title, scoreImpact: impact });
    bumpCategory(categoryScores, category, impact + 25);
  }
  return {
    text,
    metadata: {
      originalName,
      macroHint: /vbaProject\.bin|_VBA_PROJECT|macros\//i.test(text),
      autoOpenHint: /AutoOpen|Auto_Open|Workbook_Open|Document_Open/i.test(text),
      externalTemplateHint: /externalLink|TargetMode="External"|attachedTemplate/i.test(text),
      stringCount: strings.length
    },
    findings,
    categoryScores
  };
}

function analyzeArchive(buffer: Buffer) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const zip = parseZipLocalHeaders(buffer);
  const strings = printableStrings(buffer, 4, 1000);
  const filenames = zip.entries.length ? zip.entries.map((entry) => entry.name) : strings.filter((item) => /\.[a-z0-9]{1,8}$/i.test(item)).slice(0, 100);

  if (zip.encryptedEntries > 0) {
    addFinding(findings, {
      severity: "medium",
      category: "Archive",
      title: "Password-protected or encrypted archive entries",
      description: "Encrypted archives reduce analysis visibility and are often used in malware delivery.",
      source: "LEVEL 12 Archive Scanning",
      evidence: `${zip.encryptedEntries} encrypted entr${zip.encryptedEntries === 1 ? "y" : "ies"}`,
      scoreImpact: 30
    });
    bumpCategory(categoryScores, "hiddenContent", 55);
  }

  if (zip.totalUncompressed > 250 * 1024 * 1024 || zip.entries.length > 2000 || zip.compressionRatio > 120) {
    addFinding(findings, {
      severity: "critical",
      category: "Archive",
      title: "Archive bomb indicators",
      description: "Archive metadata suggests excessive decompressed size, many files, or a very high compression ratio.",
      source: "LEVEL 12 Archive Scanning",
      evidence: `files=${zip.entries.length}, ratio=${zip.compressionRatio}`,
      scoreImpact: 80
    });
    bumpCategory(categoryScores, "malware", 90);
    bumpCategory(categoryScores, "hiddenContent", 90);
  }

  const executableInside = filenames.find((name) => /\.(exe|dll|msi|scr|ps1|bat|vbs|js|jar|apk)$/i.test(name));
  if (executableInside) {
    addFinding(findings, {
      severity: "high",
      category: "Archive",
      title: "Executable or script inside archive",
      description: "Compressed attachments that hide executables or scripts are common in malware and invoice scams.",
      source: "LEVEL 12 Archive Scanning",
      evidence: executableInside,
      scoreImpact: 40
    });
    bumpCategory(categoryScores, "malware", 70);
  }

  const doubleExtension = filenames.find(hasDoubleExtension);
  if (doubleExtension) {
    addFinding(findings, {
      severity: "high",
      category: "Archive",
      title: "Double-extension file inside archive",
      description: "An archived file uses a misleading double extension.",
      source: "LEVEL 12 Archive Scanning",
      evidence: doubleExtension,
      scoreImpact: 35
    });
    bumpCategory(categoryScores, "fileStructure", 65);
  }

  return {
    filenames,
    metadata: {
      fileCountHint: zip.entries.length || filenames.length,
      encryptedEntries: zip.encryptedEntries,
      totalCompressed: zip.totalCompressed,
      totalUncompressed: zip.totalUncompressed,
      compressionRatio: zip.compressionRatio
    },
    findings,
    categoryScores
  };
}

function analyzeBinary(buffer: Buffer) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const strings = printableStrings(buffer, 5, 600);
  const joined = strings.join("\n");
  const entropy = shannonEntropy(buffer.subarray(0, Math.min(buffer.length, 4 * 1024 * 1024)));

  if (entropy > 7.2) {
    addFinding(findings, {
      severity: "medium",
      category: "Binary",
      title: "High entropy binary sections",
      description: "High entropy may indicate packed or encrypted code. This is not proof of malware, but it increases risk.",
      source: "LEVEL 13 Executable and Binary Scanning",
      evidence: entropy.toFixed(2),
      scoreImpact: 25
    });
    bumpCategory(categoryScores, "malware", 50);
  }

  const suspiciousPatterns: Array<[RegExp, string, number]> = [
    [/VirtualAlloc|WriteProcessMemory|CreateRemoteThread|LoadLibrary/i, "Process injection or dynamic loading strings", 35],
    [/powershell|cmd\.exe|wscript|regsvr32|mshta/i, "Command execution strings", 40],
    [/Run\\|CurrentVersion\\Run|Startup|schtasks/i, "Persistence-related strings", 35],
    [/http:\/\/|https:\/\/|\.onion|pastebin|telegram/i, "Network indicators embedded in binary", 25],
    [/REQUEST_INSTALL_PACKAGES|READ_SMS|BIND_ACCESSIBILITY_SERVICE|SYSTEM_ALERT_WINDOW/i, "Dangerous APK permission strings", 35]
  ];
  for (const [pattern, title, impact] of suspiciousPatterns) {
    if (!pattern.test(joined)) continue;
    addFinding(findings, {
      severity: impact >= 40 ? "high" : "medium",
      category: "Binary",
      title,
      description: "Suspicious executable strings were found during static string extraction.",
      source: "LEVEL 13 Executable and Binary Scanning",
      evidence: title,
      scoreImpact: impact
    });
    bumpCategory(categoryScores, "malware", impact + 30);
  }

  return {
    strings,
    metadata: {
      entropy: Number(entropy.toFixed(3)),
      stringCount: strings.length,
      apkPackageHint: joined.match(/package="([^"]+)"/)?.[1] ?? null
    },
    findings,
    categoryScores
  };
}

function analyzeScript(text: string) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const checks: Array<[RegExp, string, string, number, DeepFinding["severity"], RiskCategoryKey]> = [
    [/\beval\s*\(|Function\s*\(|document\.write\s*\(|atob\s*\(/i, "Obfuscated JavaScript pattern", "Script uses dynamic execution or decoding patterns.", 35, "high", "malware"],
    [/powershell(?:\.exe)?\s+.*(?:downloadstring|invoke-webrequest|iwr|curl|wget)/i, "PowerShell download command", "Script contains a download-and-execute style PowerShell command.", 60, "critical", "malware"],
    [/(curl|wget).*(\|\s*(sh|bash)|-o\s+\/tmp|chmod\s+\+x)/i, "Shell download-and-execute logic", "Script appears to download and execute code.", 55, "critical", "malware"],
    [/password|credential|localStorage|document\.cookie|navigator\.sendBeacon/i, "Credential or browser data access pattern", "Script references credentials, cookies, or browser storage.", 45, "high", "privacy"],
    [/location\.href|window\.location|meta http-equiv=.refresh|iframe/i, "Redirect or iframe behavior", "Script or HTML contains redirect/iframe behavior.", 30, "medium", "redirect"]
  ];
  for (const [pattern, title, description, impact, severity, category] of checks) {
    if (!pattern.test(text)) continue;
    addFinding(findings, { severity, category: "Script", title, description, source: "LEVEL 14 Script and Code Scanning", evidence: title, scoreImpact: impact });
    bumpCategory(categoryScores, category, impact + 20);
  }
  return {
    text,
    metadata: {
      length: text.length,
      base64BlobCount: (text.match(/[A-Za-z0-9+/]{80,}={0,2}/g) ?? []).length,
      evalLike: /\beval\s*\(|Function\s*\(/i.test(text)
    },
    findings,
    categoryScores
  };
}

function analyzeEmail(text: string) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const from = text.match(/^from:\s*(.+)$/im)?.[1]?.trim();
  const replyTo = text.match(/^reply-to:\s*(.+)$/im)?.[1]?.trim();
  const returnPath = text.match(/^return-path:\s*(.+)$/im)?.[1]?.trim();
  const fromDomain = from?.match(/@([a-z0-9.-]+\.[a-z]{2,})/i)?.[1]?.toLowerCase();
  const replyDomain = replyTo?.match(/@([a-z0-9.-]+\.[a-z]{2,})/i)?.[1]?.toLowerCase();

  if (fromDomain && replyDomain && fromDomain !== replyDomain) {
    addFinding(findings, {
      severity: "medium",
      category: "Email",
      title: "Sender and reply-to domain mismatch",
      description: "Reply-to mismatch is a common phishing indicator, especially for payment or login requests.",
      source: "LEVEL 15 Email Header Scanning",
      evidence: `${fromDomain} -> ${replyDomain}`,
      scoreImpact: 20
    });
    bumpCategory(categoryScores, "phishing", 45);
  }

  if (/spf=(fail|softfail)|dkim=(fail|none)|dmarc=(fail|none)/i.test(text)) {
    addFinding(findings, {
      severity: "medium",
      category: "Email",
      title: "SPF/DKIM/DMARC failure indicators",
      description: "Email authentication headers contain failure or missing-result indicators.",
      source: "LEVEL 15 Email Header Scanning",
      evidence: "Authentication-Results failure hint",
      scoreImpact: 25
    });
    bumpCategory(categoryScores, "phishing", 55);
  }

  return {
    text,
    metadata: { from: safePreview(from ?? "unknown"), replyTo: safePreview(replyTo ?? "unknown"), returnPath: safePreview(returnPath ?? "unknown") },
    findings,
    categoryScores
  };
}

function analyzeHiddenContent(buffer: Buffer, detectedMime: string, originalName: string) {
  const findings: DeepFinding[] = [];
  const categoryScores: Partial<Record<RiskCategoryKey, number>> = {};
  const text = textFromBuffer(buffer, 600_000);
  const executableOffset = buffer.indexOf(Buffer.from("MZ"));
  const zipOffset = buffer.indexOf(Buffer.from([0x50, 0x4b, 0x03, 0x04]));

  if (!isExecutableMime(detectedMime) && executableOffset > 32) {
    addFinding(findings, {
      severity: "critical",
      category: "Hidden Content",
      title: "Embedded executable signature found",
      description: "Executable magic bytes were found inside another file type.",
      source: "LEVEL 7 Hidden Content Scanning",
      evidence: `${originalName} offset=${executableOffset}`,
      scoreImpact: 40
    });
    bumpCategory(categoryScores, "hiddenContent", 75);
    bumpCategory(categoryScores, "malware", 80);
  }

  if (!isArchive(detectedMime, extension(originalName)) && zipOffset > 64) {
    addFinding(findings, {
      severity: "high",
      category: "Hidden Content",
      title: "Embedded archive signature found",
      description: "Archive magic bytes were found inside another file type.",
      source: "LEVEL 7 Hidden Content Scanning",
      evidence: `${originalName} offset=${zipOffset}`,
      scoreImpact: 35
    });
    bumpCategory(categoryScores, "hiddenContent", 65);
  }

  if (/steg|zsteg|steghide|LSB|hidden payload/i.test(text)) {
    addFinding(findings, {
      severity: "medium",
      category: "Hidden Content",
      title: "Steganography-related indicator",
      description: "Strings or metadata contain steganography-related indicators. This is suspicious but not conclusive.",
      source: "LEVEL 7 Hidden Content Scanning",
      evidence: "steganography keyword",
      scoreImpact: 25
    });
    bumpCategory(categoryScores, "hiddenContent", 45);
  }

  return {
    metadata: { embeddedExecutableOffset: executableOffset > 32 ? executableOffset : null, embeddedArchiveOffset: zipOffset > 64 ? zipOffset : null },
    findings,
    categoryScores
  };
}

async function analyzeImage(buffer: Buffer) {
  const meta = await sharp(buffer, { limitInputPixels: 50_000_000 }).metadata();
  const exifText = meta.exif?.toString("latin1") ?? "";
  const qrPayloads = await decodeQrPayloads(buffer);
  const ocrText = await runOcrIfConfigured(buffer);
  return {
    format: meta.format,
    width: meta.width,
    height: meta.height,
    space: meta.space,
    hasExif: Boolean(meta.exif?.length),
    hasGpsHint: /\bgps\b|gpslatitude|gpslongitude/i.test(exifText),
    softwareHint: exifText.match(/(?:software|creator|producer)\x00?([ -~]{2,80})/i)?.[1]?.trim() ?? null,
    qrPayloads,
    text: ocrText
  };
}

async function decodeQrPayloads(buffer: Buffer) {
  const image = sharp(buffer, { limitInputPixels: 50_000_000 }).ensureAlpha().raw();
  const { data, info } = await image.toBuffer({ resolveWithObject: true });
  const decoded = jsQR(new Uint8ClampedArray(data.buffer, data.byteOffset, data.byteLength), info.width, info.height);
  return decoded?.data ? [decoded.data.trim()] : [];
}

async function runOcrIfConfigured(buffer: Buffer) {
  const googleVisionKey = process.env.GOOGLE_VISION_API_KEY?.trim();
  if (!googleVisionKey) return "";
  try {
    const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${encodeURIComponent(googleVisionKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        requests: [{ image: { content: buffer.toString("base64") }, features: [{ type: "TEXT_DETECTION", maxResults: 1 }] }]
      }),
      signal: AbortSignal.timeout(8500)
    });
    if (!response.ok) return "";
    const body = (await response.json()) as { responses?: Array<{ fullTextAnnotation?: { text?: string }; textAnnotations?: Array<{ description?: string }> }> };
    return (body.responses?.[0]?.fullTextAnnotation?.text ?? body.responses?.[0]?.textAnnotations?.[0]?.description ?? "").trim();
  } catch {
    return "";
  }
}

function extractReadableText(text: string) {
  return text
    .replace(/[^\x09\x0a\x0d\x20-\x7e]+/g, " ")
    .replace(/\s+/g, " ")
    .slice(0, 120_000);
}

function parseZipLocalHeaders(buffer: Buffer) {
  const entries: Array<{ name: string; compressedSize: number; uncompressedSize: number; encrypted: boolean }> = [];
  let offset = 0;
  let totalCompressed = 0;
  let totalUncompressed = 0;
  let encryptedEntries = 0;

  while (offset < buffer.length - 30 && entries.length < 5000) {
    const signatureOffset = buffer.indexOf(Buffer.from([0x50, 0x4b, 0x03, 0x04]), offset);
    if (signatureOffset === -1) break;
    if (signatureOffset + 30 > buffer.length) break;
    const flags = buffer.readUInt16LE(signatureOffset + 6);
    const compressedSize = buffer.readUInt32LE(signatureOffset + 18);
    const uncompressedSize = buffer.readUInt32LE(signatureOffset + 22);
    const nameLength = buffer.readUInt16LE(signatureOffset + 26);
    const extraLength = buffer.readUInt16LE(signatureOffset + 28);
    const nameStart = signatureOffset + 30;
    const nameEnd = nameStart + nameLength;
    if (nameEnd > buffer.length) break;
    const name = buffer.subarray(nameStart, nameEnd).toString("utf8").replace(/\0/g, "");
    const encrypted = Boolean(flags & 1);
    entries.push({ name, compressedSize, uncompressedSize, encrypted });
    totalCompressed += compressedSize;
    totalUncompressed += uncompressedSize;
    if (encrypted) encryptedEntries += 1;
    offset = Math.max(nameEnd + extraLength + compressedSize, signatureOffset + 4);
  }

  return {
    entries,
    encryptedEntries,
    totalCompressed,
    totalUncompressed,
    compressionRatio: totalCompressed ? Math.round((totalUncompressed / totalCompressed) * 10) / 10 : 0
  };
}

function inferScanType(detectedMime: string, ext: string): DeepScanType {
  if (detectedMime.startsWith("image/")) return "image";
  if (detectedMime === "application/pdf") return "pdf";
  if (isOfficeDocument(detectedMime, ext)) return "office";
  if (isArchive(detectedMime, ext)) return "archive";
  if (isExecutableMime(detectedMime) || executableExtensions.has(ext)) return "binary";
  if (isScript(detectedMime, ext)) return "script";
  if (ext === ".eml") return "email-header";
  return "file";
}

function extension(name: string) {
  const match = name.toLowerCase().match(/(\.[a-z0-9]{1,12})$/);
  return match?.[1] ?? "";
}

function hasDoubleExtension(name: string) {
  return /\.(pdf|docx?|xlsx?|pptx?|jpg|jpeg|png|gif|webp|txt)\.(exe|scr|bat|cmd|ps1|vbs|js|jar|apk|msi)$/i.test(name);
}

function isOfficeDocument(mime: string, ext: string) {
  return officeExtensions.has(ext) || /word|excel|powerpoint|officedocument|msword|rtf|opendocument/i.test(mime);
}

function isArchive(mime: string, ext: string) {
  return archiveExtensions.has(ext) || /zip|rar|7z|tar|gzip|compressed|archive/i.test(mime);
}

function isExecutableMime(mime: string) {
  return /msdownload|x-msi|x-elf|mach|android|java-archive|octet-stream/.test(mime);
}

function isScript(mime: string, ext: string) {
  return scriptExtensions.has(ext) || /javascript|html|php|python|shell|powershell|vbscript|x-bat|text\/plain/.test(mime);
}
