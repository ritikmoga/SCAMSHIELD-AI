import { execFile } from "node:child_process";
import path from "node:path";
import { promisify } from "node:util";
import type { ExternalProviderResult } from "./types";
import { provider, safePreview } from "./utils";

const execFileAsync = promisify(execFile);

export async function runClamAvScan(filePath?: string, tempDir?: string): Promise<ExternalProviderResult> {
  if (!filePath || !tempDir) return provider("skipped", "No local file available for ClamAV.", 0);
  if (!activeToolsEnabled()) return provider("skipped", "ClamAV requires SCAMSHIELD_ENABLE_ACTIVE_TOOLS=1.", 0);
  const clamscan = process.env.CLAMSCAN_PATH?.trim() || "clamscan";
  if (!isSafeChildPath(filePath, tempDir)) return provider("error", "Unsafe file path refused before ClamAV execution.", 0);

  try {
    const { stdout, stderr } = await execFileAsync(clamscan, ["--no-summary", filePath], {
      timeout: toolTimeoutMs(),
      maxBuffer: 1024 * 1024
    });
    const output = `${stdout}\n${stderr}`.trim();
    if (/FOUND\b/i.test(output)) {
      return provider("checked", "ClamAV malware signature matched.", 70, { output: safePreview(output, 700) });
    }
    return provider("checked", "No ClamAV signature match found in available checks.", 0, { output: safePreview(output, 700) });
  } catch (error) {
    const anyError = error as { stdout?: string; stderr?: string; code?: number; message?: string };
    const output = `${anyError.stdout ?? ""}\n${anyError.stderr ?? ""}\n${anyError.message ?? ""}`.trim();
    if (/FOUND\b/i.test(output)) return provider("checked", "ClamAV malware signature matched.", 70, { output: safePreview(output, 700) });
    return provider("error", "ClamAV failed safely. File was not marked safe because of this failure.", 0, { output: safePreview(output, 700) });
  }
}

export async function runYaraScan(filePath?: string, tempDir?: string): Promise<ExternalProviderResult> {
  if (!filePath || !tempDir) return provider("skipped", "No local file available for YARA.", 0);
  if (!activeToolsEnabled()) return provider("skipped", "YARA requires SCAMSHIELD_ENABLE_ACTIVE_TOOLS=1.", 0);
  const yara = process.env.YARA_PATH?.trim();
  const rules = process.env.YARA_RULES_PATH?.trim();
  if (!yara || !rules) return provider("not_configured", "YARA_PATH and YARA_RULES_PATH are required.", 0);
  if (!isSafeChildPath(filePath, tempDir)) return provider("error", "Unsafe file path refused before YARA execution.", 0);

  try {
    const { stdout, stderr } = await execFileAsync(yara, ["--no-warnings", rules, filePath], {
      timeout: toolTimeoutMs(),
      maxBuffer: 1024 * 1024
    });
    const output = `${stdout}\n${stderr}`.trim();
    const matches = output.split(/\n+/).filter(Boolean);
    if (matches.length) {
      const malwareLike = matches.some((line) => /malware|trojan|ransom|stealer|loader|critical/i.test(line));
      return provider("checked", `${matches.length} YARA rule match(es).`, malwareLike ? 60 : 30, {
        matches: matches.slice(0, 20).map((line) => safePreview(line, 220))
      });
    }
    return provider("checked", "No YARA rule match found in available checks.", 0);
  } catch (error) {
    const anyError = error as { stdout?: string; stderr?: string; message?: string };
    const output = `${anyError.stdout ?? ""}\n${anyError.stderr ?? ""}\n${anyError.message ?? ""}`.trim();
    const matches = output.split(/\n+/).filter((line) => line && !/error|warning/i.test(line));
    if (matches.length) {
      return provider("checked", `${matches.length} YARA rule match(es).`, 40, {
        matches: matches.slice(0, 20).map((line) => safePreview(line, 220))
      });
    }
    return provider("error", "YARA failed safely. File was not marked safe because of this failure.", 0, { output: safePreview(output, 700) });
  }
}

export async function checkVirusTotalHash(sha256: string): Promise<ExternalProviderResult> {
  if (!sha256) return provider("skipped", "No file hash available for VirusTotal.", 0);
  const apiKey = process.env.VIRUSTOTAL_API_KEY?.trim();
  if (!apiKey) return provider("missing_key", "VIRUSTOTAL_API_KEY is missing. Hash reputation is unavailable.", 0);

  try {
    const response = await fetch(`https://www.virustotal.com/api/v3/files/${encodeURIComponent(sha256)}`, {
      headers: { "x-apikey": apiKey },
      signal: AbortSignal.timeout(7000)
    });
    if (response.status === 404) return provider("checked", "File hash is not known to VirusTotal yet.", 0);
    if (response.status === 429) return provider("rate_limited", "VirusTotal rate limit reached.", 0);
    if (!response.ok) return provider("error", "VirusTotal hash lookup failed safely.", 0);
    const body = (await response.json()) as { data?: { attributes?: { last_analysis_stats?: { malicious?: number; suspicious?: number } } } };
    const stats = body.data?.attributes?.last_analysis_stats;
    const malicious = stats?.malicious ?? 0;
    const suspicious = stats?.suspicious ?? 0;
    const score = malicious >= 5 ? 60 : Math.min(50, malicious * 14 + suspicious * 8);
    return provider("checked", `${malicious} malicious and ${suspicious} suspicious VirusTotal file engine result(s).`, score, { malicious, suspicious });
  } catch {
    return provider("error", "VirusTotal hash lookup timed out or failed safely.", 0);
  }
}

export async function checkGoogleWebRisk(urls: string[]): Promise<ExternalProviderResult> {
  const apiKey = process.env.GOOGLE_WEB_RISK_API_KEY?.trim();
  const targetUrls = urls.filter((url) => /^https?:\/\//i.test(url)).slice(0, 5);
  if (!targetUrls.length) return provider("skipped", "No URL available for Google Web Risk.", 0);
  if (!apiKey) return provider("not_configured", "GOOGLE_WEB_RISK_API_KEY is not configured.", 0);

  try {
    const checks = await Promise.all(
      targetUrls.map(async (url) => {
        const response = await fetch(
          `https://webrisk.googleapis.com/v1/uris:search?key=${encodeURIComponent(apiKey)}&uri=${encodeURIComponent(url)}&threatTypes=MALWARE&threatTypes=SOCIAL_ENGINEERING&threatTypes=UNWANTED_SOFTWARE`,
          { signal: AbortSignal.timeout(6000) }
        );
        if (response.status === 429) return { rateLimited: true };
        if (!response.ok) return { error: true };
        return (await response.json()) as { threat?: { threatTypes?: string[] } };
      })
    );
    if (checks.some((item) => "rateLimited" in item)) return provider("rate_limited", "Google Web Risk rate limit reached.", 0);
    const matches = checks.filter((item) => "threat" in item && item.threat?.threatTypes?.length).length;
    return provider("checked", matches ? `${matches} Google Web Risk threat match(es).` : "No Google Web Risk threat match found.", matches ? 70 : 0, { matches });
  } catch {
    return provider("error", "Google Web Risk timed out or failed safely.", 0);
  }
}

export async function checkAbuseIpDb(ips: string[]): Promise<ExternalProviderResult> {
  const apiKey = process.env.ABUSEIPDB_API_KEY?.trim();
  const target = ips[0];
  if (!target) return provider("skipped", "No IP address available for AbuseIPDB.", 0);
  if (!apiKey) return provider("missing_key", "ABUSEIPDB_API_KEY is missing. IP reputation is unavailable.", 0);

  try {
    const response = await fetch(`https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(target)}&maxAgeInDays=90`, {
      headers: { "Key": apiKey, "Accept": "application/json" },
      signal: AbortSignal.timeout(6000)
    });
    if (response.status === 429) return provider("rate_limited", "AbuseIPDB rate limit reached.", 0);
    if (!response.ok) return provider("error", "AbuseIPDB lookup failed safely.", 0);
    const body = (await response.json()) as { data?: { abuseConfidenceScore?: number; totalReports?: number } };
    const abuseScore = body.data?.abuseConfidenceScore ?? 0;
    const score = abuseScore >= 75 ? 40 : abuseScore >= 40 ? 25 : 0;
    return provider("checked", `AbuseIPDB confidence score: ${abuseScore}.`, score, {
      abuseConfidenceScore: abuseScore,
      totalReports: body.data?.totalReports ?? 0
    });
  } catch {
    return provider("error", "AbuseIPDB timed out or failed safely.", 0);
  }
}

export async function checkUrlhaus(urls: string[]): Promise<ExternalProviderResult> {
  const target = urls.find((url) => /^https?:\/\//i.test(url));
  if (!target) return provider("skipped", "No URL available for URLhaus.", 0);

  try {
    const response = await fetch(process.env.URLHAUS_API_URL?.trim() || "https://urlhaus-api.abuse.ch/v1/url/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ url: target }),
      signal: AbortSignal.timeout(6500)
    });
    if (response.status === 429) return provider("rate_limited", "URLhaus rate limit reached.", 0);
    if (!response.ok) return provider("error", "URLhaus lookup failed safely.", 0);
    const body = (await response.json()) as { query_status?: string; threat?: string; url_status?: string };
    const hit = body.query_status === "ok";
    return provider("checked", hit ? `URLhaus hit: ${body.threat ?? body.url_status ?? "listed"}.` : "No URLhaus hit found.", hit ? 60 : 0, {
      queryStatus: body.query_status,
      threat: body.threat,
      urlStatus: body.url_status
    });
  } catch {
    return provider("error", "URLhaus timed out or failed safely.", 0);
  }
}

function activeToolsEnabled() {
  return process.env.SCAMSHIELD_ENABLE_ACTIVE_TOOLS === "1";
}

function toolTimeoutMs() {
  return Number(process.env.SCAMSHIELD_LOCAL_TOOL_TIMEOUT_MS ?? 12_000);
}

function isSafeChildPath(filePath: string, root: string) {
  const resolvedFile = path.resolve(filePath);
  const resolvedRoot = path.resolve(root);
  return resolvedFile === resolvedRoot || resolvedFile.startsWith(`${resolvedRoot}${path.sep}`);
}
