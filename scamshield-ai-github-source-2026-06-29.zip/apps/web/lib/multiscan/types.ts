export type DeepScanType =
  | "url"
  | "message"
  | "email"
  | "email-header"
  | "upi"
  | "qr"
  | "image"
  | "screenshot"
  | "pdf"
  | "office"
  | "archive"
  | "binary"
  | "script"
  | "phone"
  | "job"
  | "shopping"
  | "social"
  | "file";

export type DeepScanStatus = "completed" | "rejected" | "failed";
export type DeepScanVerdict = "Low Risk" | "Suspicious" | "Risky" | "Dangerous" | "Critical";
export type DeepFindingSeverity = "low" | "medium" | "high" | "critical";
export type IndicatorType = "url" | "domain" | "ip" | "email" | "phone" | "upi" | "hash" | "crypto" | "file";
export type IndicatorReputation = "unknown" | "safe" | "suspicious" | "malicious";
export type TimelineStatus = "success" | "warning" | "error";
export type ExternalStatus = "checked" | "skipped" | "missing_key" | "rate_limited" | "error" | "pending" | "not_configured";

export type DeepScanInputFile = {
  buffer: Buffer;
  originalName: string;
  claimedMimeType?: string;
};

export type DeepScanRequest = {
  scanType?: DeepScanType;
  text?: string;
  url?: string;
  file?: DeepScanInputFile;
  communityReports?: {
    totalReports?: number;
    verifiedReports?: number;
    falsePositiveReviewed?: boolean;
  };
};

export type InputSummary = {
  originalName: string;
  size: number;
  claimedMimeType: string;
  detectedMimeType: string;
  extensionMismatch: boolean;
};

export type Hashes = {
  sha256: string;
  sha1: string;
  md5: string;
  ssdeep: string;
  tlsh: string;
};

export type DeepFinding = {
  severity: DeepFindingSeverity;
  category: string;
  title: string;
  description: string;
  source: string;
  evidence: string;
  scoreImpact: number;
};

export type DeepExtractedIndicator = {
  type: IndicatorType;
  value: string;
  reputation: IndicatorReputation;
  sources: string[];
};

export type ExternalProviderResult = {
  status: ExternalStatus;
  message: string;
  scoreImpact: number;
  checkedAt: string;
  data?: Record<string, unknown>;
};

export type ExternalResults = {
  virusTotal: ExternalProviderResult;
  urlscan: ExternalProviderResult;
  googleWebRisk: ExternalProviderResult;
  safeBrowsing: ExternalProviderResult;
  abuseIPDB: ExternalProviderResult;
  phishTank: ExternalProviderResult;
  openPhish: ExternalProviderResult;
  urlhaus: ExternalProviderResult;
  clamav: ExternalProviderResult;
  yara: ExternalProviderResult;
  sandbox: ExternalProviderResult;
};

export type DeepScanTimelineItem = {
  step: string;
  status: TimelineStatus;
  message: string;
  timeTakenMs: number;
};

export type RiskCategoryKey =
  | "phishing"
  | "malware"
  | "scam"
  | "domainReputation"
  | "redirect"
  | "privacy"
  | "payment"
  | "brandImpersonation"
  | "fileStructure"
  | "hiddenContent";

export type RiskCategoryScore = {
  key: RiskCategoryKey;
  label: string;
  score: number;
  reason: string;
  evidenceTags: string[];
};

export type DeepScanResult = {
  scanId: string;
  scanType: DeepScanType;
  status: DeepScanStatus;
  riskScore: number;
  verdict: DeepScanVerdict;
  confidence: number;
  summary: string;
  input: InputSummary;
  hashes: Hashes;
  findings: DeepFinding[];
  extractedIndicators: DeepExtractedIndicator[];
  metadata: Record<string, unknown>;
  externalResults: ExternalResults;
  recommendations: string[];
  disclaimer: string;
  categoryScores: RiskCategoryScore[];
  scanTimeline: DeepScanTimelineItem[];
};

export type DeepScanWorkingContext = {
  scanId: string;
  startedAt: number;
  tempDir?: string;
  filePath?: string;
  scanType: DeepScanType;
  inputText: string;
  input: InputSummary;
  hashes: Hashes;
  findings: DeepFinding[];
  indicators: DeepExtractedIndicator[];
  metadata: Record<string, unknown>;
  externalResults: ExternalResults;
  timeline: DeepScanTimelineItem[];
  categoryScores: Partial<Record<RiskCategoryKey, number>>;
  confidenceSignals: number;
  confidencePenalties: number;
};
