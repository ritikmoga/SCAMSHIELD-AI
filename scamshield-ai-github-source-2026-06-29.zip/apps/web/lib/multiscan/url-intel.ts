import { analyzePageBehavior } from "@/lib/scanners/pageBehavior";
import { checkDomainReputation } from "@/lib/scanners/domainReputation";
import { checkGoogleSafeBrowsing } from "@/lib/scanners/googleSafeBrowsing";
import { checkUrlscan } from "@/lib/scanners/urlscan";
import { checkVirusTotal } from "@/lib/scanners/virusTotal";
import type { DeepFinding, DeepScanTimelineItem, ExternalResults, RiskCategoryKey } from "./types";
import { addFinding, addTimeline, bumpCategory, provider, safePreview } from "./utils";
import { checkAbuseIpDb, checkGoogleWebRisk, checkUrlhaus } from "./tool-connectors";

type UrlIntelInput = {
  urls: string[];
  domains: string[];
  ips: string[];
  externalResults: ExternalResults;
  findings: DeepFinding[];
  timeline: DeepScanTimelineItem[];
  categoryScores: Partial<Record<RiskCategoryKey, number>>;
  startedAt: number;
};

export async function runUrlIntel(input: UrlIntelInput) {
  const urls = input.urls.filter((url) => /^https?:\/\//i.test(url)).slice(0, 8);
  const primaryUrl = urls[0];
  const primaryDomain = input.domains[0] || hostname(primaryUrl);

  if (!urls.length && !primaryDomain && !input.ips.length) {
    addTimeline(input.timeline, input.startedAt, "URL/domain reputation skipped", "warning", "No URL, domain, or IP indicators were extracted.");
    return { confidenceDelta: -8, redirectChain: [], finalUrl: undefined };
  }

  addTimeline(input.timeline, input.startedAt, "URL indicators prepared", "success", `${urls.length} URL(s), ${input.domains.length} domain(s), and ${input.ips.length} IP(s) queued for reputation checks.`);

  const [safeBrowsing, virusTotal, urlscan, domainReputation, pageBehavior, webRisk, abuseIpDb, urlhaus] = await Promise.all([
    checkGoogleSafeBrowsing(urls),
    checkVirusTotal(urls),
    checkUrlscan(primaryDomain),
    checkDomainReputation(primaryDomain),
    analyzePageBehavior(primaryUrl),
    checkGoogleWebRisk(urls),
    checkAbuseIpDb(input.ips),
    checkUrlhaus(urls)
  ]);

  input.externalResults.safeBrowsing = provider(safeBrowsing.status.status, safeBrowsing.status.message, safeBrowsing.score);
  input.externalResults.virusTotal = provider(virusTotal.status.status, virusTotal.status.message, virusTotal.score);
  input.externalResults.urlscan = provider(urlscan.status.status, urlscan.status.message, urlscan.score);
  input.externalResults.googleWebRisk = webRisk;
  input.externalResults.abuseIPDB = abuseIpDb;
  input.externalResults.urlhaus = urlhaus;

  addTimeline(input.timeline, input.startedAt, "Redirects followed safely", pageBehavior.redirectChain.length > 1 ? "warning" : "success", pageBehavior.redirectChain.length > 1 ? `${pageBehavior.redirectChain.length} redirect hop(s) observed by the backend scanner.` : "No multi-hop redirect chain observed by available checks.");
  addTimeline(input.timeline, input.startedAt, "Threat-intel providers checked", "success", "External providers were checked or recorded as unavailable without marking the target safe.");

  for (const item of [...safeBrowsing.evidence, ...virusTotal.evidence, ...urlscan.evidence, ...domainReputation.evidence, ...pageBehavior.evidence]) {
    if (item.status !== "warning") continue;
    addFinding(input.findings, {
      severity: "medium",
      category: "URL Reputation",
      title: item.label,
      description: "A URL/domain reputation evidence item needs review.",
      source: "LEVEL 5 URL & Domain Reputation Scanning",
      evidence: String(item.value),
      scoreImpact: 10
    });
  }

  if (safeBrowsing.score >= 60 || webRisk.scoreImpact >= 70) {
    addFinding(input.findings, {
      severity: "critical",
      category: "Threat Intelligence",
      title: "Google threat-intelligence match",
      description: "Google reputation services reported a malware/social-engineering style match.",
      source: "LEVEL 17 Threat Intelligence Correlation",
      evidence: `${safeBrowsing.status.message} ${webRisk.message}`,
      scoreImpact: 70
    });
    bumpCategory(input.categoryScores, "phishing", 90);
    bumpCategory(input.categoryScores, "malware", 80);
  }

  if (virusTotal.score >= 40) {
    addFinding(input.findings, {
      severity: "high",
      category: "Threat Intelligence",
      title: "VirusTotal URL detections",
      description: "Multiple VirusTotal engines marked this URL suspicious or malicious.",
      source: "LEVEL 17 Threat Intelligence Correlation",
      evidence: virusTotal.status.message,
      scoreImpact: 60
    });
    bumpCategory(input.categoryScores, "malware", 80);
  }

  if (urlscan.score >= 35) {
    addFinding(input.findings, {
      severity: "high",
      category: "Threat Intelligence",
      title: "urlscan.io suspicious verdict",
      description: "urlscan.io historical verdicts indicate suspicious behavior.",
      source: "LEVEL 17 Threat Intelligence Correlation",
      evidence: urlscan.status.message,
      scoreImpact: 50
    });
    bumpCategory(input.categoryScores, "phishing", 75);
  }

  if (urlhaus.scoreImpact >= 60) {
    addFinding(input.findings, {
      severity: "critical",
      category: "Threat Intelligence",
      title: "URLhaus malware URL hit",
      description: "URLhaus listed the URL as malware-related.",
      source: "LEVEL 17 Threat Intelligence Correlation",
      evidence: urlhaus.message,
      scoreImpact: 60
    });
    bumpCategory(input.categoryScores, "malware", 90);
  }

  if (abuseIpDb.scoreImpact >= 40) {
    addFinding(input.findings, {
      severity: "high",
      category: "IP Reputation",
      title: "AbuseIPDB bad IP reputation",
      description: "The extracted IP address has abuse reports.",
      source: "LEVEL 5 URL & Domain Reputation Scanning",
      evidence: abuseIpDb.message,
      scoreImpact: 40
    });
    bumpCategory(input.categoryScores, "domainReputation", 75);
  }

  if (domainReputation.ageDays !== undefined && domainReputation.ageDays < 30) {
    addFinding(input.findings, {
      severity: "medium",
      category: "Domain Reputation",
      title: "Newly registered domain",
      description: "Newly registered domains are common in phishing campaigns. This signal is not enough on its own.",
      source: "LEVEL 5 URL & Domain Reputation Scanning",
      evidence: `${domainReputation.ageDays} day(s) old`,
      scoreImpact: 25
    });
    bumpCategory(input.categoryScores, "domainReputation", 60);
  }

  if (domainReputation.missingWhois) {
    addFinding(input.findings, {
      severity: "low",
      category: "Domain Reputation",
      title: "WHOIS/domain age unavailable",
      description: "Domain age was unavailable, so confidence is lower.",
      source: "LEVEL 5 URL & Domain Reputation Scanning",
      evidence: "WHOIS unavailable",
      scoreImpact: 10
    });
  }

  if (pageBehavior.redirectChain.length > 2) {
    addFinding(input.findings, {
      severity: "medium",
      category: "Redirect",
      title: "Multiple redirects detected",
      description: "Redirect chains can hide the final destination and are common in phishing infrastructure.",
      source: "LEVEL 5 URL & Domain Reputation Scanning",
      evidence: pageBehavior.redirectChain.map((hop) => safePreview(hop.url, 90)).join(" -> "),
      scoreImpact: 20
    });
    bumpCategory(input.categoryScores, "redirect", 65);
  }

  if (pageBehavior.fieldsDetected.passwordField || pageBehavior.fieldsDetected.otpField || pageBehavior.fieldsDetected.paymentField) {
    addFinding(input.findings, {
      severity: pageBehavior.fieldsDetected.otpField || pageBehavior.fieldsDetected.paymentField ? "high" : "medium",
      category: "Page Behavior",
      title: "Sensitive form fields detected",
      description: "The backend page analysis found login, OTP, password, card, or payment fields.",
      source: "LEVEL 6 Page Behavior Analysis",
      evidence: JSON.stringify(pageBehavior.fieldsDetected),
      scoreImpact: pageBehavior.fieldsDetected.otpField || pageBehavior.fieldsDetected.paymentField ? 45 : 25
    });
    bumpCategory(input.categoryScores, "privacy", 80);
    bumpCategory(input.categoryScores, "phishing", 75);
    if (pageBehavior.fieldsDetected.paymentField) bumpCategory(input.categoryScores, "payment", 80);
  }

  if (pageBehavior.fieldsDetected.autoDownload) {
    addFinding(input.findings, {
      severity: "critical",
      category: "Page Behavior",
      title: "Auto-download indicator",
      description: "The scanned page appears to trigger or advertise automatic download behavior.",
      source: "LEVEL 6 Page Behavior Analysis",
      evidence: "auto-download",
      scoreImpact: 40
    });
    bumpCategory(input.categoryScores, "malware", 85);
  }

  if (pageBehavior.fieldsDetected.hiddenIframe) {
    addFinding(input.findings, {
      severity: "medium",
      category: "Page Behavior",
      title: "Hidden iframe indicator",
      description: "Hidden iframe behavior can indicate tracking, cloaking, or malicious redirection.",
      source: "LEVEL 6 Page Behavior Analysis",
      evidence: "hidden iframe",
      scoreImpact: 20
    });
    bumpCategory(input.categoryScores, "redirect", 55);
  }

  return {
    confidenceDelta:
      safeBrowsing.confidenceDelta +
      virusTotal.confidenceDelta +
      urlscan.confidenceDelta +
      domainReputation.confidenceDelta +
      pageBehavior.confidenceDelta +
      (webRisk.status === "checked" ? 8 : -3) +
      (abuseIpDb.status === "checked" ? 5 : 0) +
      (urlhaus.status === "checked" ? 6 : -2),
    redirectChain: pageBehavior.redirectChain,
    finalUrl: pageBehavior.finalUrl
  };
}

function hostname(url?: string) {
  if (!url) return undefined;
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return undefined;
  }
}
