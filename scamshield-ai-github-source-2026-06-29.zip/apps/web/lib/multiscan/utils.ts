import crypto from "node:crypto";
import path from "node:path";
import type {
  DeepExtractedIndicator,
  DeepFinding,
  DeepFindingSeverity,
  DeepScanTimelineItem,
  DeepScanVerdict,
  ExternalProviderResult,
  ExternalResults,
  Hashes,
  InputSummary,
  RiskCategoryKey,
  TimelineStatus
} from "./types";
import { redactSensitiveSecrets } from "@/lib/redaction";

const mimeByExtension: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".bmp": "image/bmp",
  ".tif": "image/tiff",
  ".tiff": "image/tiff",
  ".pdf": "application/pdf",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".xlsm": "application/vnd.ms-excel.sheet.macroenabled.12",
  ".ppt": "application/vnd.ms-powerpoint",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ".zip": "application/zip",
  ".rar": "application/vnd.rar",
  ".7z": "application/x-7z-compressed",
  ".gz": "application/gzip",
  ".tar": "application/x-tar",
  ".exe": "application/x-msdownload",
  ".dll": "application/x-msdownload",
  ".msi": "application/x-msi",
  ".apk": "application/vnd.android.package-archive",
  ".jar": "application/java-archive",
  ".js": "text/javascript",
  ".html": "text/html",
  ".htm": "text/html",
  ".php": "text/x-php",
  ".py": "text/x-python",
  ".sh": "text/x-shellscript",
  ".ps1": "text/x-powershell",
  ".bat": "application/x-bat",
  ".vbs": "text/vbscript",
  ".eml": "message/rfc822",
  ".txt": "text/plain"
};

export const maxUploadBytes = Number(process.env.SCAMSHIELD_MAX_UPLOAD_MB ?? 25) * 1024 * 1024;

export function newScanId() {
  return `deep-${Date.now()}-${crypto.randomBytes(5).toString("hex")}`;
}

export function sanitizeFilename(name: string) {
  const basename = path.basename(name || "upload.bin");
  const cleaned = basename.replace(/[^\w.\-()+ ]+/g, "_").replace(/\s+/g, "_").slice(0, 140);
  return cleaned || "upload.bin";
}

export function randomStoredFilename(originalName: string) {
  const ext = path.extname(sanitizeFilename(originalName)).slice(0, 16);
  return `${crypto.randomBytes(16).toString("hex")}${ext}`;
}

export function buildInputSummary(params: {
  originalName?: string;
  size: number;
  claimedMimeType?: string;
  detectedMimeType: string;
}): InputSummary {
  const originalName = sanitizeFilename(params.originalName || "text-input.txt");
  const extensionMime = mimeByExtension[path.extname(originalName).toLowerCase()];
  return {
    originalName,
    size: params.size,
    claimedMimeType: params.claimedMimeType || "unknown",
    detectedMimeType: params.detectedMimeType,
    extensionMismatch: Boolean(extensionMime && params.detectedMimeType !== "application/octet-stream" && !mimeMatches(extensionMime, params.detectedMimeType))
  };
}

export function computeHashes(buffer: Buffer): Hashes {
  return {
    sha256: crypto.createHash("sha256").update(buffer).digest("hex"),
    sha1: crypto.createHash("sha1").update(buffer).digest("hex"),
    md5: crypto.createHash("md5").update(buffer).digest("hex"),
    ssdeep: "",
    tlsh: ""
  };
}

export function emptyHashes(): Hashes {
  return { sha256: "", sha1: "", md5: "", ssdeep: "", tlsh: "" };
}

export function normalizeText(input: string) {
  return input.replace(/\r\n/g, "\n").replace(/\u00a0/g, " ").trim();
}

export function safePreview(input: string, maxLength = 220) {
  const redacted = redactSensitiveSecrets(input).replace(/\s+/g, " ").trim();
  return redacted.length > maxLength ? `${redacted.slice(0, maxLength - 1)}...` : redacted;
}

export function textFromBuffer(buffer: Buffer, maxLength = 2_000_000) {
  return buffer.subarray(0, maxLength).toString("latin1").replace(/\u0000/g, "");
}

export function printableStrings(buffer: Buffer, minLength = 5, maxStrings = 400) {
  const text = buffer.toString("latin1");
  const matches = text.match(new RegExp(`[\\x20-\\x7E]{${minLength},}`, "g")) ?? [];
  return matches.slice(0, maxStrings);
}

export function shannonEntropy(buffer: Buffer) {
  if (!buffer.length) return 0;
  const counts = new Array<number>(256).fill(0);
  for (const byte of buffer) counts[byte] = (counts[byte] ?? 0) + 1;
  return counts.reduce((sum, count) => {
    if (!count) return sum;
    const p = count / buffer.length;
    return sum - p * Math.log2(p);
  }, 0);
}

export function detectMime(buffer: Buffer, originalName = "") {
  if (startsWith(buffer, [0x25, 0x50, 0x44, 0x46])) return "application/pdf";
  if (startsWith(buffer, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return "image/png";
  if (startsWith(buffer, [0xff, 0xd8, 0xff])) return "image/jpeg";
  if (startsWith(buffer, [0x47, 0x49, 0x46, 0x38])) return "image/gif";
  if (startsWith(buffer, [0x42, 0x4d])) return "image/bmp";
  if (buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (startsWith(buffer, [0x49, 0x49, 0x2a, 0x00]) || startsWith(buffer, [0x4d, 0x4d, 0x00, 0x2a])) return "image/tiff";
  if (startsWith(buffer, [0x50, 0x4b, 0x03, 0x04]) || startsWith(buffer, [0x50, 0x4b, 0x05, 0x06]) || startsWith(buffer, [0x50, 0x4b, 0x07, 0x08])) {
    return zipMimeFromExtension(originalName);
  }
  if (startsWith(buffer, [0x52, 0x61, 0x72, 0x21])) return "application/vnd.rar";
  if (startsWith(buffer, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c])) return "application/x-7z-compressed";
  if (startsWith(buffer, [0x1f, 0x8b])) return "application/gzip";
  if (startsWith(buffer, [0x4d, 0x5a])) return "application/x-msdownload";
  if (startsWith(buffer, [0x7f, 0x45, 0x4c, 0x46])) return "application/x-elf";
  if (isMachO(buffer)) return "application/x-mach-binary";
  const ext = path.extname(originalName).toLowerCase();
  if (mimeByExtension[ext]) return mimeByExtension[ext];
  if (looksLikeText(buffer)) return "text/plain";
  return "application/octet-stream";
}

export function addFinding(
  findings: DeepFinding[],
  input: {
    severity: DeepFindingSeverity;
    category: string;
    title: string;
    description: string;
    source: string;
    evidence?: string;
    scoreImpact: number;
  }
) {
  findings.push({
    severity: input.severity,
    category: input.category,
    title: input.title,
    description: input.description,
    source: input.source,
    evidence: safePreview(input.evidence ?? input.title, 260),
    scoreImpact: clamp(input.scoreImpact)
  });
}

export function addTimeline(timeline: DeepScanTimelineItem[], startedAt: number, step: string, status: TimelineStatus, message: string) {
  timeline.push({
    step,
    status,
    message,
    timeTakenMs: Math.max(0, Math.round(performance.now() - startedAt))
  });
}

export function defaultExternalResults(): ExternalResults {
  return {
    virusTotal: provider("skipped", "Not checked yet.", 0),
    urlscan: provider("skipped", "Not checked yet.", 0),
    googleWebRisk: provider("not_configured", "Google Web Risk is optional and not configured.", 0),
    safeBrowsing: provider("skipped", "Not checked yet.", 0),
    abuseIPDB: provider("skipped", "Not checked yet.", 0),
    phishTank: provider("not_configured", "PhishTank checking requires a configured feed/API.", 0),
    openPhish: provider("not_configured", "OpenPhish checking requires a configured feed.", 0),
    urlhaus: provider("skipped", "Not checked yet.", 0),
    clamav: provider("skipped", "Local ClamAV did not run.", 0),
    yara: provider("skipped", "Local YARA did not run.", 0),
    sandbox: provider("not_configured", "Dynamic sandbox integrations are prepared but not executed on the main server.", 0)
  };
}

export function provider(status: ExternalProviderResult["status"], message: string, scoreImpact: number, data?: Record<string, unknown>): ExternalProviderResult {
  return {
    status,
    message,
    scoreImpact: clamp(scoreImpact),
    checkedAt: new Date().toISOString(),
    data
  };
}

export function uniqueIndicators(indicators: DeepExtractedIndicator[]) {
  const seen = new Set<string>();
  const result: DeepExtractedIndicator[] = [];
  for (const indicator of indicators) {
    const key = `${indicator.type}:${indicator.value.toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(indicator);
  }
  return result.slice(0, 300);
}

export function clamp(value: number) {
  return Math.max(0, Math.min(100, Math.round(Number.isFinite(value) ? value : 0)));
}

export function verdictFromScore(score: number): DeepScanVerdict {
  if (score >= 91) return "Critical";
  if (score >= 71) return "Dangerous";
  if (score >= 46) return "Risky";
  if (score >= 21) return "Suspicious";
  return "Low Risk";
}

export function bumpCategory(scores: Partial<Record<RiskCategoryKey, number>>, key: RiskCategoryKey, score: number) {
  scores[key] = Math.max(scores[key] ?? 0, clamp(score));
}

function startsWith(buffer: Buffer, bytes: number[]) {
  if (buffer.length < bytes.length) return false;
  return bytes.every((byte, index) => buffer[index] === byte);
}

function mimeMatches(expected: string, detected: string) {
  if (expected === detected) return true;
  if (expected.startsWith("image/") && detected.startsWith("image/")) return expected === detected;
  if (expected.includes("officedocument") && detected === "application/zip") return true;
  if (expected === "application/java-archive" && detected === "application/zip") return true;
  return false;
}

function zipMimeFromExtension(originalName: string) {
  const ext = path.extname(originalName).toLowerCase();
  if (ext === ".docx") return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  if (ext === ".xlsx") return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (ext === ".xlsm") return "application/vnd.ms-excel.sheet.macroenabled.12";
  if (ext === ".pptx") return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
  if (ext === ".apk") return "application/vnd.android.package-archive";
  if (ext === ".jar") return "application/java-archive";
  return "application/zip";
}

function looksLikeText(buffer: Buffer) {
  const sample = buffer.subarray(0, Math.min(buffer.length, 4096));
  if (!sample.length) return true;
  const printable = sample.filter((byte) => byte === 9 || byte === 10 || byte === 13 || (byte >= 32 && byte <= 126)).length;
  return printable / sample.length > 0.88;
}

function isMachO(buffer: Buffer) {
  const hex = buffer.subarray(0, 4).toString("hex");
  return ["feedface", "feedfacf", "cefaedfe", "cffaedfe", "cafebabe"].includes(hex);
}
