export function redactSensitiveSecrets(input: string) {
  return input
    .replace(/\b(?:otp|one[-\s]?time password|verification code)\s*[:=-]?\s*\d{4,8}\b/gi, "[REDACTED_OTP]")
    .replace(/\b\d{6}\b/g, "[REDACTED_OTP_OR_CODE]")
    .replace(/\b(?:cvv|cvc)\s*[:=-]?\s*\d{3,4}\b/gi, "[REDACTED_CVV]")
    .replace(/\b(?:upi\s*)?pin\s*[:=-]?\s*\d{4,6}\b/gi, "[REDACTED_UPI_PIN]")
    .replace(/\b(?:password|passcode|pwd)\s*[:=-]?\s*\S+/gi, "[REDACTED_PASSWORD]")
    .replace(/\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g, "[REDACTED_ID_NUMBER]")
    .replace(/\b(?:\d[ -]?){13,19}\b/g, "[REDACTED_CARD_NUMBER]")
    .replace(/\b[A-Z]{5}\d{4}[A-Z]\b/gi, "[REDACTED_PAN]")
    .replace(/\b([A-Z0-9._%+-])[A-Z0-9._%+-]*(@[A-Z0-9.-]+\.[A-Z]{2,})\b/gi, "$1***$2")
    .slice(0, 500);
}

export function buildSafePreview(input: string, maxLength = 220) {
  const redacted = redactSensitiveSecrets(input).replace(/\s+/g, " ").trim();
  return redacted.length > maxLength ? `${redacted.slice(0, maxLength - 1)}...` : redacted;
}
