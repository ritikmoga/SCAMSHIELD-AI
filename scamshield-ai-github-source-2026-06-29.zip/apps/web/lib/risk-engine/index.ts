import type { ScanType } from "@scamshield/shared";
import { getRiskLevel } from "@scamshield/shared";
import { extractIndicators, normalizeInput, type ExtractedIndicators } from "@/lib/indicators";
import { buildSafePreview, redactSensitiveSecrets } from "@/lib/redaction";
import type { ConfidenceLabel, RiskFlag, ScanResult, ScanVerdict, UnifiedScanResult } from "./types";

export type { ConfidenceLabel, RiskFlag, ScanResult, ScanVerdict, UnifiedScanResult } from "./types";

export function runHeuristicChecks(input: string, typeOrIndicators: ScanType | ExtractedIndicators = "message", maybeIndicators?: ExtractedIndicators) {
  const type = typeof typeOrIndicators === "string" ? typeOrIndicators : "message";
  const indicators = typeof typeOrIndicators === "string" ? maybeIndicators ?? extractIndicators(input) : typeOrIndicators;
  const lower = input.toLowerCase();
  const flags: RiskFlag[] = [];

  addFlag(flags, /\botp\b|one[-\s]?time password|verification code|share.*code|ओटीपी|कोड/i, "Requests OTP or verification code", "critical", 34, lower);
  addFlag(flags, /\bcvv\b|card number|debit card|credit card/i, "Requests card details or CVV", "critical", 34, lower);
  addFlag(flags, /upi\s*pin|enter.*pin|pin डाल|collect request/i, "Mentions UPI PIN or collect request", "critical", 38, lower);
  addFlag(flags, /password|passcode|login credential|recovery code/i, "Requests passwords or account recovery secrets", "critical", 34, lower);
  addFlag(flags, /expires today|account.*blocked|limited time|urgent|immediately|last chance|within \d+ (?:min|minutes|hours)/i, "Uses urgency or account-block pressure", "high", 24, lower);
  addFlag(flags, /refund|cashback|prize|lottery|bonus|free gift|claim reward/i, "Promises refund, reward, or prize", "high", 22, lower);
  addFlag(flags, /download.*apk|install.*app|anydesk|teamviewer|screen share|remote access/i, "Pushes app install or remote access", "critical", 36, lower);
  addFlag(flags, /registration fee|security deposit|processing fee|interview.*fee|pay.*before.*interview/i, "Job offer asks for a fee or deposit", "critical", 36, lower);
  addFlag(flags, /customer care|helpline|support number|call.*now/i, "Unknown customer-care framing", "medium", 16, lower);
  addFlag(flags, /aadhaar|pan card|passport|full identity|date of birth|mother'?s maiden/i, "Requests sensitive identity details", "high", 28, lower);

  if (indicators.urls.some((url) => /bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|cutt\.ly|shorturl|rebrand\.ly/i.test(url))) {
    flags.push(flag("shortened-url", "Shortened URL hides the final destination", "medium", 18, indicators.urls[0]));
  }

  if (indicators.urls.some((url) => !/^https:\/\//i.test(url) && /^http:\/\//i.test(url))) {
    flags.push(flag("http-url", "Link does not use HTTPS", "high", 24, indicators.urls.find((url) => /^http:\/\//i.test(url))));
  }

  for (const domain of indicators.domains) {
    if (/(paytm|phonepe|gpay|sbi|hdfc|icici|axis|amazon|flipkart|whatsapp|telegram)/i.test(domain) && !isLikelyOfficialDomain(domain)) {
      flags.push(flag("brand-domain-mismatch", "Possible brand/domain impersonation", "critical", 40, domain));
    }
    if (/-secure|-verify|-kyc|login-|support-|refund-|gift|prize/i.test(domain)) {
      flags.push(flag("trust-lure-domain", "Domain uses trust or recovery lure words", "high", 26, domain));
    }
  }

  if ((type === "upi" || type === "qr") && /upi:\/\/pay/i.test(input) && /collect|refund|am=|pa=/i.test(input)) {
    flags.push(flag("qr-payment-collect", "QR payload contains payment or collect intent", "critical", 42, "upi://pay"));
  }

  if (type === "email" && /reply-to:.*@(gmail|yahoo|outlook|hotmail)\./i.test(input)) {
    flags.push(flag("free-mail-replyto", "Business-looking email replies to a free mailbox", "medium", 18, "Reply-To"));
  }

  if ((type === "phone" || indicators.phoneNumbers.length > 0) && /anydesk|otp|bank|customer care|refund/i.test(lower)) {
    flags.push(flag("risky-phone-script", "Phone number appears with risky support or payment script", "high", 26, indicators.phoneNumbers[0]));
  }

  return dedupeFlags(flags);
}

export function calculateRiskScore(flags: RiskFlag[], indicators: ExtractedIndicators = emptyIndicators()) {
  const base = flags.reduce((sum, item) => sum + item.points * severityMultiplier(item.severity), 0);
  const indicatorWeight =
    Math.min(indicators.urls.length, 3) * 4 +
    Math.min(indicators.phoneNumbers.length, 3) * 3 +
    Math.min(indicators.upiIds.length, 3) * 5 +
    Math.min(indicators.emails.length, 3) * 2;
  const riskFloor = flags.some((item) => item.severity === "critical") ? 72 : flags.some((item) => item.severity === "high") ? 48 : flags.some((item) => item.severity === "medium") ? 32 : 0;
  return Math.max(riskFloor, clamp(Math.round(base + indicatorWeight)));
}

export function generateHumanExplanation(result: Pick<UnifiedScanResult, "riskScore" | "verdict" | "redFlags" | "extractedIndicators">) {
  if (result.redFlags.length === 0) {
    return "No strong scam pattern was detected. This is risk guidance, not a guarantee, so still verify the sender and avoid sharing sensitive information.";
  }

  const top = result.redFlags
    .slice(0, 3)
    .map((item) => item.label.toLowerCase())
    .join(", ");
  return `This looks ${result.verdict.toLowerCase()} because ScamShield found ${top}. The safest choice is to verify through the official app, website, or phone number instead of trusting the message or link.`;
}

export function returnScanResult(type: ScanType, input: string): UnifiedScanResult {
  const normalized = normalizeInput(input);
  const redacted = redactSensitiveSecrets(normalized);
  const extractedIndicators = extractIndicators(redacted);
  const redFlags = runHeuristicChecks(normalized, type, extractIndicators(normalized)).map((item) => ({
    ...item,
    evidence: item.evidence ? redactSensitiveSecrets(item.evidence) : undefined
  }));
  const riskScore = calculateRiskScore(redFlags, extractedIndicators);
  const riskLevel = getRiskLevel(riskScore);
  const verdict = getVerdict(riskScore);
  const confidenceScore = toConfidenceScore(redFlags, extractedIndicators, normalized.length);
  const confidence = getConfidence(redFlags, extractedIndicators);
  const shell = { riskScore, verdict, redFlags, extractedIndicators };

  return {
    id: `scan-${Date.now()}`,
    type,
    inputPreview: buildSafePreview(normalized),
    riskScore,
    riskLevel,
    verdict,
    confidence,
    confidenceScore,
    redFlags,
    extractedIndicators,
    explanation: generateHumanExplanation(shell),
    saferNextSteps: buildNextSteps(verdict, type),
    rawInputStored: false,
    createdAt: new Date().toISOString()
  };
}

export function createScanResult(inputType: string, input: string): ScanResult {
  return returnScanResult(toScanType(inputType), input);
}

export { normalizeInput, redactSensitiveSecrets, extractIndicators };

function buildNextSteps(verdict: ScanVerdict, type: ScanType) {
  const steps = [
    "Do not share OTP, UPI PIN, CVV, passwords, or full identity documents.",
    "Verify using the official app, website, or a phone number you found independently."
  ];

  if (verdict === "Dangerous") steps.unshift("Stop immediately. Do not click the link, pay money, scan the QR, or install apps.");
  if (verdict === "Suspicious") steps.unshift("Pause before acting. Treat the request as suspicious until verified.");
  if (verdict === "Safe") steps.unshift("No strong scam signs were found, but keep normal caution.");
  if (type === "upi" || type === "qr") steps.push("Remember: receiving money never requires entering a UPI PIN.");
  if (type === "job") steps.push("Do not pay registration, laptop, training, or security fees for a job offer.");
  if (type === "url" || type === "shopping") steps.push("Open the brand by typing its official address yourself, not from the message link.");
  return steps;
}

export function getVerdict(score: number): ScanVerdict {
  if (score >= 70) return "Dangerous";
  if (score >= 35) return "Suspicious";
  return "Safe";
}

export function getConfidence(flags: RiskFlag[], indicators: ExtractedIndicators): ConfidenceLabel {
  const score = clamp(50 + Math.min(flags.length * 7, 34) + Math.min(indicators.urls.length + indicators.upiIds.length + indicators.phoneNumbers.length, 4) * 4);
  if (score >= 75) return "High";
  if (score >= 56) return "Medium";
  return "Low";
}

function toConfidenceScore(flags: RiskFlag[], indicators: ExtractedIndicators, inputLength: number) {
  return clamp(50 + Math.min(flags.length * 7, 34) + Math.min(indicators.urls.length + indicators.upiIds.length + indicators.phoneNumbers.length, 4) * 4 + (inputLength > 80 ? 6 : 0));
}

function addFlag(flags: RiskFlag[], pattern: RegExp, label: string, severity: RiskFlag["severity"], points: number, input: string) {
  const match = input.match(pattern);
  if (match) flags.push(flag(label.toLowerCase().replace(/[^a-z0-9]+/g, "-"), label, severity, points, match[0]));
}

function flag(id: string, label: string, severity: RiskFlag["severity"], points: number, evidence?: string): RiskFlag {
  return { id, label, severity, points, evidence };
}

function dedupeFlags(flags: RiskFlag[]) {
  const seen = new Map<string, RiskFlag>();
  for (const item of flags) {
    const existing = seen.get(item.id);
    if (!existing || existing.points < item.points) seen.set(item.id, item);
  }
  return Array.from(seen.values()).sort((a, b) => b.points - a.points);
}

function severityMultiplier(severity: RiskFlag["severity"]) {
  if (severity === "critical") return 1.15;
  if (severity === "high") return 1;
  if (severity === "medium") return 0.76;
  return 0.45;
}

function clamp(value: number) {
  return Math.max(0, Math.min(100, value));
}

function isLikelyOfficialDomain(hostname: string) {
  return [
    "paytm.com",
    "phonepe.com",
    "google.com",
    "googlepay.com",
    "sbi.co.in",
    "hdfcbank.com",
    "icicibank.com",
    "axisbank.com",
    "amazon.in",
    "amazon.com",
    "flipkart.com",
    "whatsapp.com",
    "telegram.org"
  ].some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
}

function emptyIndicators(): ExtractedIndicators {
  return {
    urls: [],
    domains: [],
    phoneNumbers: [],
    upiIds: [],
    emails: [],
    keywords: []
  };
}

function toScanType(inputType: string): ScanType {
  const allowed: ScanType[] = ["url", "message", "email", "upi", "qr", "screenshot", "phone", "job", "shopping", "social"];
  return allowed.includes(inputType as ScanType) ? (inputType as ScanType) : "message";
}
