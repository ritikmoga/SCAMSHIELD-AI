import type { RiskLevel, ScanType } from "@scamshield/shared";
import type { ExtractedIndicators } from "@/lib/indicators";

export type ScanVerdict = "Safe" | "Suspicious" | "Dangerous";
export type ConfidenceLabel = "Low" | "Medium" | "High";
export type DetailedVerdict = "Safe-looking" | "Low Risk" | "Suspicious" | "High Risk" | "Critical Risk";
export type ApiScanStatusState = "checked" | "skipped" | "missing_key" | "rate_limited" | "error" | "pending";
export type TimelineStatus = "success" | "warning" | "error";
export type RiskCategoryKey =
  | "phishing"
  | "malware"
  | "scam"
  | "domainReputation"
  | "redirect"
  | "privacy"
  | "payment"
  | "brandImpersonation";

export type RiskFlag = {
  id: string;
  label: string;
  severity: "low" | "medium" | "high" | "critical";
  evidence?: string;
  points: number;
};

export type RiskCategoryScore = {
  key: RiskCategoryKey;
  label: string;
  score: number;
  reason: string;
  evidenceTags: string[];
};

export type EvidenceItem = {
  label: string;
  value: string | number | boolean;
  status?: TimelineStatus;
};

export type ScanTimelineItem = {
  step: string;
  status: TimelineStatus;
  message: string;
  durationMs: number;
};

export type ApiScanStatus = {
  provider: string;
  status: ApiScanStatusState;
  message: string;
  scoreImpact: number;
  checkedAt: string;
};

export type RedirectHop = {
  url: string;
  status?: number;
};

export type HttpsInfo = {
  present: boolean;
  encryption: "Yes" | "No" | "Unknown";
  trustLevel: string;
  note: string;
};

export type RiskScoreFormula = {
  threatIntelligence: number;
  urlDomain: number;
  pageBehavior: number;
  contentSocialEngineering: number;
  communityReports: number;
  weights: {
    threatIntelligence: 0.35;
    urlDomain: 0.2;
    pageBehavior: 0.2;
    contentSocialEngineering: 0.15;
    communityReports: 0.1;
  };
};

export type ScanResult = {
  id: string;
  type: ScanType;
  inputPreview: string;
  riskScore: number;
  riskLevel: RiskLevel;
  verdict: ScanVerdict;
  verdictLabel?: DetailedVerdict;
  confidence: ConfidenceLabel;
  confidenceScore: number;
  mainReason?: string;
  redFlags: RiskFlag[];
  extractedIndicators: ExtractedIndicators;
  categoryScores?: RiskCategoryScore[];
  evidence?: EvidenceItem[];
  scanTimeline?: ScanTimelineItem[];
  apiStatuses?: ApiScanStatus[];
  redirectChain?: RedirectHop[];
  httpsInfo?: HttpsInfo;
  scoreFormula?: RiskScoreFormula;
  technicalDetails?: Record<string, unknown>;
  reportDisclaimer?: string;
  explanation: string;
  saferNextSteps: string[];
  rawInputStored: false;
  createdAt: string;
};

export type UnifiedScanResult = ScanResult;
