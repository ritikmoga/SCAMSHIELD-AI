import type { EvidenceItem } from "@/lib/risk-engine/types";

const suspiciousTlds = new Set(["zip", "mov", "top", "xyz", "click", "cam", "rest", "monster", "bond", "lol"]);

export type DomainReputationResult = {
  score: number;
  ageDays?: number;
  registrar?: string;
  missingWhois: boolean;
  evidence: EvidenceItem[];
  confidenceDelta: number;
};

export async function checkDomainReputation(domain?: string): Promise<DomainReputationResult> {
  if (!domain) {
    return {
      score: 0,
      missingWhois: true,
      evidence: [{ label: "Domain reputation", value: "No domain found", status: "warning" }],
      confidenceDelta: -10
    };
  }

  const heuristicScore = scoreDomainShape(domain);
  const apiKey = process.env.WHOIS_API_KEY?.trim() || process.env.WHOISXML_API_KEY?.trim();
  if (!apiKey) {
    return {
      score: heuristicScore + (suspiciousTlds.has(domain.split(".").pop() ?? "") ? 10 : 0),
      missingWhois: true,
      evidence: [
        { label: "Domain", value: domain, status: "success" },
        { label: "WHOIS/domain age", value: "Unavailable - WHOIS_API_KEY not configured", status: "warning" }
      ],
      confidenceDelta: -8
    };
  }

  try {
    const response = await fetch(`https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=${encodeURIComponent(apiKey)}&domainName=${encodeURIComponent(domain)}&outputFormat=json`, {
      signal: AbortSignal.timeout(5000)
    });
    if (!response.ok) throw new Error("WHOIS failed");
    const body = (await response.json()) as { WhoisRecord?: { createdDateNormalized?: string; registrarName?: string } };
    const createdAt = body.WhoisRecord?.createdDateNormalized;
    const ageDays = createdAt ? Math.floor((Date.now() - new Date(createdAt).getTime()) / 86_400_000) : undefined;
    const ageScore = ageDays !== undefined && ageDays < 30 ? 20 : 0;
    const missingWhois = !createdAt;

    return {
      score: Math.min(100, heuristicScore + ageScore + (missingWhois ? 10 : 0)),
      ageDays,
      registrar: body.WhoisRecord?.registrarName,
      missingWhois,
      evidence: [
        { label: "Domain", value: domain, status: "success" },
        { label: "Domain age", value: ageDays === undefined ? "Unavailable" : `${ageDays} day(s)`, status: ageDays !== undefined && ageDays < 30 ? "warning" : "success" },
        { label: "Registrar", value: body.WhoisRecord?.registrarName ?? "Unavailable", status: body.WhoisRecord?.registrarName ? "success" : "warning" }
      ],
      confidenceDelta: missingWhois ? -4 : 10
    };
  } catch {
    return {
      score: heuristicScore,
      missingWhois: true,
      evidence: [
        { label: "Domain", value: domain, status: "success" },
        { label: "WHOIS/domain age", value: "Lookup failed safely", status: "warning" }
      ],
      confidenceDelta: -8
    };
  }
}

function scoreDomainShape(domain: string) {
  let score = 0;
  const labels = domain.split(".");
  const left = labels[0] ?? "";
  const tld = labels.at(-1) ?? "";
  if ((domain.match(/-/g) ?? []).length >= 3) score += 10;
  if (/[a-z]{8,}\d{3,}|[a-z0-9]{18,}/i.test(left)) score += 10;
  if (suspiciousTlds.has(tld)) score += 10;
  if (/(login|verify|kyc|refund|account|secure|support|gift|prize)/i.test(domain)) score += 15;
  if (/(sbi|hdfc|icici|axis|paytm|phonepe|amazon|flipkart|whatsapp)/i.test(domain) && !isLikelyOfficialDomain(domain)) score += 25;
  return score;
}

function isLikelyOfficialDomain(hostname: string) {
  return [
    "paytm.com",
    "phonepe.com",
    "google.com",
    "googlepay.com",
    "sbi.co.in",
    "hdfcbank.com",
    "icicibank.com",
    "axisbank.com",
    "amazon.in",
    "amazon.com",
    "flipkart.com",
    "whatsapp.com",
    "telegram.org"
  ].some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
}

