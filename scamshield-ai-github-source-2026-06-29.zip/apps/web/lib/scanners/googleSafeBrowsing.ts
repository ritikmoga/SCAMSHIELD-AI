import type { ProviderCheckResult } from "./types";

const endpoint = "https://safebrowsing.googleapis.com/v4/threatMatches:find";

export async function checkGoogleSafeBrowsing(urls: string[]): Promise<ProviderCheckResult> {
  const checkedAt = new Date().toISOString();
  const apiKey = process.env.GOOGLE_SAFE_BROWSING_API_KEY?.trim();
  const targetUrls = urls.filter((url) => /^https?:\/\//i.test(url)).slice(0, 5);

  if (!targetUrls.length) {
    return providerResult("Google Safe Browsing", "skipped", "No URL available for Safe Browsing check.", 0, checkedAt, -4);
  }

  if (!apiKey) {
    return providerResult("Google Safe Browsing", "missing_key", "External API unavailable - result generated with limited confidence.", 0, checkedAt, -12);
  }

  try {
    const response = await fetch(`${endpoint}?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client: { clientId: "scamshield-ai", clientVersion: "1.0.0" },
        threatInfo: {
          threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
          platformTypes: ["ANY_PLATFORM"],
          threatEntryTypes: ["URL"],
          threatEntries: targetUrls.map((url) => ({ url }))
        }
      }),
      signal: AbortSignal.timeout(5000)
    });

    if (response.status === 429) {
      return providerResult("Google Safe Browsing", "rate_limited", "Rate limit reached. Heuristics and other signals still applied.", 0, checkedAt, -10);
    }
    if (!response.ok) {
      return providerResult("Google Safe Browsing", "error", "Safe Browsing check failed safely. It was not treated as safe.", 0, checkedAt, -10);
    }

    const body = (await response.json()) as { matches?: Array<{ threatType?: string }> };
    const matches = body.matches ?? [];
    const score = matches.length ? 60 : 0;
    return {
      status: {
        provider: "Google Safe Browsing",
        status: "checked",
        message: matches.length ? `${matches.length} threat match(es) found.` : "No Safe Browsing threat match found.",
        scoreImpact: score,
        checkedAt
      },
      score,
      evidence: [{ label: "Google Safe Browsing matches", value: matches.length, status: matches.length ? "warning" : "success" }],
      confidenceDelta: 12
    };
  } catch {
    return providerResult("Google Safe Browsing", "error", "Safe Browsing timed out or failed. Verdict uses remaining signals.", 0, checkedAt, -10);
  }
}

function providerResult(provider: string, status: ProviderCheckResult["status"]["status"], message: string, score: number, checkedAt: string, confidenceDelta: number): ProviderCheckResult {
  return {
    status: { provider, status, message, scoreImpact: score, checkedAt },
    score,
    evidence: [{ label: provider, value: message, status: status === "checked" ? "success" : "warning" }],
    confidenceDelta
  };
}

