import type { ScanType } from "@scamshield/shared";
import type { ExtractedIndicators } from "@/lib/indicators";
import { databaseRecords } from "@/lib/mock-intel";
import { runHeuristicChecks } from "@/lib/risk-engine";
import type { RiskCategoryKey } from "@/lib/risk-engine/types";
import type { CommunitySignalSummary, HeuristicScanResult, HeuristicSignal } from "./types";

export function runHeuristicScanner(type: ScanType, input: string, indicators: ExtractedIndicators, community?: CommunitySignalSummary): HeuristicScanResult {
  const lower = input.toLowerCase();
  const legacyFlags = runHeuristicChecks(input, type, indicators);
  const signals: HeuristicSignal[] = legacyFlags.map((flag) => ({
    id: flag.id,
    label: flag.label,
    severity: flag.severity,
    evidence: flag.evidence,
    points: flag.points,
    category: inferCategory(flag.id, flag.label)
  }));

  for (const url of indicators.urls) {
    try {
      const parsed = new URL(/^https?:\/\//i.test(url) ? url : `https://${url}`);
      if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(parsed.hostname)) add(signals, "ip-url", "URL uses an IP address instead of a normal domain", "domainReputation", 20, "high", parsed.hostname);
      if (!/^https:/i.test(parsed.protocol)) add(signals, "not-https", "URL does not use HTTPS", "privacy", 18, "high", parsed.protocol);
      if ((parsed.hostname.match(/-/g) ?? []).length >= 3) add(signals, "many-hyphens", "Domain contains many hyphens", "domainReputation", 10, "medium", parsed.hostname);
      if (/bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|cutt\.ly|shorturl|rebrand\.ly/i.test(parsed.hostname)) add(signals, "shortener", "URL shortener hides the final destination", "redirect", 10, "medium", parsed.hostname);
      if (/login|verify|otp|kyc|refund|account-block|account|secure/i.test(url)) add(signals, "sensitive-url-words", "URL contains login, KYC, refund, or account recovery wording", "phishing", 16, "high", url);
    } catch {
      // Indicator extraction can include loose domains. Invalid URL parsing is ignored safely.
    }
  }

  if (/https/i.test(lower)) add(signals, "https-present-note", "HTTPS may be present, but HTTPS alone does not prove trustworthiness", "privacy", 0, "low", "HTTPS");
  if (/urgent|immediately|last chance|expires today|limited time/i.test(input)) add(signals, "urgency-language", "Urgency or deadline pressure detected", "scam", 10, "medium");
  if (/prize|reward|cashback|refund|lottery|free gift/i.test(input)) add(signals, "reward-lure", "Prize, reward, refund, or cashback lure detected", "scam", 15, "high");
  if (/pay|payment|upi|collect request|card|cvv|pin/i.test(input)) add(signals, "payment-language", "Payment or sensitive payment credential wording detected", "payment", 20, "high");
  if (/registration fee|security deposit|processing fee|training fee|before interview/i.test(input)) add(signals, "job-fee", "Job offer asks for a registration, security, processing, or training fee", "scam", 25, "critical");
  if (/flat\s?\d{2,}%|90% off|clearance sale|free iphone|limited stock/i.test(input)) add(signals, "shopping-discount", "Fake shopping discount pattern detected", "scam", 15, "medium");

  const communityReports = Math.max(countCommunityReports(input, indicators), community?.totalReports ?? 0);
  const verifiedReports = community?.verifiedReports ?? 0;
  if (verifiedReports > 0) add(signals, "community-admin-verified", "Admin-verified community threat report matched", "scam", 70, "critical", `${verifiedReports} verified report(s)`);
  if (communityReports >= 50) add(signals, "community-50", "50+ matching community reports", "scam", 30, "critical", `${communityReports} reports`);
  else if (communityReports >= 20) add(signals, "community-20", "20+ matching community reports", "scam", 20, "high", `${communityReports} reports`);
  else if (communityReports >= 5) add(signals, "community-5", "5+ matching community reports", "scam", 10, "medium", `${communityReports} reports`);

  const categoryAdjustments: Partial<Record<RiskCategoryKey, number>> = {};
  for (const signal of signals) {
    categoryAdjustments[signal.category] = Math.min(100, (categoryAdjustments[signal.category] ?? 0) + signal.points);
  }

  return {
    urlDomainScore: clamp(sumCategory(signals, ["domainReputation", "redirect", "brandImpersonation", "privacy"])),
    contentScore: clamp(sumCategory(signals, ["scam", "payment", "phishing"])),
    communityScore: verifiedReports > 0 ? 70 : communityReports >= 50 ? 30 : communityReports >= 20 ? 20 : communityReports >= 5 ? 10 : 0,
    categoryAdjustments,
    signals: dedupe(signals),
    evidence: [
      { label: "Risk keywords found", value: indicators.keywords.length ? indicators.keywords.join(", ") : "None", status: indicators.keywords.length ? "warning" : "success" },
      { label: "Community reports", value: communityReports, status: communityReports ? "warning" : "success" },
      { label: "Verified community reports", value: verifiedReports, status: verifiedReports ? "warning" : "success" }
    ],
    confidenceDelta: Math.min(18, indicators.urls.length * 4 + indicators.phoneNumbers.length * 3 + indicators.upiIds.length * 4 + legacyFlags.length * 2)
  };
}

function add(signals: HeuristicSignal[], id: string, label: string, category: RiskCategoryKey, points: number, severity: HeuristicSignal["severity"], evidence?: string) {
  signals.push({ id, label, category, points, severity, evidence });
}

function inferCategory(id: string, label: string): RiskCategoryKey {
  const text = `${id} ${label}`.toLowerCase();
  if (/upi|payment|card|cvv|pin|collect/.test(text)) return "payment";
  if (/brand|impersonation/.test(text)) return "brandImpersonation";
  if (/redirect|shortened|shortener/.test(text)) return "redirect";
  if (/domain|url|https|http/.test(text)) return "domainReputation";
  if (/password|otp|login|credential|kyc/.test(text)) return "phishing";
  if (/privacy|identity|aadhaar|document/.test(text)) return "privacy";
  return "scam";
}

function sumCategory(signals: HeuristicSignal[], categories: RiskCategoryKey[]) {
  return signals.filter((signal) => categories.includes(signal.category)).reduce((sum, signal) => sum + signal.points, 0);
}

function countCommunityReports(input: string, indicators: ExtractedIndicators) {
  const haystack = `${input} ${indicators.domains.join(" ")} ${indicators.upiIds.join(" ")} ${indicators.phoneNumbers.join(" ")}`.toLowerCase();
  return databaseRecords
    .filter((record) => haystack.includes(record.value.toLowerCase()) || record.tags.some((tag) => haystack.includes(tag.toLowerCase())))
    .reduce((sum, record) => sum + record.reports, 0);
}

function dedupe(signals: HeuristicSignal[]) {
  const map = new Map<string, HeuristicSignal>();
  for (const signal of signals) {
    const existing = map.get(signal.id);
    if (!existing || existing.points < signal.points) map.set(signal.id, signal);
  }
  return Array.from(map.values()).sort((a, b) => b.points - a.points);
}

function clamp(value: number) {
  return Math.max(0, Math.min(100, Math.round(value)));
}
