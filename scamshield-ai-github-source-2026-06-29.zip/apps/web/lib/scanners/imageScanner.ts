import sharp from "sharp";
import jsQR from "jsqr";
import { createWorker } from "tesseract.js";
import type { ScanType } from "@scamshield/shared";
import { buildSafePreview } from "@/lib/redaction";
import type { EvidenceItem, RiskCategoryKey, ScanTimelineItem } from "@/lib/risk-engine/types";

const allowedImageTypes = new Set(["image/png", "image/jpeg", "image/webp"]);
const maxImageBytes = 8 * 1024 * 1024;

export type ImageScanAnalysis = {
  scanText: string;
  decodedQr?: string;
  qrType?: "URL" | "UPI Payment" | "Text" | "Contact" | "Wi-Fi" | "Unknown";
  ocrText?: string;
  metadata: {
    format?: string;
    width?: number;
    height?: number;
    hasExif: boolean;
    hasGpsHint: boolean;
    orientation?: number;
    sizeBytes: number;
  };
  evidence: EvidenceItem[];
  timeline: ScanTimelineItem[];
  categoryBoosts: Partial<Record<RiskCategoryKey, number>>;
  confidenceDelta: number;
  technicalDetails: Record<string, unknown>;
};

export async function analyzeUploadedImage(file: File, type: ScanType, manualInput = ""): Promise<ImageScanAnalysis> {
  const startedAt = performance.now();
  const timeline: ScanTimelineItem[] = [
    {
      step: "Image received",
      status: "success",
      message: "Uploaded image was accepted for backend-only decoding. Links and payment intents are not opened.",
      durationMs: 0
    }
  ];

  if (!allowedImageTypes.has(file.type)) {
    throw new Error("Only PNG, JPG, and WebP images are supported.");
  }
  if (file.size > maxImageBytes) {
    throw new Error("Image must be 8MB or smaller.");
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const metadata = await readImageMetadata(buffer, file.size);
  timeline.push({
    step: "Image metadata analyzed",
    status: metadata.hasExif ? "warning" : "success",
    message: metadata.hasExif
      ? "Image contains metadata. Metadata can include device or location details, so avoid sharing original files unnecessarily."
      : "No embedded EXIF metadata was detected by available checks.",
    durationMs: elapsed(startedAt)
  });

  const decodedQr = type === "qr" || type === "screenshot" ? await decodeQrPayload(buffer).catch(() => undefined) : undefined;
  if (type === "qr" || decodedQr) {
    timeline.push({
      step: "QR payload decoded",
      status: decodedQr ? "success" : "warning",
      message: decodedQr ? "QR payload was decoded safely without opening the destination." : "No readable QR payload was found in the image.",
      durationMs: elapsed(startedAt)
    });
  }

  const ocrAvailable = isOcrAvailable();
  const ocrText = type === "screenshot" || type === "qr" ? await runOcr(buffer).catch(() => "") : "";
  if (type === "screenshot" || ocrText) {
    timeline.push({
      step: "OCR text extracted",
      status: ocrText ? "success" : ocrAvailable ? "warning" : "warning",
      message: ocrText
        ? "Screenshot text was extracted and sent through the risk engine."
        : ocrAvailable
          ? "OCR could not extract readable text; metadata and manual text are still analyzed."
          : "No production OCR provider is configured. Metadata, QR payload, and manual text were analyzed without opening links.",
      durationMs: elapsed(startedAt)
    });
  }

  const qrType = decodedQr ? classifyQrPayload(decodedQr) : undefined;
  const scanText =
    [manualInput, decodedQr ? `Decoded QR payload (${qrType}): ${decodedQr}` : "", ocrText ? `OCR text: ${ocrText}` : "", metadataSummary(metadata)]
      .filter(Boolean)
      .join("\n\n")
      .trim() || `Image uploaded for ${type} scan. No readable QR payload or OCR text was extracted. ${metadataSummary(metadata)}`;

  const categoryBoosts: Partial<Record<RiskCategoryKey, number>> = {};
  if (metadata.hasExif) categoryBoosts.privacy = Math.max(categoryBoosts.privacy ?? 0, 24);
  if (decodedQr && /^upi:\/\//i.test(decodedQr)) categoryBoosts.payment = Math.max(categoryBoosts.payment ?? 0, 52);
  if (decodedQr && /^https?:\/\//i.test(decodedQr)) categoryBoosts.redirect = Math.max(categoryBoosts.redirect ?? 0, 20);

  return {
    scanText,
    decodedQr,
    qrType,
    ocrText,
    metadata,
    evidence: buildImageEvidence(file, metadata, decodedQr, qrType, ocrText),
    timeline,
    categoryBoosts,
    confidenceDelta: (decodedQr ? 12 : 0) + (ocrText ? 10 : -4) + (metadata.format ? 4 : -4),
    technicalDetails: {
      imageAnalysis: {
        filename: buildSafePreview(file.name, 120),
        mimeType: file.type,
        qrType: qrType ?? "Not detected",
        decodedQrPreview: decodedQr ? buildSafePreview(decodedQr, 220) : null,
        ocrPreview: ocrText ? buildSafePreview(ocrText, 300) : null,
        metadata
      }
    }
  };
}

async function readImageMetadata(buffer: Buffer, sizeBytes: number): Promise<ImageScanAnalysis["metadata"]> {
  const meta = await sharp(buffer, { limitInputPixels: 50_000_000 }).metadata();
  const exifString = meta.exif ? meta.exif.toString("latin1").toLowerCase() : "";
  return {
    format: meta.format,
    width: meta.width,
    height: meta.height,
    hasExif: Boolean(meta.exif?.length),
    hasGpsHint: /\bgps\b|gpslatitude|gpslongitude/.test(exifString),
    orientation: meta.orientation,
    sizeBytes
  };
}

async function decodeQrPayload(buffer: Buffer) {
  const image = sharp(buffer, { limitInputPixels: 50_000_000 }).ensureAlpha().raw();
  const { data, info } = await image.toBuffer({ resolveWithObject: true });
  const decoded = jsQR(new Uint8ClampedArray(data.buffer, data.byteOffset, data.byteLength), info.width, info.height);
  return decoded?.data?.trim() || undefined;
}

async function runOcr(buffer: Buffer) {
  const googleVisionKey = process.env.GOOGLE_VISION_API_KEY?.trim();
  if (googleVisionKey) return withTimeout(runGoogleVisionOcr(buffer, googleVisionKey), 9000);
  if (process.env.VERCEL === "1" && process.env.SCAMSHIELD_ENABLE_TESSERACT_OCR !== "1") return "";
  return withTimeout(runTesseractOcr(buffer), 9000);
}

async function runTesseractOcr(buffer: Buffer) {
  const worker = await createWorker("eng");
  try {
    const result = await worker.recognize(buffer);
    return result.data.text.replace(/\s+\n/g, "\n").trim();
  } finally {
    await worker.terminate().catch(() => undefined);
  }
}

async function runGoogleVisionOcr(buffer: Buffer, apiKey: string) {
  const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      requests: [
        {
          image: { content: buffer.toString("base64") },
          features: [{ type: "TEXT_DETECTION", maxResults: 1 }]
        }
      ]
    }),
    signal: AbortSignal.timeout(8500)
  });
  if (!response.ok) return "";
  const body = (await response.json()) as { responses?: Array<{ fullTextAnnotation?: { text?: string }; textAnnotations?: Array<{ description?: string }> }> };
  return (body.responses?.[0]?.fullTextAnnotation?.text ?? body.responses?.[0]?.textAnnotations?.[0]?.description ?? "").trim();
}

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      setTimeout(() => reject(new Error("OCR timed out")), timeoutMs);
    })
  ]);
}

function isOcrAvailable() {
  return Boolean(process.env.GOOGLE_VISION_API_KEY?.trim() || process.env.SCAMSHIELD_ENABLE_TESSERACT_OCR === "1" || process.env.VERCEL !== "1");
}

function classifyQrPayload(payload: string): ImageScanAnalysis["qrType"] {
  if (/^upi:\/\//i.test(payload)) return "UPI Payment";
  if (/^https?:\/\//i.test(payload)) return "URL";
  if (/^wifi:/i.test(payload)) return "Wi-Fi";
  if (/^mecard:|^begin:vcard/i.test(payload)) return "Contact";
  if (payload.trim()) return "Text";
  return "Unknown";
}

function buildImageEvidence(file: File, metadata: ImageScanAnalysis["metadata"], decodedQr?: string, qrType?: string, ocrText?: string): EvidenceItem[] {
  return [
    { label: "Image file", value: buildSafePreview(file.name, 120), status: "success" },
    { label: "Image MIME type", value: file.type, status: "success" },
    { label: "Image size", value: `${Math.round(file.size / 1024)} KB`, status: file.size > 5 * 1024 * 1024 ? "warning" : "success" },
    { label: "Image dimensions", value: metadata.width && metadata.height ? `${metadata.width} x ${metadata.height}` : "Unknown", status: metadata.width ? "success" : "warning" },
    { label: "EXIF metadata present", value: metadata.hasExif ? "Yes" : "No", status: metadata.hasExif ? "warning" : "success" },
    { label: "GPS metadata hint", value: metadata.hasGpsHint ? "Possible" : "Not detected", status: metadata.hasGpsHint ? "warning" : "success" },
    { label: "Decoded QR type", value: qrType ?? "Not detected", status: decodedQr ? "warning" : "success" },
    { label: "Decoded QR preview", value: decodedQr ? buildSafePreview(decodedQr, 220) : "None", status: decodedQr ? "warning" : "success" },
    { label: "OCR text extracted", value: ocrText ? buildSafePreview(ocrText, 220) : "None", status: ocrText ? "warning" : "success" }
  ];
}

function metadataSummary(metadata: ImageScanAnalysis["metadata"]) {
  return `Image metadata: format=${metadata.format ?? "unknown"}, dimensions=${metadata.width ?? "?"}x${metadata.height ?? "?"}, exif=${metadata.hasExif ? "present" : "not detected"}, gpsHint=${metadata.hasGpsHint ? "possible" : "not detected"}.`;
}

function elapsed(startedAt: number) {
  return Math.max(0, Math.round(performance.now() - startedAt));
}
