import type { PageBehaviorResult } from "./types";

export async function analyzePageBehavior(url?: string): Promise<PageBehaviorResult> {
  const start = performance.now();
  const timeline: PageBehaviorResult["timeline"] = [];

  if (!url || !/^https?:\/\//i.test(url)) {
    return emptyResult([{ step: "Page behavior analyzed", status: "warning", message: "No fetchable URL was available for backend page analysis.", durationMs: 0 }], -8);
  }

  try {
    const redirectChain: PageBehaviorResult["redirectChain"] = [];
    let current = url;
    let html = "";
    let status = 0;

    for (let hop = 0; hop < 4; hop += 1) {
      const hopStart = performance.now();
      const response = await fetch(current, {
        method: "GET",
        redirect: "manual",
        headers: {
          "User-Agent": "ScamShieldAI-RiskScanner/1.0 (+defensive backend scan)",
          "Accept": "text/html,application/xhtml+xml,text/plain;q=0.8,*/*;q=0.2"
        },
        signal: AbortSignal.timeout(6000)
      });
      status = response.status;
      redirectChain.push({ url: current, status });
      const location = response.headers.get("location");
      if (location && status >= 300 && status < 400) {
        current = new URL(location, current).toString();
        timeline.push({ step: "Redirect followed", status: "warning", message: `Redirected to ${safeUrl(current)}`, durationMs: Math.round(performance.now() - hopStart) });
        continue;
      }
      const contentType = response.headers.get("content-type") ?? "";
      if (contentType.includes("text/html") || contentType.includes("text/plain")) {
        html = await response.text();
      }
      break;
    }

    const fields = detectFields(html);
    const score =
      (fields.loginForm ? 15 : 0) +
      (fields.passwordField ? 20 : 0) +
      (fields.otpField ? 25 : 0) +
      (fields.paymentField ? 25 : 0) +
      (fields.autoDownload ? 40 : 0) +
      (fields.hiddenIframe ? 20 : 0) +
      (redirectChain.length > 1 ? 15 : 0) +
      Math.min(20, fields.externalScripts * 3);

    timeline.push({ step: "Page behavior analyzed", status: html ? "success" : "warning", message: html ? "Backend safely analyzed static page markup without executing scripts." : "Page loaded without analyzable HTML content.", durationMs: Math.round(performance.now() - start) });

    return {
      score: Math.min(100, score),
      evidence: [
        { label: "Final URL", value: safeUrl(current), status: "success" },
        { label: "Redirect count", value: Math.max(0, redirectChain.length - 1), status: redirectChain.length > 1 ? "warning" : "success" },
        { label: "Login form found", value: fields.loginForm, status: fields.loginForm ? "warning" : "success" },
        { label: "Password field found", value: fields.passwordField, status: fields.passwordField ? "warning" : "success" },
        { label: "OTP field found", value: fields.otpField, status: fields.otpField ? "warning" : "success" },
        { label: "Payment/card/UPI field found", value: fields.paymentField, status: fields.paymentField ? "warning" : "success" },
        { label: "External scripts", value: fields.externalScripts, status: fields.externalScripts > 4 ? "warning" : "success" }
      ],
      redirectChain,
      finalUrl: current,
      htmlAnalyzed: Boolean(html),
      fieldsDetected: fields,
      timeline,
      confidenceDelta: html ? 16 : -8
    };
  } catch {
    return emptyResult([{ step: "Page behavior analyzed", status: "warning", message: "Page scan timed out or was blocked. Verdict uses available signals with lower confidence.", durationMs: Math.round(performance.now() - start) }], -14);
  }
}

function detectFields(html: string): PageBehaviorResult["fieldsDetected"] {
  const lower = html.toLowerCase();
  const scriptSources = Array.from(html.matchAll(/<script[^>]+src=["']([^"']+)["']/gi)).map((match) => match[1] ?? "");
  return {
    loginForm: /<form[\s\S]{0,2500}(login|sign in|password|otp|account)/i.test(html),
    passwordField: /type=["']password["']|name=["'][^"']*password/i.test(html),
    otpField: /\botp\b|one[-\s]?time|verification code|name=["'][^"']*(otp|code)/i.test(html),
    paymentField: /\b(card|cvv|upi|payment|pay now|debit|credit)\b/i.test(html),
    hiddenIframe: /<iframe[^>]+(?:display:\s*none|visibility:\s*hidden|width=["']?0|height=["']?0)/i.test(html),
    autoDownload: /download\s*=|application\/vnd\.android\.package-archive|\.apk\b|window\.location\s*=|settimeout\([\s\S]{0,120}download/i.test(lower),
    externalScripts: scriptSources.filter((src) => /^https?:\/\//i.test(src)).length
  };
}

function emptyResult(timeline: PageBehaviorResult["timeline"], confidenceDelta: number): PageBehaviorResult {
  return {
    score: 0,
    evidence: [],
    redirectChain: [],
    htmlAnalyzed: false,
    fieldsDetected: {
      loginForm: false,
      passwordField: false,
      otpField: false,
      paymentField: false,
      hiddenIframe: false,
      autoDownload: false,
      externalScripts: 0
    },
    timeline,
    confidenceDelta
  };
}

function safeUrl(url: string) {
  try {
    const parsed = new URL(url);
    parsed.username = "";
    parsed.password = "";
    parsed.search = parsed.search ? "?..." : "";
    return parsed.toString();
  } catch {
    return url;
  }
}

