import type { ScanType } from "@scamshield/shared";
import { getRiskLevel } from "@scamshield/shared";
import { extractIndicators, normalizeInput } from "@/lib/indicators";
import { buildSafePreview, redactSensitiveSecrets } from "@/lib/redaction";
import type {
  ApiScanStatus,
  DetailedVerdict,
  EvidenceItem,
  HttpsInfo,
  RiskCategoryKey,
  RiskCategoryScore,
  RiskFlag,
  RiskScoreFormula,
  ScanResult,
  ScanTimelineItem,
  ScanVerdict
} from "@/lib/risk-engine/types";
import { checkDomainReputation } from "./domainReputation";
import { checkGoogleSafeBrowsing } from "./googleSafeBrowsing";
import { runHeuristicScanner } from "./heuristicScanner";
import { analyzePageBehavior } from "./pageBehavior";
import type { CommunitySignalSummary } from "./types";
import { checkUrlscan } from "./urlscan";
import { checkVirusTotal } from "./virusTotal";

const categoryLabels: Record<RiskCategoryKey, string> = {
  phishing: "Phishing Risk",
  malware: "Malware Risk",
  scam: "Scam / Social Engineering Risk",
  domainReputation: "Domain Reputation Risk",
  redirect: "Redirect Risk",
  privacy: "Privacy / Data Theft Risk",
  payment: "Payment / UPI Risk",
  brandImpersonation: "Brand Impersonation Risk"
};

export async function scanRiskIntelligence(
  inputType: ScanType,
  input: string,
  options: {
    community?: CommunitySignalSummary;
    additionalEvidence?: EvidenceItem[];
    additionalTimeline?: ScanTimelineItem[];
    categoryBoosts?: Partial<Record<RiskCategoryKey, number>>;
    confidenceDelta?: number;
    technicalDetails?: Record<string, unknown>;
  } = {}
): Promise<ScanResult> {
  const startedAt = performance.now();
  const scanId = `scan-${Date.now()}`;
  const createdAt = new Date().toISOString();
  const timeline: ScanTimelineItem[] = [];

  const normalizedInput = normalizeInput(input);
  const sanitizedInput = redactSensitiveSecrets(normalizedInput);
  const indicators = extractIndicators(normalizedInput);
  timeline.push(timelineItem("Input received", "success", "Input was accepted and sensitive preview fields will be redacted.", startedAt));

  const primaryUrl = findPrimaryUrl(inputType, normalizedInput, indicators.urls);
  const primaryDomain = primaryUrl ? safeHostname(primaryUrl) : indicators.domains[0];
  timeline.push(timelineItem("URL normalized", primaryUrl ? "success" : "warning", primaryUrl ? `Primary URL/domain extracted: ${primaryDomain ?? "unknown"}` : "No fetchable URL found; text/indicator checks will be used.", startedAt));

  const httpsInfo = buildHttpsInfo(primaryUrl);
  timeline.push(timelineItem("HTTPS checked", httpsInfo.present ? "success" : primaryUrl ? "warning" : "warning", httpsInfo.present ? "HTTPS is present, but still requires reputation and behavior checks." : "HTTPS is not present or no URL was available.", startedAt));

  const [safeBrowsing, virusTotal, urlscan, domainReputation, pageBehavior] = await Promise.all([
    checkGoogleSafeBrowsing(primaryUrl ? [primaryUrl] : indicators.urls),
    checkVirusTotal(primaryUrl ? [primaryUrl] : indicators.urls),
    checkUrlscan(primaryDomain),
    checkDomainReputation(primaryDomain),
    inputType === "url" || inputType === "shopping" || inputType === "qr" || inputType === "social" ? analyzePageBehavior(primaryUrl) : analyzePageBehavior(undefined)
  ]);

  timeline.push(...pageBehavior.timeline);
  timeline.push(timelineItem("Domain reputation checked", domainReputation.missingWhois ? "warning" : "success", domainReputation.missingWhois ? "Domain reputation used available signals; WHOIS age may be unavailable." : "Domain age and registrar data were checked.", startedAt));
  timeline.push(timelineItem("Threat-intel APIs checked", "success", "Threat-intel providers were checked or recorded as unavailable without marking the target safe.", startedAt));

  const heuristic = runHeuristicScanner(inputType, normalizedInput, indicators, options.community);
  timeline.push(timelineItem("Content and scam language analyzed", heuristic.signals.length ? "warning" : "success", heuristic.signals.length ? `${heuristic.signals.length} risk signal(s) detected in content or structure.` : "No major content risk signals found.", startedAt));
  if (options.additionalTimeline?.length) timeline.push(...options.additionalTimeline);

  const apiStatuses: ApiScanStatus[] = [safeBrowsing.status, virusTotal.status, urlscan.status];
  const threatIntelligenceScore = clamp(Math.max(safeBrowsing.score, virusTotal.score, urlscan.score));
  const urlDomainScore = clamp(Math.max(domainReputation.score, heuristic.urlDomainScore));
  const pageBehaviorScore = clamp(pageBehavior.score);
  const contentSocialEngineeringScore = clamp(heuristic.contentScore);
  const communityReportScore = clamp(heuristic.communityScore);
  const weightedRiskScore = clamp(
    threatIntelligenceScore * 0.35 +
      urlDomainScore * 0.2 +
      pageBehaviorScore * 0.2 +
      contentSocialEngineeringScore * 0.15 +
      communityReportScore * 0.1
  );
  const signalFloor = buildSignalFloor(heuristic.signals);
  const riskScore = clamp(Math.max(weightedRiskScore, signalFloor));
  const scoreFormula: RiskScoreFormula = {
    threatIntelligence: threatIntelligenceScore,
    urlDomain: urlDomainScore,
    pageBehavior: pageBehaviorScore,
    contentSocialEngineering: contentSocialEngineeringScore,
    communityReports: communityReportScore,
    weights: {
      threatIntelligence: 0.35,
      urlDomain: 0.2,
      pageBehavior: 0.2,
      contentSocialEngineering: 0.15,
      communityReports: 0.1
    }
  };

  const categoryScores = buildCategoryScores(heuristic.categoryAdjustments, {
    phishing: Math.max(pageBehavior.fieldsDetected.passwordField ? 40 : 0, pageBehavior.fieldsDetected.otpField ? 45 : 0, options.categoryBoosts?.phishing ?? 0),
    malware: Math.max(safeBrowsing.score, virusTotal.score, pageBehavior.fieldsDetected.autoDownload ? 65 : 0, options.categoryBoosts?.malware ?? 0),
    scam: Math.max(contentSocialEngineeringScore, options.categoryBoosts?.scam ?? 0),
    domainReputation: Math.max(urlDomainScore, options.categoryBoosts?.domainReputation ?? 0),
    redirect: Math.max(pageBehavior.redirectChain.length > 1 ? 65 : 0, heuristic.categoryAdjustments.redirect ?? 0, options.categoryBoosts?.redirect ?? 0),
    privacy: Math.max(pageBehavior.fieldsDetected.passwordField ? 55 : 0, pageBehavior.fieldsDetected.paymentField ? 60 : 0, heuristic.categoryAdjustments.privacy ?? 0, options.categoryBoosts?.privacy ?? 0),
    payment: Math.max(pageBehavior.fieldsDetected.paymentField ? 70 : 0, heuristic.categoryAdjustments.payment ?? 0, options.categoryBoosts?.payment ?? 0),
    brandImpersonation: Math.max(heuristic.categoryAdjustments.brandImpersonation ?? 0, options.categoryBoosts?.brandImpersonation ?? 0)
  });

  const confidenceScore = buildConfidence({
    apiStatuses,
    pageBehaviorConfidence: pageBehavior.confidenceDelta,
    domainConfidence: domainReputation.confidenceDelta,
    heuristicConfidence: heuristic.confidenceDelta,
    hasCommunityReports: communityReportScore > 0,
    hasDomain: Boolean(primaryDomain),
    additionalConfidenceDelta: options.confidenceDelta ?? 0
  });
  const verdictLabel = getDetailedVerdict(riskScore);
  const verdict = toLegacyVerdict(riskScore);
  const mainReason = buildMainReason(categoryScores, heuristic.signals.map((signal) => signal.label));
  const redFlags = heuristic.signals.map(toRiskFlag);
  const evidence = buildEvidence({
    inputType,
    originalUrl: primaryUrl,
    finalUrl: pageBehavior.finalUrl,
    domain: primaryDomain,
    httpsInfo,
    domainReputation,
    pageBehavior,
    providerEvidence: [...safeBrowsing.evidence, ...virusTotal.evidence, ...urlscan.evidence],
    heuristicEvidence: heuristic.evidence,
    additionalEvidence: options.additionalEvidence ?? []
  });

  timeline.push(timelineItem("Risk score generated", "success", `Final weighted risk score: ${riskScore}/100 with ${confidenceScore}% confidence.`, startedAt));
  timeline.push(timelineItem("Report saved", "success", "Result is ready for user review. Raw scan input is not stored by default.", startedAt));

  return {
    id: scanId,
    type: inputType,
    inputPreview: buildSafePreview(sanitizedInput),
    riskScore,
    riskLevel: getRiskLevel(riskScore),
    verdict,
    verdictLabel,
    confidence: confidenceLabel(confidenceScore),
    confidenceScore,
    mainReason,
    redFlags,
    extractedIndicators: extractIndicators(sanitizedInput),
    categoryScores,
    evidence,
    scanTimeline: timeline,
    apiStatuses,
    redirectChain: pageBehavior.redirectChain,
    httpsInfo,
    scoreFormula,
    technicalDetails: {
      inputType,
      domain: primaryDomain ?? null,
      finalUrl: pageBehavior.finalUrl ? safeUrl(pageBehavior.finalUrl) : null,
      fieldsDetected: pageBehavior.fieldsDetected,
      htmlAnalyzed: pageBehavior.htmlAnalyzed,
      weightedFormulaScore: weightedRiskScore,
      signalFloor,
      formula: "ThreatIntel*0.35 + URLDomain*0.20 + PageBehavior*0.20 + Content*0.15 + Community*0.10, with a conservative floor for critical social-engineering evidence.",
      ...(options.technicalDetails ?? {})
    },
    reportDisclaimer:
      "ScamShield AI provides risk analysis based on available data, reputation signals, heuristics, and user reports. It cannot guarantee that a link, message, QR code, email, or number is completely safe or unsafe. Always verify sensitive requests through official sources.",
    explanation: buildExplanation(verdictLabel, mainReason, confidenceScore, apiStatuses),
    saferNextSteps: buildRecommendedActions(inputType, riskScore),
    rawInputStored: false,
    createdAt
  };
}

function buildCategoryScores(adjustments: Partial<Record<RiskCategoryKey, number>>, overrides: Partial<Record<RiskCategoryKey, number>>): RiskCategoryScore[] {
  return (Object.keys(categoryLabels) as RiskCategoryKey[]).map((key) => {
    const score = clamp(Math.max(adjustments[key] ?? 0, overrides[key] ?? 0));
    const tags = evidenceTagsFor(key, score);
    return {
      key,
      label: categoryLabels[key],
      score,
      reason:
        score >= 70
          ? `Strong ${categoryLabels[key].toLowerCase()} signals detected.`
          : score >= 40
            ? `Some ${categoryLabels[key].toLowerCase()} signals detected.`
            : score >= 20
              ? `Low-level ${categoryLabels[key].toLowerCase()} signals detected.`
              : "No major risk found in available checks.",
      evidenceTags: tags
    };
  });
}

function buildEvidence(input: {
  inputType: ScanType;
  originalUrl?: string;
  finalUrl?: string;
  domain?: string;
  httpsInfo: HttpsInfo;
  domainReputation: Awaited<ReturnType<typeof checkDomainReputation>>;
  pageBehavior: Awaited<ReturnType<typeof analyzePageBehavior>>;
  providerEvidence: EvidenceItem[];
  heuristicEvidence: EvidenceItem[];
  additionalEvidence: EvidenceItem[];
}): EvidenceItem[] {
  return [
    { label: "Input type", value: input.inputType, status: "success" },
    { label: "Original URL", value: input.originalUrl ? safeUrl(input.originalUrl) : "Not applicable", status: input.originalUrl ? "success" : "warning" },
    { label: "Final URL", value: input.finalUrl ? safeUrl(input.finalUrl) : "Not available", status: input.finalUrl ? "success" : "warning" },
    { label: "Final domain", value: input.domain ?? "Not available", status: input.domain ? "success" : "warning" },
    { label: "HTTPS present", value: input.httpsInfo.present ? "Yes" : "No / unknown", status: input.httpsInfo.present ? "success" : "warning" },
    ...input.domainReputation.evidence,
    ...input.pageBehavior.evidence,
    ...input.providerEvidence,
    ...input.heuristicEvidence,
    ...input.additionalEvidence
  ];
}

function buildConfidence(input: {
  apiStatuses: ApiScanStatus[];
  pageBehaviorConfidence: number;
  domainConfidence: number;
  heuristicConfidence: number;
  hasCommunityReports: boolean;
  hasDomain: boolean;
  additionalConfidenceDelta: number;
}) {
  const checkedProviders = input.apiStatuses.filter((status) => status.status === "checked").length;
  const failedProviders = input.apiStatuses.filter((status) => ["missing_key", "rate_limited", "error"].includes(status.status)).length;
  return Math.min(
    95,
    clamp(
      42 +
        checkedProviders * 10 -
        failedProviders * 7 +
        input.pageBehaviorConfidence +
        input.domainConfidence +
        input.heuristicConfidence +
        input.additionalConfidenceDelta +
        (input.hasCommunityReports ? 8 : 0) +
        (input.hasDomain ? 6 : -8)
    )
  );
}

function buildMainReason(categories: RiskCategoryScore[], signalLabels: string[]) {
  const topCategories = categories.filter((category) => category.score > 40).sort((a, b) => b.score - a.score).slice(0, 2).map((category) => category.label.replace(" Risk", "").toLowerCase());
  const topSignals = signalLabels.slice(0, 2);
  if (topSignals.length) return [...topSignals, ...topCategories].slice(0, 3).join(" + ");
  if (topCategories.length) return `${topCategories.join(" + ")} signals`;
  return "No major risk found in available checks";
}

function buildExplanation(verdict: DetailedVerdict, mainReason: string, confidenceScore: number, apiStatuses: ApiScanStatus[]) {
  const unavailable = apiStatuses.filter((status) => ["missing_key", "rate_limited", "error"].includes(status.status));
  const uncertainty = confidenceScore < 55 || unavailable.length ? ` Confidence is limited because ${unavailable.length ? "some external checks were unavailable" : "only limited signals were available"}.` : "";
  if (verdict === "Safe-looking" || verdict === "Low Risk") {
    return `No major risk found in available checks. This does not guarantee safety; verify sensitive requests through official sources.${uncertainty}`;
  }
  return `This item is marked ${verdict} because ${mainReason.toLowerCase()}. Avoid entering OTPs, passwords, UPI PINs, card details, or identity documents until verified through an official source.${uncertainty}`;
}

function buildRecommendedActions(type: ScanType, score: number) {
  const risky = score >= 41;
  const base = [
    "Do not share OTP, UPI PIN, CVV, passwords, or full identity documents.",
    "Verify through the official app, official website, or a trusted phone number you found independently.",
    "Use this as risk guidance, not a guarantee of complete safety."
  ];
  if (type === "upi" || type === "qr") {
    return ["Do not scan or pay blindly.", "Check the receiver name carefully.", "Never enter UPI PIN to receive money.", ...base];
  }
  if (type === "email") {
    return ["Do not download unknown attachments.", "Do not click payment or login links from the email.", "Check sender and reply-to domains carefully.", ...base];
  }
  if (type === "job") {
    return ["Do not pay registration, laptop, training, or security fees.", "Check the official company career page.", "Avoid sharing documents before verification.", ...base];
  }
  if (type === "url" || type === "shopping" || type === "social") {
    return risky
      ? ["Do not log in or enter payment details on this page.", "Close the page and type the official website address manually.", "Report the link if it impersonates a brand.", ...base]
      : ["Do not rely on HTTPS alone.", "Check domain spelling and official brand channels before entering information.", ...base];
  }
  if (type === "phone") return ["This number has scam-like reports or wording if shown; do not accuse a real person without verification.", "Avoid sharing codes or payment details on calls.", ...base];
  return base;
}

function buildSignalFloor(signals: Array<{ severity: string; points: number }>) {
  if (signals.some((signal) => signal.severity === "critical" && signal.points >= 34)) return 82;
  if (signals.some((signal) => signal.severity === "critical")) return 72;
  if (signals.some((signal) => signal.severity === "high")) return 62;
  if (signals.some((signal) => signal.severity === "medium")) return 42;
  return 0;
}

function findPrimaryUrl(type: ScanType, input: string, urls: string[]) {
  if (type === "qr" && /^upi:\/\//i.test(input)) return undefined;
  const first = urls[0] ?? (type === "url" || type === "shopping" || type === "social" ? input : undefined);
  if (!first) return undefined;
  try {
    return new URL(/^https?:\/\//i.test(first) ? first : `https://${first}`).toString();
  } catch {
    return undefined;
  }
}

function safeHostname(url: string) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return undefined;
  }
}

function buildHttpsInfo(url?: string): HttpsInfo {
  const present = Boolean(url && /^https:\/\//i.test(url));
  return {
    present,
    encryption: present ? "Yes" : url ? "No" : "Unknown",
    trustLevel: "Still requires reputation and behavior checks",
    note: "HTTPS does not guarantee safety. It only protects the connection between your browser and the website. Scam, phishing, and malware websites can also use HTTPS."
  };
}

function getDetailedVerdict(score: number): DetailedVerdict {
  if (score <= 20) return "Safe-looking";
  if (score <= 40) return "Low Risk";
  if (score <= 60) return "Suspicious";
  if (score <= 80) return "High Risk";
  return "Critical Risk";
}

function toLegacyVerdict(score: number): ScanVerdict {
  if (score >= 61) return "Dangerous";
  if (score >= 41) return "Suspicious";
  return "Safe";
}

function confidenceLabel(score: number) {
  if (score >= 75) return "High";
  if (score >= 55) return "Medium";
  return "Low";
}

function evidenceTagsFor(key: RiskCategoryKey, score: number) {
  if (score <= 20) return ["no-major-signal"];
  const map: Record<RiskCategoryKey, string[]> = {
    phishing: ["login", "otp", "credential"],
    malware: ["threat-intel", "download", "engine-result"],
    scam: ["urgency", "reward", "pressure"],
    domainReputation: ["domain-age", "whois", "domain-shape"],
    redirect: ["redirect-chain", "shortener"],
    privacy: ["sensitive-fields", "identity-data"],
    payment: ["upi", "card", "payment-request"],
    brandImpersonation: ["brand-word", "domain-mismatch"]
  };
  return map[key];
}

function toRiskFlag(signal: { id: string; label: string; severity: RiskFlag["severity"]; points: number; evidence?: string }): RiskFlag {
  return {
    id: signal.id,
    label: signal.label,
    severity: signal.severity,
    points: signal.points,
    evidence: signal.evidence ? redactSensitiveSecrets(signal.evidence) : undefined
  };
}

function timelineItem(step: string, status: ScanTimelineItem["status"], message: string, startedAt: number): ScanTimelineItem {
  return { step, status, message, durationMs: Math.max(0, Math.round(performance.now() - startedAt)) };
}

function safeUrl(url: string) {
  try {
    const parsed = new URL(url);
    parsed.username = "";
    parsed.password = "";
    parsed.search = parsed.search ? "?..." : "";
    return parsed.toString();
  } catch {
    return redactSensitiveSecrets(url);
  }
}

function clamp(value: number) {
  return Math.max(0, Math.min(100, Math.round(value)));
}
