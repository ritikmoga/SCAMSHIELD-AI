import type { ScanType } from "@scamshield/shared";
import type { ExtractedIndicators } from "@/lib/indicators";
import type { ApiScanStatus, EvidenceItem, RedirectHop, RiskCategoryKey, ScanTimelineItem } from "@/lib/risk-engine/types";

export type ScannerContext = {
  scanId: string;
  inputType: ScanType;
  originalInput: string;
  normalizedInput: string;
  sanitizedInput: string;
  indicators: ExtractedIndicators;
  startedAt: number;
};

export type ProviderCheckResult = {
  status: ApiScanStatus;
  score: number;
  evidence: EvidenceItem[];
  confidenceDelta: number;
};

export type PageBehaviorResult = {
  score: number;
  evidence: EvidenceItem[];
  redirectChain: RedirectHop[];
  finalUrl?: string;
  htmlAnalyzed: boolean;
  fieldsDetected: {
    loginForm: boolean;
    passwordField: boolean;
    otpField: boolean;
    paymentField: boolean;
    hiddenIframe: boolean;
    autoDownload: boolean;
    externalScripts: number;
  };
  timeline: ScanTimelineItem[];
  confidenceDelta: number;
};

export type HeuristicSignal = {
  id: string;
  label: string;
  category: RiskCategoryKey;
  points: number;
  severity: "low" | "medium" | "high" | "critical";
  evidence?: string;
};

export type HeuristicScanResult = {
  urlDomainScore: number;
  contentScore: number;
  communityScore: number;
  categoryAdjustments: Partial<Record<RiskCategoryKey, number>>;
  signals: HeuristicSignal[];
  evidence: EvidenceItem[];
  confidenceDelta: number;
};

export type CommunitySignalSummary = {
  totalReports?: number;
  verifiedReports?: number;
  pendingReports?: number;
};
