import type { ProviderCheckResult } from "./types";

export async function checkUrlscan(domain?: string): Promise<ProviderCheckResult> {
  const checkedAt = new Date().toISOString();
  const apiKey = process.env.URLSCAN_API_KEY?.trim();
  if (!domain) return providerResult("urlscan.io", "skipped", "No domain available for urlscan.io lookup.", 0, checkedAt, -3);
  if (!apiKey) return providerResult("urlscan.io", "missing_key", "External API unavailable - result generated with limited confidence.", 0, checkedAt, -10);

  try {
    const response = await fetch(`https://urlscan.io/api/v1/search/?q=domain:${encodeURIComponent(domain)}`, {
      headers: { "api-key": apiKey },
      signal: AbortSignal.timeout(5000)
    });
    if (response.status === 429) return providerResult("urlscan.io", "rate_limited", "Rate limit reached. Heuristics and other signals still applied.", 0, checkedAt, -8);
    if (!response.ok) return providerResult("urlscan.io", "error", "urlscan.io lookup failed safely.", 0, checkedAt, -8);

    const body = (await response.json()) as { total?: number; results?: Array<{ verdicts?: { overall?: { malicious?: boolean; score?: number } } }> };
    const results = body.results ?? [];
    const malicious = results.filter((item) => item.verdicts?.overall?.malicious).length;
    const maxScore = Math.max(0, ...results.map((item) => item.verdicts?.overall?.score ?? 0));
    const score = Math.min(35, malicious * 25 + Math.max(0, maxScore));
    return {
      status: {
        provider: "urlscan.io",
        status: "checked",
        message: `${body.total ?? results.length} historical result(s), ${malicious} malicious verdict(s).`,
        scoreImpact: score,
        checkedAt
      },
      score,
      evidence: [
        { label: "urlscan.io historical results", value: body.total ?? results.length, status: "success" },
        { label: "urlscan.io malicious verdicts", value: malicious, status: malicious ? "warning" : "success" }
      ],
      confidenceDelta: 8
    };
  } catch {
    return providerResult("urlscan.io", "error", "urlscan.io timed out or failed. Verdict uses remaining signals.", 0, checkedAt, -8);
  }
}

function providerResult(provider: string, status: ProviderCheckResult["status"]["status"], message: string, score: number, checkedAt: string, confidenceDelta: number): ProviderCheckResult {
  return {
    status: { provider, status, message, scoreImpact: score, checkedAt },
    score,
    evidence: [{ label: provider, value: message, status: status === "checked" ? "success" : "warning" }],
    confidenceDelta
  };
}

