import type { ProviderCheckResult } from "./types";

export async function checkVirusTotal(urls: string[]): Promise<ProviderCheckResult> {
  const checkedAt = new Date().toISOString();
  const apiKey = process.env.VIRUSTOTAL_API_KEY?.trim();
  const target = urls.find((url) => /^https?:\/\//i.test(url));

  if (!target) return providerResult("VirusTotal", "skipped", "No URL available for VirusTotal lookup.", 0, checkedAt, -4);
  if (!apiKey) return providerResult("VirusTotal", "missing_key", "External API unavailable - result generated with limited confidence.", 0, checkedAt, -12);

  try {
    const id = Buffer.from(target).toString("base64url");
    const response = await fetch(`https://www.virustotal.com/api/v3/urls/${id}`, {
      headers: { "x-apikey": apiKey },
      signal: AbortSignal.timeout(5000)
    });

    if (response.status === 404) return providerResult("VirusTotal", "checked", "URL is not known to VirusTotal yet.", 0, checkedAt, 3);
    if (response.status === 429) return providerResult("VirusTotal", "rate_limited", "Rate limit reached. Heuristics and other signals still applied.", 0, checkedAt, -10);
    if (!response.ok) return providerResult("VirusTotal", "error", "VirusTotal check failed safely. It was not treated as safe.", 0, checkedAt, -10);

    const body = (await response.json()) as { data?: { attributes?: { last_analysis_stats?: { malicious?: number; suspicious?: number } } } };
    const stats = body.data?.attributes?.last_analysis_stats;
    const malicious = stats?.malicious ?? 0;
    const suspicious = stats?.suspicious ?? 0;
    const score = Math.min(40, malicious * 14 + suspicious * 8);
    return {
      status: {
        provider: "VirusTotal",
        status: "checked",
        message: `${malicious} malicious and ${suspicious} suspicious engine result(s).`,
        scoreImpact: score,
        checkedAt
      },
      score,
      evidence: [
        { label: "VirusTotal malicious engines", value: malicious, status: malicious ? "warning" : "success" },
        { label: "VirusTotal suspicious engines", value: suspicious, status: suspicious ? "warning" : "success" }
      ],
      confidenceDelta: 12
    };
  } catch {
    return providerResult("VirusTotal", "error", "VirusTotal timed out or failed. Verdict uses remaining signals.", 0, checkedAt, -10);
  }
}

function providerResult(provider: string, status: ProviderCheckResult["status"]["status"], message: string, score: number, checkedAt: string, confidenceDelta: number): ProviderCheckResult {
  return {
    status: { provider, status, message, scoreImpact: score, checkedAt },
    score,
    evidence: [{ label: provider, value: message, status: status === "checked" ? "success" : "warning" }],
    confidenceDelta
  };
}

