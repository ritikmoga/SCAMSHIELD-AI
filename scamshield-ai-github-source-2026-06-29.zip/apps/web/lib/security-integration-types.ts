export type SecurityIntegrationId =
  | "virustotal"
  | "urlscan"
  | "google-safe-browsing"
  | "abuseipdb"
  | "shodan"
  | "alienvault-otx"
  | "mozilla-observatory"
  | "ssl-labs"
  | "hibp"
  | "malwarebazaar"
  | "whoisxml"
  | "cloudflare-dns"
  | "google-dns"
  | "owasp-zap"
  | "nmap"
  | "nuclei"
  | "clamav"
  | "yara"
  | "trivy"
  | "gitleaks"
  | "semgrep"
  | "mobsf"
  | "wazuh"
  | "exiftool"
  | "pefile"
  | "pdfid"
  | "pdf-parser"
  | "wappalyzer"
  | "phishtank"
  | "cisco-talos"
  | "ibm-xforce"
  | "mxtoolbox"
  | "hybrid-analysis"
  | "cuckoo-sandbox"
  | "joe-sandbox"
  | "anyrun"
  | "securityheaders";

export type SecurityIntegrationCategory =
  | "reputation"
  | "dns"
  | "web"
  | "network"
  | "file"
  | "code"
  | "sandbox"
  | "siem"
  | "mobile"
  | "osint";

export type SecurityIntegrationMode = "api" | "public-api" | "local-cli" | "local-service" | "manual";

export type SecurityIntegrationTargetType = "url" | "domain" | "ip" | "hash" | "email" | "file" | "repository" | "apk";

export type SecurityIntegrationStatus = "ready" | "needs_key" | "needs_service" | "disabled" | "blocked";

export interface SecurityIntegrationDefinition {
  id: SecurityIntegrationId;
  name: string;
  category: SecurityIntegrationCategory;
  mode: SecurityIntegrationMode;
  targetTypes: SecurityIntegrationTargetType[];
  description: string;
  envVars?: string[];
  activeScan?: boolean;
  requiresAuthorization?: boolean;
  runnable: boolean;
  setup: string;
}

export interface SecurityIntegrationStatusItem extends SecurityIntegrationDefinition {
  configured: boolean;
  status: SecurityIntegrationStatus;
  statusLabel: string;
}

export interface SecurityIntegrationRunResult {
  toolId: SecurityIntegrationId;
  toolName: string;
  target: string;
  status: "ok" | "not_configured" | "not_supported" | "blocked" | "error";
  summary: string;
  details: Record<string, unknown>;
  createdAt: string;
}

export const securityIntegrationCatalog: SecurityIntegrationDefinition[] = [
  {
    id: "virustotal",
    name: "VirusTotal",
    category: "reputation",
    mode: "api",
    targetTypes: ["url", "domain", "ip", "hash"],
    envVars: ["VIRUSTOTAL_API_KEY"],
    runnable: true,
    description: "Reputation checks for URLs, domains, IPs, and file hashes.",
    setup: "Add VIRUSTOTAL_API_KEY."
  },
  {
    id: "urlscan",
    name: "urlscan.io",
    category: "web",
    mode: "api",
    targetTypes: ["url", "domain", "ip"],
    envVars: ["URLSCAN_API_KEY"],
    runnable: true,
    description: "Passive URL/domain search and optional submitted browser analysis.",
    setup: "Add URLSCAN_API_KEY. ScamShield uses passive search by default."
  },
  {
    id: "google-safe-browsing",
    name: "Google Safe Browsing",
    category: "reputation",
    mode: "api",
    targetTypes: ["url"],
    envVars: ["GOOGLE_SAFE_BROWSING_API_KEY"],
    runnable: true,
    description: "Checks URLs against Google malware and social-engineering threat lists.",
    setup: "Add GOOGLE_SAFE_BROWSING_API_KEY."
  },
  {
    id: "abuseipdb",
    name: "AbuseIPDB",
    category: "reputation",
    mode: "api",
    targetTypes: ["ip"],
    envVars: ["ABUSEIPDB_API_KEY"],
    runnable: true,
    description: "IP abuse confidence, country, usage type, ISP, and report counts.",
    setup: "Add ABUSEIPDB_API_KEY."
  },
  {
    id: "shodan",
    name: "Shodan",
    category: "network",
    mode: "api",
    targetTypes: ["ip", "domain"],
    envVars: ["SHODAN_API_KEY"],
    runnable: true,
    description: "Passive internet exposure intelligence for public hosts.",
    setup: "Add SHODAN_API_KEY."
  },
  {
    id: "alienvault-otx",
    name: "AlienVault OTX",
    category: "reputation",
    mode: "api",
    targetTypes: ["domain", "ip", "hash", "url"],
    envVars: ["OTX_API_KEY"],
    runnable: true,
    description: "Pulse and indicator reputation from AlienVault Open Threat Exchange.",
    setup: "Add OTX_API_KEY."
  },
  {
    id: "mozilla-observatory",
    name: "Mozilla HTTP Observatory",
    category: "web",
    mode: "public-api",
    targetTypes: ["domain", "url"],
    runnable: true,
    description: "External web security posture scoring for response headers.",
    setup: "No key required."
  },
  {
    id: "ssl-labs",
    name: "SSL Labs",
    category: "web",
    mode: "public-api",
    targetTypes: ["domain", "url"],
    runnable: true,
    description: "TLS/SSL grade and certificate analysis using cache-first checks.",
    setup: "No key required."
  },
  {
    id: "hibp",
    name: "Have I Been Pwned",
    category: "reputation",
    mode: "api",
    targetTypes: ["email"],
    envVars: ["HIBP_API_KEY"],
    runnable: true,
    description: "Checks whether an email appears in known public breaches.",
    setup: "Add HIBP_API_KEY. Only scan emails with user consent."
  },
  {
    id: "malwarebazaar",
    name: "MalwareBazaar",
    category: "file",
    mode: "public-api",
    targetTypes: ["hash"],
    runnable: true,
    description: "Malware sample hash lookup from abuse.ch MalwareBazaar.",
    setup: "No key required for hash lookup."
  },
  {
    id: "whoisxml",
    name: "WhoisXML API",
    category: "osint",
    mode: "api",
    targetTypes: ["domain", "ip"],
    envVars: ["WHOISXML_API_KEY"],
    runnable: true,
    description: "WHOIS/RDAP style domain ownership and registration metadata.",
    setup: "Add WHOISXML_API_KEY."
  },
  {
    id: "cloudflare-dns",
    name: "Cloudflare DNS API",
    category: "dns",
    mode: "public-api",
    targetTypes: ["domain"],
    runnable: true,
    description: "DNS-over-HTTPS resolver for passive A/AAAA/MX/TXT checks.",
    setup: "No key required for public resolver queries."
  },
  {
    id: "google-dns",
    name: "Google DNS API",
    category: "dns",
    mode: "public-api",
    targetTypes: ["domain"],
    runnable: true,
    description: "Google DNS-over-HTTPS resolver for passive domain checks.",
    setup: "No key required for public resolver queries."
  },
  {
    id: "owasp-zap",
    name: "OWASP ZAP",
    category: "web",
    mode: "local-service",
    targetTypes: ["url"],
    envVars: ["ZAP_API_URL", "ZAP_API_KEY", "SCAMSHIELD_ENABLE_ACTIVE_TOOLS"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "DAST proxy/scanner integration for authorized applications using spider plus passive alert summary.",
    setup: "Run ZAP in daemon/API mode and set ZAP_API_URL, ZAP_API_KEY, and SCAMSHIELD_ENABLE_ACTIVE_TOOLS=1."
  },
  {
    id: "nmap",
    name: "Nmap",
    category: "network",
    mode: "local-cli",
    targetTypes: ["domain", "ip"],
    envVars: ["NMAP_PATH", "SCAMSHIELD_ENABLE_ACTIVE_TOOLS"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Authorized network service discovery. Disabled by default.",
    setup: "Install nmap and set NMAP_PATH plus SCAMSHIELD_ENABLE_ACTIVE_TOOLS=1."
  },
  {
    id: "nuclei",
    name: "Nuclei",
    category: "web",
    mode: "local-cli",
    targetTypes: ["url", "domain"],
    envVars: ["NUCLEI_PATH", "NUCLEI_TEMPLATES_PATH", "SCAMSHIELD_ENABLE_ACTIVE_TOOLS"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Template-based authorized vulnerability checks.",
    setup: "Install nuclei, maintain vetted templates, and set NUCLEI_PATH plus NUCLEI_TEMPLATES_PATH."
  },
  {
    id: "clamav",
    name: "ClamAV",
    category: "file",
    mode: "local-cli",
    targetTypes: ["file"],
    envVars: ["CLAMSCAN_PATH", "CLAMAV_DATABASE_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Local antivirus scan for uploaded files.",
    setup: "Install ClamAV, update signatures with freshclam, then set CLAMSCAN_PATH and CLAMAV_DATABASE_PATH."
  },
  {
    id: "yara",
    name: "YARA",
    category: "file",
    mode: "local-cli",
    targetTypes: ["file"],
    envVars: ["YARA_PATH", "YARA_RULES_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Local rule-based malware and document triage.",
    setup: "Install YARA and set YARA_PATH plus YARA_RULES_PATH."
  },
  {
    id: "trivy",
    name: "Trivy",
    category: "code",
    mode: "local-cli",
    targetTypes: ["repository", "file"],
    envVars: ["TRIVY_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Container, dependency, IaC, and filesystem vulnerability scanning.",
    setup: "Install Trivy and set TRIVY_PATH."
  },
  {
    id: "gitleaks",
    name: "Gitleaks",
    category: "code",
    mode: "local-cli",
    targetTypes: ["repository"],
    envVars: ["GITLEAKS_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Secret scanning for repositories and archives.",
    setup: "Install Gitleaks and set GITLEAKS_PATH."
  },
  {
    id: "semgrep",
    name: "Semgrep",
    category: "code",
    mode: "local-cli",
    targetTypes: ["repository", "file"],
    envVars: ["SEMGREP_PATH", "SEMGREP_RULES_PATH", "SEMGREP_SSL_CERT_FILE"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Static application security testing using Semgrep rules.",
    setup: "Install Semgrep and set SEMGREP_PATH, SEMGREP_RULES_PATH, and SEMGREP_SSL_CERT_FILE if needed."
  },
  {
    id: "mobsf",
    name: "MobSF",
    category: "mobile",
    mode: "local-service",
    targetTypes: ["apk", "file"],
    envVars: ["MOBSF_API_URL", "MOBSF_API_KEY"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Mobile APK/IPA static and dynamic security analysis.",
    setup: "Run MobSF and set MOBSF_API_URL plus MOBSF_API_KEY."
  },
  {
    id: "wazuh",
    name: "Wazuh",
    category: "siem",
    mode: "local-service",
    targetTypes: ["domain", "ip"],
    envVars: ["WAZUH_API_URL", "WAZUH_API_USER", "WAZUH_API_PASSWORD"],
    runnable: true,
    description: "SIEM alert and endpoint telemetry connector.",
    setup: "Set WAZUH_API_URL and credentials for your Wazuh deployment."
  },
  {
    id: "exiftool",
    name: "ExifTool",
    category: "file",
    mode: "local-cli",
    targetTypes: ["file"],
    envVars: ["EXIFTOOL_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Metadata extraction for images, PDFs, and documents.",
    setup: "Install ExifTool and set EXIFTOOL_PATH."
  },
  {
    id: "pefile",
    name: "pefile",
    category: "file",
    mode: "local-cli",
    targetTypes: ["file"],
    envVars: ["PEFILE_PYTHON_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Portable Executable metadata parser for Windows binaries.",
    setup: "Install pefile in Python and set PEFILE_PYTHON_PATH if needed."
  },
  {
    id: "pdfid",
    name: "pdfid",
    category: "file",
    mode: "local-cli",
    targetTypes: ["file"],
    envVars: ["PDFID_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "PDF suspicious keyword triage.",
    setup: "Install pdfid.py and set PDFID_PATH."
  },
  {
    id: "pdf-parser",
    name: "pdf-parser",
    category: "file",
    mode: "local-cli",
    targetTypes: ["file"],
    envVars: ["PDF_PARSER_PATH"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Deep PDF object inspection for suspicious structures.",
    setup: "Install pdf-parser.py and set PDF_PARSER_PATH."
  },
  {
    id: "wappalyzer",
    name: "Wappalyzer",
    category: "web",
    mode: "api",
    targetTypes: ["url", "domain"],
    envVars: ["WAPPALYZER_API_KEY"],
    runnable: true,
    description: "Technology fingerprinting for public websites.",
    setup: "Add WAPPALYZER_API_KEY or connect a local Wappalyzer runner."
  },
  {
    id: "phishtank",
    name: "PhishTank",
    category: "reputation",
    mode: "api",
    targetTypes: ["url"],
    envVars: ["PHISHTANK_API_KEY"],
    runnable: true,
    description: "Community phishing URL intelligence.",
    setup: "Add PHISHTANK_API_KEY."
  },
  {
    id: "cisco-talos",
    name: "Cisco Talos Intelligence",
    category: "reputation",
    mode: "manual",
    targetTypes: ["domain", "ip", "url"],
    runnable: true,
    description: "Talos web/IP reputation lookup connector placeholder.",
    setup: "Uses Cisco Talos Reputation Center analyst handoff links."
  },
  {
    id: "ibm-xforce",
    name: "IBM X-Force Exchange",
    category: "reputation",
    mode: "api",
    targetTypes: ["url", "domain", "ip", "hash"],
    envVars: ["XFORCE_API_KEY", "XFORCE_API_PASSWORD"],
    runnable: true,
    description: "IBM X-Force reputation for URLs, hosts, IPs, and malware hashes.",
    setup: "Add XFORCE_API_KEY and XFORCE_API_PASSWORD."
  },
  {
    id: "mxtoolbox",
    name: "MXToolbox",
    category: "dns",
    mode: "api",
    targetTypes: ["domain", "ip"],
    envVars: ["MXTOOLBOX_API_KEY"],
    runnable: true,
    description: "Mail/DNS blacklist and deliverability intelligence.",
    setup: "Add MXTOOLBOX_API_KEY."
  },
  {
    id: "hybrid-analysis",
    name: "Hybrid Analysis",
    category: "sandbox",
    mode: "api",
    targetTypes: ["hash", "file"],
    envVars: ["HYBRID_ANALYSIS_API_KEY"],
    runnable: true,
    description: "File reputation and sandbox report connector.",
    setup: "Add HYBRID_ANALYSIS_API_KEY."
  },
  {
    id: "cuckoo-sandbox",
    name: "Cuckoo Sandbox",
    category: "sandbox",
    mode: "local-service",
    targetTypes: ["file", "url"],
    envVars: ["CUCKOO_API_URL"],
    activeScan: true,
    requiresAuthorization: true,
    runnable: true,
    description: "Self-hosted malware detonation workflow.",
    setup: "Run Cuckoo and set CUCKOO_API_URL plus optional CUCKOO_API_KEY."
  },
  {
    id: "joe-sandbox",
    name: "Joe Sandbox",
    category: "sandbox",
    mode: "api",
    targetTypes: ["hash", "file", "url"],
    envVars: ["JOE_SANDBOX_API_KEY"],
    runnable: true,
    description: "Commercial sandbox submission/report connector.",
    setup: "Add JOE_SANDBOX_API_KEY and optionally JOE_SANDBOX_API_URL."
  },
  {
    id: "anyrun",
    name: "Any.Run",
    category: "sandbox",
    mode: "api",
    targetTypes: ["hash", "file", "url"],
    envVars: ["ANYRUN_API_KEY"],
    runnable: true,
    description: "Interactive sandbox report connector.",
    setup: "Add ANYRUN_API_KEY and optionally ANYRUN_API_URL/ANYRUN_LOOKUP_PATH."
  },
  {
    id: "securityheaders",
    name: "SecurityHeaders.com",
    category: "web",
    mode: "api",
    targetTypes: ["url", "domain"],
    envVars: ["SECURITYHEADERS_API_KEY"],
    runnable: true,
    description: "Security header grade connector. ScamShield includes an internal header scanner already.",
    setup: "Add SECURITYHEADERS_API_KEY."
  }
];
