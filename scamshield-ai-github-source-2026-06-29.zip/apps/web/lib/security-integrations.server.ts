import dns from "node:dns/promises";
import { execFile as execFileCallback } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import net from "node:net";
import path from "node:path";
import { promisify } from "node:util";
import {
  securityIntegrationCatalog,
  type SecurityIntegrationId,
  type SecurityIntegrationRunResult,
  type SecurityIntegrationStatusItem
} from "./security-integration-types";

const execFile = promisify(execFileCallback);
const repoRoot = process.cwd().endsWith(`${path.sep}apps${path.sep}web`) ? path.resolve(process.cwd(), "../..") : process.cwd();
const defaultToolHome = path.join(repoRoot, ".tool-home");
const defaultToolCache = path.join(repoRoot, ".tool-cache");
const allowedLocalRoots = [repoRoot, "/private/tmp"];

type RunInput = {
  toolId: SecurityIntegrationId;
  target: string;
  authorized?: boolean;
};

const activeToolsEnabled = () => process.env.SCAMSHIELD_ENABLE_ACTIVE_TOOLS === "1";

export function getSecurityIntegrationStatuses(): SecurityIntegrationStatusItem[] {
  return securityIntegrationCatalog.map((item) => {
    const missingEnv = missingEnvVars(item.envVars);
    const configured = missingEnv.length === 0;
    let status: SecurityIntegrationStatusItem["status"] = "ready";
    let statusLabel = "Ready";

    if (item.activeScan && !activeToolsEnabled()) {
      status = "disabled";
      statusLabel = "Active tools disabled";
    } else if (!configured) {
      status = item.mode === "local-cli" || item.mode === "local-service" ? "needs_service" : "needs_key";
      statusLabel = missingSetupLabel(item.mode);
    } else if (!item.runnable) {
      status = item.mode === "manual" ? "blocked" : "needs_service";
      statusLabel = item.mode === "manual" ? "Manual connector" : pendingAdapterLabel(item.mode);
    }

    return {
      ...item,
      configured,
      status,
      statusLabel
    };
  });
}

function missingSetupLabel(mode: SecurityIntegrationStatusItem["mode"]) {
  if (mode === "local-cli") return "Install CLI tool";
  if (mode === "local-service") return "Connect service";
  return "Needs API key";
}

function pendingAdapterLabel(mode: SecurityIntegrationStatusItem["mode"]) {
  if (mode === "local-cli") return "CLI adapter pending";
  if (mode === "local-service") return "Service adapter pending";
  return "Adapter pending";
}

export async function runSecurityIntegration(input: RunInput): Promise<SecurityIntegrationRunResult> {
  const tool = securityIntegrationCatalog.find((item) => item.id === input.toolId);
  if (!tool) throw new Error("Unknown security integration");

  const target = input.target.trim();
  if (!target) throw new Error("Target is required");
  if (target.length > 700) throw new Error("Target is too long");

  if (tool.activeScan && !input.authorized) {
    return runResult(tool.id, tool.name, target, "blocked", "This tool requires authorization confirmation before it can run.", {
      reason: "authorization_required"
    });
  }
  if (tool.activeScan && !activeToolsEnabled()) {
    return runResult(tool.id, tool.name, target, "blocked", "Active tools are disabled by server policy.", {
      requiredEnv: "SCAMSHIELD_ENABLE_ACTIVE_TOOLS=1"
    });
  }
  if ((tool.activeScan && (tool.category === "network" || tool.category === "web")) || ["network", "web"].includes(tool.category)) {
    await assertSafePublicTarget(target);
  }

  const missingEnv = missingEnvVars(tool.envVars);
  if (missingEnv.length > 0) {
    return runResult(tool.id, tool.name, target, "not_configured", `${tool.name} is not configured yet.`, {
      missingEnv,
      setup: tool.setup
    });
  }
  if (!tool.runnable) {
    return runResult(tool.id, tool.name, target, "not_supported", `${tool.name} is present in the Integration Hub but its adapter is not enabled for direct browser use yet.`, {
      setup: tool.setup,
      mode: tool.mode,
      activeScan: Boolean(tool.activeScan)
    });
  }

  try {
    switch (tool.id) {
      case "virustotal":
        return await runVirusTotal(target);
      case "urlscan":
        return await runUrlscan(target);
      case "google-safe-browsing":
        return await runGoogleSafeBrowsing(target);
      case "abuseipdb":
        return await runAbuseIpDb(target);
      case "shodan":
        return await runShodan(target);
      case "alienvault-otx":
        return await runOtx(target);
      case "mozilla-observatory":
        return await runMozillaObservatory(target);
      case "ssl-labs":
        return await runSslLabs(target);
      case "hibp":
        return await runHibp(target);
      case "malwarebazaar":
        return await runMalwareBazaar(target);
      case "whoisxml":
        return await runWhoisXml(target);
      case "cloudflare-dns":
        return await runCloudflareDns(target);
      case "google-dns":
        return await runGoogleDns(target);
      case "owasp-zap":
        return await runOwaspZap(target);
      case "nmap":
        return await runNmap(target);
      case "nuclei":
        return await runNuclei(target);
      case "clamav":
        return await runClamAv(target);
      case "yara":
        return await runYara(target);
      case "trivy":
        return await runTrivy(target);
      case "gitleaks":
        return await runGitleaks(target);
      case "semgrep":
        return await runSemgrep(target);
      case "mobsf":
        return await runMobsf(target);
      case "wazuh":
        return await runWazuh(target);
      case "exiftool":
        return await runExifTool(target);
      case "pefile":
        return await runPefile(target);
      case "pdfid":
        return await runPdfId(target);
      case "pdf-parser":
        return await runPdfParser(target);
      case "wappalyzer":
        return await runWappalyzer(target);
      case "phishtank":
        return await runPhishTank(target);
      case "cisco-talos":
        return runCiscoTalos(target);
      case "ibm-xforce":
        return await runIbmXforce(target);
      case "mxtoolbox":
        return await runMxToolbox(target);
      case "hybrid-analysis":
        return await runHybridAnalysis(target);
      case "cuckoo-sandbox":
        return await runCuckooSandbox(target);
      case "joe-sandbox":
        return await runJoeSandbox(target);
      case "anyrun":
        return await runAnyRun(target);
      case "securityheaders":
        return await runSecurityHeaders(target);
      default:
        return runResult(tool.id, tool.name, target, "not_supported", `${tool.name} is cataloged but does not have a safe direct-run adapter yet.`, {
          setup: tool.setup
        });
    }
  } catch (error) {
    return runResult(tool.id, tool.name, target, "error", `${tool.name} request failed.`, {
      error: error instanceof Error ? error.message : "Unknown integration error"
    });
  }
}

async function runVirusTotal(target: string) {
  const key = requireEnv("VIRUSTOTAL_API_KEY");
  const indicator = classifyTarget(target);
  let path = "";
  if (indicator.kind === "url") path = `/urls/${Buffer.from(indicator.value).toString("base64url")}`;
  if (indicator.kind === "domain") path = `/domains/${indicator.value}`;
  if (indicator.kind === "ip") path = `/ip_addresses/${indicator.value}`;
  if (indicator.kind === "hash") path = `/files/${indicator.value}`;
  if (!path) return unsupportedRun("virustotal", "VirusTotal", target, "Use a URL, domain, IP, or SHA-256 hash.");

  const details = await fetchJson(`https://www.virustotal.com/api/v3${path}`, {
    headers: { "x-apikey": key }
  });
  const stats = getNested(details, ["data", "attributes", "last_analysis_stats"]) as Record<string, unknown> | undefined;
  return runResult("virustotal", "VirusTotal", target, "ok", summarizeStats("VirusTotal", stats), { indicator, stats, raw: shrink(details) });
}

async function runUrlscan(target: string) {
  const key = requireEnv("URLSCAN_API_KEY");
  const indicator = classifyTarget(target);
  const query =
    indicator.kind === "url"
      ? `page.url:"${escapeUrlscanQuery(indicator.value)}"`
      : indicator.kind === "ip"
        ? `ip:${indicator.value}`
        : `domain:${escapeUrlscanQuery(indicator.host ?? indicator.value)}`;
  const details = await fetchJson(`https://urlscan.io/api/v1/search/?q=${encodeURIComponent(query)}&size=10`, {
    headers: { "API-Key": key }
  });
  const total = getNumber(getNested(details, ["total"])) ?? 0;
  return runResult("urlscan", "urlscan.io", target, "ok", `urlscan.io returned ${total} matching public result(s).`, {
    query,
    total,
    raw: shrink(details)
  });
}

function escapeUrlscanQuery(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

async function runGoogleSafeBrowsing(target: string) {
  const key = requireEnv("GOOGLE_SAFE_BROWSING_API_KEY");
  const indicator = classifyTarget(target);
  if (indicator.kind !== "url") return unsupportedRun("google-safe-browsing", "Google Safe Browsing", target, "Use a full HTTP or HTTPS URL.");
  const details = await fetchJson(`https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${encodeURIComponent(key)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      client: { clientId: "scamshield-ai", clientVersion: "1.0.0" },
      threatInfo: {
        threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
        platformTypes: ["ANY_PLATFORM"],
        threatEntryTypes: ["URL"],
        threatEntries: [{ url: indicator.value }]
      }
    })
  });
  const matches = Array.isArray((details as { matches?: unknown[] }).matches) ? (details as { matches: unknown[] }).matches.length : 0;
  return runResult("google-safe-browsing", "Google Safe Browsing", target, "ok", matches ? `Google Safe Browsing returned ${matches} threat match(es).` : "Google Safe Browsing returned no threat matches.", {
    matches,
    raw: shrink(details)
  });
}

async function runAbuseIpDb(target: string) {
  const key = requireEnv("ABUSEIPDB_API_KEY");
  const indicator = classifyTarget(target);
  if (indicator.kind !== "ip") return unsupportedRun("abuseipdb", "AbuseIPDB", target, "Use a public IP address.");
  const details = await fetchJson(`https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(indicator.value)}&maxAgeInDays=90&verbose`, {
    headers: { Key: key, Accept: "application/json" }
  });
  const score = getNumber(getNested(details, ["data", "abuseConfidenceScore"])) ?? 0;
  return runResult("abuseipdb", "AbuseIPDB", target, "ok", `AbuseIPDB abuse confidence score: ${score}.`, {
    score,
    raw: shrink(details)
  });
}

async function runShodan(target: string) {
  const key = requireEnv("SHODAN_API_KEY");
  const indicator = classifyTarget(target);
  const host = indicator.kind === "ip" ? indicator.value : indicator.host ?? indicator.value;
  const details = await fetchJson(`https://api.shodan.io/shodan/host/${encodeURIComponent(host)}?key=${encodeURIComponent(key)}`);
  const ports = Array.isArray((details as { ports?: unknown[] }).ports) ? (details as { ports: unknown[] }).ports : [];
  return runResult("shodan", "Shodan", target, "ok", `Shodan returned ${ports.length} exposed service port(s).`, {
    ports,
    raw: shrink(details)
  });
}

async function runOtx(target: string) {
  const key = requireEnv("OTX_API_KEY");
  const indicator = classifyTarget(target);
  const base = "https://otx.alienvault.com/api/v1/indicators";
  const path =
    indicator.kind === "ip"
      ? `/IPv4/${encodeURIComponent(indicator.value)}/general`
      : indicator.kind === "hash"
        ? `/file/${encodeURIComponent(indicator.value)}/general`
        : indicator.kind === "url"
          ? `/url/${encodeURIComponent(indicator.value)}/general`
          : `/domain/${encodeURIComponent(indicator.host ?? indicator.value)}/general`;
  const details = await fetchJson(`${base}${path}`, {
    headers: { "X-OTX-API-KEY": key }
  });
  const pulses = getNumber(getNested(details, ["pulse_info", "count"])) ?? 0;
  return runResult("alienvault-otx", "AlienVault OTX", target, "ok", `AlienVault OTX returned ${pulses} related pulse(s).`, {
    pulses,
    raw: shrink(details)
  });
}

async function runMozillaObservatory(target: string) {
  const host = classifyTarget(target).host ?? classifyTarget(target).value;
  const details = await fetchJson(`https://http-observatory.security.mozilla.org/api/v1/analyze?host=${encodeURIComponent(host)}&rescan=false`);
  return runResult("mozilla-observatory", "Mozilla HTTP Observatory", target, "ok", "Mozilla HTTP Observatory analysis requested or returned.", {
    raw: shrink(details)
  });
}

async function runSslLabs(target: string) {
  const host = classifyTarget(target).host ?? classifyTarget(target).value;
  const details = await fetchJson(`https://api.ssllabs.com/api/v3/analyze?host=${encodeURIComponent(host)}&fromCache=on&all=done`);
  const grade = getNested(details, ["endpoints", 0, "grade"]);
  return runResult("ssl-labs", "SSL Labs", target, "ok", grade ? `SSL Labs cached grade: ${String(grade)}.` : "SSL Labs returned TLS analysis metadata.", {
    grade,
    raw: shrink(details)
  });
}

async function runHibp(target: string) {
  const key = requireEnv("HIBP_API_KEY");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(target)) return unsupportedRun("hibp", "Have I Been Pwned", target, "Use an email address and only scan with user consent.");
  const details = await fetchJson(`https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(target)}?truncateResponse=false`, {
    headers: {
      "hibp-api-key": key,
      "user-agent": "ScamShieldAI-SecurityLab"
    },
    allow404: true
  });
  const count = Array.isArray(details) ? details.length : 0;
  return runResult("hibp", "Have I Been Pwned", redactEmail(target), "ok", count ? `HIBP returned ${count} breach record(s).` : "HIBP returned no breach records.", {
    count,
    raw: shrink(details)
  });
}

async function runMalwareBazaar(target: string) {
  const indicator = classifyTarget(target);
  if (indicator.kind !== "hash") return unsupportedRun("malwarebazaar", "MalwareBazaar", target, "Use an MD5, SHA-1, or SHA-256 hash.");
  const body = new URLSearchParams({ query: "get_info", hash: indicator.value });
  const details = await fetchJson("https://mb-api.abuse.ch/api/v1/", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  const status = typeof (details as { query_status?: unknown }).query_status === "string" ? (details as { query_status: string }).query_status : "unknown";
  return runResult("malwarebazaar", "MalwareBazaar", target, "ok", `MalwareBazaar query status: ${status}.`, {
    queryStatus: status,
    raw: shrink(details)
  });
}

async function runWhoisXml(target: string) {
  const key = requireEnv("WHOISXML_API_KEY");
  const host = classifyTarget(target).host ?? classifyTarget(target).value;
  const details = await fetchJson(`https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=${encodeURIComponent(key)}&domainName=${encodeURIComponent(host)}&outputFormat=JSON`);
  return runResult("whoisxml", "WhoisXML API", target, "ok", "WhoisXML returned registration metadata.", {
    raw: shrink(details)
  });
}

async function runCloudflareDns(target: string) {
  const host = classifyTarget(target).host ?? classifyTarget(target).value;
  const details = await dohQuery("https://cloudflare-dns.com/dns-query", host);
  return runResult("cloudflare-dns", "Cloudflare DNS API", target, "ok", "Cloudflare DNS-over-HTTPS returned resolver data.", details);
}

async function runGoogleDns(target: string) {
  const host = classifyTarget(target).host ?? classifyTarget(target).value;
  const details = await dohQuery("https://dns.google/resolve", host);
  return runResult("google-dns", "Google DNS API", target, "ok", "Google DNS-over-HTTPS returned resolver data.", details);
}

async function runOwaspZap(target: string) {
  const scanUrl = normalizeHttpTarget(target);
  const version = await fetchZapJson("core/view/version");
  await fetchZapJson("core/action/accessUrl", { url: scanUrl, followRedirects: "true" });
  const spiderStart = await fetchZapJson("spider/action/scan", {
    url: scanUrl,
    maxChildren: "8",
    recurse: "false",
    subtreeOnly: "true"
  });
  const scanId = getString((spiderStart as Record<string, unknown>).scan) ?? "0";
  let status = 0;
  for (let attempt = 0; attempt < 12; attempt += 1) {
    await sleep(750);
    const statusBody = await fetchZapJson("spider/view/status", { scanId });
    status = Number(getString((statusBody as Record<string, unknown>).status) ?? "0");
    if (status >= 100) break;
  }
  const recordsBody = await fetchZapJson("pscan/view/recordsToScan").catch(() => ({ recordsToScan: "unknown" }));
  const alertsBody = await fetchZapJson("core/view/alerts", {
    baseurl: scanUrl,
    start: "0",
    count: "25"
  });
  const alerts = Array.isArray((alertsBody as { alerts?: unknown[] }).alerts) ? (alertsBody as { alerts: Array<Record<string, unknown>> }).alerts : [];
  const riskCounts = alerts.reduce<Record<string, number>>((counts, alert) => {
    const risk = getString(alert.risk) ?? "Unknown";
    counts[risk] = (counts[risk] ?? 0) + 1;
    return counts;
  }, {});

  return runResult("owasp-zap", "OWASP ZAP", target, "ok", `ZAP spider reached ${status}% and returned ${alerts.length} passive alert(s).`, {
    scanUrl,
    zapVersion: getString((version as Record<string, unknown>).version),
    spiderStatus: status,
    passiveRecordsToScan: getString((recordsBody as Record<string, unknown>).recordsToScan) ?? "unknown",
    riskCounts,
    alerts: alerts.map(sanitizeZapAlert)
  });
}

async function runNmap(target: string) {
  const nmapPath = requireEnv("NMAP_PATH");
  const indicator = classifyTarget(target);
  if (indicator.kind !== "domain" && indicator.kind !== "ip" && indicator.kind !== "url") {
    return unsupportedRun("nmap", "Nmap", target, "Use a domain, public IP, or full URL you are authorized to test.");
  }

  const host = indicator.kind === "ip" ? indicator.value : indicator.host ?? indicator.value;
  const { stdout } = await execFile(
    nmapPath,
    ["-Pn", "--top-ports", "25", "--max-retries", "1", "--host-timeout", "20s", "-oG", "-", host],
    {
      timeout: 25000,
      maxBuffer: 512 * 1024
    }
  );
  const ports = parseNmapGrepable(stdout);
  return runResult("nmap", "Nmap", target, "ok", `Nmap found ${ports.filter((port) => port.state === "open").length} open port(s) in the authorized quick scan.`, {
    host,
    ports,
    raw: stdout.slice(0, 12000)
  });
}

async function runNuclei(target: string) {
  const nucleiPath = requireEnv("NUCLEI_PATH");
  const templatesPath = requireEnv("NUCLEI_TEMPLATES_PATH");
  const scanUrl = normalizeHttpTarget(target);
  const { stdout, stderr } = await execFileLenient(
    nucleiPath,
    [
      "-u",
      scanUrl,
      "-ud",
      templatesPath,
      "-t",
      templatesPath,
      "-jsonl",
      "-silent",
      "-no-color",
      "-omit-raw",
      "-omit-template",
      "-duc",
      "-ni",
      "-no-stdin",
      "-lna",
      "-rl",
      "5",
      "-c",
      "5",
      "-timeout",
      "6",
      "-retries",
      "0"
    ],
    {
      timeout: 35000,
      maxBuffer: 1024 * 1024,
      env: localToolEnv()
    }
  );
  const stdoutText = String(stdout);
  const stderrText = String(stderr);
  const findings = parseJsonLines(stdoutText).map(sanitizeNucleiFinding);
  return runResult("nuclei", "Nuclei", target, "ok", `Nuclei returned ${findings.length} finding(s) with the configured templates.`, {
    scanUrl,
    templatesPath,
    findings,
    stderr: stderrText.slice(0, 2000)
  });
}

async function runYara(target: string) {
  const yaraPath = requireEnv("YARA_PATH");
  const rulesPath = requireEnv("YARA_RULES_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: true });
  const { stdout } = await execFile(yaraPath, ["-w", "-m", "-r", "-a", "15", rulesPath, targetPath], {
    timeout: 30000,
    maxBuffer: 512 * 1024
  });
  const matches = stdout
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  return runResult("yara", "YARA", target, "ok", `YARA returned ${matches.length} match(es).`, {
    targetPath,
    rulesPath,
    matches,
    raw: stdout.slice(0, 12000)
  });
}

async function runClamAv(target: string) {
  const clamscanPath = requireEnv("CLAMSCAN_PATH");
  const databasePath = requireEnv("CLAMAV_DATABASE_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
  const { stdout, stderr } = await execFileLenient(clamscanPath, ["--database", databasePath, "--no-summary", targetPath], {
    timeout: 45000,
    maxBuffer: 512 * 1024
  });
  const stdoutText = String(stdout);
  const infected = /\sFOUND\s*$/m.test(stdoutText);
  const signature = infected ? stdoutText.match(/:\s(.+?)\sFOUND/m)?.[1] : null;
  return runResult("clamav", "ClamAV", target, "ok", infected ? `ClamAV detected ${signature ?? "a malware signature"}.` : "ClamAV found no malware signatures.", {
    targetPath,
    infected,
    signature,
    raw: stdoutText.slice(0, 12000),
    stderr: String(stderr).slice(0, 2000)
  });
}

async function runTrivy(target: string) {
  const trivyPath = requireEnv("TRIVY_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: true });
  const { stdout } = await execFile(
    trivyPath,
    [
      "fs",
      "--scanners",
      "secret,misconfig",
      "--skip-db-update",
      "--skip-java-db-update",
      "--offline-scan",
      "--format",
      "json",
      "--quiet",
      "--cache-dir",
      path.join(defaultToolCache, "trivy"),
      targetPath
    ],
    {
      timeout: 60000,
      maxBuffer: 2 * 1024 * 1024,
      env: localToolEnv()
    }
  );
  const parsed = parseJson(stdout);
  const results = Array.isArray((parsed as { Results?: unknown[] }).Results) ? (parsed as { Results: Array<Record<string, unknown>> }).Results : [];
  const issueCount = results.reduce((count, result) => {
    const secrets = Array.isArray(result.Secrets) ? result.Secrets.length : 0;
    const misconfigs = Array.isArray(result.Misconfigurations) ? result.Misconfigurations.length : 0;
    return count + secrets + misconfigs;
  }, 0);
  return runResult("trivy", "Trivy", target, "ok", `Trivy returned ${issueCount} secret/misconfiguration finding(s).`, {
    targetPath,
    issueCount,
    raw: shrink(parsed)
  });
}

async function runSemgrep(target: string) {
  const semgrepPath = requireEnv("SEMGREP_PATH");
  const rulesPath = requireEnv("SEMGREP_RULES_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: true });
  const { stdout, stderr } = await execFileLenient(
    semgrepPath,
    ["--config", rulesPath, "--json", "--timeout", "15", "--metrics", "off", "--disable-version-check", targetPath],
    {
      timeout: 45000,
      maxBuffer: 2 * 1024 * 1024,
      env: semgrepToolEnv()
    }
  );
  const parsed = parseJson(String(stdout)) as Record<string, unknown>;
  const results = Array.isArray(parsed.results) ? parsed.results : [];
  return runResult("semgrep", "Semgrep", target, "ok", `Semgrep returned ${results.length} static finding(s).`, {
    targetPath,
    rulesPath,
    count: results.length,
    raw: shrink(parsed),
    stderr: String(stderr).slice(0, 2000)
  });
}

async function runGitleaks(target: string) {
  const gitleaksPath = requireEnv("GITLEAKS_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: true });
  const { stdout } = await execFile(
    gitleaksPath,
    [
      "detect",
      "--source",
      targetPath,
      "--no-git",
      "--no-banner",
      "--no-color",
      "--redact",
      "--report-format",
      "json",
      "--report-path",
      "-",
      "--exit-code",
      "0",
      "--timeout",
      "30"
    ],
    {
      timeout: 45000,
      maxBuffer: 1024 * 1024
    }
  );
  const findings = parseJson(stdout) as unknown;
  const count = Array.isArray(findings) ? findings.length : 0;
  return runResult("gitleaks", "Gitleaks", target, "ok", `Gitleaks returned ${count} redacted secret finding(s).`, {
    targetPath,
    count,
    raw: shrink(findings)
  });
}

async function runPdfId(target: string) {
  const pdfidPath = requireEnv("PDFID_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
  const { stdout, stderr } = await execFile(pdfidPath, [targetPath], {
    timeout: 15000,
    maxBuffer: 512 * 1024
  });
  const parsed = parseJson(stdout);
  const riskSignals = Array.isArray((parsed as { riskSignals?: unknown[] }).riskSignals) ? (parsed as { riskSignals: unknown[] }).riskSignals : [];
  return runResult("pdfid", "pdfid", target, "ok", `pdfid returned ${riskSignals.length} PDF risk signal(s).`, {
    targetPath,
    raw: parsed,
    stderr: stderr.slice(0, 2000)
  });
}

async function runPdfParser(target: string) {
  const pdfParserPath = requireEnv("PDF_PARSER_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
  const { stdout, stderr } = await execFile(pdfParserPath, [targetPath], {
    timeout: 15000,
    maxBuffer: 1024 * 1024
  });
  const parsed = parseJson(stdout) as Record<string, unknown>;
  const suspicious = getNumber(parsed.suspiciousObjectCount) ?? 0;
  return runResult("pdf-parser", "pdf-parser", target, "ok", `pdf-parser returned ${suspicious} suspicious PDF object(s).`, {
    targetPath,
    raw: shrink(parsed),
    stderr: stderr.slice(0, 2000)
  });
}

async function runExifTool(target: string) {
  const exifToolPath = requireEnv("EXIFTOOL_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
  const { stdout } = await execFile(exifToolPath, ["-json", "-fast", "-n", targetPath], {
    timeout: 15000,
    maxBuffer: 512 * 1024
  });
  const metadata = parseJson(stdout);
  return runResult("exiftool", "ExifTool", target, "ok", "ExifTool returned file metadata.", {
    targetPath,
    raw: shrink(metadata)
  });
}

async function runPefile(target: string) {
  const pythonPath = requireEnv("PEFILE_PYTHON_PATH");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
  const script = [
    "import json, sys, pefile",
    "path = sys.argv[1]",
    "pe = pefile.PE(path, fast_load=True)",
    "data = {",
    "  'machine': hex(pe.FILE_HEADER.Machine),",
    "  'numberOfSections': pe.FILE_HEADER.NumberOfSections,",
    "  'timeDateStamp': pe.FILE_HEADER.TimeDateStamp,",
    "  'characteristics': hex(pe.FILE_HEADER.Characteristics),",
    "  'sections': [{'name': s.Name.rstrip(b'\\x00').decode('utf-8', 'replace'), 'virtualSize': s.Misc_VirtualSize, 'rawSize': s.SizeOfRawData, 'entropy': round(s.get_entropy(), 3)} for s in pe.sections]",
    "}",
    "print(json.dumps(data))"
  ].join("\n");
  const { stdout } = await execFile(pythonPath, ["-c", script, targetPath], {
    timeout: 15000,
    maxBuffer: 512 * 1024
  });
  const parsed = parseJson(stdout);
  return runResult("pefile", "pefile", target, "ok", "pefile parsed Portable Executable metadata.", {
    targetPath,
    raw: parsed
  });
}

async function runIbmXforce(target: string) {
  const key = requireEnv("XFORCE_API_KEY");
  const password = requireEnv("XFORCE_API_PASSWORD");
  const indicator = classifyTarget(target);
  const token = Buffer.from(`${key}:${password}`).toString("base64");
  const path = indicator.kind === "hash" ? `/malware/${indicator.value}` : indicator.kind === "ip" ? `/ipr/${indicator.value}` : `/url/${encodeURIComponent(indicator.kind === "url" ? indicator.value : indicator.host ?? indicator.value)}`;
  const details = await fetchJson(`https://api.xforce.ibmcloud.com${path}`, {
    headers: { Authorization: `Basic ${token}` }
  });
  return runResult("ibm-xforce", "IBM X-Force Exchange", target, "ok", "IBM X-Force returned reputation metadata.", {
    raw: shrink(details)
  });
}

async function runMobsf(target: string) {
  const baseUrl = requireEnv("MOBSF_API_URL").replace(/\/+$/, "");
  const key = requireEnv("MOBSF_API_KEY");
  const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
  const bytes = fs.readFileSync(targetPath);
  const formData = new FormData();
  formData.append("file", new Blob([new Uint8Array(bytes)]), path.basename(targetPath));

  const upload = (await fetchJson(`${baseUrl}/api/v1/upload`, {
    method: "POST",
    headers: { Authorization: key },
    body: formData,
    signal: AbortSignal.timeout(45000)
  })) as Record<string, unknown>;

  const hash = getString(upload.hash);
  if (!hash) throw new Error("MobSF upload did not return a scan hash");
  const scanType = getString(upload.scan_type) ?? inferMobSfScanType(targetPath);
  const fileName = getString(upload.file_name) ?? path.basename(targetPath);
  const body = new URLSearchParams({ hash, scan_type: scanType, file_name: fileName, re_scan: "0" });

  await fetchJson(`${baseUrl}/api/v1/scan`, {
    method: "POST",
    headers: { Authorization: key, "Content-Type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(90000)
  });

  const report = await fetchJson(`${baseUrl}/api/v1/report_json`, {
    method: "POST",
    headers: { Authorization: key, "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ hash }),
    signal: AbortSignal.timeout(45000)
  });

  return runResult("mobsf", "MobSF", target, "ok", "MobSF completed a mobile static analysis report.", {
    targetPath,
    hash,
    scanType,
    raw: shrink(report)
  });
}

async function runWazuh(target: string) {
  const baseUrl = requireEnv("WAZUH_API_URL").replace(/\/+$/, "");
  const user = requireEnv("WAZUH_API_USER");
  const password = requireEnv("WAZUH_API_PASSWORD");
  const tokenResponse = await fetch(`${baseUrl}/security/user/authenticate?raw=true`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${user}:${password}`).toString("base64")}`
    },
    signal: AbortSignal.timeout(12000)
  });
  if (!tokenResponse.ok) {
    const text = await tokenResponse.text().catch(() => "");
    throw new Error(`Wazuh authentication failed with HTTP ${tokenResponse.status}${text ? `: ${text.slice(0, 180)}` : ""}`);
  }
  const token = (await tokenResponse.text()).trim();
  const headers = { Authorization: `Bearer ${token}` };
  const [root, manager, agentStatus] = await Promise.allSettled([
    fetchJson(`${baseUrl}/?pretty=true`, { headers }),
    fetchJson(`${baseUrl}/manager/info?pretty=true`, { headers }),
    fetchJson(`${baseUrl}/agents/summary/status?pretty=true`, { headers })
  ]);

  return runResult("wazuh", "Wazuh", target, "ok", "Wazuh API authenticated and returned manager telemetry.", {
    queryTarget: target,
    root: settledValue(root),
    manager: settledValue(manager),
    agentStatus: settledValue(agentStatus)
  });
}

async function runWappalyzer(target: string) {
  const key = requireEnv("WAPPALYZER_API_KEY");
  const scanUrl = normalizeHttpTarget(target);
  const details = await fetchJson(`https://api.wappalyzer.com/v2/lookup/?urls=${encodeURIComponent(scanUrl)}&sets=all`, {
    headers: { "x-api-key": key }
  });
  const records = Array.isArray(details) ? details : [];
  const technologies = Array.isArray((records[0] as { technologies?: unknown[] } | undefined)?.technologies)
    ? ((records[0] as { technologies: unknown[] }).technologies)
    : [];

  return runResult("wappalyzer", "Wappalyzer", target, "ok", `Wappalyzer returned ${technologies.length} detected technolog${technologies.length === 1 ? "y" : "ies"}.`, {
    scanUrl,
    technologyCount: technologies.length,
    raw: shrink(details)
  });
}

async function runPhishTank(target: string) {
  const key = requireEnv("PHISHTANK_API_KEY");
  const indicator = classifyTarget(target);
  if (indicator.kind !== "url") return unsupportedRun("phishtank", "PhishTank", target, "Use a full HTTP or HTTPS URL.");
  const body = new URLSearchParams({ url: indicator.value, format: "json", app_key: key });
  const details = await fetchJson("https://checkurl.phishtank.com/checkurl/", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent": "ScamShieldAI-SecurityLab"
    },
    body
  });
  const inDatabase = Boolean(getNested(details, ["results", "in_database"]));
  const valid = Boolean(getNested(details, ["results", "valid"]));

  return runResult("phishtank", "PhishTank", target, "ok", inDatabase ? `PhishTank has a record for this URL. Valid phish: ${valid}.` : "PhishTank returned no matching phishing record.", {
    inDatabase,
    valid,
    raw: shrink(details)
  });
}

function runCiscoTalos(target: string) {
  const indicator = classifyTarget(target);
  const query = indicator.kind === "url" ? indicator.host ?? indicator.value : indicator.value;
  const lookupUrl = `https://talosintelligence.com/reputation_center/lookup?search=${encodeURIComponent(query)}`;
  return runResult("cisco-talos", "Cisco Talos Intelligence", target, "ok", "Cisco Talos public Reputation Center lookup prepared.", {
    query,
    lookupUrl,
    note: "Cisco Talos does not expose a simple public reputation API for this workflow. Open this analyst handoff URL for Talos reputation data."
  });
}

async function runMxToolbox(target: string) {
  const key = requireEnv("MXTOOLBOX_API_KEY");
  const indicator = classifyTarget(target);
  const argument = indicator.kind === "ip" ? indicator.value : indicator.host ?? indicator.value;
  const firstUrl = `https://api.mxtoolbox.com/api/v1/lookup/blacklist/${encodeURIComponent(argument)}`;
  const fallbackUrl = `https://api.mxtoolbox.com/api/v1/Lookup/blacklist/?argument=${encodeURIComponent(argument)}`;
  let details: unknown;
  try {
    details = await fetchJson(firstUrl, { headers: { Authorization: key } });
  } catch {
    details = await fetchJson(fallbackUrl, { headers: { Authorization: key } });
  }
  return runResult("mxtoolbox", "MXToolbox", target, "ok", "MXToolbox returned blacklist lookup data.", {
    argument,
    raw: shrink(details)
  });
}

async function runHybridAnalysis(target: string) {
  const key = requireEnv("HYBRID_ANALYSIS_API_KEY");
  const hash = getTargetHash(target);
  if (!hash) return unsupportedRun("hybrid-analysis", "Hybrid Analysis", target, "Use an MD5, SHA-1, SHA-256 hash, or a local file path.");
  const details = await fetchJson(`https://www.hybrid-analysis.com/api/v2/search/hash?hash=${encodeURIComponent(hash)}`, {
    headers: {
      "api-key": key,
      Accept: "application/json",
      "User-Agent": "ScamShieldAI-SecurityLab"
    },
    allow404: true
  });
  const count = Array.isArray(details) ? details.length : Array.isArray((details as { result?: unknown[] }).result) ? (details as { result: unknown[] }).result.length : 0;
  return runResult("hybrid-analysis", "Hybrid Analysis", target, "ok", `Hybrid Analysis returned ${count} matching report(s).`, {
    hash,
    count,
    raw: shrink(details)
  });
}

async function runCuckooSandbox(target: string) {
  const baseUrl = requireEnv("CUCKOO_API_URL").replace(/\/+$/, "");
  const indicator = classifyTarget(target);
  const headers = optionalBearerHeaders("CUCKOO_API_KEY");

  if (indicator.kind === "hash") {
    const algorithm = indicator.value.length === 64 ? "sha256" : indicator.value.length === 40 ? "sha1" : "md5";
    const details = await fetchJson(`${baseUrl}/files/view/${algorithm}/${encodeURIComponent(indicator.value)}`, {
      headers,
      allow404: true
    });
    return runResult("cuckoo-sandbox", "Cuckoo Sandbox", target, "ok", "Cuckoo returned file analysis lookup data.", {
      hash: indicator.value,
      algorithm,
      raw: shrink(details)
    });
  }

  if (indicator.kind === "url") {
    const details = await fetchJson(`${baseUrl}/tasks/list`, { headers, allow404: true });
    return runResult("cuckoo-sandbox", "Cuckoo Sandbox", target, "ok", "Cuckoo service is reachable. URL detonation is intentionally not auto-submitted from the browser.", {
      queryUrl: indicator.value,
      raw: shrink(details)
    });
  }

  const hash = getTargetHash(target);
  if (hash) {
    const details = await fetchJson(`${baseUrl}/files/view/sha256/${encodeURIComponent(hash)}`, {
      headers,
      allow404: true
    });
    return runResult("cuckoo-sandbox", "Cuckoo Sandbox", target, "ok", "Cuckoo returned local file hash lookup data.", {
      hash,
      raw: shrink(details)
    });
  }

  return unsupportedRun("cuckoo-sandbox", "Cuckoo Sandbox", target, "Use a hash, local file path, or URL.");
}

async function runJoeSandbox(target: string) {
  const key = requireEnv("JOE_SANDBOX_API_KEY");
  const baseUrl = (process.env.JOE_SANDBOX_API_URL?.trim() || "https://jbxcloud.joesecurity.org/api").replace(/\/+$/, "");
  const query = getSearchableIndicator(target);
  const details = await fetchJson(`${baseUrl}/analysis/search?apikey=${encodeURIComponent(key)}&q=${encodeURIComponent(query)}`);
  return runResult("joe-sandbox", "Joe Sandbox", target, "ok", "Joe Sandbox returned analysis search data.", {
    query,
    raw: shrink(details)
  });
}

async function runAnyRun(target: string) {
  const key = requireEnv("ANYRUN_API_KEY");
  const baseUrl = (process.env.ANYRUN_API_URL?.trim() || "https://api.any.run").replace(/\/+$/, "");
  const template = process.env.ANYRUN_LOOKUP_PATH?.trim() || "/v1/analysis/search?query={target}";
  const query = getSearchableIndicator(target);
  const pathTemplate = template.startsWith("/") ? template : `/${template}`;
  const lookupPath = pathTemplate.replace("{target}", encodeURIComponent(query));
  const authScheme = process.env.ANYRUN_API_AUTH_SCHEME?.trim() || "Bearer";
  const details = await fetchJson(`${baseUrl}${lookupPath}`, {
    headers: {
      Authorization: `${authScheme} ${key}`,
      Accept: "application/json"
    }
  });
  return runResult("anyrun", "Any.Run", target, "ok", "Any.Run returned lookup data from the configured endpoint.", {
    query,
    endpoint: lookupPath.replace(encodeURIComponent(query), "{target}"),
    raw: shrink(details)
  });
}

async function runSecurityHeaders(target: string) {
  const key = requireEnv("SECURITYHEADERS_API_KEY");
  const scanUrl = normalizeHttpTarget(target);
  const details = await fetchJson(`https://api.securityheaders.com/?q=${encodeURIComponent(scanUrl)}&hide=on&followRedirects=on`, {
    headers: { "x-api-key": key }
  });
  const grade = getNested(details, ["summary", "grade"]);
  return runResult("securityheaders", "SecurityHeaders.com", target, "ok", grade ? `SecurityHeaders.com grade: ${String(grade)}.` : "SecurityHeaders.com returned header analysis data.", {
    scanUrl,
    grade,
    raw: shrink(details)
  });
}

async function dohQuery(baseUrl: string, host: string) {
  const records = await Promise.all(
    ["A", "AAAA", "MX", "TXT"].map(async (type) => {
      const separator = baseUrl.includes("?") ? "&" : "?";
      const data = await fetchJson(`${baseUrl}${separator}name=${encodeURIComponent(host)}&type=${type}`, {
        headers: { Accept: "application/dns-json" }
      });
      return [type, shrink(data)] as const;
    })
  );
  return Object.fromEntries(records);
}

async function fetchZapJson(endpoint: string, params: Record<string, string> = {}) {
  const baseUrl = requireEnv("ZAP_API_URL").replace(/\/+$/, "");
  const apiKey = requireEnv("ZAP_API_KEY");
  const url = new URL(`${baseUrl}/JSON/${endpoint}/`);
  url.searchParams.set("apikey", apiKey);
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.set(key, value);
  }
  return fetchJson(url.href, { signal: AbortSignal.timeout(12000) });
}

function missingEnvVars(envVars: readonly string[] | undefined) {
  return (envVars ?? []).filter((name) => !process.env[name]?.trim());
}

function requireEnv(name: string) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`${name} is not configured`);
  return value;
}

async function fetchJson(url: string, init?: RequestInit & { allow404?: boolean }) {
  const response = await fetch(url, {
    ...init,
    signal: init?.signal ?? AbortSignal.timeout(9000)
  });
  if (!response.ok && !(init?.allow404 && response.status === 404)) {
    const text = await response.text().catch(() => "");
    throw new Error(`HTTP ${response.status}${text ? `: ${text.slice(0, 180)}` : ""}`);
  }
  if (response.status === 404 && init?.allow404) return [];
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("json")) return response.json();
  return { text: (await response.text()).slice(0, 5000), contentType };
}

function classifyTarget(target: string): { kind: "url" | "domain" | "ip" | "hash" | "email"; value: string; host?: string } {
  const trimmed = target.trim();
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) return { kind: "email", value: trimmed.toLowerCase() };
  if (/^(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/i.test(trimmed)) return { kind: "hash", value: trimmed.toLowerCase() };
  if (/^https?:\/\//i.test(trimmed)) {
    const url = new URL(trimmed);
    return { kind: "url", value: url.href, host: url.hostname.toLowerCase() };
  }
  if (net.isIP(trimmed)) return { kind: "ip", value: trimmed };
  const host = trimmed.replace(/^https?:\/\//i, "").replace(/\/.*$/, "").toLowerCase();
  return { kind: "domain", value: host, host };
}

async function assertSafePublicTarget(target: string) {
  const indicator = classifyTarget(target);
  const host = indicator.kind === "url" || indicator.kind === "domain" ? indicator.host ?? indicator.value : indicator.kind === "ip" ? indicator.value : null;
  if (!host) return;
  rejectInternalHost(host);
  const records = await dns.lookup(host, { all: true }).catch(() => []);
  if (records.some((record) => isPrivateAddress(record.address))) {
    throw new Error("Private, loopback, link-local, and internal targets are blocked");
  }
}

function rejectInternalHost(host: string) {
  const lower = host.toLowerCase();
  if (lower === "localhost" || lower.endsWith(".local") || lower.endsWith(".internal") || lower.endsWith(".lan")) {
    throw new Error("Private, loopback, link-local, and internal targets are blocked");
  }
  if (net.isIP(lower) && isPrivateAddress(lower)) {
    throw new Error("Private, loopback, link-local, and internal targets are blocked");
  }
}

function isPrivateAddress(address: string) {
  if (net.isIPv4(address)) {
    const parts = address.split(".").map(Number);
    const [a = 0, b = 0] = parts;
    return a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 0 && b === 0);
  }
  if (net.isIPv6(address)) {
    const lower = address.toLowerCase();
    return lower === "::1" || lower.startsWith("fc") || lower.startsWith("fd") || lower.startsWith("fe80:");
  }
  return false;
}

function runResult(
  toolId: SecurityIntegrationId,
  toolName: string,
  target: string,
  status: SecurityIntegrationRunResult["status"],
  summary: string,
  details: Record<string, unknown>
): SecurityIntegrationRunResult {
  return {
    toolId,
    toolName,
    target,
    status,
    summary,
    details,
    createdAt: new Date().toISOString()
  };
}

function unsupportedRun(toolId: SecurityIntegrationId, toolName: string, target: string, guidance: string) {
  return runResult(toolId, toolName, target, "not_supported", guidance, { guidance });
}

function summarizeStats(provider: string, stats: Record<string, unknown> | undefined) {
  if (!stats) return `${provider} returned reputation metadata.`;
  return `${provider}: ${stats.malicious ?? 0} malicious, ${stats.suspicious ?? 0} suspicious, ${stats.harmless ?? 0} harmless.`;
}

function getNested(value: unknown, path: Array<string | number>): unknown {
  return path.reduce<unknown>((current, key) => {
    if (!current || typeof current !== "object") return undefined;
    return (current as Record<string | number, unknown>)[key];
  }, value);
}

function getNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function getString(value: unknown) {
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return undefined;
}

function settledValue(result: PromiseSettledResult<unknown>) {
  if (result.status === "fulfilled") return shrink(result.value);
  return {
    error: result.reason instanceof Error ? result.reason.message : "Request failed"
  };
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function truncate(value: string | undefined, length: number) {
  if (!value) return undefined;
  return value.length > length ? `${value.slice(0, length)}...` : value;
}

function parseNmapGrepable(stdout: string) {
  const portLine = stdout
    .split("\n")
    .find((line) => line.startsWith("Host:") && line.includes("Ports:"));
  const portsText = portLine?.split("Ports:")[1]?.trim() ?? "";
  if (!portsText) return [];
  return portsText
    .split(",")
    .map((entry) => {
      const [port, state, protocol, owner, service] = entry.trim().split("/");
      return {
        port: Number(port),
        state: state || "unknown",
        protocol: protocol || "tcp",
        owner: owner || "",
        service: service || ""
      };
    })
    .filter((entry) => Number.isFinite(entry.port));
}

async function execFileLenient(file: string, args: string[], options: Parameters<typeof execFile>[2]) {
  try {
    return await execFile(file, args, options);
  } catch (error) {
    const maybe = error as { code?: number | string; stdout?: string | Buffer; stderr?: string | Buffer };
    if (maybe.code === 1 || maybe.code === "1") {
      return {
        stdout: String(maybe.stdout ?? ""),
        stderr: String(maybe.stderr ?? "")
      };
    }
    throw error;
  }
}

function normalizeHttpTarget(target: string) {
  const indicator = classifyTarget(target);
  if (indicator.kind === "url") return indicator.value;
  if (indicator.kind === "domain") return `https://${indicator.host ?? indicator.value}`;
  throw new Error("Use an HTTP(S) URL or public domain for this connector.");
}

function inferMobSfScanType(filePath: string) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".ipa") return "ipa";
  if (ext === ".appx") return "appx";
  return "apk";
}

function getTargetHash(target: string) {
  const indicator = classifyTarget(target);
  if (indicator.kind === "hash") return indicator.value;
  try {
    const targetPath = resolveLocalScanPath(target, { allowDirectory: false });
    return hashFile(targetPath);
  } catch {
    return undefined;
  }
}

function getSearchableIndicator(target: string) {
  const indicator = classifyTarget(target);
  if (indicator.kind === "url") return indicator.value;
  if (indicator.kind === "domain" || indicator.kind === "ip" || indicator.kind === "hash" || indicator.kind === "email") return indicator.value;
  return getTargetHash(target) ?? target.trim();
}

function hashFile(filePath: string) {
  const hash = crypto.createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex");
}

function optionalBearerHeaders(envName: string): Record<string, string> {
  const token = process.env[envName]?.trim();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function resolveLocalScanPath(target: string, options: { allowDirectory: boolean }) {
  const raw = target.trim();
  if (!raw) throw new Error("A local file or repository path is required");
  const inputPath = raw.startsWith("file://") ? new URL(raw).pathname : raw;
  const resolved = path.resolve(path.isAbsolute(inputPath) ? inputPath : path.join(repoRoot, inputPath));
  if (!allowedLocalRoots.some((root) => isPathInside(resolved, root))) {
    throw new Error("Local tool scans are limited to this project workspace and /private/tmp");
  }
  const stat = fs.statSync(resolved);
  if (stat.isDirectory() && !options.allowDirectory) throw new Error("This connector expects a file, not a directory");
  if (!stat.isFile() && !stat.isDirectory()) throw new Error("Target must be a regular file or directory");
  if (stat.isFile() && stat.size > 50 * 1024 * 1024) throw new Error("File is too large for the local quick scan limit");
  return resolved;
}

function isPathInside(candidate: string, root: string) {
  const relative = path.relative(path.resolve(root), candidate);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function localToolEnv() {
  return {
    ...process.env,
    HOME: process.env.SCAMSHIELD_TOOL_HOME?.trim() || defaultToolHome
  };
}

function semgrepToolEnv() {
  return {
    ...localToolEnv(),
    SSL_CERT_FILE: requireEnv("SEMGREP_SSL_CERT_FILE"),
    SEMGREP_SEND_METRICS: "off"
  };
}

function parseJsonLines(stdout: string) {
  return stdout
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      try {
        return JSON.parse(line) as Record<string, unknown>;
      } catch {
        return { line };
      }
    });
}

function sanitizeNucleiFinding(finding: Record<string, unknown>) {
  const info = finding.info && typeof finding.info === "object" ? (finding.info as Record<string, unknown>) : {};
  return {
    templateId: finding["template-id"],
    template: finding.template,
    matcher: finding["matcher-name"],
    severity: info.severity,
    name: info.name,
    type: finding.type,
    host: finding.host,
    matchedAt: finding["matched-at"],
    ip: finding.ip,
    timestamp: finding.timestamp
  };
}

function sanitizeZapAlert(alert: Record<string, unknown>) {
  return {
    name: getString(alert.name),
    risk: getString(alert.risk),
    confidence: getString(alert.confidence),
    url: getString(alert.url),
    method: getString(alert.method),
    param: getString(alert.param),
    evidence: getString(alert.evidence),
    cweid: getString(alert.cweid),
    wascid: getString(alert.wascid),
    description: truncate(getString(alert.description), 420),
    solution: truncate(getString(alert.solution), 420)
  };
}

function parseJson(stdout: string) {
  const trimmed = stdout.trim();
  if (!trimmed) return [];
  return JSON.parse(trimmed) as unknown;
}

function shrink(value: unknown): unknown {
  const json = JSON.stringify(value);
  if (json.length <= 14000) return value as Record<string, unknown>;
  return {
    truncated: true,
    preview: json.slice(0, 14000)
  };
}

function redactEmail(value: string) {
  return value.replace(/^(.).+(@.+)$/, "$1***$2");
}
