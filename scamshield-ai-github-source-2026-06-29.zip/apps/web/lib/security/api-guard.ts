import crypto from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";

const csrfCookieName = "scamshield_csrf";
const mutatingMethods = new Set(["POST", "PUT", "PATCH", "DELETE"]);

export function verifyCsrf(request: NextRequest) {
  if (!mutatingMethods.has(request.method)) return true;
  if (!isTrustedRequestOrigin(request)) return false;

  const cookieToken = request.cookies.get(csrfCookieName)?.value;
  const headerToken = request.headers.get("x-csrf-token");
  if (!cookieToken || !headerToken) return false;

  const left = Buffer.from(cookieToken);
  const right = Buffer.from(headerToken);
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

export function csrfError() {
  return NextResponse.json(
    {
      error: {
        code: "CSRF_INVALID",
        message: "Invalid or missing CSRF token"
      }
    },
    { status: 403 }
  );
}

export function requireApiGuard(request: NextRequest) {
  return verifyCsrf(request);
}

export function jsonError(message: string, status = 400, code = "BAD_REQUEST") {
  return NextResponse.json({ error: { code, message } }, { status });
}

export function hashForMatching(value: string) {
  return crypto.createHash("sha256").update(value.trim().toLowerCase()).digest("hex");
}

function isTrustedRequestOrigin(request: NextRequest) {
  const origin = request.headers.get("origin");
  const referer = request.headers.get("referer");
  const expectedOrigin = request.nextUrl.origin;
  const allowed = allowedOrigins(expectedOrigin);

  if (origin && !allowed.has(origin)) return false;
  if (!origin && referer) {
    try {
      if (!allowed.has(new URL(referer).origin)) return false;
    } catch {
      return false;
    }
  }

  return true;
}

function allowedOrigins(currentOrigin: string) {
  const origins = new Set<string>([currentOrigin]);
  const publicApiUrl = process.env.NEXT_PUBLIC_API_URL?.trim();
  const publicWebUrl = process.env.NEXT_PUBLIC_WEB_URL?.trim();
  const explicit = process.env.SCAMSHIELD_ALLOWED_ORIGINS?.trim();
  const vercelUrl = process.env.VERCEL_URL?.trim();

  for (const value of [publicApiUrl, publicWebUrl, vercelUrl ? `https://${vercelUrl}` : "", explicit ?? ""]) {
    for (const item of value?.split(",") ?? []) {
      const trimmed = item.trim();
      if (!trimmed) continue;
      try {
        origins.add(new URL(trimmed).origin);
      } catch {
        // Ignore malformed environment entries instead of widening trust.
      }
    }
  }

  return origins;
}
