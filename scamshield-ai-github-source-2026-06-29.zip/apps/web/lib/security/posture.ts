import { maxUploadBytes } from "@/lib/multiscan/utils";

export type SecurityPostureControl = {
  id: string;
  label: string;
  status: "enforced" | "configured" | "limited" | "needs_setup";
  detail: string;
};

export type SecurityPosture = {
  generatedAt: string;
  publicAttackSurface: {
    productionPorts: string[];
    closedByDesign: string[];
    notes: string[];
  };
  controls: SecurityPostureControl[];
  scanRuntime: {
    maxUploadMb: number;
    activeLocalTools: boolean;
    activeToolTimeoutMs: number;
    urlNetworkChecks: boolean;
    rawInputStoredByDefault: false;
  };
  infrastructureChecklist: string[];
};

export function getSecurityPosture(): SecurityPosture {
  const activeLocalTools = process.env.SCAMSHIELD_ENABLE_ACTIVE_TOOLS === "1";
  const mongoConfigured = Boolean((process.env.MONGODB_URI ?? process.env.MONGODB_ATLAS_URI)?.trim());
  const allowedOriginsConfigured = Boolean(process.env.SCAMSHIELD_ALLOWED_ORIGINS?.trim() || process.env.NEXT_PUBLIC_WEB_URL?.trim());

  return {
    generatedAt: new Date().toISOString(),
    publicAttackSurface: {
      productionPorts: ["443/HTTPS via Vercel edge"],
      closedByDesign: [
        "No public SSH port in the Vercel deployment",
        "No public MongoDB port from the web app",
        "No exposed local scanner daemon port",
        "Active Security Lab probes are disabled unless explicitly enabled and authorized"
      ],
      notes: [
        "Vercel deployments do not expose arbitrary inbound ports from this Next.js app.",
        "Database access should stay on MongoDB Atlas IP allowlists or private access rules.",
        "If you run a custom VPS later, expose only 80/443 and keep admin, database, and scanner worker ports private."
      ]
    },
    controls: [
      {
        id: "secure-headers",
        label: "Secure response headers",
        status: "enforced",
        detail: "CSP, frame denial, MIME sniffing protection, referrer policy, permissions policy, HSTS, COOP, and CORP are set at the app edge."
      },
      {
        id: "csrf-origin",
        label: "CSRF and origin guard",
        status: "enforced",
        detail: "Mutating API calls require a same-origin CSRF token and trusted Origin/Referer checks."
      },
      {
        id: "rate-limits",
        label: "API rate limits",
        status: "enforced",
        detail: "Scanner, report, admin, integration, terminal, and Security Lab routes are throttled independently."
      },
      {
        id: "target-guard",
        label: "Private target blocking",
        status: "enforced",
        detail: "Security Lab blocks localhost, private, link-local, .local, .internal, and .lan targets."
      },
      {
        id: "active-tools",
        label: "Active tool isolation",
        status: activeLocalTools ? "configured" : "limited",
        detail: activeLocalTools
          ? "Active/local tools are enabled; keep them isolated to a dedicated worker or locked-down host."
          : "Active/local tools remain disabled. Passive checks and safe metadata scans continue to work."
      },
      {
        id: "storage",
        label: "Persistent storage",
        status: mongoConfigured ? "configured" : "needs_setup",
        detail: mongoConfigured
          ? "MongoDB is configured for redacted scan history, reports, and audit-ready records."
          : "MongoDB is not configured; the app falls back to temporary memory storage."
      },
      {
        id: "trusted-origins",
        label: "Trusted browser origins",
        status: allowedOriginsConfigured ? "configured" : "limited",
        detail: allowedOriginsConfigured
          ? "Trusted origins are explicitly configured for production browser requests."
          : "Same-origin protection is active. Set SCAMSHIELD_ALLOWED_ORIGINS or NEXT_PUBLIC_WEB_URL for stricter production allowlisting."
      }
    ],
    scanRuntime: {
      maxUploadMb: Math.round(maxUploadBytes / 1024 / 1024),
      activeLocalTools,
      activeToolTimeoutMs: Number(process.env.SCAMSHIELD_LOCAL_TOOL_TIMEOUT_MS ?? 12_000),
      urlNetworkChecks: process.env.SCAMSHIELD_ENABLE_URL_NETWORK !== "0",
      rawInputStoredByDefault: false
    },
    infrastructureChecklist: [
      "Keep Vercel as HTTPS-only public ingress.",
      "Do not expose MongoDB, scanner workers, ZAP, MobSF, Cuckoo, or local CLIs to the internet.",
      "Use MongoDB Atlas IP allowlisting and least-privilege database users.",
      "Put Cloudflare WAF/DDoS protection in front of the production domain when using a custom domain.",
      "Rotate leaked API keys and keep all provider keys in server-side environment variables.",
      "Run dependency audit and package updates before each production release."
    ]
  };
}
