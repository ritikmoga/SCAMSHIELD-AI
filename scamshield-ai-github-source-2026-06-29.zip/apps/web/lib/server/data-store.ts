import crypto from "node:crypto";
import { MongoClient, type Collection, type Db } from "mongodb";
import type { NextRequest, NextResponse } from "next/server";
import type { ScanType } from "@scamshield/shared";
import { normalizeInput, type ExtractedIndicators } from "@/lib/indicators";
import { buildSafePreview } from "@/lib/redaction";
import type { ScanResult } from "@/lib/risk-engine/types";

const guestCookieName = "scamshield_guest";
const mongoUri = process.env.MONGODB_URI?.trim() || process.env.MONGODB_ATLAS_URI?.trim();
const mongoDbName = process.env.MONGODB_DB?.trim() || "scamshield_ai";

type StorageMode = "mongodb" | "memory";

export type StoredScanHistoryItem = {
  id: string;
  type: ScanType;
  preview: string;
  riskScore: number;
  verdict: string;
  verdictLabel?: string;
  confidenceScore: number;
  createdAt: string;
};

export type StoredReport = {
  id: string;
  type: ScanType;
  valueHash: string;
  valuePreview: string;
  descriptionPreview: string;
  sourcePlatform: string;
  status: "Pending" | "Verified" | "Rejected" | "Duplicate" | "Escalated";
  duplicates: number;
  risk: string;
  riskHints: string[];
  submittedAt: string;
  updatedAt?: string;
};

type StoredScanDocument = StoredScanHistoryItem & {
  guestId: string;
  inputHash: string;
  result: ScanResult;
  source: {
    ipHash: string;
    userAgent: string;
  };
};

type StoredReportDocument = StoredReport & {
  guestId: string;
  userContactHash?: string;
  evidenceFile?: {
    name: string;
    type: string;
    size: number;
  };
  source: {
    ipHash: string;
    userAgent: string;
  };
};

type StoredAuditLog = {
  id: string;
  action: string;
  entityType: "report" | "scan";
  entityId: string;
  metadata: Record<string, unknown>;
  createdAt: string;
  source: {
    ipHash: string;
    userAgent: string;
  };
};

const memory = globalThis as typeof globalThis & {
  __scamshieldMemoryStore?: {
    scans: StoredScanDocument[];
    reports: StoredReportDocument[];
    auditLogs: StoredAuditLog[];
  };
  __scamshieldMongoClient?: Promise<MongoClient | null>;
  __scamshieldMongoIndexes?: Promise<void>;
  __scamshieldMongoLastError?: string;
};

function memoryStore() {
  memory.__scamshieldMemoryStore ??= {
    scans: [],
    reports: [],
    auditLogs: []
  };
  return memory.__scamshieldMemoryStore;
}

async function getDb(): Promise<Db | null> {
  if (!mongoUri) return null;
  memory.__scamshieldMongoClient ??= MongoClient.connect(mongoUri, {
    maxPoolSize: 8,
    minPoolSize: 0,
    maxIdleTimeMS: 30_000,
    serverSelectionTimeoutMS: 5000,
    connectTimeoutMS: 5000
  })
    .then((client) => {
      memory.__scamshieldMongoLastError = undefined;
      return client;
    })
    .catch((error: unknown) => {
      memory.__scamshieldMongoClient = undefined;
      memory.__scamshieldMongoLastError = error instanceof Error ? buildSafePreview(error.message, 180) : "MongoDB connection failed";
      return null;
    });
  const client = await memory.__scamshieldMongoClient;
  const db = client?.db(mongoDbName) ?? null;
  if (db) await ensureMongoIndexes(db);
  return db;
}

async function ensureMongoIndexes(db: Db) {
  memory.__scamshieldMongoIndexes ??= Promise.all([
    db.collection<StoredScanDocument>("scan_results").createIndexes([
      { key: { id: 1 }, name: "scan_id_unique", unique: true },
      { key: { guestId: 1, createdAt: -1 }, name: "scan_guest_history" },
      { key: { inputHash: 1, createdAt: -1 }, name: "scan_duplicate_matching" }
    ]),
    db.collection<StoredReportDocument>("community_reports").createIndexes([
      { key: { id: 1 }, name: "report_id_unique", unique: true },
      { key: { valueHash: 1, status: 1 }, name: "report_indicator_status" },
      { key: { status: 1, submittedAt: -1 }, name: "report_moderation_queue" }
    ]),
    db.collection<StoredAuditLog>("admin_audit_logs").createIndexes([
      { key: { id: 1 }, name: "audit_id_unique", unique: true },
      { key: { entityType: 1, entityId: 1, createdAt: -1 }, name: "audit_entity_history" }
    ])
  ])
    .then(() => undefined)
    .catch((error: unknown) => {
      memory.__scamshieldMongoIndexes = undefined;
      memory.__scamshieldMongoLastError = error instanceof Error ? buildSafePreview(error.message, 180) : "MongoDB index setup failed";
    });
  await memory.__scamshieldMongoIndexes;
}

export async function getStorageHealth() {
  const startedAt = performance.now();
  if (!mongoUri) {
    return {
      configured: false,
      connected: false,
      mode: "memory" as const,
      database: mongoDbName,
      latencyMs: 0,
      message: "MONGODB_URI is not configured. Temporary memory storage is active."
    };
  }

  const db = await getDb();
  if (!db) {
    return {
      configured: true,
      connected: false,
      mode: "memory" as const,
      database: mongoDbName,
      latencyMs: Math.round(performance.now() - startedAt),
      message: memory.__scamshieldMongoLastError || "MongoDB is configured but unavailable. Temporary memory storage is active."
    };
  }

  try {
    await db.command({ ping: 1 });
    return {
      configured: true,
      connected: true,
      mode: "mongodb" as const,
      database: mongoDbName,
      latencyMs: Math.round(performance.now() - startedAt),
      message: "MongoDB connection and required indexes are ready."
    };
  } catch (error) {
    return {
      configured: true,
      connected: false,
      mode: "memory" as const,
      database: mongoDbName,
      latencyMs: Math.round(performance.now() - startedAt),
      message: error instanceof Error ? buildSafePreview(error.message, 180) : "MongoDB ping failed safely."
    };
  }
}

async function collection<T extends object>(name: string): Promise<{ collection: Collection<T> | null; mode: StorageMode }> {
  const db = await getDb();
  if (!db) return { collection: null, mode: "memory" };
  return { collection: db.collection<T>(name), mode: "mongodb" };
}

export function getGuestId(request: NextRequest) {
  return request.cookies.get(guestCookieName)?.value || crypto.randomUUID();
}

export function attachGuestCookie(response: NextResponse, guestId: string) {
  response.cookies.set(guestCookieName, guestId, {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30
  });
}

export function hashForMatching(value: string) {
  return crypto.createHash("sha256").update(normalizeInput(value).toLowerCase()).digest("hex");
}

export async function saveScanResult(input: {
  request: NextRequest;
  guestId: string;
  originalInput: string;
  result: ScanResult;
}) {
  const now = input.result.createdAt || new Date().toISOString();
  const doc: StoredScanDocument = {
    id: input.result.id,
    type: input.result.type,
    preview: input.result.inputPreview,
    riskScore: input.result.riskScore,
    verdict: input.result.verdict,
    verdictLabel: input.result.verdictLabel,
    confidenceScore: input.result.confidenceScore,
    createdAt: now,
    guestId: input.guestId,
    inputHash: hashForMatching(input.originalInput),
    result: input.result,
    source: requestSource(input.request)
  };

  const store = await collection<StoredScanDocument>("scan_results");
  if (store.collection) {
    await store.collection.updateOne({ id: doc.id }, { $set: doc }, { upsert: true });
  } else {
    const memoryDb = memoryStore();
    memoryDb.scans = [doc, ...memoryDb.scans.filter((scan) => scan.id !== doc.id)].slice(0, 1000);
  }
  return { storageMode: store.mode };
}

export async function listScanHistory(guestId: string) {
  const store = await collection<StoredScanDocument>("scan_results");
  const scans = store.collection
    ? await store.collection
        .find({ guestId }, { projection: { result: 0, inputHash: 0, source: 0, guestId: 0 } })
        .sort({ createdAt: -1 })
        .limit(100)
        .toArray()
    : memoryStore().scans.filter((scan) => scan.guestId === guestId).sort(sortNewest).slice(0, 100);

  return {
    demo: false,
    storageMode: store.mode,
    scans: scans.map(toHistoryItem),
    privacy: "Saved history contains redacted previews, hashes, scores, and report metadata only. Raw scan input is not stored by default."
  };
}

export async function deleteScanHistory(guestId: string) {
  const store = await collection<StoredScanDocument>("scan_results");
  if (store.collection) {
    const result = await store.collection.deleteMany({ guestId });
    return { storageMode: store.mode, deleted: result.deletedCount ?? 0 };
  }
  const db = memoryStore();
  const before = db.scans.length;
  db.scans = db.scans.filter((scan) => scan.guestId !== guestId);
  return { storageMode: store.mode, deleted: before - db.scans.length };
}

export async function deleteScanById(guestId: string, id: string) {
  const store = await collection<StoredScanDocument>("scan_results");
  if (store.collection) {
    const result = await store.collection.deleteOne({ guestId, id });
    return { storageMode: store.mode, deleted: result.deletedCount ?? 0 };
  }
  const db = memoryStore();
  const before = db.scans.length;
  db.scans = db.scans.filter((scan) => !(scan.guestId === guestId && scan.id === id));
  return { storageMode: store.mode, deleted: before - db.scans.length };
}

export async function saveCommunityReport(input: {
  request: NextRequest;
  guestId: string;
  type: ScanType;
  value: string;
  description: string;
  sourcePlatform: string;
  userContact?: string;
  evidenceFile?: File;
}) {
  const valueHash = hashForMatching(input.value);
  const now = new Date().toISOString();
  const existing = await getReportDuplicateCount(valueHash);
  const doc: StoredReportDocument = {
    id: `rep-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
    type: input.type,
    valueHash,
    valuePreview: buildSafePreview(input.value, 160),
    descriptionPreview: buildSafePreview(input.description, 220),
    sourcePlatform: input.sourcePlatform || "Unknown",
    status: "Pending",
    duplicates: existing + 1,
    risk: inferReportRisk(input.type, input.value, input.description),
    riskHints: inferReportHints(input.value, input.description),
    submittedAt: now,
    guestId: input.guestId,
    userContactHash: input.userContact ? hashForMatching(input.userContact) : undefined,
    evidenceFile: input.evidenceFile
      ? {
          name: input.evidenceFile.name,
          type: input.evidenceFile.type,
          size: input.evidenceFile.size
        }
      : undefined,
    source: requestSource(input.request)
  };

  const store = await collection<StoredReportDocument>("community_reports");
  if (store.collection) {
    await store.collection.insertOne(doc);
  } else {
    memoryStore().reports = [doc, ...memoryStore().reports].slice(0, 2000);
  }
  return { report: doc, storageMode: store.mode };
}

export async function listAdminReports(status?: string) {
  const normalizedStatus = normalizeStatus(status);
  const store = await collection<StoredReportDocument>("community_reports");
  const reports = store.collection
    ? await store.collection
        .find(normalizedStatus ? { status: normalizedStatus } : {})
        .sort({ submittedAt: -1 })
        .limit(200)
        .toArray()
    : memoryStore().reports.filter((report) => !normalizedStatus || report.status === normalizedStatus).sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));

  return {
    demo: false,
    storageMode: store.mode,
    privateUserDataPublic: false,
    auditLogging: "Moderator actions are recorded with redacted metadata. User contact hashes are not exposed.",
    reports: reports.map(toAdminReport)
  };
}

export async function updateAdminReportStatus(input: {
  request: NextRequest;
  reportId: string;
  status: StoredReport["status"];
  note?: string;
}) {
  const now = new Date().toISOString();
  const store = await collection<StoredReportDocument>("community_reports");
  let matched = 0;
  if (store.collection) {
    const result = await store.collection.updateOne({ id: input.reportId }, { $set: { status: input.status, updatedAt: now } });
    matched = result.matchedCount ?? 0;
  } else {
    const report = memoryStore().reports.find((item) => item.id === input.reportId);
    if (report) {
      report.status = input.status;
      report.updatedAt = now;
      matched = 1;
    }
  }

  const auditLog: StoredAuditLog = {
    id: `audit-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
    action: "moderation_status_update",
    entityType: "report",
    entityId: input.reportId,
    metadata: {
      status: input.status,
      note: input.note ? buildSafePreview(input.note, 180) : undefined
    },
    createdAt: now,
    source: requestSource(input.request)
  };
  await saveAuditLog(auditLog);
  return { matched, auditLog, storageMode: store.mode };
}

export async function getCommunityReportSummary(input: string, indicators: ExtractedIndicators) {
  const candidates = candidateValues(input, indicators);
  if (!candidates.length) return { totalReports: 0, verifiedReports: 0, pendingReports: 0 };
  const hashes = candidates.map(hashForMatching);
  const store = await collection<StoredReportDocument>("community_reports");
  const reports = store.collection
    ? await store.collection.find({ valueHash: { $in: hashes }, status: { $in: ["Pending", "Verified"] } }).limit(200).toArray()
    : memoryStore().reports.filter((report) => hashes.includes(report.valueHash) && ["Pending", "Verified"].includes(report.status));

  return {
    totalReports: reports.reduce((sum, report) => sum + Math.max(1, report.duplicates || 1), 0),
    verifiedReports: reports.filter((report) => report.status === "Verified").length,
    pendingReports: reports.filter((report) => report.status === "Pending").length
  };
}

async function getReportDuplicateCount(valueHash: string) {
  const store = await collection<StoredReportDocument>("community_reports");
  if (store.collection) return store.collection.countDocuments({ valueHash });
  return memoryStore().reports.filter((report) => report.valueHash === valueHash).length;
}

async function saveAuditLog(log: StoredAuditLog) {
  const store = await collection<StoredAuditLog>("admin_audit_logs");
  if (store.collection) {
    await store.collection.insertOne(log);
  } else {
    memoryStore().auditLogs = [log, ...memoryStore().auditLogs].slice(0, 1000);
  }
}

function toHistoryItem(scan: Partial<StoredScanDocument>): StoredScanHistoryItem {
  return {
    id: String(scan.id),
    type: scan.type as ScanType,
    preview: String(scan.preview ?? ""),
    riskScore: Number(scan.riskScore ?? 0),
    verdict: String(scan.verdict ?? "Safe"),
    verdictLabel: scan.verdictLabel,
    confidenceScore: Number(scan.confidenceScore ?? 0),
    createdAt: String(scan.createdAt ?? new Date().toISOString())
  };
}

function toAdminReport(report: Partial<StoredReportDocument>): StoredReport {
  return {
    id: String(report.id),
    type: report.type as ScanType,
    valueHash: String(report.valueHash ?? ""),
    valuePreview: String(report.valuePreview ?? ""),
    descriptionPreview: String(report.descriptionPreview ?? ""),
    sourcePlatform: String(report.sourcePlatform ?? "Unknown"),
    status: normalizeStatus(report.status) ?? "Pending",
    duplicates: Number(report.duplicates ?? 1),
    risk: String(report.risk ?? "Suspicious"),
    riskHints: Array.isArray(report.riskHints) ? report.riskHints.map(String) : [],
    submittedAt: String(report.submittedAt ?? new Date().toISOString()),
    updatedAt: report.updatedAt
  };
}

function normalizeStatus(status?: string | null): StoredReport["status"] | undefined {
  if (!status || status === "All") return undefined;
  const lower = status.toLowerCase();
  if (lower === "pending") return "Pending";
  if (lower === "verified") return "Verified";
  if (lower === "rejected") return "Rejected";
  if (lower === "duplicate") return "Duplicate";
  if (lower === "escalated") return "Escalated";
  return undefined;
}

function candidateValues(input: string, indicators: ExtractedIndicators) {
  return Array.from(
    new Set([
      normalizeInput(input),
      ...indicators.urls,
      ...indicators.domains,
      ...indicators.phoneNumbers,
      ...indicators.upiIds,
      ...indicators.emails
    ].filter((value) => value && value.length >= 3))
  );
}

function inferReportRisk(type: ScanType, value: string, description: string) {
  const text = `${type} ${value} ${description}`.toLowerCase();
  if (/otp|upi pin|cvv|password|kyc|account blocked|remote access|anydesk|deposit|security fee/.test(text)) return "Dangerous";
  if (/urgent|refund|verify|login|payment|collect|prize|job|discount/.test(text)) return "High Risk";
  return "Suspicious";
}

function inferReportHints(value: string, description: string) {
  const text = `${value} ${description}`.toLowerCase();
  const hints = [
    [/kyc|account blocked|verify|login/, "phishing lure"],
    [/upi|collect|refund|payment/, "payment pressure"],
    [/otp|password|cvv|pin/, "sensitive credential request"],
    [/remote access|anydesk|teamviewer/, "remote access request"],
    [/job|registration fee|security deposit|training fee/, "job fee request"],
    [/prize|lottery|reward|cashback/, "reward lure"]
  ] as const;
  return hints.filter(([pattern]) => pattern.test(text)).map(([, hint]) => hint).slice(0, 5);
}

function sortNewest(a: { createdAt: string }, b: { createdAt: string }) {
  return b.createdAt.localeCompare(a.createdAt);
}

function requestSource(request: NextRequest) {
  return {
    ipHash: hashForMatching(request.headers.get("x-forwarded-for")?.split(",")[0] ?? "unknown"),
    userAgent: buildSafePreview(request.headers.get("user-agent") ?? "unknown", 180)
  };
}
