export type ScanType =
  | "url"
  | "message"
  | "email"
  | "upi"
  | "qr"
  | "screenshot"
  | "phone"
  | "job"
  | "shopping"
  | "social";

export type RiskLevel = "Safe" | "Low Risk" | "Suspicious" | "High Risk" | "Dangerous";

export type DetectionSignalCategory =
  | "identity"
  | "financial"
  | "urgency"
  | "technical"
  | "reputation"
  | "privacy"
  | "social-engineering"
  | "content";

export interface DetectionSignal {
  id: string;
  label: string;
  category: DetectionSignalCategory;
  severity: "info" | "low" | "medium" | "high" | "critical";
  weight: number;
  evidence?: string;
}

export interface ScanBreakdown {
  ai: number;
  reputation: number;
  heuristics: number;
  userReports: number;
  technical: number;
}

export interface ScanResult {
  id?: string;
  type: ScanType;
  inputPreview: string;
  riskScore: number;
  riskLevel: RiskLevel;
  confidence: number;
  explanation: string;
  recommendedAction: string;
  signals: DetectionSignal[];
  breakdown: ScanBreakdown;
  extracted?: {
    urls: string[];
    phoneNumbers: string[];
    upiIds: string[];
    emails: string[];
    decodedQr?: string;
    ocrText?: string;
  };
  analysis?: {
    engine: string;
    source?: string;
    url?: Record<string, unknown>;
    text?: Record<string, unknown>;
    file?: Record<string, unknown>;
  };
  createdAt?: string;
}

export interface ScamReportInput {
  type: ScanType;
  value: string;
  description: string;
  evidenceUrls?: string[];
}

export interface EducationTopic {
  slug: string;
  title: string;
  category: string;
  readingMinutes: number;
  summary: string;
  checklist: string[];
}

export type SecurityLabScanType = "file" | "link" | "dns" | "tls" | "headers" | "ports" | "exposure" | "osint";

export type SecurityFindingSeverity = "info" | "low" | "medium" | "high" | "critical";

export interface SecurityFinding {
  id: string;
  title: string;
  severity: SecurityFindingSeverity;
  category: "malware" | "network" | "dns" | "tls" | "headers" | "exposure" | "privacy" | "policy";
  evidence?: string;
  recommendation: string;
}

export interface SecurityLabResult {
  id?: string;
  type: SecurityLabScanType;
  target: string;
  riskScore: number;
  riskLevel: RiskLevel;
  summary: string;
  authorizedRequired: boolean;
  authorized: boolean;
  findings: SecurityFinding[];
  details: Record<string, unknown>;
  createdAt: string;
}

export const RISK_LEVELS: Record<RiskLevel, { min: number; max: number; color: string; tone: string }> = {
  Safe: { min: 0, max: 19, color: "#42f58a", tone: "No major scam indicators found." },
  "Low Risk": { min: 20, max: 39, color: "#8ee88e", tone: "Some weak indicators need attention." },
  Suspicious: { min: 40, max: 59, color: "#ffd166", tone: "Several warning signs are present." },
  "High Risk": { min: 60, max: 79, color: "#ff9f1c", tone: "Strong scam indicators detected." },
  Dangerous: { min: 80, max: 100, color: "#ff4b6e", tone: "Likely scam or malicious activity." }
};

export const SCAN_TYPE_LABELS: Record<ScanType, string> = {
  url: "URL Scanner",
  message: "Message Checker",
  email: "Email Checker",
  upi: "UPI Checker",
  qr: "QR Scanner",
  screenshot: "Screenshot Analyzer",
  phone: "Phone Risk Check",
  job: "Job Offer Check",
  shopping: "Shopping Site Check",
  social: "Social Profile Check"
};

const severityRank: Record<DetectionSignal["severity"], number> = {
  info: 1,
  low: 2,
  medium: 3,
  high: 4,
  critical: 5
};

export function clampScore(value: number): number {
  return Math.max(0, Math.min(100, Math.round(value)));
}

export function getRiskLevel(score: number): RiskLevel {
  if (score >= 80) return "Dangerous";
  if (score >= 60) return "High Risk";
  if (score >= 40) return "Suspicious";
  if (score >= 20) return "Low Risk";
  return "Safe";
}

export function redactSensitive(input: string): string {
  return input
    .replace(/\b\d{6}\b/g, "[OTP]")
    .replace(/\b\d{12,19}\b/g, "[NUMBER]")
    .replace(/\b([A-Z]{4}0[A-Z0-9]{6})\b/gi, "[IFSC]")
    .replace(/([a-z0-9._%+-])[a-z0-9._%+-]*(@[a-z0-9.-]+\.[a-z]{2,})/gi, "$1***$2")
    .slice(0, 280);
}

export function extractIndicators(input: string) {
  const urls = Array.from(input.matchAll(/\bhttps?:\/\/[^\s<>"')]+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s<>"')]+)?/gi)).map(
    (match) => normalizeUrl(match[0])
  );
  const phoneNumbers = Array.from(input.matchAll(/(?:\+?91[\s-]?)?[6-9]\d{9}\b/g)).map((match) => match[0]);
  const upiIds = Array.from(input.matchAll(/\b[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}\b/g)).map((match) => match[0]);
  const emails = Array.from(input.matchAll(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi)).map((match) => match[0]);

  return {
    urls: unique(urls),
    phoneNumbers: unique(phoneNumbers),
    upiIds: unique(upiIds),
    emails: unique(emails)
  };
}

export function normalizeUrl(rawUrl: string): string {
  const trimmed = rawUrl.trim().replace(/[),.;]+$/g, "");
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export function analyzeUrlHeuristics(rawUrl: string): DetectionSignal[] {
  const signals: DetectionSignal[] = [];
  const normalized = normalizeUrl(rawUrl);

  try {
    const url = new URL(normalized);
    const hostname = url.hostname.toLowerCase();
    const path = url.pathname.toLowerCase();
    const joined = `${hostname}${path}${url.search}`.toLowerCase();

    if (url.protocol !== "https:") {
      signals.push(signal("url-http", "URL does not use HTTPS", "technical", "high", 18, url.protocol));
    }

    if (/bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|cutt\.ly|shorturl|rebrand\.ly/i.test(hostname)) {
      signals.push(signal("url-shortener", "URL shortener hides the final destination", "technical", "medium", 14, hostname));
    }

    if (hostname.split(".").length > 4) {
      signals.push(signal("deep-subdomain", "Unusually deep subdomain chain", "identity", "medium", 12, hostname));
    }

    if (/-secure|-verify|-kyc|login-|support-|bank-|refund-|gift/i.test(hostname)) {
      signals.push(signal("brand-lure", "Domain uses trust or account-recovery lure words", "identity", "high", 18, hostname));
    }

    if (/\d{1,3}(?:\.\d{1,3}){3}/.test(hostname)) {
      signals.push(signal("raw-ip", "Raw IP address used instead of a recognizable domain", "technical", "high", 20, hostname));
    }

    if (/(xn--|%[0-9a-f]{2}|@)/i.test(rawUrl)) {
      signals.push(signal("obfuscated-url", "URL contains encoded or obfuscated characters", "technical", "high", 18, rawUrl.slice(0, 90)));
    }

    if (/(login|verify|password|otp|kyc|wallet|refund|claim|airdrop|free|bonus|urgent)/i.test(joined)) {
      signals.push(signal("danger-keywords", "URL path contains high-risk action words", "social-engineering", "medium", 12, path));
    }

    if (/(paytm|phonepe|gpay|sbi|hdfc|icici|axis|amazon|flipkart|whatsapp|telegram)/i.test(joined) && !isLikelyOfficialDomain(hostname)) {
      signals.push(signal("possible-impersonation", "Possible brand impersonation", "identity", "critical", 28, hostname));
    }
  } catch {
    signals.push(signal("invalid-url", "Input is not a valid URL", "technical", "medium", 10, rawUrl.slice(0, 90)));
  }

  return signals;
}

export function analyzeTextHeuristics(input: string, scanType: ScanType = "message"): DetectionSignal[] {
  const lower = input.toLowerCase();
  const signals: DetectionSignal[] = [];
  const checks: Array<[RegExp, string, DetectionSignalCategory, DetectionSignal["severity"], number]> = [
    [/\botp\b|one[-\s]?time password|verification code|share.*code|कोड|ओटीपी/i, "Requests or references OTP/security codes", "privacy", "critical", 24],
    [/upi pin|pin डाल|pin share|enter.*pin|collect request|refund.*upi/i, "Mentions UPI PIN or collect/refund flow", "financial", "critical", 28],
    [/urgent|immediately|within \d+ (?:min|minutes|hours)|last chance|account.*block|kyc.*expire|तुरंत|अभी/i, "Uses urgency pressure", "urgency", "high", 18],
    [/click (?:here|link)|open.*link|verify.*link|login.*link|update.*kyc|complete.*kyc/i, "Pushes user to click a verification link", "social-engineering", "high", 18],
    [/refund|cashback|reward|prize|lottery|bonus|free gift|commission|investment.*return/i, "Promises money, rewards, or unrealistic returns", "financial", "high", 18],
    [/job.*registration|processing fee|security deposit|work from home.*earn|interview.*fee/i, "Job offer asks for fees or deposits", "financial", "high", 20],
    [/bank|debit card|credit card|netbanking|wallet|paytm|phonepe|gpay|customer care/i, "Uses finance or customer-care trust framing", "identity", "medium", 10],
    [/whatsapp|telegram|instagram|dating|friend request|romance|emergency|hospital/i, "Potential social relationship manipulation", "social-engineering", "medium", 12],
    [/password|cvv|card number|aadhaar|pan card|date of birth|mother'?s maiden/i, "Requests sensitive personal data", "privacy", "critical", 26],
    [/apk|download app|install.*app|remote access|anydesk|screen share|teamviewer/i, "Encourages app install or remote access", "technical", "critical", 28]
  ];

  for (const [pattern, label, category, severity, weight] of checks) {
    const match = lower.match(pattern);
    if (match) signals.push(signal(`text-${signals.length}-${label.toLowerCase().replace(/\W+/g, "-")}`, label, category, severity, weight, match[0]));
  }

  const extracted = extractIndicators(input);
  for (const url of extracted.urls) signals.push(...analyzeUrlHeuristics(url));

  if (scanType === "email" && /(from:|reply-to:|return-path:)/i.test(input) && /reply-to:.*@(gmail|yahoo|outlook)\./i.test(input)) {
    signals.push(signal("free-mail-replyto", "Business-looking email replies to a free mailbox", "identity", "medium", 12));
  }

  if (scanType === "upi" && extracted.upiIds.length > 0 && /refund|receive|collect|request/i.test(input)) {
    signals.push(signal("upi-collect-language", "UPI collect/refund language can be abused", "financial", "high", 18));
  }

  if (input.length < 12) signals.push(signal("low-context", "Very little context available", "content", "info", 4));
  return dedupeSignals(signals);
}

export function scoreSignals(signals: DetectionSignal[], externalScore = 0): number {
  const raw = signals.reduce((sum, item) => sum + item.weight * severityRank[item.severity] * 0.22, 0);
  const categorySpread = new Set(signals.map((item) => item.category)).size;
  return clampScore(raw + externalScore + Math.max(0, categorySpread - 1) * 4);
}

export function buildScanResult(params: {
  type: ScanType;
  input: string;
  signals: DetectionSignal[];
  externalScore?: number;
  aiScore?: number;
  reputationScore?: number;
  userReportScore?: number;
  technicalScore?: number;
  explanation?: string;
  recommendedAction?: string;
  ocrText?: string;
  decodedQr?: string;
}): ScanResult {
  const heuristicScore = scoreSignals(params.signals, params.externalScore ?? 0);
  const aiScore = params.aiScore ?? Math.min(100, Math.max(heuristicScore - 8, heuristicScore + 6));
  const reputationScore = params.reputationScore ?? Math.min(100, Math.round((params.externalScore ?? 0) * 1.6));
  const userReports = params.userReportScore ?? 0;
  const technical = params.technicalScore ?? Math.min(100, params.signals.filter((item) => item.category === "technical").length * 18);
  const riskScore = clampScore(heuristicScore * 0.44 + aiScore * 0.24 + reputationScore * 0.14 + userReports * 0.1 + technical * 0.08);
  const riskLevel = getRiskLevel(riskScore);
  const confidence = clampScore(62 + Math.min(params.signals.length * 5, 25) + (params.input.length > 80 ? 8 : 0));

  return {
    type: params.type,
    inputPreview: redactSensitive(params.input),
    riskScore,
    riskLevel,
    confidence,
    explanation: params.explanation ?? defaultExplanation(riskLevel, params.signals),
    recommendedAction: params.recommendedAction ?? defaultAction(riskLevel),
    signals: dedupeSignals(params.signals).sort((a, b) => b.weight - a.weight),
    breakdown: {
      ai: clampScore(aiScore),
      reputation: clampScore(reputationScore),
      heuristics: clampScore(heuristicScore),
      userReports: clampScore(userReports),
      technical: clampScore(technical)
    },
    extracted: {
      ...extractIndicators(params.input),
      ocrText: params.ocrText,
      decodedQr: params.decodedQr
    },
    createdAt: new Date().toISOString()
  };
}

export function defaultExplanation(level: RiskLevel, signals: DetectionSignal[]): string {
  const topSignals = signals.slice(0, 3).map((item) => item.label.toLowerCase());
  if (topSignals.length === 0) {
    return "ScamShield AI did not find strong scam patterns. Still verify the sender and avoid sharing OTPs, passwords, UPI PINs, or identity documents.";
  }

  return `${level} result because the content shows ${topSignals.join(", ")}. Treat this as safety guidance, verify through official channels, and do not click links or share sensitive details.`;
}

export function defaultAction(level: RiskLevel): string {
  switch (level) {
    case "Dangerous":
      return "Do not proceed. Block/report the sender, avoid payment, and contact the official organization directly.";
    case "High Risk":
      return "Pause and verify independently. Do not share OTP, UPI PIN, passwords, or documents.";
    case "Suspicious":
      return "Check the sender, domain, and request details before taking action.";
    case "Low Risk":
      return "Proceed only after basic verification and avoid sharing sensitive information.";
    case "Safe":
      return "No strong scam signs were found, but continue using normal caution.";
  }
}

export function signal(
  id: string,
  label: string,
  category: DetectionSignalCategory,
  severity: DetectionSignal["severity"],
  weight: number,
  evidence?: string
): DetectionSignal {
  return { id, label, category, severity, weight, evidence };
}

export function unique<T>(items: T[]): T[] {
  return Array.from(new Set(items));
}

export function dedupeSignals(signals: DetectionSignal[]): DetectionSignal[] {
  const seen = new Map<string, DetectionSignal>();
  for (const item of signals) {
    const existing = seen.get(item.id);
    if (!existing || existing.weight < item.weight) seen.set(item.id, item);
  }
  return Array.from(seen.values());
}

function isLikelyOfficialDomain(hostname: string): boolean {
  const official = [
    "paytm.com",
    "phonepe.com",
    "google.com",
    "googlepay.com",
    "sbi.co.in",
    "hdfcbank.com",
    "icicibank.com",
    "axisbank.com",
    "amazon.in",
    "amazon.com",
    "flipkart.com",
    "whatsapp.com",
    "telegram.org"
  ];

  return official.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
}
