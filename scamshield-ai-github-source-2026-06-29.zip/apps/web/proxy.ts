import { NextResponse, type NextRequest } from "next/server";

type Bucket = {
  count: number;
  resetAt: number;
};

const buckets = new Map<string, Bucket>();
const windowMs = 60_000;

const limits = [
  { pattern: /^\/api\/v1\/deep-scan/, max: 12 },
  { pattern: /^\/api\/v1\/scan/, max: 45 },
  { pattern: /^\/api\/v1\/report/, max: 20 },
  { pattern: /^\/api\/v1\/admin/, max: 45 },
  { pattern: /^\/api\/v1\/integrations\/test/, max: 24 },
  { pattern: /^\/api\/security-lab\/terminal/, max: 24 },
  { pattern: /^\/api\/security-lab\/integrations\/run/, max: 24 },
  { pattern: /^\/api\/security-lab/, max: 72 },
  { pattern: /^\/api\//, max: 120 }
];

export function proxy(request: NextRequest) {
  const requestId = crypto.randomUUID();
  const pathname = request.nextUrl.pathname;
  const limit = limits.find((item) => item.pattern.test(pathname));

  if (limit) {
    const key = `${clientKey(request)}:${limit.pattern.source}`;
    const bucket = getBucket(key);
    bucket.count += 1;

    if (bucket.count > limit.max) {
      return NextResponse.json(
        {
          error: {
            message: "Too many requests. Please wait before running more scans.",
            requestId
          }
        },
        {
          status: 429,
          headers: securityResponseHeaders(requestId, bucket.resetAt, limit.max, bucket.count)
        }
      );
    }

    const response = NextResponse.next();
    setSecurityHeaders(response, requestId, bucket.resetAt, limit.max, bucket.count);
    return response;
  }

  const response = NextResponse.next();
  setSecurityHeaders(response, requestId);
  return response;
}

export const config = {
  matcher: ["/api/:path*"]
};

function getBucket(key: string) {
  const now = Date.now();
  const existing = buckets.get(key);
  if (existing && existing.resetAt > now) return existing;

  const next = {
    count: 0,
    resetAt: now + windowMs
  };
  buckets.set(key, next);

  if (buckets.size > 800) {
    for (const [bucketKey, bucket] of buckets.entries()) {
      if (bucket.resetAt <= now) buckets.delete(bucketKey);
    }
  }

  return next;
}

function clientKey(request: NextRequest) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const realIp = request.headers.get("x-real-ip")?.trim();
  const session = request.cookies.get("scamshield_guest")?.value;
  return forwarded || realIp || session || "local";
}

function setSecurityHeaders(response: NextResponse, requestId: string, resetAt?: number, limit?: number, used?: number) {
  response.headers.set("X-ScamShield-Request-ID", requestId);
  applyBaselineSecurityHeaders(response.headers);
  if (resetAt && limit && used) {
    response.headers.set("RateLimit-Limit", String(limit));
    response.headers.set("RateLimit-Remaining", String(Math.max(0, limit - used)));
    response.headers.set("RateLimit-Reset", String(Math.ceil(resetAt / 1000)));
  }
}

function securityResponseHeaders(requestId: string, resetAt: number, limit: number, used: number) {
  const headers = new Headers();
  headers.set("X-ScamShield-Request-ID", requestId);
  applyBaselineSecurityHeaders(headers);
  headers.set("RateLimit-Limit", String(limit));
  headers.set("RateLimit-Remaining", String(Math.max(0, limit - used)));
  headers.set("RateLimit-Reset", String(Math.ceil(resetAt / 1000)));
  return headers;
}

function applyBaselineSecurityHeaders(headers: Headers) {
  headers.set("Cache-Control", "no-store");
  headers.set("X-Robots-Tag", "noindex, nofollow");
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("X-Frame-Options", "DENY");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=()");
  headers.set("Cross-Origin-Resource-Policy", "same-origin");
  headers.set("Cross-Origin-Opener-Policy", "same-origin");
  headers.set("X-Permitted-Cross-Domain-Policies", "none");
}
