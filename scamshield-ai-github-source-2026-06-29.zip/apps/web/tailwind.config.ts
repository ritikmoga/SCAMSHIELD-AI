import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
    "../../packages/shared/src/**/*.{ts,tsx}"
  ],
  theme: {
    container: {
      center: true,
      padding: "1rem",
      screens: {
        "2xl": "1280px"
      }
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))"
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))"
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))"
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))"
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))"
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))"
        },
        cyber: {
          green: "#67e8f9",
          red: "#ff315a",
          yellow: "#fbbf24",
          cyan: "#22d3ee",
          ink: "#010405",
          panel: "#060b0f"
        },
        void: "#05030A",
        abyss: "#090616",
        domain: "#0E0B1F",
        cursed: "#8B5CF6",
        energy: "#38BDF8",
        danger: "#F43F5E",
        safe: "#34D399",
        warning: "#F59E0B"
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)"
      },
      boxShadow: {
        glow: "0 0 36px rgba(34, 211, 238, 0.18)",
        cursed: "0 0 35px rgba(139, 92, 246, 0.45)",
        energy: "0 0 35px rgba(56, 189, 248, 0.35)",
        danger: "0 0 35px rgba(244, 63, 94, 0.35)"
      },
      keyframes: {
        scan: {
          "0%": { transform: "translateY(-100%)", opacity: "0" },
          "15%": { opacity: "1" },
          "85%": { opacity: "1" },
          "100%": { transform: "translateY(520%)", opacity: "0" }
        },
        pulseRing: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(34, 211, 238, 0.35)" },
          "50%": { boxShadow: "0 0 0 10px rgba(34, 211, 238, 0)" }
        },
        aura: {
          "0%, 100%": { opacity: "0.55", transform: "scale(1)" },
          "50%": { opacity: "1", transform: "scale(1.04)" }
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-16px)" }
        },
        portal: {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" }
        }
      },
      animation: {
        scan: "scan 3.4s ease-in-out infinite",
        pulseRing: "pulseRing 2.5s ease-in-out infinite",
        aura: "aura 4s ease-in-out infinite",
        float: "float 6s ease-in-out infinite",
        spinSlow: "spin 12s linear infinite",
        portal: "portal 8s linear infinite"
      }
    }
  },
  plugins: []
};

export default config;
