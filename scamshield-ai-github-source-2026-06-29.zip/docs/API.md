# ScamShield AI API

Base URL: `/api/v1`

## Security

Fetch a CSRF token before state-changing requests:

```http
GET /api/v1/security/csrf-token
```

Send it as `X-CSRF-Token`. Auth tokens are issued as HttpOnly cookies.

## Auth

```http
POST /auth/register
POST /auth/login
POST /auth/refresh
POST /auth/logout
GET  /auth/me
POST /auth/password-reset
```

## Scans

```http
POST /scan/url
POST /scan/message
POST /scan/email
POST /scan/upi
POST /scan/qr
POST /scan/phone
POST /scan/job
POST /scan/shopping
POST /scan/social
POST /scan/screenshot/image
GET  /scan/history/me
```

JSON scan body:

```json
{
  "input": "https://sbi-kyc-secure-login.example.com/verify",
  "locale": "en",
  "retainContent": false
}
```

Screenshot scan uses multipart form field `screenshot`.

For local frontend-only testing, the Next.js same-origin route `/api/scan/:type`
uses `services/python-scanner/scamshield_scanner.py` first. URL results include
an `analysis.url` object with parsed domain, path, keyword, DNS, TLS, and HTTP
metadata when network checks are enabled.

## Reports

```http
POST  /reports
GET   /reports
PATCH /reports/:id/moderate
```

## Intelligence

```http
GET  /database?q=kyc&type=url
GET  /alerts
POST /alerts
GET  /education
GET  /admin/overview
```

Admin routes require `moderator` or `super_admin`.

## Security Lab

Local Next.js endpoints:

```http
POST /api/security-lab/link
POST /api/security-lab/dns
POST /api/security-lab/tls
POST /api/security-lab/headers
POST /api/security-lab/osint
POST /api/security-lab/ports
POST /api/security-lab/exposure
POST /api/security-lab/file
GET  /api/security-lab/integrations
POST /api/security-lab/integrations/run
```

JSON scans accept `target`. Active scans also require `authorized: true`.
File scans use multipart field `file`. Private, loopback, link-local, local,
and internal targets are blocked by default. `VIRUSTOTAL_API_KEY` enables
optional file hash and URL reputation lookups.

Integration runs accept:

```json
{
  "toolId": "virustotal",
  "target": "https://example.com/login",
  "authorized": false
}
```

API-key providers return `not_configured` until their environment variables are
set. Active/local tools remain `disabled` unless `SCAMSHIELD_ENABLE_ACTIVE_TOOLS`
is set to `1`; they still require an authorization confirmation.
