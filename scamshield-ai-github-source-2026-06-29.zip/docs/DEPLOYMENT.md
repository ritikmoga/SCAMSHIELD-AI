# Deployment Guide

## Frontend on Vercel

1. Create a Vercel project pointing to `apps/web`.
2. Set build command:
   ```bash
   npm run build -w scamshield-web
   ```
3. Set output to Next.js default.
4. Add environment variable:
   ```text
   NEXT_PUBLIC_API_URL=https://your-api.example.com/api/v1
   ```

## Backend on Railway or Render

1. Create a Node service pointing to `apps/api`.
2. Install command:
   ```bash
   npm install
   ```
3. Build command:
   ```bash
   npm run build -w scamshield-api
   ```
4. Start command:
   ```bash
   npm run start -w scamshield-api
   ```
5. Add all variables from `apps/api/.env.example`.

## MongoDB Atlas

1. Create a dedicated database user with least-privilege access.
2. Enable IP allowlisting for your backend host.
3. Use TLS connection strings.
4. Enable backups and alerts.

## Cloudflare

1. Proxy frontend and API domains.
2. Enable WAF managed rules.
3. Add rate-limit rules for auth and scan endpoints.
4. Enable bot fight mode or Turnstile for suspicious activity.
5. Enforce HTTPS and HSTS after verifying certificates.

## Production Checklist

- Rotate all default secrets.
- Set `NODE_ENV=production`.
- Configure `WEB_ORIGIN` to the exact frontend origin.
- Enable MongoDB backups.
- Add Safe Browsing/VirusTotal/IPQualityScore keys after privacy review.
- Enable dependency scanning and scheduled security updates.
- Run penetration testing against staging before launch.
