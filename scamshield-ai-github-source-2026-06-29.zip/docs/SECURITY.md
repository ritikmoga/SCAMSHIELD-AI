# Security Architecture

ScamShield AI is designed as a highly secure, enterprise-grade cybersecurity application. It never describes itself as unhackable.

## Authentication

- Argon2id password hashing
- Short-lived JWT access tokens
- Refresh token rotation with reuse detection
- HttpOnly, Secure, SameSite cookies
- MFA-ready user schema
- Failed login tracking and temporary lockout

## Application Security

- Zod request validation
- HTML sanitization
- NoSQL sanitization
- HPP protection
- CSRF protection for state-changing routes
- Strict CORS configuration
- Helmet secure headers
- HSTS in production
- Centralized safe error responses

## Data Security

- Input hashes for matching
- Encrypted sensitive fields
- Optional raw content retention only for authenticated users
- Redacted previews
- Privacy-first default retention
- API secret isolation through environment variables

## Abuse Protection

- Global, auth, and scan-specific rate limits
- Guest scan limits
- Suspicious scan usage logging
- Audit logs for admin activity
- CAPTCHA and bot detection are planned extension points

## File Upload Security

- Screenshot uploads limited to PNG, JPG, and WebP
- 5MB maximum upload size
- Memory storage before OCR processing
- Malware scanning hook planned before persistent storage

## Infrastructure

Production deployments should use:

- Cloudflare proxy, WAF, bot protection, and DDoS controls
- HTTPS only
- MongoDB Atlas IP allowlisting
- Least-privilege database user
- Separate staging and production projects
- Secrets managed by Vercel/Railway/Render
- Dependency scanning in CI

## OWASP Checklist

- Broken access control: role middleware and admin-only routes
- Cryptographic failures: encrypted fields and secure cookies
- Injection: validation and NoSQL sanitization
- Insecure design: threat-modelled scan and report flows
- Security misconfiguration: secure headers and environment templates
- Vulnerable components: `npm audit`/Dependabot recommended
- Identification failures: lockout, rotation, MFA-ready schema
- Integrity failures: audit logs and immutable report review trail
- Logging failures: structured logs and API usage records
- SSRF: external API calls are constrained to known providers
