#!/usr/bin/env python3
"""ScamShield AI Python scanner.

This module is based on the user's "ScamShield Python Scanner Tool" PDF and
extends it into a JSON scanner that the Next.js API route can call safely.
It performs defensive analysis only; it never opens a URL in a browser.
"""

from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import mimetypes
import os
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


ENGINE = "python-scamshield-v1"

SUSPICIOUS_WORDS = [
    "verify",
    "login",
    "password",
    "otp",
    "bank",
    "urgent",
    "free",
    "gift",
    "winner",
    "claim",
    "limited",
    "blocked",
    "suspended",
    "kyc",
    "wallet",
    "crypto",
    "refund",
    "bonus",
    "airdrop",
    "support",
]

SHORTENERS = {
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "goo.gl",
    "is.gd",
    "buff.ly",
    "cutt.ly",
    "shorturl.at",
    "rebrand.ly",
    "lnkd.in",
    "ow.ly",
    "s.id",
}

DANGEROUS_EXTENSIONS = {
    ".exe",
    ".bat",
    ".cmd",
    ".scr",
    ".js",
    ".vbs",
    ".jar",
    ".msi",
    ".apk",
    ".com",
    ".ps1",
}

BRAND_DOMAINS = {
    "paytm": {"paytm.com", "paytmbank.com"},
    "phonepe": {"phonepe.com"},
    "gpay": {"google.com", "google.co.in"},
    "googlepay": {"google.com", "google.co.in"},
    "sbi": {"sbi.co.in", "onlinesbi.sbi"},
    "hdfc": {"hdfcbank.com"},
    "icici": {"icicibank.com"},
    "axis": {"axisbank.com"},
    "amazon": {"amazon.in", "amazon.com"},
    "flipkart": {"flipkart.com"},
    "whatsapp": {"whatsapp.com"},
    "telegram": {"telegram.org"},
}

INDIA_SECOND_LEVEL_TLDS = {"co", "com", "net", "org", "gov", "ac"}


@dataclass
class Signal:
    id: str
    label: str
    category: str
    severity: str
    weight: int
    evidence: str | None = None

    def as_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.id,
            "label": self.label,
            "category": self.category,
            "severity": self.severity,
            "weight": self.weight,
        }
        if self.evidence:
            payload["evidence"] = self.evidence[:180]
        return payload


def clamp(value: float) -> int:
    return max(0, min(100, round(value)))


def risk_level(score: int) -> str:
    if score >= 80:
        return "Dangerous"
    if score >= 60:
        return "High Risk"
    if score >= 40:
        return "Suspicious"
    if score >= 20:
        return "Low Risk"
    return "Safe"


def redact(value: str) -> str:
    value = re.sub(r"\b\d{6}\b", "[OTP]", value)
    value = re.sub(r"\b\d{12,19}\b", "[NUMBER]", value)
    value = re.sub(
        r"([a-z0-9._%+-])[a-z0-9._%+-]*(@[a-z0-9.-]+\.[a-z]{2,})",
        r"\1***\2",
        value,
        flags=re.IGNORECASE,
    )
    return value[:280]


def normalize_url(raw_url: str) -> str:
    value = raw_url.strip().strip("\"'")
    if re.match(r"^[a-z][a-z0-9+.-]*://", value, flags=re.IGNORECASE):
        return value
    return f"https://{value}"


def registered_domain(hostname: str) -> str:
    labels = [part for part in hostname.lower().strip(".").split(".") if part]
    if len(labels) < 2:
        return hostname.lower()
    if labels[-1] == "in" and len(labels) >= 3 and labels[-2] in INDIA_SECOND_LEVEL_TLDS:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def is_official_brand_domain(brand: str, hostname: str) -> bool:
    official_domains = BRAND_DOMAINS.get(brand, set())
    return any(hostname == domain or hostname.endswith(f".{domain}") for domain in official_domains)


def extract_indicators(text: str) -> dict[str, list[str]]:
    urls = []
    for match in re.findall(r"\bhttps?://[^\s<>\"')]+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/[^\s<>\"')]+)?", text, re.I):
        urls.append(normalize_url(match).rstrip("),.;"))

    return {
        "urls": sorted(set(urls)),
        "phoneNumbers": sorted(set(re.findall(r"(?:\+?91[\s-]?)?[6-9]\d{9}\b", text))),
        "upiIds": sorted(set(re.findall(r"\b[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}\b", text))),
        "emails": sorted(set(re.findall(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", text, re.I))),
    }


def signal_score(signals: list[Signal]) -> int:
    severity_factor = {
        "info": 0.25,
        "low": 0.45,
        "medium": 0.75,
        "high": 1.0,
        "critical": 1.2,
    }
    raw = sum(item.weight * severity_factor.get(item.severity, 0.75) for item in signals)
    category_bonus = max(0, len({item.category for item in signals}) - 1) * 3
    return clamp(raw + category_bonus)


def is_ip_address(hostname: str) -> bool:
    try:
        ipaddress.ip_address(hostname.strip("[]"))
        return True
    except ValueError:
        return False


def is_private_hostname(hostname: str) -> bool:
    if hostname in {"localhost", "localhost.localdomain"}:
        return True
    try:
        address = ipaddress.ip_address(hostname.strip("[]"))
    except ValueError:
        return False
    return address.is_private or address.is_loopback or address.is_link_local or address.is_reserved


class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        return None


def network_probe(parsed: urllib.parse.ParseResult, signals: list[Signal]) -> dict[str, Any]:
    host = parsed.hostname or ""
    details: dict[str, Any] = {
        "enabled": True,
        "dnsResolved": False,
        "httpChecked": False,
        "tlsChecked": False,
    }
    if not host or is_private_hostname(host):
        details["skippedReason"] = "Private, local, or invalid host"
        signals.append(
            Signal(
                "network-private-host",
                "Network probe skipped for private/local host",
                "technical",
                "medium",
                10,
                host,
            )
        )
        return details

    previous_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(3)
    try:
        try:
            addresses = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
            ips = sorted({item[4][0] for item in addresses})
            details["dnsResolved"] = True
            details["resolvedIpCount"] = len(ips)
            details["resolvedIpsPreview"] = ips[:3]
        except OSError as exc:
            details["dnsError"] = str(exc)
            signals.append(Signal("dns-unresolved", "Domain did not resolve in DNS", "reputation", "high", 20, str(exc)))

        if parsed.scheme == "https":
            tls_details = tls_probe(host, parsed.port or 443)
            details["tlsChecked"] = True
            details["tls"] = tls_details
            expires_in = tls_details.get("expiresInDays")
            if isinstance(expires_in, int) and expires_in < 14:
                signals.append(
                    Signal("tls-expiring", "TLS certificate expires soon", "technical", "medium", 10, f"{expires_in} days")
                )
            if tls_details.get("error"):
                signals.append(Signal("tls-error", "TLS certificate check failed", "technical", "medium", 12, str(tls_details["error"])))

        if parsed.scheme in {"http", "https"}:
            http_details = http_head_probe(parsed)
            details["httpChecked"] = True
            details["http"] = http_details
            status = http_details.get("status")
            if isinstance(status, int) and status in {301, 302, 303, 307, 308}:
                signals.append(
                    Signal("http-redirect", "URL returns a redirect response", "technical", "medium", 10, str(status))
                )
            if http_details.get("error"):
                details["httpError"] = http_details["error"]
    finally:
        socket.setdefaulttimeout(previous_timeout)

    return details


def tls_probe(host: str, port: int) -> dict[str, Any]:
    started = time.time()
    try:
        context = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=3) as sock:
            with context.wrap_socket(sock, server_hostname=host) as secure_sock:
                cert = secure_sock.getpeercert()
                not_after = cert.get("notAfter")
                expires_in = None
                if not_after:
                    expires_at = ssl.cert_time_to_seconds(not_after)
                    expires_in = round((expires_at - time.time()) / 86400)
                issuer = cert.get("issuer", ())
                issuer_name = " ".join("=".join(part) for group in issuer for part in group)[:160]
                return {
                    "valid": True,
                    "issuer": issuer_name,
                    "expiresAt": not_after,
                    "expiresInDays": expires_in,
                    "elapsedMs": round((time.time() - started) * 1000),
                }
    except Exception as exc:  # noqa: BLE001 - scanner should return safe diagnostics.
        return {"valid": False, "error": str(exc)[:180], "elapsedMs": round((time.time() - started) * 1000)}


def http_head_probe(parsed: urllib.parse.ParseResult) -> dict[str, Any]:
    url = urllib.parse.urlunparse(parsed)
    opener = urllib.request.build_opener(NoRedirectHandler)
    request = urllib.request.Request(
        url,
        method="HEAD",
        headers={"User-Agent": "ScamShieldAI/1.0 defensive-url-scanner"},
    )
    started = time.time()
    try:
        with opener.open(request, timeout=3) as response:
            return {
                "status": response.status,
                "contentType": response.headers.get("content-type"),
                "server": response.headers.get("server"),
                "location": response.headers.get("location"),
                "elapsedMs": round((time.time() - started) * 1000),
            }
    except urllib.error.HTTPError as exc:
        return {
            "status": exc.code,
            "contentType": exc.headers.get("content-type"),
            "server": exc.headers.get("server"),
            "location": exc.headers.get("location"),
            "elapsedMs": round((time.time() - started) * 1000),
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:180], "elapsedMs": round((time.time() - started) * 1000)}


def scan_url(raw_url: str, allow_network: bool = True) -> dict[str, Any]:
    normalized = normalize_url(raw_url)
    signals: list[Signal] = []
    details: dict[str, Any] = {"normalizedUrl": normalized}

    try:
        parsed = urllib.parse.urlparse(normalized)
        hostname = (parsed.hostname or "").lower()
        path = parsed.path or "/"
        query = urllib.parse.parse_qs(parsed.query)
        path_extension = os.path.splitext(path.lower())[1]
        reg_domain = registered_domain(hostname)
        joined = f"{hostname}{path}?{parsed.query}".lower()

        details.update(
            {
                "scheme": parsed.scheme.upper() if parsed.scheme else "",
                "hostname": hostname,
                "registeredDomain": reg_domain,
                "port": parsed.port,
                "path": path,
                "queryParamCount": len(query),
                "fragmentPresent": bool(parsed.fragment),
                "subdomainDepth": max(0, len(hostname.split(".")) - len(reg_domain.split("."))),
                "domainHyphenCount": hostname.count("-"),
                "urlLength": len(normalized),
                "pathExtension": path_extension or None,
                "networkChecksEnabled": bool(allow_network),
            }
        )

        if parsed.scheme != "https":
            signals.append(Signal("url-http", "URL does not use HTTPS", "technical", "high", 18, parsed.scheme or "missing"))

        if hostname in SHORTENERS or any(hostname.endswith(f".{item}") for item in SHORTENERS):
            signals.append(Signal("url-shortener", "URL shortener hides the final destination", "technical", "medium", 16, hostname))

        if is_ip_address(hostname):
            signals.append(Signal("raw-ip", "Raw IP address used instead of a recognizable domain", "technical", "high", 22, hostname))

        if hostname.count("-") >= 2:
            signals.append(Signal("many-hyphens", "Domain contains many hyphens", "identity", "medium", 8, hostname))

        if len(normalized) > 120:
            signals.append(Signal("long-url", "URL is unusually long", "technical", "medium", 12, f"{len(normalized)} characters"))

        suspicious_keywords = sorted({word for word in SUSPICIOUS_WORDS if word in joined})
        details["suspiciousKeywords"] = suspicious_keywords
        if suspicious_keywords:
            signals.append(
                Signal(
                    "suspicious-url-words",
                    "URL contains suspicious action words",
                    "social-engineering",
                    "high",
                    min(24, 8 + len(suspicious_keywords) * 4),
                    ", ".join(suspicious_keywords),
                )
            )

        if path_extension in DANGEROUS_EXTENSIONS:
            signals.append(Signal("risky-file-extension", "URL points to a risky file type", "technical", "critical", 30, path_extension))

        if "@" in normalized or re.search(r"%[0-9a-f]{2}", normalized, re.I):
            signals.append(
                Signal("obfuscated-url", "URL contains encoded or obfuscated characters", "technical", "high", 18, normalized[:120])
            )

        if "xn--" in hostname:
            signals.append(Signal("punycode-domain", "Domain uses punycode characters", "identity", "high", 18, hostname))

        if re.search(r"(?:redirect|return|next|url|target)=", parsed.query, re.I):
            signals.append(Signal("redirect-parameter", "URL contains redirect-style parameters", "technical", "medium", 12, parsed.query[:120]))

        if re.search(r"[A-Za-z0-9_-]{32,}", path):
            signals.append(Signal("long-random-token", "Path contains a long token-like value", "technical", "medium", 10, path[:120]))

        impersonated_brands = [
            brand for brand in BRAND_DOMAINS if re.search(rf"(^|[^a-z0-9]){re.escape(brand)}([^a-z0-9]|$)", joined)
        ]
        details["brandKeywords"] = impersonated_brands
        suspicious_brands = [brand for brand in impersonated_brands if not is_official_brand_domain(brand, hostname)]
        if suspicious_brands:
            signals.append(
                Signal(
                    "possible-impersonation",
                    "Possible brand impersonation",
                    "identity",
                    "critical",
                    30,
                    f"{', '.join(suspicious_brands)} on {hostname}",
                )
            )

        if allow_network:
            details["network"] = network_probe(parsed, signals)
        else:
            details["network"] = {"enabled": False}

    except Exception as exc:  # noqa: BLE001
        signals.append(Signal("invalid-url", "Input is not a valid URL", "technical", "medium", 12, str(exc)))
        details["parseError"] = str(exc)

    score = signal_score(signals)
    return build_response(
        scan_type="url",
        input_value=raw_url,
        score=score,
        signals=signals,
        extracted=extract_indicators(raw_url),
        analysis={"engine": ENGINE, "source": "python", "url": details},
    )


def scan_text(text: str, scan_type: str = "message", allow_network: bool = False) -> dict[str, Any]:
    lowered = text.lower()
    signals: list[Signal] = []
    found_words = sorted({word for word in SUSPICIOUS_WORDS if word in lowered})

    if found_words:
        signals.append(
            Signal(
                "text-suspicious-words",
                "Suspicious scam words found",
                "content",
                "medium",
                min(28, 8 + len(found_words) * 3),
                ", ".join(found_words),
            )
        )

    text_checks: list[tuple[str, str, str, str, int]] = [
        (r"\b\d{6}\b|\botp\b|one[-\s]?time password|verification code", "Contains OTP or security-code language", "privacy", "critical", 26),
        (r"upi pin|pin share|collect request|refund.*upi", "Mentions UPI PIN or collect/refund flow", "financial", "critical", 28),
        (r"click here|act now|verify now|account suspended|account.*block|kyc.*expire", "Contains phishing-style urgency language", "urgency", "high", 22),
        (r"password|cvv|card number|aadhaar|pan card|date of birth", "Requests sensitive personal data", "privacy", "critical", 26),
        (r"apk|install.*app|remote access|anydesk|screen share|teamviewer", "Encourages risky app install or remote access", "technical", "critical", 30),
        (r"processing fee|security deposit|registration fee|work from home.*earn", "Job or earning offer asks for money first", "financial", "high", 22),
    ]
    for index, (pattern, label, category, severity, weight) in enumerate(text_checks):
        match = re.search(pattern, lowered, re.I)
        if match:
            signals.append(Signal(f"text-{index}", label, category, severity, weight, match.group(0)))

    extracted = extract_indicators(text)
    nested_url_details = []
    for url in extracted["urls"][:3]:
        nested = scan_url(url, allow_network=allow_network)
        nested_url_details.append(nested.get("analysis", {}).get("url", {}))
        for raw_signal in nested.get("signals", [])[:4]:
            signals.append(
                Signal(
                    f"embedded-{raw_signal['id']}",
                    f"Embedded URL: {raw_signal['label']}",
                    raw_signal["category"],
                    raw_signal["severity"],
                    min(int(raw_signal["weight"]), 16),
                    raw_signal.get("evidence"),
                )
            )

    if len(text.strip()) < 12:
        signals.append(Signal("low-context", "Very little context available", "content", "info", 4))

    details = {
        "characterCount": len(text),
        "urlCount": len(extracted["urls"]),
        "phoneNumberCount": len(extracted["phoneNumbers"]),
        "upiIdCount": len(extracted["upiIds"]),
        "emailCount": len(extracted["emails"]),
        "suspiciousKeywords": found_words,
        "embeddedUrlDetails": nested_url_details,
    }
    score = signal_score(signals)
    return build_response(
        scan_type=scan_type,
        input_value=text,
        score=score,
        signals=signals,
        extracted=extracted,
        analysis={"engine": ENGINE, "source": "python", "text": details},
    )


def scan_file(file_path: str) -> dict[str, Any]:
    signals: list[Signal] = []
    if not os.path.exists(file_path):
        return {"ok": False, "error": "File not found"}

    filename = os.path.basename(file_path)
    extension = os.path.splitext(filename)[1].lower()
    mime_type, _ = mimetypes.guess_type(file_path)
    size_bytes = os.path.getsize(file_path)
    file_hash = calculate_hash(file_path)

    if extension in DANGEROUS_EXTENSIONS:
        signals.append(Signal("file-risky-extension", "Risky file extension detected", "technical", "critical", 40, extension))
    if size_bytes > 50 * 1024 * 1024:
        signals.append(Signal("file-large", "File is very large", "technical", "low", 8, str(size_bytes)))

    details = {
        "fileName": filename,
        "extension": extension,
        "mimeType": mime_type,
        "sizeBytes": size_bytes,
        "sha256": file_hash,
    }
    score = signal_score(signals)
    return build_response(
        scan_type="screenshot",
        input_value=filename,
        score=score,
        signals=signals,
        extracted={"urls": [], "phoneNumbers": [], "upiIds": [], "emails": []},
        analysis={"engine": ENGINE, "source": "python", "file": details},
    )


def calculate_hash(file_path: str) -> str:
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def build_response(
    scan_type: str,
    input_value: str,
    score: int,
    signals: list[Signal],
    extracted: dict[str, list[str]],
    analysis: dict[str, Any],
) -> dict[str, Any]:
    level = risk_level(score)
    confidence = clamp(66 + min(len(signals) * 5, 24) + (8 if len(input_value) > 80 else 0))
    top = ", ".join(item.label.lower() for item in signals[:3])
    explanation = (
        f"Python scanner found {len(signals)} warning signal(s): {top}. "
        "Verify through official channels and do not share OTPs, passwords, UPI PINs, or payment details."
        if signals
        else "Python scanner did not find strong scam indicators. Still verify the sender, domain, and request before acting."
    )
    action = (
        "Do not click or pay. Block/report the sender and contact the official organization directly."
        if score >= 60
        else "Pause and verify independently before sharing any sensitive information."
        if score >= 40
        else "Proceed only after basic verification and avoid sharing sensitive information."
    )
    return {
        "ok": True,
        "engine": ENGINE,
        "type": scan_type,
        "inputPreview": redact(input_value),
        "riskScore": score,
        "riskLevel": level,
        "confidence": confidence,
        "explanation": explanation,
        "recommendedAction": action,
        "signals": [item.as_dict() for item in dedupe_signals(signals)],
        "breakdown": {
            "ai": clamp(score * 0.35),
            "reputation": clamp(sum(item.weight for item in signals if item.category == "reputation")),
            "heuristics": score,
            "userReports": 0,
            "technical": clamp(sum(item.weight for item in signals if item.category == "technical")),
        },
        "extracted": extracted,
        "analysis": analysis,
    }


def dedupe_signals(signals: list[Signal]) -> list[Signal]:
    seen: set[str] = set()
    deduped: list[Signal] = []
    for item in signals:
        key = f"{item.id}:{item.evidence or ''}"
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def scan_payload(payload: dict[str, Any]) -> dict[str, Any]:
    scan_type = str(payload.get("type") or "message").lower()
    input_value = str(payload.get("input") or "").strip()
    allow_network = bool(payload.get("allow_network", False))

    if not input_value:
        return {"ok": False, "error": "Scan input is required"}
    if len(input_value) > 15000:
        return {"ok": False, "error": "Scan input is too large"}

    if scan_type == "url":
        return scan_url(input_value, allow_network=allow_network)
    if scan_type == "file":
        return scan_file(input_value)
    return scan_text(input_value, scan_type=scan_type, allow_network=allow_network)


def main() -> int:
    parser = argparse.ArgumentParser(description="ScamShield AI defensive URL, message, email, UPI, and file scanner")
    parser.add_argument("--json", action="store_true", help="Read JSON payload from stdin and output JSON")
    parser.add_argument("--url", help="Scan a suspicious URL or link")
    parser.add_argument("--text", help="Scan email/message text")
    parser.add_argument("--file", help="Scan image, voicemail, document, or any file")
    parser.add_argument("--allow-network", action="store_true", help="Allow DNS, TLS, and HTTP HEAD metadata checks")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON")
    args = parser.parse_args()

    if args.json:
        payload = json.loads(sys.stdin.read() or "{}")
    elif args.url:
        payload = {"type": "url", "input": args.url, "allow_network": args.allow_network}
    elif args.text:
        payload = {"type": "message", "input": args.text, "allow_network": args.allow_network}
    elif args.file:
        payload = {"type": "file", "input": args.file}
    else:
        payload = {"type": "message", "input": ""}

    result = scan_payload(payload)
    print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
