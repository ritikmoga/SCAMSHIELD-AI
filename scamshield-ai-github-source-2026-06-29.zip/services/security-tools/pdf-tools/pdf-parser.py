#!/usr/bin/env python3
import hashlib
import json
import re
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: pdf-parser.py FILE", file=sys.stderr)
        return 2

    path = Path(sys.argv[-1])
    data = path.read_bytes()
    objects = []
    for match in re.finditer(rb"(\d+)\s+(\d+)\s+obj(.*?)endobj", data, re.S):
        body = match.group(3)
        object_id = int(match.group(1))
        generation = int(match.group(2))
        objects.append(
            {
                "object": object_id,
                "generation": generation,
                "offset": match.start(),
                "length": len(body),
                "hasStream": b"stream" in body,
                "hasJavaScript": b"/JS" in body or b"/JavaScript" in body,
                "hasLaunch": b"/Launch" in body,
                "hasEmbeddedFile": b"/EmbeddedFile" in body,
                "preview": body[:180].decode("latin-1", "replace").replace("\n", "\\n"),
            }
        )

    result = {
        "file": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "isPdf": data.startswith(b"%PDF"),
        "objectCount": len(objects),
        "suspiciousObjectCount": sum(
            1
            for item in objects
            if item["hasJavaScript"] or item["hasLaunch"] or item["hasEmbeddedFile"]
        ),
        "objects": objects[:60],
        "truncated": len(objects) > 60,
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
