#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

KEYWORDS = [
    b"/JS",
    b"/JavaScript",
    b"/AA",
    b"/OpenAction",
    b"/AcroForm",
    b"/JBIG2Decode",
    b"/RichMedia",
    b"/Launch",
    b"/EmbeddedFile",
    b"/XFA",
    b"/ObjStm",
]


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: pdfid.py FILE", file=sys.stderr)
        return 2

    path = Path(sys.argv[-1])
    data = path.read_bytes()
    result = {
        "file": str(path),
        "isPdf": data.startswith(b"%PDF"),
        "size": len(data),
        "version": None,
        "objectCount": len(re.findall(rb"\b\d+\s+\d+\s+obj\b", data)),
        "streamCount": len(re.findall(rb"\bstream\b", data)),
        "endstreamCount": len(re.findall(rb"\bendstream\b", data)),
        "xrefCount": len(re.findall(rb"\bxref\b", data)),
        "trailerCount": len(re.findall(rb"\btrailer\b", data)),
        "keywords": {},
        "riskSignals": [],
    }

    match = re.match(rb"%PDF-(\d\.\d)", data[:16])
    if match:
        result["version"] = match.group(1).decode("ascii", "replace")

    for keyword in KEYWORDS:
        count = data.count(keyword)
        result["keywords"][keyword.decode("ascii")] = count
        if count:
            result["riskSignals"].append(f"{keyword.decode('ascii')} present {count} time(s)")

    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
