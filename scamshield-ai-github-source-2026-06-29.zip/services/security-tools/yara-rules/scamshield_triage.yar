rule ScamShield_EICAR_Test_File
{
  meta:
    description = "Detects the standard EICAR antivirus test string"
    severity = "high"
  strings:
    $eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR" ascii
  condition:
    $eicar
}

rule ScamShield_PDF_Embedded_JavaScript
{
  meta:
    description = "Flags PDFs containing embedded JavaScript markers"
    severity = "medium"
  strings:
    $pdf = "%PDF"
    $js1 = "/JavaScript" nocase
    $js2 = "/JS" ascii
  condition:
    $pdf at 0 and any of ($js*)
}

rule ScamShield_UPX_Packed_PE
{
  meta:
    description = "Flags Windows PE files with UPX section markers"
    severity = "medium"
  strings:
    $mz = { 4D 5A }
    $upx0 = "UPX0" ascii
    $upx1 = "UPX1" ascii
  condition:
    $mz at 0 and any of ($upx*)
}
